# Leaply — Identitate vizuală 2026 (brief intern, sursa unică de adevăr)

## Concept
„Prinde fiecare lead." Viteză + încredere calmă. Modern-minimalist, cald, premium dar accesibil pentru antreprenori români (termopane, imobiliare, clinici, dealeri auto). NU corporate rece, NU startup-generic violet.

## Paletă (definite ca CSS variables în app/globals.css — folosește DOAR variabilele)
- `--ink: #101214` — text principal, suprafețe dark
- `--ink-2: #3A3D42` — text secundar pe dark/light
- `--paper: #F7F5F1` — fundal cald (off-white)
- `--card: #FFFFFF` — carduri
- `--line: #E8E3DA` — borduri hairline (1px)
- `--accent: #FF4D1F` — portocaliu electric (viteză/energie). Folosit chirurgical: CTA-uri, cifre cheie, logo. Max ~10% din suprafață.
- `--accent-deep: #E23A0E` — hover CTA
- `--accent-soft: #FFE9E1` — fundal chip/eyebrow
- `--muted: #6E6A62` — text terțiar
- `--ok: #17945B`, `--warn: #B7791F`, `--bad: #C43D3D`
- Dark sections/sidebar: fundal `--ink`, text `#F2F0EA`, accente `--accent`

## Tipografie (setată de mine în app/layout.tsx via next/font — NU adăuga alte fonturi)
- Display: **Bricolage Grotesque** → var `--font-display` (headline-uri, cifre mari, logo wordmark). Tracking strâns (-0.02em), leading 1.05–1.1.
- Text/UI: **Inter** → var `--font-text`. Body 15–16px, line-height 1.6.

## Limbaj vizual
- Spațiu generos. Secțiuni landing: padding vertical 96–128px desktop.
- Carduri: radius 20px, border 1px var(--line), fundal var(--card), umbră DOAR la hover (`0 12px 32px rgba(16,18,20,.08)` + translateY(-2px), tranziție 0.2s). Bento grids.
- Butoane: radius 12px; primar = accent bg + alb; secundar = transparent + border line + ink; pe dark = alb bg + ink text. Padding 12px 22px, font-weight 600.
- Hairlines peste tot, fără umbre permanente. Fără gradienturi țipătoare — permis: un glow radial subtil orange în hero dark.
- Emoji-urile din UI-ul vechi se ÎNLOCUIESC cu pictograme SVG inline minimaliste (stroke 1.75, currentColor, 20×20).
- Ghilimele românești corecte: „text”. Diacritice peste tot.
- Micro-interacțiuni: hover pe carduri/linkuri, focus-visible cu outline accent 2px.
- Responsive obligatoriu: breakpoints 960px și 640px; nav mobil simplu (fără JS complex).

## Logo (definit de mine în lib/logo.tsx — importă-l, nu-l reinventa)
Marcă: pătrat rotunjit (radius ~28%) fundal --accent cu fulger alb minimal + wordmark „leaply" lowercase în font display, ink. Pe dark: wordmark alb.

## Voce
Direct, concret, fără corporatisme. Cifre reale, beneficii palpabile. Ton: „un coleg care îți aduce clienți", nu „soluție inovatoare de automatizare".

## Reguli tehnice
- CSS: fără Tailwind, fără librării noi. Fiecare agent scrie DOAR în fișierul lui CSS. Clase prefixate: landing `lp-*`, app `ap-*`. Componentele shared (.btn, .badge, .panel, .fld, .txt, .bubble, .pill) sunt în globals.css — folosește-le, nu le redefini.
- Server components implicit; 'use client' doar unde e nevoie de interactivitate.
- Nu atinge: lib/db.ts, lib/store.ts, lib/webhook.ts, lib/brain.ts, app/api/*, middleware.ts, Dockerfile, next.config.js, package.json.
