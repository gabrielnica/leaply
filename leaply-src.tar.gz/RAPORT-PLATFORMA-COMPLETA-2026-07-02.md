# Leaply — Raport platformă completă · 2 iulie 2026

## Ce s-a construit în această rundă (live pe leaply.ro)

1. **Conectare Meta „cu un click"** — exact ce ai cerut: clientul apasă „Conectează cu Facebook", alege pagina în popup-ul Meta, iar Leaply primește automat tokenul, conectează Messenger + Instagram DM (dacă pagina are cont IG legat) și abonează webhook-urile. Zero câmpuri tehnice. Formularul manual (Page ID + token) a rămas ca opțiune „avansat".
2. **Limite de utilizare pe planuri** — Trial 30 / Start 300 / Pro 1.000 / Scale 3.000 conversații/lună. Peste limită: lead-urile INTRĂ în inbox (nu pierzi nimic), dar asistentul nu mai răspunde automat; owner-ul primește email o dată pe lună cu îndemn de upgrade; bară de utilizare în Setări & Plan.
3. **Admin complet**: utilizatori înregistrați (cine plătește, cine nu, MRR), cereri demo, **Setări platformă** (toate cheile API: LLM, Resend, Google, Stripe, Meta — editabile din UI, aplicate instant).

## Răspunsuri la întrebările tale

**„Nu se face prin OAuth?"** — Ba da, acum se face. Detaliul important: fluxul OAuth funcționează imediat pentru tine și pentru orice utilizator adăugat ca „tester" pe aplicația ta Meta (Development Mode). Pentru public (orice client, fără să-l adaugi tu manual) e nevoie de Meta App Review — 1-5 zile lucrătoare + Business Verification. Codul e identic în ambele cazuri; review-ul e doar o aprobare administrativă.

**„E funcțională integrarea cu o pagină?"** — Codul e complet și testat (schimb de token, long-lived, listare pagini, abonare webhooks, trimitere prin Send API). Se activează în momentul în care completezi META_APP_ID + META_APP_SECRET în Admin → Setări platformă (aplicație Meta creată de tine, ~15 minute).

## Analiza de costuri (prețuri verificate, iulie 2026)

| Serviciu | Preț |
|---|---|
| gpt-4o-mini | $0,15/M input · $0,60/M output → **~€0,002/conversație** (15 mesaje) |
| WhatsApp Meta direct, fereastra service 24h | **Gratuit** (+FEP 72h gratuit din reclame click-to-WhatsApp) |
| Template utility RO (în afara ferestrei 24h) | ~$0,03/mesaj (scumpit la 1 iul. 2026) |
| Twilio WhatsApp | +$0,005/mesaj trimis ȘI primit + ~$1,15/lună numărul |
| Resend | gratuit 3.000 emailuri/lună |

**Marje pe planurile actuale (LLM + WhatsApp):**

| Plan | Cu Meta direct | Cu Twilio |
|---|---|---|
| Start 59€ / 300 conv | ~99% marjă | ~61% |
| Pro 129€ / 1.000 | ~99% | ~44% |
| Scale 299€ / 3.000 | ~98% | ~28% |

**Concluzii:** (1) Planurile actuale sunt OK — cu Meta direct, costurile variabile sunt neglijabile; te încadrezi practic la orice volum realist. (2) Twilio e doar plan B pentru viteză — la scală îți mănâncă marja; țintește Meta direct. (3) Nu ai costuri SMS (produsul nu trimite SMS). (4) Riscul de cost real e doar dacă vei trimite template-uri în afara ferestrei de 24h (follow-up-uri) — de tarifat separat când adaugi feature-ul. (5) Ce se întâmplă la limite: implementat — AI-ul se oprește elegant, lead-urile se păstrează, clientul primește prompt de upgrade. LLM-ul devine semnificativ abia la zeci de mii de conversații/lună per client.

## Audit — starea actuală a platformei

**Funcțional end-to-end, fără intervenție:** landing → cerere demo → wizard → cont → dashboard multi-tenant → config AI → demo pe config propriu → inbox cu conversații continue → takeover → limite plan → notificări (log până la cheia Resend) → webhook-out CRM → admin complet.

**Funcțional imediat ce introduci o cheie (Admin → Setări platformă):**
- LLM real: OPENAI_API_KEY (recomandat gpt-4o-mini)
- Emailuri: RESEND_API_KEY (domeniu verificat în Resend)
- Conectare Facebook un-click: META_APP_ID + META_APP_SECRET
- Google Calendar: GOOGLE_CLIENT_ID + SECRET (redirect: https://leaply.ro/api/integrations/google/callback)
- Plăți: STRIPE_SECRET_KEY + WEBHOOK_SECRET + 3 price ID-uri
- WhatsApp per client: credențiale în pagina Canale (Meta Cloud sau Twilio)

## Pașii TĂI (în ordinea impactului)

1. **Aplicație Meta** (developers.facebook.com, ~15 min): creează app business, adaugă produsele Facebook Login + Messenger + WhatsApp + Webhooks; copiază App ID + App Secret în Admin → Setări. Setează webhook-urile către https://leaply.ro/api/webhooks/meta (+ /messenger, /instagram, /whatsapp) cu verify token-ul din Setări. Testează conectarea un-click cu pagina ta.
2. **Cheie OpenAI** (~5 min) → LLM real pe toate conversațiile.
3. **Resend** (~15 min, verifici domeniul leaply.ro) → resetări de parolă + notificări reale.
4. **Pornește Business Verification + App Review la Meta** (pages_messaging, instagram_manage_messages; ulterior WhatsApp Embedded Signup ca Tech Provider) — durează, e pe drumul critic pentru clienți publici. Până se aprobă: clienții pilot se adaugă ca testeri pe aplicația ta (funcționează integral).
5. **Google Cloud OAuth** (~20 min) → Calendar live. **Stripe** (~30 min) → plăți self-service. Ambele pot aștepta primul client.
6. Vinde. Demo-ul live + wizard-ul sunt gata de arătat oricui.

## Idei suplimentare (backlog recomandat, în ordine)

- Follow-up automat la lead-urile fără răspuns (template WhatsApp după 24h) — feature cu impact direct pe „lead-uri salvate"; atenție la costul template-urilor.
- Widget de chat embeddable pentru site-urile clienților (o linie de script) — canalul „webform" există deja în backend.
- Răspuns manual din inbox (owner-ul scrie din Leaply după takeover, mesajul pleacă pe canal) — trimiterea există, lipsește doar UI-ul.
- Rezumat săptămânal pe email către owner („săptămâna asta: X lead-uri, Y programări, Z lei salvați").
- e-Factura ANAF la facturare (după primii clienți Stripe).
- Backup automat al SQLite (cron în Coolify → volum secundar).
