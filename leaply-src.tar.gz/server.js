// Server custom: Next.js + WebSocket pentru agentul vocal (Twilio Media Streams).
// Producția rulează `node server.js` (vezi package.json / Dockerfile).
const { createServer } = require('http');
const next = require('next');
const { WebSocketServer } = require('ws');
const { attachVoiceBridge } = require('./voice-bridge');

const port = Number(process.env.PORT) || 3000;
const app = next({ dev: false });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const server = createServer((req, res) => handle(req, res));
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (req, socket, head) => {
    if (req.url && req.url.startsWith('/api/voice-stream')) {
      wss.handleUpgrade(req, socket, head, ws => attachVoiceBridge(ws));
    } else {
      socket.destroy();
    }
  });

  server.listen(port, () => console.log(`[leaply] server + voice-stream pe :${port}`));
});
