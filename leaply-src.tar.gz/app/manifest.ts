import type { MetadataRoute } from 'next';

// PWA: „Adaugă pe ecranul principal" → /app se deschide ca aplicație (standalone).
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Leaply — asistent AI pentru lead-uri',
    short_name: 'Leaply',
    description: 'Inbox-ul tău Leaply: lead-uri, conversații, programări. Răspuns automat în sub 60 de secunde.',
    start_url: '/app',
    display: 'standalone',
    background_color: '#F7F5F1',
    theme_color: '#101214',
    icons: [
      { src: '/icon-1024.png', sizes: '1024x1024', type: 'image/png', purpose: 'any' },
      { src: '/icon-1024.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };
}
