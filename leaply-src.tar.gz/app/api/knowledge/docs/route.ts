import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { listDocs, addDoc, deleteDoc } from '../../../../lib/docs';
export const dynamic = 'force-dynamic';

const MAX_DOCS = 10;
const MAX_SIZE = 5 * 1024 * 1024; // 5 MB per fișier

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  return NextResponse.json({ docs: listDocs(user.account_id) });
}

// Upload: multipart (file) sau JSON {name, content}. Acceptă .txt .csv .md .pdf
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  if (listDocs(user.account_id).length >= MAX_DOCS) {
    return NextResponse.json({ error: `Maxim ${MAX_DOCS} documente. Șterge unul ca să adaugi altul.` }, { status: 400 });
  }
  let name = '', content = '';
  const ctype = req.headers.get('content-type') || '';
  if (ctype.includes('multipart/form-data')) {
    const form = await req.formData().catch(() => null);
    const f = form?.get('file') as File | null;
    if (!f) return NextResponse.json({ error: 'Lipsește fișierul' }, { status: 400 });
    if (f.size > MAX_SIZE) return NextResponse.json({ error: 'Fișier prea mare (max 5 MB)' }, { status: 400 });
    name = f.name || 'document';
    const buf = Buffer.from(await f.arrayBuffer());
    if (/\.pdf$/i.test(name)) {
      try {
        const mod: any = await import('pdf-parse/lib/pdf-parse.js' as any);
        const parsed = await (mod.default || mod)(buf);
        content = String(parsed?.text || '').trim();
      } catch { return NextResponse.json({ error: 'Nu am putut citi PDF-ul. Încearcă un .txt sau .csv cu același conținut.' }, { status: 400 }); }
    } else {
      content = buf.toString('utf8');
    }
  } else {
    const b = await req.json().catch(() => ({}));
    name = String(b.name || '').trim(); content = String(b.content || '').trim();
  }
  if (!name || !content) return NextResponse.json({ error: 'Documentul e gol sau nu are text extras.' }, { status: 400 });
  const id = addDoc(user.account_id, name, content);
  return NextResponse.json({ ok: true, id, chars: content.length });
}

export async function DELETE(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const id = String(req.nextUrl.searchParams.get('id') || '');
  if (!id || !deleteDoc(user.account_id, id)) return NextResponse.json({ error: 'Document negăsit' }, { status: 404 });
  return NextResponse.json({ ok: true });
}
