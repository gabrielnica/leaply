import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { getAccount, updateAccountConfig } from '../../../../lib/store';
import { scrapeSite, syncSiteDoc } from '../../../../lib/scrape';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// Reimport de knowledge de pe site-ul clientului — oricând, nu doar în wizard.
// NEDISTRUCTIV: documentul „Site: …" se actualizează mereu; serviciile NOI se adaugă
// (fără să atingă ce a editat omul); cunoștințele scrise manual NU se suprascriu.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const acc = getAccount(user.account_id);
  if (!acc) return NextResponse.json({ error: 'Cont negăsit' }, { status: 404 });
  const url = String(b.url || acc.config?.website || '').trim().slice(0, 300);
  if (!url) return NextResponse.json({ error: 'Spune-mi adresa site-ului (ex. firma.ro).' }, { status: 400 });

  const res = await scrapeSite(url);
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 422 });

  // 1. documentul „Site: …" pentru RAG — mereu actualizat
  const docSaved = await syncSiteDoc(user.account_id, url).catch(() => false);

  // 2. servicii noi (care nu există deja după nume, case-insensitive)
  const cfg = { ...(acc.config || {}) };
  const existing = new Set((cfg.services || []).map((s: any) => String(s.name || '').toLowerCase().trim()));
  const newServices = (res.services || []).filter(s => s.name && !existing.has(s.name.toLowerCase().trim()));
  if (newServices.length) cfg.services = [...(cfg.services || []), ...newServices];

  // 3. dacă nu are deloc cunoștințe/descriere, le punem pe cele extrase
  if (!String(cfg.knowledge || '').trim() && res.knowledge) cfg.knowledge = res.knowledge;
  if (!String(cfg.description || '').trim() && res.description) cfg.description = res.description;
  cfg.website = url;
  updateAccountConfig(user.account_id, cfg);

  return NextResponse.json({
    ok: true,
    pages: res.pages?.length || 1,
    addedServices: newServices.map(s => s.name),
    docSaved,
    knowledgePreview: (res.knowledge || '').slice(0, 300),
  });
}
