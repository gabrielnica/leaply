import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser, hashPassword, emailOk } from '../../../lib/auth';
import { db, uid } from '../../../lib/db';
import { sendMail } from '../../../lib/mail';
import { appUrl } from '../../../lib/settings';
import { audit } from '../../../lib/audit';
export const dynamic = 'force-dynamic';

const isOwner = (u: any) => u && (u.role === 'owner' || u.role === 'admin');

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const members = db().prepare('SELECT id,name,email,role,created_at FROM users WHERE account_id=? ORDER BY created_at').all(user.account_id);
  return NextResponse.json({ members, me: user.id, canManage: isOwner(user) });
}

/** Adaugă un coleg: nume + email; parola se generează și pleacă pe emailul lui. */
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!isOwner(user)) return NextResponse.json({ error: 'Doar proprietarul contului poate adăuga colegi.' }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const name = String(b.name || '').trim().slice(0, 120);
  const email = String(b.email || '').trim().toLowerCase();
  if (!name || !emailOk(email)) return NextResponse.json({ error: 'Nume și email valide, te rog.' }, { status: 400 });
  const exists = db().prepare('SELECT id FROM users WHERE email=?').get(email);
  if (exists) return NextResponse.json({ error: 'Există deja un cont cu acest email.' }, { status: 409 });
  const password = 'lp-' + Math.random().toString(36).slice(2, 10);
  const id = uid('us_');
  db().prepare('INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)')
    .run(id, user!.account_id, email, name, hashPassword(password), 'agent', new Date().toISOString());
  audit(user!.email, 'team.add', email, { account: user!.account_id });
  sendMail(email, 'Ai fost adăugat în echipa Leaply',
    `<p>${user!.name} te-a adăugat în contul echipei pe Leaply.</p><p>Intră pe <a href="${appUrl()}/login">${appUrl()}/login</a> cu emailul tău și parola temporară: <b>${password}</b></p><p>Schimb-o din Setări după prima autentificare.</p>`).catch(() => {});
  return NextResponse.json({ ok: true, id });
}

export async function DELETE(req: NextRequest) {
  const user = getSessionUser();
  if (!isOwner(user)) return NextResponse.json({ error: 'Doar proprietarul poate elimina colegi.' }, { status: 403 });
  const id = String(new URL(req.url).searchParams.get('id') || '');
  const target: any = db().prepare('SELECT id,email,role FROM users WHERE id=? AND account_id=?').get(id, user!.account_id);
  if (!target) return NextResponse.json({ error: 'Utilizator inexistent.' }, { status: 404 });
  if (target.id === user!.id || target.role === 'owner') return NextResponse.json({ error: 'Nu poți elimina proprietarul.' }, { status: 400 });
  db().prepare('DELETE FROM users WHERE id=?').run(id);
  db().prepare('UPDATE conversations SET assigned_to=NULL WHERE assigned_to=?').run(id);
  audit(user!.email, 'team.remove', target.email);
  return NextResponse.json({ ok: true });
}
