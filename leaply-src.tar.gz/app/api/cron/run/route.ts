import { NextRequest, NextResponse } from 'next/server';
import { cfg, appUrl } from '../../../../lib/settings';
import { db } from '../../../../lib/db';
import { getAccount, addMessage } from '../../../../lib/store';
import { getIntegrations } from '../../../../lib/integrations';
import { sendReply } from '../../../../lib/channels';
import { sendSms } from '../../../../lib/sms';
import { sendMail } from '../../../../lib/mail';
import { backupDb } from '../../../../lib/backup';
import { getOwnerEmail } from '../../../../lib/integrations';
import { setSetting } from '../../../../lib/settings';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// Motorul de follow-up: apelează la ~15 min (Coolify Scheduled Task):
//   curl "https://leaply.ro/api/cron/run?key=CRON_SECRET"
// 1. Follow-up lead-uri fără răspuns (config per cont: followup.enabled/hours/text)
// 2. Reamintiri SMS cu ~3h înainte de programările din notele de booking
export async function GET(req: NextRequest) {
  const key = new URL(req.url).searchParams.get('key') || '';
  if (!cfg('CRON_SECRET') || key !== cfg('CRON_SECRET')) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  }
  const d = db();
  let followups = 0;

  // Conversații active/calificate unde ULTIMUL mesaj e al AI-ului, mai vechi de N ore, fără follow-up trimis
  const convs: any[] = d.prepare(`
    SELECT c.id, c.account_id, c.channel, l.phone, l.name,
      (SELECT direction FROM messages WHERE conversation_id=c.id AND direction IN ('in','out') ORDER BY created_at DESC LIMIT 1) AS last_dir,
      (SELECT MAX(created_at) FROM messages WHERE conversation_id=c.id) AS last_at,
      (SELECT COUNT(*) FROM messages WHERE conversation_id=c.id AND sender='followup') AS fu_count
    FROM conversations c JOIN leads l ON l.id=c.lead_id
    WHERE c.status IN ('active','qualified') AND c.updated_at > datetime('now','-7 days')`).all();

  for (const c of convs) {
    if (c.last_dir !== 'out' || c.fu_count > 0) continue;
    const integ = getIntegrations(c.account_id);
    const fu = integ.followup || {};
    if (fu.enabled === false) continue;
    const hours = Number(fu.hours) || 4;
    if (new Date(c.last_at).getTime() > Date.now() - hours * 3600_000) continue;
    const acc = getAccount(c.account_id);
    const text = (fu.text || `Bună! Revenim cu drag — mai putem ajuta cu ceva legat de solicitarea dumneavoastră? Echipa ${acc?.name || ''}`).slice(0, 300);

    let sent = false;
    if (['whatsapp', 'messenger', 'instagram'].includes(c.channel) && c.phone) {
      sent = (await sendReply(c.account_id, c.channel, c.phone, text)).sent;
    }
    if (!sent && c.phone && c.phone.startsWith('+')) sent = await sendSms(c.phone, text);
    if (sent) {
      addMessage(c.id, 'out', 'followup', text);
      followups++;
    }
  }
  // ---- Backup zilnic (o dată pe zi, la primul tick de după miezul nopții) ----
  let backup: string | null = null;
  const today = new Date().toISOString().slice(0, 10);
  if (cfg('LAST_BACKUP_DAY') !== today) {
    try {
      const b = await backupDb();
      setSetting('LAST_BACKUP_DAY', today);
      backup = `${b.file.split('/').pop()} (${Math.round(b.size / 1024)} KB)`;
    } catch (e) { console.error('[cron backup]', String(e).slice(0, 200)); }
  }

  // ---- Raport săptămânal către clienți (lunea, o dată) ----
  let weekly = 0;
  const now = new Date();
  const week = `${now.getFullYear()}-W${Math.ceil(((+now - +new Date(now.getFullYear(), 0, 1)) / 86400000 + 1) / 7)}`;
  if (now.getDay() === 1 && cfg('LAST_WEEKLY') !== week) {
    const accounts: any[] = d.prepare("SELECT id, name FROM accounts WHERE id != 'acc_demo'").all();
    for (const a of accounts) {
      try {
        const email = getOwnerEmail(a.id);
        if (!email) continue;
        if (getIntegrations(a.id).notify?.email === false) continue;
        const st: any = d.prepare(`SELECT COUNT(*) leads,
            SUM(CASE WHEN status='booked' THEN 1 ELSE 0 END) booked,
            SUM(CASE WHEN status IN ('qualified','booked') THEN 1 ELSE 0 END) qualified
          FROM conversations WHERE account_id=? AND created_at > datetime('now','-7 days')`).get(a.id);
        if (!st || !st.leads) continue; // fără activitate → fără spam
        const dv = (d.prepare('SELECT avg_deal_value v FROM accounts WHERE id=?').get(a.id) as any)?.v || 0;
        const saved = Math.round((st.qualified || 0) * 0.35 * dv);
        await sendMail(email, `Săptămâna ta cu Leaply: ${st.leads} lead-uri, ${st.booked || 0} programări`,
          `<h2 style="font-family:sans-serif">Raportul săptămânal — ${a.name}</h2>
           <p style="font-size:16px">În ultimele 7 zile, Leaply a răspuns pentru tine la <b>${st.leads} lead-uri</b>, a calificat <b>${st.qualified || 0}</b> și a obținut <b>${st.booked || 0} programări</b>${saved ? ` — echivalentul a aproximativ <b>${saved.toLocaleString('ro-RO')} lei</b> în oportunități` : ''}.</p>
           <p><a href="${appUrl()}/app" style="background:#FF4D1F;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Vezi detaliile în dashboard</a></p>
           <p style="color:#888;font-size:13px">Primești acest raport în fiecare luni. Îl poți opri din Setări → Notificări.</p>`);
        weekly++;
      } catch (e) { console.error('[cron weekly]', a.id, String(e).slice(0, 150)); }
    }
    setSetting('LAST_WEEKLY', week);
  }

  return NextResponse.json({ ok: true, followups, checked: convs.length, backup, weekly, ts: new Date().toISOString() });
}
