import { NextRequest, NextResponse } from 'next/server';
import { cfg, appUrl } from '../../../../lib/settings';
import { db } from '../../../../lib/db';
import { getAccount, addMessage } from '../../../../lib/store';
import { getIntegrations } from '../../../../lib/integrations';
import { sendReply } from '../../../../lib/channels';
import { sendSms } from '../../../../lib/sms';
import { sendMail } from '../../../../lib/mail';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// Motorul de follow-up: apelează la ~15 min (Coolify Scheduled Task):
//   curl "https://leaply.ro/api/cron/run?key=CRON_SECRET"
// 1. Follow-up lead-uri fără răspuns (config per cont: followup.enabled/hours/text)
// 2. Reamintiri SMS cu ~3h înainte de programările din notele de booking
export async function GET(req: NextRequest) {
  const key = new URL(req.url).searchParams.get('key') || '';
  if (!cfg('CRON_SECRET') || key !== cfg('CRON_SECRET')) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  }
  const d = db();
  let followups = 0;

  // Conversații active/calificate unde ULTIMUL mesaj e al AI-ului, mai vechi de N ore, fără follow-up trimis
  const convs: any[] = d.prepare(`
    SELECT c.id, c.account_id, c.channel, l.phone, l.name,
      (SELECT direction FROM messages WHERE conversation_id=c.id AND direction IN ('in','out') ORDER BY created_at DESC LIMIT 1) AS last_dir,
      (SELECT MAX(created_at) FROM messages WHERE conversation_id=c.id) AS last_at,
      (SELECT COUNT(*) FROM messages WHERE conversation_id=c.id AND sender='followup') AS fu_count
    FROM conversations c JOIN leads l ON l.id=c.lead_id
    WHERE c.status IN ('active','qualified') AND c.updated_at > datetime('now','-7 days')`).all();

  for (const c of convs) {
    if (c.last_dir !== 'out' || c.fu_count > 0) continue;
    const integ = getIntegrations(c.account_id);
    const fu = integ.followup || {};
    if (fu.enabled === false) continue;
    const hours = Number(fu.hours) || 4;
    if (new Date(c.last_at).getTime() > Date.now() - hours * 3600_000) continue;
    const acc = getAccount(c.account_id);
    const text = (fu.text || `Bună! Revenim cu drag — mai putem ajuta cu ceva legat de solicitarea dumneavoastră? Echipa ${acc?.name || ''}`).slice(0, 300);

    let sent = false;
    if (['whatsapp', 'messenger', 'instagram'].includes(c.channel) && c.phone) {
      sent = (await sendReply(c.account_id, c.channel, c.phone, text)).sent;
    }
    if (!sent && c.phone && c.phone.startsWith('+')) sent = await sendSms(c.phone, text);
    if (sent) {
      addMessage(c.id, 'out', 'followup', text);
      followups++;
    }
  }
  return NextResponse.json({ ok: true, followups, checked: convs.length, ts: new Date().toISOString() });
}
