import { NextRequest, NextResponse } from 'next/server';
import { cfg, appUrl } from '../../../../lib/settings';
import { db } from '../../../../lib/db';
import { getAccount, addMessage } from '../../../../lib/store';
import { getIntegrations } from '../../../../lib/integrations';
import { sendReply } from '../../../../lib/channels';
import { sendSms } from '../../../../lib/sms';
import { sendMail, sendMailWithAttachment } from '../../../../lib/mail';
import { backupDb, latestBackup } from '../../../../lib/backup';
import { getOwnerEmail } from '../../../../lib/integrations';
// stare internă cron — scriem direct în tabela settings (nu sunt chei expuse în UI)
const saveState = (key: string, value: string) =>
  db().prepare('INSERT INTO settings (key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at')
    .run(key, value, new Date().toISOString());
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// Motorul de follow-up: apelează la ~15 min (Coolify Scheduled Task):
//   curl "https://leaply.ro/api/cron/run?key=CRON_SECRET"
// 1. Follow-up lead-uri fără răspuns (config per cont: followup.enabled/hours/text)
// 2. Reamintiri SMS cu ~3h înainte de programările din notele de booking
export async function GET(req: NextRequest) {
  const key = new URL(req.url).searchParams.get('key') || '';
  if (!cfg('CRON_SECRET') || key !== cfg('CRON_SECRET')) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  }
  const d = db();
  let followups = 0;

  // Conversații active/calificate unde ULTIMUL mesaj e al AI-ului, mai vechi de N ore, fără follow-up trimis
  const convs: any[] = d.prepare(`
    SELECT c.id, c.account_id, c.channel, l.phone, l.name,
      (SELECT direction FROM messages WHERE conversation_id=c.id AND direction IN ('in','out') ORDER BY created_at DESC LIMIT 1) AS last_dir,
      (SELECT MAX(created_at) FROM messages WHERE conversation_id=c.id) AS last_at,
      (SELECT COUNT(*) FROM messages WHERE conversation_id=c.id AND sender='followup') AS fu_count
    FROM conversations c JOIN leads l ON l.id=c.lead_id
    WHERE c.status IN ('active','qualified') AND c.updated_at > datetime('now','-7 days')`).all();

  for (const c of convs) {
    if (c.last_dir !== 'out') continue;
    const integ = getIntegrations(c.account_id);
    const fu = integ.followup || {};
    if (fu.enabled === false) continue;
    // Cadență multi-touch: ore de la ULTIMUL mesaj pentru fiecare pas. Compatibil cu vechiul {hours}.
    const steps: number[] = Array.isArray(fu.steps) && fu.steps.length
      ? fu.steps.map((x: any) => Number(x)).filter((x: number) => x > 0).slice(0, 5)
      : [Number(fu.hours) || 4, 24, 72];
    if (c.fu_count >= steps.length) continue;
    const hours = steps[c.fu_count];
    if (new Date(c.last_at).getTime() > Date.now() - hours * 3600_000) continue;
    const acc = getAccount(c.account_id);
    const variants = [
      fu.text || `Bună! Revenim cu drag — mai putem ajuta cu ceva legat de solicitarea dumneavoastră? Echipa ${acc?.name || ''}`,
      `Bună ziua! Nu vrem să insistăm — dacă mai e de actualitate solicitarea, ne găsiți aici oricând. Echipa ${acc?.name || ''}`,
      `Bună! Un ultim mesaj din partea noastră 😊 Dacă vă mai putem ajuta, răspundeți oricând la acest mesaj — vă preluăm imediat. ${acc?.name || ''}`,
    ];
    const text = String(variants[Math.min(c.fu_count, variants.length - 1)]).slice(0, 300);

    let sent = false;
    if (['whatsapp', 'messenger', 'instagram'].includes(c.channel) && c.phone) {
      sent = (await sendReply(c.account_id, c.channel, c.phone, text)).sent;
    }
    if (!sent && c.phone && c.phone.startsWith('+')) {
      const { allowSms } = await import('../../../../lib/plan');
      if (allowSms(c.account_id, acc?.plan || 'Trial')) sent = await sendSms(c.phone, text);
    }
    if (sent) {
      addMessage(c.id, 'out', 'followup', text);
      followups++;
    }
  }
  // ---- Backup zilnic (o dată pe zi, la primul tick de după miezul nopții) ----
  let backup: string | null = null;
  const today = new Date().toISOString().slice(0, 10);
  if (cfg('LAST_BACKUP_DAY') !== today) {
    try {
      const b = await backupDb();
      saveState('LAST_BACKUP_DAY', today);
      backup = `${b.file.split('/').pop()} (${Math.round(b.size / 1024)} KB)`;
    } catch (e) { console.error('[cron backup]', String(e).slice(0, 200)); }
  }

  // ---- Raport săptămânal către clienți (lunea, o dată) ----
  let weekly = 0;
  const now = new Date();
  const week = `${now.getFullYear()}-W${Math.ceil(((+now - +new Date(now.getFullYear(), 0, 1)) / 86400000 + 1) / 7)}`;
  if (now.getDay() === 1 && cfg('LAST_WEEKLY') !== week) {
    const accounts: any[] = d.prepare("SELECT id, name FROM accounts WHERE id != 'acc_demo'").all();
    for (const a of accounts) {
      try {
        const email = getOwnerEmail(a.id);
        if (!email) continue;
        if (getIntegrations(a.id).notify?.email === false) continue;
        const st: any = d.prepare(`SELECT COUNT(*) leads,
            SUM(CASE WHEN status='booked' THEN 1 ELSE 0 END) booked,
            SUM(CASE WHEN status IN ('qualified','booked') THEN 1 ELSE 0 END) qualified
          FROM conversations WHERE account_id=? AND created_at > datetime('now','-7 days')`).get(a.id);
        if (!st || !st.leads) continue; // fără activitate → fără spam
        const dv = (d.prepare('SELECT avg_deal_value v FROM accounts WHERE id=?').get(a.id) as any)?.v || 0;
        const saved = Math.round((st.qualified || 0) * 0.35 * dv);
        await sendMail(email, `Săptămâna ta cu Leaply: ${st.leads} lead-uri, ${st.booked || 0} programări`,
          `<h2 style="font-family:sans-serif">Raportul săptămânal — ${a.name}</h2>
           <p style="font-size:16px">În ultimele 7 zile, Leaply a răspuns pentru tine la <b>${st.leads} lead-uri</b>, a calificat <b>${st.qualified || 0}</b> și a obținut <b>${st.booked || 0} programări</b>${saved ? ` — echivalentul a aproximativ <b>${saved.toLocaleString('ro-RO')} lei</b> în oportunități` : ''}.</p>
           <p><a href="${appUrl()}/app" style="background:#FF4D1F;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Vezi detaliile în dashboard</a></p>
           <p style="color:#888;font-size:13px">Primești acest raport în fiecare luni. Îl poți opri din Setări → Notificări.</p>`);
        weekly++;
      } catch (e) { console.error('[cron weekly]', a.id, String(e).slice(0, 150)); }
    }
    saveState('LAST_WEEKLY', week);
  }

  // ---- Anti-neprezentare: confirmare cu ~24h înainte de programare (o singură dată) ----
  let confirms = 0;
  const bookings: any[] = d.prepare(`
    SELECT c.id, c.account_id, c.booking_at, l.phone, l.name FROM conversations c JOIN leads l ON l.id=c.lead_id
    WHERE c.status='booked' AND c.confirm_sent=0 AND c.booking_at IS NOT NULL
      AND c.booking_at > datetime('now','+20 hours') AND c.booking_at < datetime('now','+26 hours')`).all();
  for (const b of bookings) {
    if (!b.phone || b.phone.replace(/[^\d]/g, '').length < 9) continue;
    const acc = getAccount(b.account_id);
    const dt = new Date(b.booking_at);
    const when = `mâine la ${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
    const { allowSms: allowSms2 } = await import('../../../../lib/plan');
    if (!allowSms2(b.account_id, acc?.plan || 'Trial')) continue;
    const ok = await sendSms(b.phone, `${acc?.name || 'Echipa'}: vă reamintim programarea de ${when}. Confirmați cu DA — sau răspundeți la acest mesaj dacă doriți reprogramare.`);
    if (ok) { d.prepare('UPDATE conversations SET confirm_sent=1 WHERE id=?').run(b.id); addMessage(b.id, 'note', 'system', `SMS de confirmare (24h înainte) trimis pentru ${when}.`); confirms++; }
  }

  // ---- Drip de onboarding: ziua 0 / 2 / 5 de la creare cont ----
  let drips = 0;
  const dripAccounts: any[] = d.prepare("SELECT id, name, created_at, integrations FROM accounts WHERE id != 'acc_demo' AND created_at > datetime('now','-7 days')").all();
  for (const a of dripAccounts) {
    try {
      const integ = JSON.parse(a.integrations || '{}');
      const drip = integ.drip || {};
      const email = getOwnerEmail(a.id);
      if (!email) continue;
      const days = Math.floor((Date.now() - new Date(a.created_at).getTime()) / 86400_000);
      const send = async (flag: string, subject: string, html: string) => {
        if (drip[flag]) return;
        await sendMail(email, subject, html);
        drip[flag] = true; integ.drip = drip;
        d.prepare('UPDATE accounts SET integrations=? WHERE id=?').run(JSON.stringify(integ), a.id);
        drips++;
      };
      if (days >= 0 && !drip.d0) await send('d0', `Bun venit la Leaply, ${a.name}!`,
        `<p>Contul tău e gata. 3 pași și primești primul lead cu răspuns automat:</p><p>1. <a href="${appUrl()}/app/config">Configurează asistentul</a> · 2. <a href="${appUrl()}/app/channels">Conectează un canal</a> · 3. <a href="${appUrl()}/app/settings">Conectează calendarul</a></p>`);
      else if (days >= 2 && !drip.d2) await send('d2', 'Știai că poți pune Leaply direct pe site-ul tău?',
        `<p>O singură linie de cod și fiecare vizitator poate vorbi cu asistentul tău — găsești codul în <a href="${appUrl()}/app/channels">Canale → Formular web</a>.</p><p>Tot de acolo poți cere și un număr de telefon de la Leaply: apelurile ratate devin lead-uri cu SMS automat.</p>`);
      else if (days >= 5 && !drip.d5) await send('d5', 'Cum merge cu Leaply?',
        `<p>Ai întrebări sau vrei o mână de ajutor la configurare? Răspunde la acest email și te ajutăm personal, în aceeași zi.</p><p>Când ești gata de volum, <a href="${appUrl()}/app/settings">planurile plătite</a> pornesc de la 59€/lună.</p>`);
    } catch {}
  }

  // ---- Backup off-site: lunea, ultimul backup pleacă pe email ca atașament ----
  let offsite = false;
  if (now.getDay() === 1 && cfg('LAST_OFFSITE') !== week) {
    try {
      const last = latestBackup();
      if (last) {
        const fs = require('fs');
        offsite = await sendMailWithAttachment('salut@gabrielnica.ro', `Backup Leaply — ${today}`,
          '<p>Copia săptămânală off-site a bazei de date Leaply. Păstreaz-o într-un loc sigur.</p>',
          last.file.split('/').pop() || 'leaply.db', fs.readFileSync(last.file));
        if (offsite) saveState('LAST_OFFSITE', week);
      }
    } catch (e) { console.error('[cron offsite]', String(e).slice(0, 150)); }
  }

  return NextResponse.json({ ok: true, followups, confirms, drips, offsite, checked: convs.length, backup, weekly, ts: new Date().toISOString() });
}
