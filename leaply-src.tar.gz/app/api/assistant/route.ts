import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { db } from '../../../lib/db';
import { getAccount } from '../../../lib/store';
import { getIntegrations } from '../../../lib/integrations';
import { llmReply, llmActive } from '../../../lib/llm';
import { usageThisMonth, limitFor } from '../../../lib/usage';
import { LEAPLY_ONBOARDING_GUIDE, LEAPLY_KNOWLEDGE } from '../../../lib/leaply-kb';
export const dynamic = 'force-dynamic';

// Asistentul de onboarding din aplicație: ajută utilizatorul logat să-și configureze
// contul și să-și conecteze canalele. Vede starea reală a contului (canale, config, plan).

function accountContext(accId: string, plan: string) {
  const config = getAccount(accId)?.config || {};
  const chans: any[] = db().prepare('SELECT type, status, label FROM channels WHERE account_id=?').all(accId);
  const integ = getIntegrations(accId);
  const lines = [
    `- ID cont (pentru scriptul de widget): ${accId}`,
    `- Plan: ${plan} · conversații folosite luna asta: ${usageThisMonth(accId)}/${limitFor(plan)}`,
    `- Canale: ${chans.map(c => `${c.type}=${c.type === 'calendar' ? (integ.google?.refresh_token ? 'connected' : 'pending') : c.status}`).join(', ') || 'niciunul'}`,
    `- Configurare AI: ${Array.isArray(config.services) && config.services.length ? config.services.length + ' servicii definite' : 'FĂRĂ servicii definite (pas important!)'}${config.knowledge ? ', are cunoștințe despre afacere' : ', fără cunoștințe despre afacere'}${config.rules ? ', are reguli' : ''}`,
    `- Întrebări de calificare: ${(config.qualificationQuestions || []).length}`,
    `- Nume afacere: ${config.businessName || '-'} · ton: ${config.tone || '-'}`,
  ];
  return lines.join('\n');
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const history: { role: string; content: string }[] = (Array.isArray(b.history) ? b.history : [])
    .slice(-12)
    .map((m: any) => ({ role: m?.role === 'assistant' ? 'assistant' : 'user', content: String(m?.content || '').slice(0, 1500) }))
    .filter((m: any) => m.content);
  if (!history.length || history[history.length - 1].role !== 'user') {
    return NextResponse.json({ error: 'Mesaj lipsă' }, { status: 400 });
  }
  if (!llmActive()) {
    return NextResponse.json({ reply: 'Asistentul nu e disponibil momentan. Scrie-ne la salut@leaply.ro și te ajutăm noi direct.' });
  }

  const acc = getAccount(user.account_id);
  const system = `Ești asistentul de configurare din aplicația Leaply. Utilizatorul (${user.name}, rol ${user.role}) e logat în contul lui și îl ajuți să-și configureze asistentul AI și să-și conecteze canalele.
Răspunde în ROMÂNĂ, scurt și concret, cu pași numerotați când explici o procedură. Referă-te la paginile aplicației cu numele + calea lor (ex: „Canale (/app/channels)"). Nu inventa funcții care nu există în ghid. Pentru probleme pe care nu le poți rezolva, recomandă salut@leaply.ro.

${LEAPLY_ONBOARDING_GUIDE}

DESPRE PRODUS (dacă întreabă de planuri/prețuri/funcții):
${LEAPLY_KNOWLEDGE}

STAREA REALĂ A CONTULUI ACESTUI UTILIZATOR (folosește-o ca să dai sfaturi personalizate — ex. ce pas urmează):
${accountContext(user.account_id, acc?.plan || 'Trial')}`;

  const reply = await llmReply(system, history, { maxTokens: 600, temperature: 0.3 });
  return NextResponse.json({ reply: reply || 'Nu am reușit să răspund acum — mai încearcă o dată sau scrie-ne la salut@leaply.ro.' });
}
