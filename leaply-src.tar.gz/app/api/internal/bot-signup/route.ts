import { NextRequest, NextResponse } from 'next/server';
import { cfg } from '../../../../lib/settings';
import { createAccountFromBot } from '../../../../lib/botsignup';
export const dynamic = 'force-dynamic';

// Endpoint INTERN — folosit de agentul vocal (voice-bridge.js, același proces)
// pentru a crea conturi în timpul apelului. Protejat cu CRON_SECRET.
export async function POST(req: NextRequest) {
  const secret = cfg('CRON_SECRET');
  if (!secret || req.headers.get('x-leaply-key') !== secret) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  }
  const b = await req.json().catch(() => ({}));
  const res = await createAccountFromBot({
    name: String(b.name || '').slice(0, 120),
    email: String(b.email || '').slice(0, 200),
    company: String(b.company || '').slice(0, 120),
    phone: String(b.phone || '').slice(0, 20),
    source: String(b.source || 'voicebot').slice(0, 40),
  });
  return NextResponse.json(res);
}
