import { NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db, uid } from '../../../../lib/db';
import { getAccount } from '../../../../lib/store';
import { sendMail } from '../../../../lib/mail';
export const dynamic = 'force-dynamic';

// „Cere număr WhatsApp de la Leaply" — clientul nu face niciun cont nicăieri.
// Cererea apare în admin + email către platformă; numărul se provisionează din contul Twilio master.
export async function POST() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const acc = getAccount(user.account_id);
  const d = db();
  const existing: any = d.prepare("SELECT id FROM demo_requests WHERE account_id=? AND vertical='whatsapp_number'").get(user.account_id);
  if (existing) return NextResponse.json({ ok: true, already: true });
  d.prepare('INSERT INTO demo_requests (id,name,contact,business,vertical,status,account_id,created_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(uid('wr_'), user.name, user.email, acc?.name || '', 'whatsapp_number', 'cerere număr WhatsApp', user.account_id, new Date().toISOString());
  sendMail('salut@gabrielnica.ro', `Cerere număr WhatsApp — ${acc?.name || user.email}`,
    `<p><b>${user.name}</b> (${user.email}, cont ${acc?.name}) a cerut un număr WhatsApp gestionat de Leaply.</p><p>Provisionează un număr din contul Twilio master și conectează-l din pagina Canale a contului lor.</p>`);
  return NextResponse.json({ ok: true });
}
