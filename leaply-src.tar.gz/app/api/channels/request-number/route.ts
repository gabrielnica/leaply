import { NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db, uid } from '../../../../lib/db';
import { getAccount } from '../../../../lib/store';
import { sendMail } from '../../../../lib/mail';
import { planSpec, requiredPlanFor, upgradeMsg } from '../../../../lib/plan';
export const dynamic = 'force-dynamic';

// „Cere număr WhatsApp de la Leaply" — clientul nu face niciun cont nicăieri.
// Cererea apare în admin + email către platformă; numărul se provisionează din contul Twilio master.
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({} as any));
  const kind = body?.kind === 'voice' ? 'voice' : 'whatsapp';
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const acc = getAccount(user.account_id);
  // numerele gestionate de Leaply costă bani reali — cer plan plătit care le include
  if (!planSpec(acc?.plan || 'Trial').requestNumber.includes(kind)) {
    const need = requiredPlanFor(s => s.requestNumber.includes(kind));
    return NextResponse.json({ error: upgradeMsg(kind === 'voice' ? 'Numărul de telefon gestionat de Leaply' : 'Numărul WhatsApp gestionat de Leaply', need) }, { status: 403 });
  }
  const d = db();
  const existing: any = d.prepare("SELECT id FROM demo_requests WHERE account_id=? AND vertical=?").get(user.account_id, kind + '_number');
  if (existing) return NextResponse.json({ ok: true, already: true });
  d.prepare('INSERT INTO demo_requests (id,name,contact,business,vertical,status,account_id,created_at) VALUES (?,?,?,?,?,?,?,?)')
    .run(uid('wr_'), user.name, user.email, acc?.name || '', kind + '_number', kind === 'voice' ? 'cerere număr telefon' : 'cerere număr WhatsApp', user.account_id, new Date().toISOString());
  sendMail('salut@gabrielnica.ro', `Cerere număr ${kind === 'voice' ? 'de telefon (voce)' : 'WhatsApp'} — ${acc?.name || user.email}`,
    `<p><b>${user.name}</b> (${user.email}, cont ${acc?.name}) a cerut un număr ${kind === 'voice' ? 'de telefon pentru apeluri' : 'WhatsApp'} gestionat de Leaply.</p><p>Provisionează un număr din contul Twilio master${kind === 'voice' ? ', setează Voice webhook la https://leaply.ro/api/webhooks/voice' : ''} și conectează-l din pagina Canale a contului lor.</p>`);
  return NextResponse.json({ ok: true });
}
