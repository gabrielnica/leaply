import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { listChannels } from '../../../lib/store';
import { setChannelCreds, getChannel } from '../../../lib/channels';
export const dynamic = 'force-dynamic';

const mask = (s: string) => (s || '').length > 8 ? `${s.slice(0, 4)}…${s.slice(-4)}` : '••••';

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const chans = listChannels(user.account_id).map((c: any) => {
    let creds: any = null;
    try { creds = JSON.parse(c.credentials || 'null'); } catch {}
    return {
      id: c.id, type: c.type, status: c.status, label: c.label,
      provider: creds?.provider || null,
      masked: creds ? Object.fromEntries(Object.entries(creds).map(([k, v]) => [k, k === 'provider' ? v : mask(String(v))])) : null,
    };
  });
  return NextResponse.json({ channels: chans });
}

const ALLOWED: Record<string, string[][]> = {
  // per tip: seturile de câmpuri acceptate
  whatsapp: [
    ['provider', 'phone_number_id', 'access_token'],           // meta
    ['provider', 'account_sid', 'auth_token', 'from_number'],  // twilio
  ],
  messenger: [['provider', 'page_id', 'page_access_token']],
  instagram: [['provider', 'page_id', 'page_access_token']],
};

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const type = String(b.type || '');
  if (!ALLOWED[type]) return NextResponse.json({ error: 'Canal necunoscut sau fără credențiale.' }, { status: 400 });

  if (b.disconnect) {
    setChannelCreds(user.account_id, type, null);
    return NextResponse.json({ ok: true, status: 'pending' });
  }

  const creds = b.credentials || {};
  const provider = creds.provider === 'twilio' ? 'twilio' : 'meta';
  creds.provider = provider;
  const shape = ALLOWED[type].find(fields => fields.every(f => typeof creds[f] === 'string' && creds[f].trim().length > 0));
  if (!shape) return NextResponse.json({ error: 'Credențiale incomplete pentru acest canal/provider.' }, { status: 400 });
  const clean = Object.fromEntries(shape.map(f => [f, String(creds[f]).trim()]));

  const label = type === 'whatsapp'
    ? (provider === 'twilio' ? `WhatsApp via Twilio (${clean.from_number})` : `WhatsApp Cloud API (${clean.phone_number_id})`)
    : `${type === 'messenger' ? 'Messenger' : 'Instagram'} — pagina ${clean.page_id}`;
  setChannelCreds(user.account_id, type, clean, label);
  return NextResponse.json({ ok: true, status: 'connected', label });
}
