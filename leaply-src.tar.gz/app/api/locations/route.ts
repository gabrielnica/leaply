import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { db, uid } from '../../../lib/db';
import { audit } from '../../../lib/audit';
export const dynamic = 'force-dynamic';

// Multi-locație (pachetul Total): un cont-părinte + până la 4 locații (conturi-copil).
// Ownerul comută între locații (users.active_account_id); fiecare locație are propriile
// canale, configurare AI și inbox — abonamentul e unul singur, pe contul-părinte.
const MAX_LOCATIONS = 5; // total, inclusiv sediul principal

const isOwner = (u: any) => u && (u.role === 'owner' || u.role === 'admin');

function familyOf(homeId: string) {
  const d = db();
  const home: any = d.prepare('SELECT id, name, plan FROM accounts WHERE id=?').get(homeId);
  const children: any[] = d.prepare('SELECT id, name FROM accounts WHERE parent_id=? ORDER BY created_at').all(homeId);
  return { home, children };
}

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const homeId = user.home_account_id || user.account_id;
  const { home, children } = familyOf(homeId);
  const canManage = isOwner(user) && home?.plan === 'Scale';
  return NextResponse.json({
    active: user.account_id,
    canManage,
    maxLocations: MAX_LOCATIONS,
    locations: [
      { id: home.id, name: home.name, primary: true, active: user.account_id === home.id },
      ...children.map(c => ({ id: c.id, name: c.name, primary: false, active: user.account_id === c.id })),
    ],
  });
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const homeId = user.home_account_id || user.account_id;
  const b = await req.json().catch(() => ({}));
  const d = db();

  // Comutare între locații — permisă oricui din cont (ownerul; agenții n-au locații)
  if (b.action === 'switch') {
    const target = String(b.account_id || '');
    const ok = target === homeId || d.prepare('SELECT id FROM accounts WHERE id=? AND parent_id=?').get(target, homeId);
    if (!ok) return NextResponse.json({ error: 'Locație necunoscută.' }, { status: 404 });
    d.prepare('UPDATE users SET active_account_id=? WHERE id=?').run(target === homeId ? null : target, user.id);
    return NextResponse.json({ ok: true, active: target });
  }

  // Creare locație nouă — doar owner, doar pe Total (Scale)
  if (b.action === 'create') {
    if (!isOwner(user)) return NextResponse.json({ error: 'Doar proprietarul contului poate adăuga locații.' }, { status: 403 });
    const home: any = d.prepare('SELECT id, name, plan, config FROM accounts WHERE id=?').get(homeId);
    if (home?.plan !== 'Scale') {
      return NextResponse.json({ error: 'Locațiile multiple sunt incluse în pachetul Total. Fă upgrade din Setări & Plan și se activează instant.' }, { status: 403 });
    }
    const count = (d.prepare('SELECT COUNT(*) c FROM accounts WHERE parent_id=?').get(homeId) as any).c;
    if (count + 1 >= MAX_LOCATIONS) {
      return NextResponse.json({ error: `Pachetul Total include maxim ${MAX_LOCATIONS} locații. Pentru mai multe, scrie-ne la salut@leaply.ro.` }, { status: 403 });
    }
    const name = String(b.name || '').trim().slice(0, 120);
    if (!name) return NextResponse.json({ error: 'Dă un nume locației (ex. „Sediul Cluj").' }, { status: 400 });

    const now = new Date().toISOString();
    const id = uid('acc_');
    let baseConfig: any = {};
    try { baseConfig = JSON.parse(home.config || '{}'); } catch {}
    // locația moștenește configurarea AI a sediului (o poate schimba apoi independent)
    const config = { ...baseConfig, businessName: name };
    d.transaction(() => {
      d.prepare('INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at,parent_id) VALUES (?,?,?,?,?,?,?,?)')
        .run(id, name, (baseConfig.vertical || 'servicii'), 'Scale', 3000, JSON.stringify(config), now, homeId);
      const chans = [
        ['webform', 'connected', 'Formular / chat web'],
        ['whatsapp', 'pending', 'WhatsApp Business'],
        ['meta_lead_ads', 'pending', 'Facebook Lead Ads'],
        ['messenger', 'pending', 'Messenger'],
        ['instagram', 'pending', 'Instagram DM'],
        ['voice', 'pending', 'Apeluri telefonice (număr de la Leaply)'],
        ['calendar', 'pending', 'Google Calendar'],
      ];
      const ins = d.prepare('INSERT INTO channels (id,account_id,type,status,label) VALUES (?,?,?,?,?)');
      for (const [type, status, label] of chans) ins.run(uid('ch_'), id, type, status, label);
    })();
    audit(user.email, 'location.create', id, { parent: homeId, name });
    return NextResponse.json({ ok: true, id, name });
  }

  return NextResponse.json({ error: 'Acțiune necunoscută.' }, { status: 400 });
}
