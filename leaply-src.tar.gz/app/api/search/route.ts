import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { db } from '../../../lib/db';
export const dynamic = 'force-dynamic';

// Căutarea globală (Cmd+K): lead-uri, conversații (nume/telefon/etichete) + pagini.
const PAGES = [
  { title: 'Overview', url: '/app', hint: 'pagina principală' },
  { title: 'Lead-uri / Inbox', url: '/app/inbox', hint: 'toate conversațiile' },
  { title: 'Programări', url: '/app/bookings', hint: 'lead-uri programate' },
  { title: 'Canale', url: '/app/channels', hint: 'WhatsApp, Messenger, Instagram…' },
  { title: 'Configurare AI', url: '/app/config', hint: 'cunoștințe, documente, reguli' },
  { title: 'Rapoarte', url: '/app/reports', hint: 'grafice + PDF' },
  { title: 'Setări & Plan', url: '/app/settings', hint: 'abonament, notificări, echipă' },
];

export async function GET(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const q = String(req.nextUrl.searchParams.get('q') || '').trim().slice(0, 60);
  if (q.length < 2) return NextResponse.json({ results: [] });
  const like = `%${q}%`;
  const convs: any[] = db().prepare(`
    SELECT c.id, c.status, c.channel, c.tags, l.name, l.phone FROM conversations c
    JOIN leads l ON l.id = c.lead_id
    WHERE c.account_id = ? AND (l.name LIKE ? OR l.phone LIKE ? OR c.tags LIKE ?)
    ORDER BY c.updated_at DESC LIMIT 8`).all(user.account_id, like, like, like);
  const results = [
    ...convs.map(c => ({ title: c.name || 'Lead', hint: `${c.channel} · ${c.phone || ''} · ${c.status}`, url: `/app/conversation/${c.id}` })),
    ...PAGES.filter(p => p.title.toLowerCase().includes(q.toLowerCase()) || p.hint.includes(q.toLowerCase())),
  ].slice(0, 10);
  return NextResponse.json({ results });
}
