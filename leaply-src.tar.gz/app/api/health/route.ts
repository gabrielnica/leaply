import { NextRequest, NextResponse } from 'next/server';
import { llmActive, llmProbe } from '../../../lib/llm';
import { stats } from '../../../lib/store';
import { cfg } from '../../../lib/settings';
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  let db_ok = true, kpis: any = null;
  try { kpis = stats(); } catch { db_ok = false; }
  // Heartbeat cron: scheduled task-ul din Coolify rulează la ~15 min și scrie CRON_LAST_RUN.
  // Dacă n-a rulat de >30 min, status devine „degraded" — UptimeRobot (keyword "\"status\":\"ok\"") alertează.
  let cron_ok = false, cron_last_run: string | null = null;
  try {
    cron_last_run = cfg('CRON_LAST_RUN') || null;
    cron_ok = !!cron_last_run && Date.now() - new Date(cron_last_run).getTime() < 30 * 60_000;
  } catch { /* db jos — deja reflectat în db_ok */ }
  const base: any = { status: db_ok && cron_ok ? 'ok' : 'degraded', service: 'leaply', db_ok, cron_ok, cron_last_run, llm: llmActive() ? 'active' : 'rule-based', kpis, ts: new Date().toISOString() };
  // diagnostic LLM la cerere: /api/health?llm=1 — face un apel minimal real și întoarce eroarea (fără chei)
  if (req.nextUrl.searchParams.get('llm') === '1') {
    try { base.llm_probe = await llmProbe(); } catch (e: any) { base.llm_probe = { ok: false, error: String(e?.message || e).slice(0, 200) }; }
  }
  return NextResponse.json(base);
}
