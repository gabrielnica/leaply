import { NextResponse } from 'next/server';
import { llmActive } from '../../../lib/llm';
import { stats } from '../../../lib/store';
export const dynamic = 'force-dynamic';
export async function GET() {
  let db_ok = true, kpis: any = null;
  try { kpis = stats(); } catch { db_ok = false; }
  return NextResponse.json({ status: 'ok', service: 'leaply', db_ok, llm: llmActive() ? 'active' : 'rule-based', kpis, ts: new Date().toISOString() });
}
