import { NextRequest, NextResponse } from 'next/server';
import { llmActive, llmProbe } from '../../../lib/llm';
import { stats } from '../../../lib/store';
export const dynamic = 'force-dynamic';
export async function GET(req: NextRequest) {
  let db_ok = true, kpis: any = null;
  try { kpis = stats(); } catch { db_ok = false; }
  const base: any = { status: 'ok', service: 'leaply', db_ok, llm: llmActive() ? 'active' : 'rule-based', kpis, ts: new Date().toISOString() };
  // diagnostic LLM la cerere: /api/health?llm=1 — face un apel minimal real și întoarce eroarea (fără chei)
  if (req.nextUrl.searchParams.get('llm') === '1') {
    try { base.llm_probe = await llmProbe(); } catch (e: any) { base.llm_probe = { ok: false, error: String(e?.message || e).slice(0, 200) }; }
  }
  return NextResponse.json(base);
}
