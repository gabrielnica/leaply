import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { scrapeSite } from '../../../../lib/scrape';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const url = String(b.url || '').slice(0, 300);
  if (!url) return NextResponse.json({ error: 'Lipsește adresa site-ului.' }, { status: 400 });
  const res = await scrapeSite(url);
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 422 });
  return NextResponse.json(res);
}
