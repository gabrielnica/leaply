import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { createInboundConversation, addMessage, updateConversation } from '../../../../lib/store';
export const dynamic = 'force-dynamic';

// La finalul wizard-ului: salvează conversația de test în inbox-ul contului nou,
// ca dashboard-ul să nu fie gol la prima vizită.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const history: any[] = Array.isArray(b.history) ? b.history.slice(0, 40) : [];
  if (history.length > 0) {
    const first = String(history[0]?.body || 'Test din wizard').slice(0, 1000);
    const { convId } = createInboundConversation(user.account_id, 'webform', `${user.name} (test)`, '', 'wizard', first);
    for (const m of history.slice(1)) {
      const dir = m?.sender === 'ai' ? 'out' : 'in';
      addMessage(convId, dir, m?.sender === 'ai' ? 'ai' : 'lead', String(m?.body || '').slice(0, 1000));
    }
    updateConversation(convId, { first_response_ms: 800, status: String(b.status || 'active'), score: String(b.score || 'warm') as any, qualification: b.qualification || {} });
  }
  return NextResponse.json({ ok: true });
}
