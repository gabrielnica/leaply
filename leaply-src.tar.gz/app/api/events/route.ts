import { NextRequest } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { onAccountEvent } from '../../../lib/events';
export const dynamic = 'force-dynamic';

// SSE: dashboardul (și aplicația mobilă) primesc instant evenimentele contului —
// mesaj nou de la lead, răspuns AI — fără refresh manual.
export async function GET(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return new Response('Neautentificat', { status: 401 });
  const accId = user.account_id;
  const enc = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      const send = (data: any) => {
        try { controller.enqueue(enc.encode(`data: ${JSON.stringify(data)}\n\n`)); } catch { /* closed */ }
      };
      send({ type: 'hello', at: new Date().toISOString() });
      const off = onAccountEvent(accId, ev => send(ev));
      const ping = setInterval(() => {
        try { controller.enqueue(enc.encode(': ping\n\n')); } catch { clearInterval(ping); off(); }
      }, 25_000);
      req.signal.addEventListener('abort', () => {
        clearInterval(ping); off();
        try { controller.close(); } catch { /* already closed */ }
      });
    },
  });
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  });
}
