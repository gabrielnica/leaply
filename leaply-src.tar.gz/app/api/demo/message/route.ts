import { NextRequest, NextResponse } from 'next/server';
import { nextReply, Turn } from '../../../../lib/brain';
import { effectiveDemoConfig, DemoMode } from '../../../../lib/demo';

export const dynamic = 'force-dynamic';

const MAX_TURNS = 30;
const MAX_LEN = 1000;

export async function POST(req: NextRequest) {
  const t0 = Date.now();
  const body = await req.json().catch(() => ({}));
  // Istoricul vine de la client, dar e limitat și igienizat (fără config injectat de client)
  const history: Turn[] = (Array.isArray(body.history) ? body.history : [])
    .slice(-MAX_TURNS)
    .map((h: any) => ({ sender: h?.sender === 'ai' ? 'ai' as const : 'lead' as const, body: String(h?.body ?? '').slice(0, MAX_LEN) }));

  // mode 'public' → demo-ul DentArt; 'preview' → config efemer din site-ul vizitatorului; 'account' → contul logat
  const mode: DemoMode = body.mode === 'public' || body.mode === 'preview' ? 'public' : 'account';
  let { config, personalized, accountId } = effectiveDemoConfig(mode);
  if (body.mode === 'preview' && typeof body.previewId === 'string') {
    try {
      const { db } = await import('../../../../lib/db');
      const row: any = db().prepare("SELECT config FROM demo_previews WHERE id=? AND created_at > datetime('now','-1 day')").get(body.previewId.slice(0, 40));
      if (row?.config) { config = JSON.parse(row.config); personalized = true; }
    } catch { /* rămâne demo-ul public */ }
  }

  // Contul logat primește EXACT contextul canalelor reale: documente firmă (RAG) + exemple apreciate
  if (personalized && accountId) {
    const lastLead = [...history].reverse().find(h => h.sender === 'lead')?.body || '';
    try {
      const { docsContext } = await import('../../../../lib/docs');
      const dctx = docsContext(accountId, lastLead);
      if (dctx) config = { ...config, _docsContext: dctx };
    } catch {}
    try {
      const { fewShotExamples } = await import('../../../../lib/quality');
      const fs = fewShotExamples(accountId);
      if (fs) config = { ...config, _fewShot: fs };
    } catch {}
  }

  const res = await nextReply(config, history);
  return NextResponse.json({ ...res, personalized, latencyMs: Date.now() - t0 });
}
