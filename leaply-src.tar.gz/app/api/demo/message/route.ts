import { NextRequest, NextResponse } from 'next/server';
import { nextReply, Turn } from '../../../../lib/brain';
import { DEMO_CONFIG } from '../../../../lib/db';
import { getAccount } from '../../../../lib/store';
import { getSessionUser } from '../../../../lib/auth';

export const dynamic = 'force-dynamic';

const MAX_TURNS = 30;
const MAX_LEN = 1000;

export async function POST(req: NextRequest) {
  const t0 = Date.now();
  const body = await req.json().catch(() => ({}));
  // Istoricul vine de la client, dar e limitat și igienizat (fără config injectat de client)
  const history: Turn[] = (Array.isArray(body.history) ? body.history : [])
    .slice(-MAX_TURNS)
    .map((h: any) => ({ sender: h?.sender === 'ai' ? 'ai' as const : 'lead' as const, body: String(h?.body ?? '').slice(0, MAX_LEN) }));
  // Config: contul utilizatorului logat (wizard/test), altfel contul demo public
  let config: any = DEMO_CONFIG;
  try {
    const user = getSessionUser();
    const acc = getAccount(user ? user.account_id : 'acc_demo');
    if (acc?.config && typeof acc.config === 'object') config = acc.config;
  } catch {}
  const res = await nextReply(config, history);
  return NextResponse.json({ ...res, latencyMs: Date.now() - t0 });
}
