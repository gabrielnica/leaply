import { NextRequest, NextResponse } from 'next/server';
import { nextReply, Turn } from '../../../../lib/brain';
import { DEMO_CONFIG } from '../../../../lib/db';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const t0 = Date.now();
  const body = await req.json().catch(() => ({}));
  const history: Turn[] = Array.isArray(body.history) ? body.history : [];
  const config = body.config || DEMO_CONFIG;
  const res = await nextReply(config, history);
  return NextResponse.json({ ...res, latencyMs: Date.now() - t0 });
}
