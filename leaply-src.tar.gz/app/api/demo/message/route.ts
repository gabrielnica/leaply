import { NextRequest, NextResponse } from 'next/server';
import { nextReply, Turn } from '../../../../lib/brain';
import { effectiveDemoConfig } from '../../../../lib/demo';

export const dynamic = 'force-dynamic';

const MAX_TURNS = 30;
const MAX_LEN = 1000;

export async function POST(req: NextRequest) {
  const t0 = Date.now();
  const body = await req.json().catch(() => ({}));
  // Istoricul vine de la client, dar e limitat și igienizat (fără config injectat de client)
  const history: Turn[] = (Array.isArray(body.history) ? body.history : [])
    .slice(-MAX_TURNS)
    .map((h: any) => ({ sender: h?.sender === 'ai' ? 'ai' as const : 'lead' as const, body: String(h?.body ?? '').slice(0, MAX_LEN) }));
  // Config: contul utilizatorului logat (cu fallback-uri sigure), altfel contul demo public
  const { config, personalized } = effectiveDemoConfig();
  const res = await nextReply(config, history);
  return NextResponse.json({ ...res, personalized, latencyMs: Date.now() - t0 });
}
