import { NextRequest, NextResponse } from 'next/server';
import { db, uid } from '../../../../lib/db';
import { scrapeSite } from '../../../../lib/scrape';
import { heuristicStarters } from '../../../../lib/demo';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// Demo personalizat FĂRĂ cont: vizitatorul dă site-ul, noi îl citim și pornim un
// asistent efemer pe datele lui. Rate-limit strict (cost LLM): 5/IP/zi + 150 global/zi.
export async function POST(req: NextRequest) {
  const ip = (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || 'unknown';
  const b = await req.json().catch(() => ({}));
  const raw = String(b.website || '').trim().slice(0, 200);
  const host = raw.replace(/^https?:\/\//i, '').replace(/^www\./i, '').split('/')[0].toLowerCase();
  if (!host || !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(host)) {
    return NextResponse.json({ error: 'Scrie adresa site-ului firmei, ex. firma-mea.ro' }, { status: 400 });
  }
  const d = db();
  const day = new Date().toISOString().slice(0, 10);
  const perIp = (d.prepare("SELECT COUNT(*) n FROM demo_previews WHERE ip=? AND created_at LIKE ? || '%'").get(ip, day) as any).n;
  const global = (d.prepare("SELECT COUNT(*) n FROM demo_previews WHERE created_at LIKE ? || '%'").get(day) as any).n;
  if (perIp >= 5 || global >= 150) {
    return NextResponse.json({ error: 'Limita de demo-uri pe azi a fost atinsă. Fă-ți un cont gratuit — acolo testezi fără limită.' }, { status: 429 });
  }
  // refolosim un preview recent pe același site (evită re-scrape la refresh)
  const recent: any = d.prepare("SELECT id, config FROM demo_previews WHERE website=? AND created_at > datetime('now','-6 hours') ORDER BY created_at DESC LIMIT 1").get(host);
  if (recent) {
    const cfg = JSON.parse(recent.config);
    return NextResponse.json({ ok: true, previewId: recent.id, businessName: cfg.businessName, services: (cfg.services || []).length, starters: heuristicStarters(cfg) });
  }

  const res = await scrapeSite(host);
  if (!res.ok || (!res.services?.length && !res.knowledge)) {
    return NextResponse.json({ error: res.error || 'Nu am putut citi suficiente informații de pe site. Verifică adresa sau creează-ți un cont și configurează manual.' }, { status: 422 });
  }
  const pretty = host.split('.')[0].split(/[-_]/).filter(Boolean)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') || host;
  const config = {
    businessName: pretty,
    website: host,
    tone: 'profesional',
    welcome: `Bună ziua! Ați contactat ${pretty} 😊 Cu ce vă putem ajuta?`,
    services: (res.services || []).slice(0, 12),
    knowledge: (res.knowledge || '').slice(0, 4000),
    description: (res.description || '').slice(0, 600),
    qualificationQuestions: [],
  };
  const id = uid('dp_');
  d.prepare('INSERT INTO demo_previews (id,ip,website,config,created_at) VALUES (?,?,?,?,?)')
    .run(id, ip, host, JSON.stringify(config), new Date().toISOString());
  return NextResponse.json({ ok: true, previewId: id, businessName: pretty, services: config.services.length, starters: heuristicStarters(config) });
}
