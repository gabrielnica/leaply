import { NextResponse } from 'next/server';
import { effectiveDemoConfig, accountStarters, heuristicStarters, PUBLIC_STARTERS } from '../../../../lib/demo';

export const dynamic = 'force-dynamic';

// Context pentru demo-ul din cont (/app/demo): datele afacerii + întrebări de start realiste.
// Nelogat → datele demo-ului public (folosit doar ca fallback).
export async function GET() {
  const { config, personalized, accountId } = effectiveDemoConfig('account');
  if (!personalized || !accountId) {
    return NextResponse.json({ personalized: false, businessName: config.businessName, welcome: config.welcome, starters: PUBLIC_STARTERS, configured: true });
  }
  // mostră din documente pentru starters mai bine ancorate în datele reale
  let docsSample = '';
  try {
    const { docsContext } = await import('../../../../lib/docs');
    docsSample = docsContext(accountId, `preț tarif ofertă program servicii ${(config.services || []).map((s: any) => s.name).join(' ')}`) || '';
  } catch {}
  let starters: string[];
  try { starters = await accountStarters(accountId, config, docsSample); }
  catch { starters = heuristicStarters(config); }
  return NextResponse.json({
    personalized: true,
    businessName: config.businessName,
    welcome: config.welcome || '',
    starters,
    configured: Boolean((config.services || []).length || config.knowledge || docsSample),
  });
}
