import { NextResponse } from 'next/server';
import { effectiveDemoConfig, demoStarters } from '../../../../lib/demo';

export const dynamic = 'force-dynamic';

// Context pentru pagina /demo: pe cine „joacă" asistentul și ce întrebări de start arătăm.
// Logat → datele afacerii utilizatorului; nelogat → demo-ul public (DentArt).
export async function GET() {
  const { config, personalized } = effectiveDemoConfig();
  return NextResponse.json({
    personalized,
    businessName: config.businessName || 'DentArt Studio',
    welcome: config.welcome || '',
    starters: demoStarters(config, personalized),
    configured: personalized ? Boolean((config.services || []).length || config.knowledge) : true,
  });
}
