import { NextRequest, NextResponse } from 'next/server';
import { lookupCui } from '../../../lib/anaf';
export const dynamic = 'force-dynamic';

// Public (folosit și în wizard, înainte de cont) — dar rate-limitat simplu în memorie.
const hits = new Map<string, { n: number; t: number }>();
export async function GET(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  const h = hits.get(ip) || { n: 0, t: Date.now() };
  if (Date.now() - h.t > 60_000) { h.n = 0; h.t = Date.now(); }
  if (++h.n > 10) return NextResponse.json({ ok: false, error: 'Prea multe încercări. Așteaptă un minut.' }, { status: 429 });
  hits.set(ip, h);
  const res = await lookupCui(req.nextUrl.searchParams.get('cui') || '');
  return NextResponse.json(res, { status: res.ok ? 200 : 404 });
}
