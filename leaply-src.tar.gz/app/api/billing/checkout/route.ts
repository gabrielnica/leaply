import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { changePlan } from '../../../../lib/stripe';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const plan = ['Start', 'Pro', 'Scale'].includes(b.plan) ? b.plan : null;
  if (!plan) return NextResponse.json({ error: 'Plan invalid' }, { status: 400 });
  const res = await changePlan(user.account_id, plan);
  if (res.error) return NextResponse.json({ error: res.error }, { status: 400 });
  return NextResponse.json(res.updated ? { updated: true } : { url: res.url });
}
