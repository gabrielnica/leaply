import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { getAccount } from '../../../../lib/store';
import { getIntegrations, setIntegration } from '../../../../lib/integrations';
import { accountAddons } from '../../../../lib/plan';
import { syncAddonItems } from '../../../../lib/stripe';
import { audit } from '../../../../lib/audit';
export const dynamic = 'force-dynamic';

// Add-on-uri SELF-SERVE: clientul adaugă/scoate pachete de resurse cu 1 click.
// Se facturează imediat ca subscription items (prorata). Cere abonament activ.
const UNITS: Record<string, { unit: number; max: number; label: string }> = {
  conv: { unit: 200, max: 10, label: '+200 conversații (19 €/lună)' },
  voice_min: { unit: 100, max: 10, label: '+100 minute voce (29 €/lună)' },
  sms: { unit: 500, max: 10, label: '+500 SMS (29 €/lună)' },
  numbers: { unit: 1, max: 10, label: 'număr suplimentar (12 €/lună)' },
};

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  if (!['owner', 'admin'].includes(user.role)) return NextResponse.json({ error: 'Doar proprietarul contului poate modifica abonamentul.' }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const kind = String(b.kind || '');
  const def = UNITS[kind];
  if (!def) return NextResponse.json({ error: 'Add-on necunoscut.' }, { status: 400 });
  const delta = b.delta === -1 ? -1 : 1;

  const plan = getAccount(user.account_id)?.plan || 'Trial';
  const subId = getIntegrations(user.account_id).stripe?.subscription_id;
  if (!['Start', 'Pro', 'Scale'].includes(plan) || !subId) {
    return NextResponse.json({ error: 'Extra resursele se adaugă pe un abonament activ. Alege întâi un pachet — apoi le activezi cu un click.' }, { status: 400 });
  }

  const cur = accountAddons(user.account_id);
  const packs = Math.round(((cur as any)[kind] || 0) / def.unit) + delta;
  if (packs < 0) return NextResponse.json({ error: 'Nu ai acest add-on activ.' }, { status: 400 });
  if (packs > def.max) return NextResponse.json({ error: `Maxim ${def.max} pachete de acest tip — pentru mai mult, scrie-ne la salut@leaply.ro.` }, { status: 400 });

  const next = { ...cur, [kind]: packs * def.unit };
  // întâi facturăm în Stripe; salvăm limitele DOAR dacă facturarea a reușit
  const billing = await syncAddonItems(user.account_id, next);
  if (!billing.ok) return NextResponse.json({ error: billing.error || 'Nu am putut actualiza abonamentul. Mai încearcă sau scrie-ne.' }, { status: 400 });
  const empty = !next.conv && !next.sms && !next.voice_min && !next.numbers;
  setIntegration(user.account_id, 'addons', empty ? null : next);
  audit(user.email, 'addons.self', user.account_id, next);
  return NextResponse.json({ ok: true, addons: next });
}
