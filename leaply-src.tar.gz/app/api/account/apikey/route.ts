import { NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { generateApiKey, revokeApiKey, apiKeyInfo } from '../../../../lib/apikey';
export const dynamic = 'force-dynamic';

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  return NextResponse.json({ key: apiKeyInfo(user.account_id) });
}
export async function POST(req: Request) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({} as any));
  if (b.action === 'revoke') { revokeApiKey(user.account_id); return NextResponse.json({ ok: true }); }
  const raw = generateApiKey(user.account_id);
  return NextResponse.json({ ok: true, key: raw }); // afișată o singură dată
}
