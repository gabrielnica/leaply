import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser, SESSION_COOKIE } from '../../../../lib/auth';
import { getAccount, deleteAccount } from '../../../../lib/store';
import { getIntegrations } from '../../../../lib/integrations';
import { cfg } from '../../../../lib/settings';
export const dynamic = 'force-dynamic';

// Ștergerea contului de către proprietar — GDPR + cerința Apple 5.1.1 (in-app account deletion).
// Necesită reconfirmarea numelui firmei. Anulează abonamentul Stripe (best-effort), apoi șterge tot.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  if (!['owner', 'admin'].includes(user.role)) {
    return NextResponse.json({ error: 'Doar proprietarul contului poate șterge contul.' }, { status: 403 });
  }
  const acc = getAccount(user.account_id);
  if (!acc) return NextResponse.json({ error: 'Cont inexistent' }, { status: 404 });
  if (user.account_id === 'acc_demo' || user.account_id === 'acc_leaply') {
    return NextResponse.json({ error: 'Acest cont nu poate fi șters.' }, { status: 400 });
  }
  const b = await req.json().catch(() => ({}));
  const confirmName = String(b.confirmName || '').trim();
  if (confirmName.toLowerCase() !== String(acc.name || '').trim().toLowerCase()) {
    return NextResponse.json({ error: 'Numele firmei nu se potrivește. Scrie exact numele ca să confirmi.' }, { status: 400 });
  }

  // Anulează abonamentul Stripe, dacă există (best-effort, nu blochează ștergerea)
  try {
    const sub = getIntegrations(user.account_id).stripe?.subscription_id;
    const key = cfg('STRIPE_SECRET_KEY');
    if (sub && key) {
      await fetch(`https://api.stripe.com/v1/subscriptions/${sub}`, {
        method: 'DELETE', headers: { Authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(8000),
      }).catch(() => {});
    }
  } catch {}

  console.log(`[leaply] ștergere cont ${user.account_id} (${acc.name}) de către ${user.email}`);
  const r = deleteAccount(user.account_id);
  if (!r.ok) return NextResponse.json({ error: 'Ștergerea a eșuat. Scrie-ne la salut@leaply.ro.' }, { status: 500 });

  const out = NextResponse.json({ ok: true });
  out.cookies.set(SESSION_COOKIE, '', { httpOnly: true, path: '/', expires: new Date(0) });
  return out;
}
