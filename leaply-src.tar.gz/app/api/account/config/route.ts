import { NextRequest, NextResponse } from 'next/server';
import { getAccount, updateAccountConfig } from '../../../../lib/store';
export const dynamic = 'force-dynamic';
export async function GET() { return NextResponse.json(getAccount().config); }
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  updateAccountConfig('acc_demo', body);
  return NextResponse.json({ ok: true });
}
