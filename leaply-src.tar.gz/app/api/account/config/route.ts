import { NextRequest, NextResponse } from 'next/server';
import { getAccount, updateAccountConfig } from '../../../../lib/store';
import { getSessionUser } from '../../../../lib/auth';
export const dynamic = 'force-dynamic';

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const acc = getAccount(user.account_id);
  if (!acc) return NextResponse.json({ error: 'Cont negăsit' }, { status: 404 });
  return NextResponse.json(acc.config);
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== 'object' || Array.isArray(body) || typeof body.welcome !== 'string') {
    return NextResponse.json({ error: 'Config invalid' }, { status: 400 });
  }
  updateAccountConfig(user.account_id, body);
  return NextResponse.json({ ok: true });
}
