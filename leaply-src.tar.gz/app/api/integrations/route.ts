import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { getIntegrations, setIntegration } from '../../../lib/integrations';
import { gcalConfigured } from '../../../lib/gcal';
import { stripeConfigured } from '../../../lib/stripe';
import { metaConfigured, getPendingPages } from '../../../lib/meta';
import { usageThisMonth, limitFor } from '../../../lib/usage';
import { getAccount } from '../../../lib/store';
import { trialDaysLeft, trialEndsAt } from '../../../lib/plan';
export const dynamic = 'force-dynamic';

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const i = getIntegrations(user.account_id);
  const acc = getAccount(user.account_id);
  const plan = acc?.plan || 'Trial';
  const isPaid = ['Start', 'Pro', 'Scale'].includes(plan);
  return NextResponse.json({
    plan,
    accountName: acc?.name || '',
    canDelete: ['owner', 'admin'].includes(user.role),
    usage: (() => {
      const { convLimitFor } = require('../../../lib/usage');
      const { accountAddons } = require('../../../lib/plan');
      return { used: usageThisMonth(user.account_id), limit: convLimitFor(user.account_id, plan), addons: accountAddons(user.account_id) };
    })(),
    trial: plan === 'Trial' ? { daysLeft: trialDaysLeft(user.account_id), endsAt: trialEndsAt(user.account_id) } : null,
    subscription: isPaid ? { since: i.stripe?.since || null, renewsAt: i.stripe?.renews_at || null, status: i.stripe?.status || 'active' } : null,
    google: { configured: gcalConfigured(), connected: Boolean(i.google?.refresh_token), email: i.google?.email || null },
    meta: { configured: metaConfigured(), pendingPages: (getPendingPages(user.account_id) || []).length },
    webhookOut: { url: i.webhookOut?.url || '', hasSecret: Boolean(i.webhookOut?.secret) },
    notify: { email: i.notify?.email !== false, push: i.notify?.push !== false },
    followup: i.followup || { enabled: true, hours: 4, text: '' },
    billing: i.billing || {},
    stripe: { configured: stripeConfigured() },
  });
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));

  if (b.action === 'google_disconnect') {
    setIntegration(user.account_id, 'google', null);
    return NextResponse.json({ ok: true });
  }
  if (b.action === 'webhook_out') {
    const url = String(b.url || '').trim();
    if (url && !/^https:\/\/.+/.test(url)) return NextResponse.json({ error: 'URL-ul trebuie să fie https://' }, { status: 400 });
    setIntegration(user.account_id, 'webhookOut', url ? { url, secret: String(b.secret || '').trim() || undefined } : null);
    return NextResponse.json({ ok: true });
  }
  if (b.action === 'followup') {
    const steps = Array.isArray(b.steps)
      ? b.steps.map((x: any) => Number(x)).filter((x: number) => x >= 1 && x <= 720).slice(0, 5)
      : undefined;
    setIntegration(user.account_id, 'followup', {
      enabled: b.enabled !== false,
      hours: [2, 4, 8, 24].includes(Number(b.hours)) ? Number(b.hours) : 4,
      ...(steps && steps.length ? { steps } : {}),
      text: String(b.text || '').slice(0, 300),
    });
    return NextResponse.json({ ok: true });
  }
  if (b.action === 'billing') {
    setIntegration(user.account_id, 'billing', {
      company: String(b.company || '').slice(0, 160),
      cif: String(b.cif || '').slice(0, 40),
      address: String(b.address || '').slice(0, 200),
      city: String(b.city || '').slice(0, 80),
      email: String(b.email || '').slice(0, 160),
    });
    return NextResponse.json({ ok: true });
  }
  if (b.action === 'notify') {
    const cur = getIntegrations(user.account_id).notify || {};
    const next = { ...cur };
    if ('email' in b) next.email = Boolean(b.email);
    if ('push' in b) next.push = Boolean(b.push);
    setIntegration(user.account_id, 'notify', next);
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: 'Acțiune necunoscută' }, { status: 400 });
}
