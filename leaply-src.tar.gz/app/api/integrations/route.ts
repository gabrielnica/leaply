import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../lib/auth';
import { getIntegrations, setIntegration } from '../../../lib/integrations';
import { gcalConfigured } from '../../../lib/gcal';
import { stripeConfigured } from '../../../lib/stripe';
import { metaConfigured, getPendingPages } from '../../../lib/meta';
import { usageThisMonth, limitFor } from '../../../lib/usage';
import { getAccount } from '../../../lib/store';
export const dynamic = 'force-dynamic';

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const i = getIntegrations(user.account_id);
  const acc = getAccount(user.account_id);
  const plan = acc?.plan || 'Trial';
  return NextResponse.json({
    plan,
    usage: { used: usageThisMonth(user.account_id), limit: limitFor(plan) },
    google: { configured: gcalConfigured(), connected: Boolean(i.google?.refresh_token), email: i.google?.email || null },
    meta: { configured: metaConfigured(), pendingPages: (getPendingPages(user.account_id) || []).length },
    webhookOut: { url: i.webhookOut?.url || '', hasSecret: Boolean(i.webhookOut?.secret) },
    notify: { email: i.notify?.email !== false },
    stripe: { configured: stripeConfigured() },
  });
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));

  if (b.action === 'google_disconnect') {
    setIntegration(user.account_id, 'google', null);
    return NextResponse.json({ ok: true });
  }
  if (b.action === 'webhook_out') {
    const url = String(b.url || '').trim();
    if (url && !/^https:\/\/.+/.test(url)) return NextResponse.json({ error: 'URL-ul trebuie să fie https://' }, { status: 400 });
    setIntegration(user.account_id, 'webhookOut', url ? { url, secret: String(b.secret || '').trim() || undefined } : null);
    return NextResponse.json({ ok: true });
  }
  if (b.action === 'notify') {
    setIntegration(user.account_id, 'notify', { email: Boolean(b.email) });
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: 'Acțiune necunoscută' }, { status: 400 });
}
