import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { cfg, appUrl } from '../../../../../lib/settings';
import { getSessionUser } from '../../../../../lib/auth';
export const dynamic = 'force-dynamic';

// WhatsApp Embedded Signup: clientul își conectează PROPRIUL număr pe Meta Cloud API
// dintr-un popup Facebook — fără chei, fără pași tehnici. Necesită App Review aprobat
// + META_WA_CONFIG_ID (configurația de Embedded Signup din Facebook Login for Business).
const sign = (s: string) => crypto.createHmac('sha256', cfg('META_VERIFY_TOKEN') || 'leaply_state').update(s).digest('hex').slice(0, 24);

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.redirect(new URL('/login', appUrl()));
  if (!cfg('META_APP_ID') || !cfg('META_WA_CONFIG_ID')) {
    return NextResponse.redirect(new URL('/app/channels?wa=unconfigured', appUrl()));
  }
  // gating: WhatsApp e de la Complet în sus
  const { getAccount } = await import('../../../../../lib/store');
  const { channelAllowed } = await import('../../../../../lib/plan');
  const plan = getAccount(user.account_id)?.plan || 'Trial';
  if (!channelAllowed(plan, 'whatsapp')) return NextResponse.redirect(new URL('/app/channels?meta=plan', appUrl()));

  const state = `${user.account_id}.${sign(user.account_id)}`;
  const p = new URLSearchParams({
    client_id: cfg('META_APP_ID'),
    redirect_uri: `${appUrl()}/api/integrations/whatsapp/callback`,
    response_type: 'code',
    config_id: cfg('META_WA_CONFIG_ID'),
    override_default_response_type: 'true',
    state,
  });
  return NextResponse.redirect(`https://www.facebook.com/v19.0/dialog/oauth?${p}`);
}
