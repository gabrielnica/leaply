import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { cfg, appUrl } from '../../../../../lib/settings';
import { setChannelCreds } from '../../../../../lib/channels';
import { audit } from '../../../../../lib/audit';
export const dynamic = 'force-dynamic';

// Callback Embedded Signup WhatsApp: schimbăm codul pe token, găsim WABA + numărul,
// îl înregistrăm pe Cloud API și abonăm aplicația la webhooks — totul automat.
const G = 'https://graph.facebook.com/v19.0';
const sign = (s: string) => crypto.createHmac('sha256', cfg('META_VERIFY_TOKEN') || 'leaply_state').update(s).digest('hex').slice(0, 24);
const fail = (why: string) => NextResponse.redirect(new URL(`/app/channels?wa=error&why=${encodeURIComponent(why.slice(0, 60))}`, appUrl()));

export async function GET(req: NextRequest) {
  const q = new URL(req.url).searchParams;
  const code = q.get('code') || '';
  const state = q.get('state') || '';
  const [accId, sig] = state.split('.');
  if (!code || !accId || sig !== sign(accId)) return fail('state');
  try {
    // 1. code → business token
    const tp = new URLSearchParams({
      client_id: cfg('META_APP_ID'), client_secret: cfg('META_APP_SECRET'),
      redirect_uri: `${appUrl()}/api/integrations/whatsapp/callback`, code,
    });
    const tr = await fetch(`${G}/oauth/access_token?${tp}`, { signal: AbortSignal.timeout(12000) });
    const tj: any = await tr.json().catch(() => ({}));
    const token = tj.access_token;
    if (!token) return fail('token');

    // 2. WABA id din granular_scopes (debug_token)
    const dr = await fetch(`${G}/debug_token?input_token=${encodeURIComponent(token)}&access_token=${cfg('META_APP_ID')}|${cfg('META_APP_SECRET')}`, { signal: AbortSignal.timeout(12000) });
    const dj: any = await dr.json().catch(() => ({}));
    const scopes: any[] = dj?.data?.granular_scopes || [];
    const wabaId = scopes.find(s => s.scope === 'whatsapp_business_management')?.target_ids?.[0]
      || scopes.find(s => s.scope === 'whatsapp_business_messaging')?.target_ids?.[0];
    if (!wabaId) return fail('waba');

    // 3. numărul de telefon din WABA
    const pr = await fetch(`${G}/${wabaId}/phone_numbers?access_token=${encodeURIComponent(token)}`, { signal: AbortSignal.timeout(12000) });
    const pj: any = await pr.json().catch(() => ({}));
    const phone = pj?.data?.[0];
    if (!phone?.id) return fail('phone');
    const display = String(phone.display_phone_number || '').replace(/[^\d+]/g, '');

    // 4. înregistrare pe Cloud API + abonare webhooks (best-effort — pot fi deja făcute)
    await fetch(`${G}/${phone.id}/register`, {
      method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', pin: '000000' }),
      signal: AbortSignal.timeout(12000),
    }).catch(() => {});
    await fetch(`${G}/${wabaId}/subscribed_apps`, {
      method: 'POST', headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(12000),
    }).catch(() => {});

    // 5. legăm canalul de cont — de aici totul curge prin motorul existent
    setChannelCreds(accId, 'whatsapp', {
      provider: 'meta', phone_number_id: String(phone.id), access_token: token,
      ...(display ? { from_number: display.startsWith('+') ? display : '+' + display } : {}),
    }, `WhatsApp ${phone.display_phone_number || ''} (numărul tău, Cloud API)`);
    audit('embedded-signup', 'whatsapp.connect', accId, { phone: phone.display_phone_number, waba: wabaId });
    return NextResponse.redirect(new URL('/app/channels?wa=connected', appUrl()));
  } catch (e) {
    console.error('[wa embedded]', String(e).slice(0, 200));
    return fail('exception');
  }
}
