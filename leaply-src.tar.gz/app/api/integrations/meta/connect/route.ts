import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { cfg, appUrl } from '../../../../../lib/settings';
import { getSessionUser } from '../../../../../lib/auth';
import { metaAuthUrl, metaConfigured } from '../../../../../lib/meta';
export const dynamic = 'force-dynamic';

const sign = (s: string) => crypto.createHmac('sha256', cfg('META_VERIFY_TOKEN') || 'leaply_state').update(s).digest('hex').slice(0, 24);

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.redirect(new URL('/login', appUrl()));
  if (!metaConfigured()) return NextResponse.redirect(new URL('/app/channels?meta=unconfigured', appUrl()));
  const state = `${user.account_id}.${sign(user.account_id)}`;
  return NextResponse.redirect(metaAuthUrl(state));
}
