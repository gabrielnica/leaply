import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { cfg, appUrl } from '../../../../../lib/settings';
import { metaExchangeCode, listPages, connectPage, setPendingPages } from '../../../../../lib/meta';
export const dynamic = 'force-dynamic';

const sign = (s: string) => crypto.createHmac('sha256', cfg('META_VERIFY_TOKEN') || 'leaply_state').update(s).digest('hex').slice(0, 24);
const back = (q: string) => NextResponse.redirect(new URL(`/app/channels?meta=${q}`, appUrl()));

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state') || '';
  const [accId, sig] = state.split('.');
  if (!code || !accId || sig !== sign(accId)) return back('error');

  const token = await metaExchangeCode(code);
  if (!token) return back('error');
  const pages = await listPages(token);
  if (pages.length === 0) return back('nopages');
  if (pages.length === 1) {
    const res = await connectPage(accId, pages[0]);
    return back(res.instagram ? 'connected_ig' : 'connected');
  }
  setPendingPages(accId, pages);
  return back('choose');
}
