import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../../lib/auth';
import { getPendingPages, connectPage } from '../../../../../lib/meta';
export const dynamic = 'force-dynamic';

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const pages = getPendingPages(user.account_id) || [];
  // fără tokenuri în răspuns
  return NextResponse.json({ pages: pages.map(p => ({ id: p.id, name: p.name, ig: p.ig?.username || null })) });
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const pages = getPendingPages(user.account_id) || [];
  const page = pages.find(p => p.id === String(b.page_id || ''));
  if (!page) return NextResponse.json({ error: 'Pagina nu mai e disponibilă — reconectează cu Facebook.' }, { status: 400 });
  const res = await connectPage(user.account_id, page);
  return NextResponse.json({ ok: true, ...res });
}
