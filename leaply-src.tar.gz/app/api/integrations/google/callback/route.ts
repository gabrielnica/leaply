import { NextRequest, NextResponse } from 'next/server';
import { cfg, appUrl } from '../../../../../lib/settings';
import crypto from 'crypto';
import { exchangeCode } from '../../../../../lib/gcal';
import { setIntegration, getIntegrations } from '../../../../../lib/integrations';
export const dynamic = 'force-dynamic';

const sign = (s: string) => crypto.createHmac('sha256', cfg('META_VERIFY_TOKEN') || 'leaply_state').update(s).digest('hex').slice(0, 24);

export async function GET(req: NextRequest) {
  const base = appUrl();
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state') || '';
  const [accId, sig] = state.split('.');
  if (!code || !accId || sig !== sign(accId)) {
    return NextResponse.redirect(new URL('/app/settings?google=error', base));
  }
  const tok = await exchangeCode(code);
  if (!tok?.refresh_token) {
    // fără refresh_token (ex. re-consimțământ) — păstrăm ce era
    const existing = getIntegrations(accId).google;
    if (!existing) return NextResponse.redirect(new URL('/app/settings?google=error', base));
    return NextResponse.redirect(new URL('/app/settings?google=connected', base));
  }
  setIntegration(accId, 'google', { refresh_token: tok.refresh_token, email: tok.email || '', calendar_id: 'primary' });
  return NextResponse.redirect(new URL('/app/settings?google=connected', base));
}
