import { NextResponse } from 'next/server';
import { cfg, appUrl } from '../../../../../lib/settings';
import crypto from 'crypto';
import { getSessionUser } from '../../../../../lib/auth';
import { authUrl, gcalConfigured } from '../../../../../lib/gcal';
export const dynamic = 'force-dynamic';

const sign = (s: string) => crypto.createHmac('sha256', cfg('META_VERIFY_TOKEN') || 'leaply_state').update(s).digest('hex').slice(0, 24);

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.redirect(new URL('/login', appUrl()));
  if (!gcalConfigured()) {
    return NextResponse.redirect(new URL('/app/settings?google=unconfigured', appUrl()));
  }
  const state = `${user.account_id}.${sign(user.account_id)}`;
  return NextResponse.redirect(authUrl(state));
}
