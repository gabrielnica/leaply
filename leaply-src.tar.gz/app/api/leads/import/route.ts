import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db, uid } from '../../../../lib/db';
import { sendSms } from '../../../../lib/sms';
import { audit } from '../../../../lib/audit';
import { getAccount } from '../../../../lib/store';
import { allowSms } from '../../../../lib/plan';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/** Import CSV de lead-uri (nume,telefon[,sursă]) + campanie opțională de reactivare pe SMS.
 *  Trimiterea presupune că clientul are consimțământul persoanelor din listă. */
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const lines = String(b.csv || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean).slice(0, 200);
  const campaign = Boolean(b.campaign);
  const message = String(b.message || '').slice(0, 300);
  if (!lines.length) return NextResponse.json({ error: 'CSV gol. Format: nume,telefon pe fiecare rând.' }, { status: 400 });
  if (campaign && !message) return NextResponse.json({ error: 'Scrie mesajul campaniei.' }, { status: 400 });

  const d = db(); const now = new Date().toISOString();
  let imported = 0, sent = 0, skipped = 0;
  for (const line of lines) {
    const [rawName, rawPhone, rawSource] = line.split(/[,;\t]/).map(x => (x || '').trim().replace(/^"|"$/g, ''));
    const phone = (rawPhone || rawName || '').replace(/[^\d+]/g, '');
    const name = /\d{6,}/.test(rawName || '') ? 'Lead importat' : (rawName || 'Lead importat');
    if (phone.replace(/\D/g, '').length < 9) { skipped++; continue; }
    if (d.prepare('SELECT id FROM leads WHERE account_id=? AND phone=?').get(user.account_id, phone)) { skipped++; continue; }
    const leadId = uid('ld_'); const convId = uid('cv_');
    d.transaction(() => {
      d.prepare('INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)')
        .run(leadId, user.account_id, name.slice(0, 120), phone, (rawSource || 'import CSV').slice(0, 60), 'cold', now);
      d.prepare('INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(convId, user.account_id, leadId, 'import', 'active', 0, '{}', now, now);
      d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)')
        .run(uid('ms_'), convId, 'note', 'system', 'Lead importat din CSV.', now);
    })();
    imported++;
    if (campaign && sent < 100) {
      const plan = getAccount(user.account_id)?.plan || 'Trial';
      if (!allowSms(user.account_id, plan)) { continue; } // plafonul lunar de SMS al planului e atins
      const ok = await sendSms(phone, message).catch(() => false);
      if (ok) {
        d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)')
          .run(uid('ms_'), convId, 'out', 'followup', message, new Date().toISOString());
        sent++;
      }
    }
  }
  audit(user.email, 'leads.import', user.account_id, { imported, sent, skipped, campaign });
  return NextResponse.json({ ok: true, imported, sent, skipped });
}
