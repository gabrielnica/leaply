import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

// 👍/👎 pe un răspuns AI. 👍 = exemplu few-shot în prompt; 0 = anulează.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const id = String(b.id || '');
  const rating = [1, -1, 0].includes(b.rating) ? b.rating : null;
  if (!id || rating === null) return NextResponse.json({ error: 'id + rating (1/-1/0)' }, { status: 400 });
  const row: any = db().prepare(`
    SELECT m.id FROM messages m JOIN conversations c ON c.id = m.conversation_id
    WHERE m.id = ? AND c.account_id = ? AND m.sender = 'ai'`).get(id, user.account_id);
  if (!row && user.role !== 'admin') return NextResponse.json({ error: 'Mesaj negăsit' }, { status: 404 });
  db().prepare('UPDATE messages SET rating=? WHERE id=?').run(rating === 0 ? null : rating, id);
  return NextResponse.json({ ok: true, rating: rating === 0 ? null : rating });
}
