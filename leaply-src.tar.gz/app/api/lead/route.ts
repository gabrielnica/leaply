import { NextRequest, NextResponse } from 'next/server';
import { db, uid } from '../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const name = (b.name || '').toString().slice(0, 120) || 'Vizitator';
  const contact = (b.contact || '').toString().slice(0, 160);
  const business = (b.business || '').toString().slice(0, 160);
  const vertical = (b.vertical || '').toString().slice(0, 80);
  if (!contact) return NextResponse.json({ ok: false, error: 'contact required' }, { status: 400 });
  const d = db(); const now = new Date().toISOString();

  // 1. Cererea de demo — datele de contact rămân salvate chiar dacă nu continuă wizard-ul
  const drId = uid('dr_');
  d.prepare('INSERT INTO demo_requests (id,name,contact,business,vertical,status,created_at) VALUES (?,?,?,?,?,?,?)')
    .run(drId, name, contact, business, vertical, 'nou', now);

  // 2. Apare și ca lead în inbox-ul demo (Leaply își folosește propriul produs)
  const leadId = uid('ld_'); const convId = uid('cv_');
  d.transaction(() => {
    d.prepare('INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(leadId, 'acc_demo', name, contact, 'leaply.ro (landing)', 'hot', now);
    d.prepare('INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(convId, 'acc_demo', leadId, 'landing', 'qualified', 0, JSON.stringify({ business, vertical }), now, now);
    d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)')
      .run(uid('ms_'), convId, 'in', 'lead', `Cerere demo de pe leaply.ro — ${business || 'firmă'} (${vertical || 'nespecificat'}).`, now);
  })();

  return NextResponse.json({ ok: true, demoRequestId: drId, next: '/start' });
}
