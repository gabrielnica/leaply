import { NextRequest, NextResponse } from 'next/server';
import { db, uid } from '../../../../lib/db';
import { getAccount, addMessage, updateConversation } from '../../../../lib/store';
import { nextReply, Turn } from '../../../../lib/brain';
import { overLimit } from '../../../../lib/usage';
import { emitWebhookOut, getOwnerEmail } from '../../../../lib/integrations';
import { sendMail } from '../../../../lib/mail';
export const dynamic = 'force-dynamic';

// API-ul public al widgetului de chat instalat pe site-urile clienților.
// CORS deschis (rulează pe domeniile lor); identificare prin account id + session id.
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};
export async function OPTIONS() { return new NextResponse(null, { headers: CORS }); }

const hits = new Map<string, { n: number; t: number }>();

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const accId = String(b.account || '').slice(0, 40);
  const sid = String(b.session || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 48);
  const message = String(b.message || '').slice(0, 1000).trim();
  if (!accId || !sid || !message) return NextResponse.json({ error: 'account, session și message sunt obligatorii' }, { status: 400, headers: CORS });

  // rate limit per sesiune: 20 mesaje / 5 min
  const h = hits.get(sid) || { n: 0, t: Date.now() };
  if (Date.now() - h.t > 300_000) { h.n = 0; h.t = Date.now(); }
  if (++h.n > 20) return NextResponse.json({ reply: 'Ați trimis foarte multe mesaje — un coleg vă va prelua conversația în scurt timp.' }, { headers: CORS });
  hits.set(sid, h);

  const acc = getAccount(accId);
  if (!acc) return NextResponse.json({ error: 'Cont necunoscut' }, { status: 404, headers: CORS });
  if (overLimit(accId, acc.plan)) {
    return NextResponse.json({ reply: `Mulțumim pentru mesaj! Un coleg de la ${acc.config?.businessName || 'echipa noastră'} vă va răspunde personal în cel mai scurt timp.` }, { headers: CORS });
  }

  const d = db(); const now = new Date().toISOString();
  const marker = `widget:${sid}`;
  let conv: any = d.prepare(
    "SELECT c.id, c.status FROM conversations c JOIN leads l ON l.id=c.lead_id WHERE c.account_id=? AND l.phone=? ORDER BY c.created_at DESC LIMIT 1"
  ).get(accId, marker);
  let isNew = false;
  if (!conv) {
    isNew = true;
    const leadId = uid('ld_'); const convId = uid('cv_');
    d.transaction(() => {
      d.prepare('INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)')
        .run(leadId, accId, `Vizitator site`, marker, 'widget site', 'warm', now);
      d.prepare('INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(convId, accId, leadId, 'webform', 'active', 0, '{}', now, now);
    })();
    conv = { id: convId, status: 'active' };
  }
  addMessage(conv.id, 'in', 'lead', message);
  if (conv.status === 'human') return NextResponse.json({ reply: null, human: true }, { headers: CORS });

  const rows: any[] = d.prepare("SELECT sender, body FROM messages WHERE conversation_id=? AND sender IN ('lead','ai') ORDER BY created_at").all(conv.id);
  const history: Turn[] = rows.map(r => ({ sender: r.sender === 'ai' ? 'ai' : 'lead', body: r.body }));
  const res = await nextReply(acc.config || {}, history);
  addMessage(conv.id, 'out', 'ai', res.reply);
  updateConversation(conv.id, { status: res.status, score: res.score, qualification: res.qualification });

  // dacă lead-ul a lăsat un telefon în mesaj, îl promovăm pe lead
  const phone = message.match(/(\+?4?0?7\d{8})/)?.[1];
  if (phone) d.prepare('UPDATE leads SET phone=?, name=? WHERE phone=?').run(phone.startsWith('+') ? phone : '+4' + phone.replace(/^4?0/, '0'), 'Lead widget', marker);

  if (isNew) {
    const email = getOwnerEmail(accId);
    if (email) sendMail(email, 'Lead nou de pe site (widget)', `<p>Un vizitator a început o conversație pe site-ul tău. O găsești în inbox-ul Leaply.</p>`).catch(() => {});
  }
  emitWebhookOut(accId, isNew ? 'lead.created' : 'lead.updated', { conversation_id: conv.id, channel: 'webform', status: res.status }).catch(() => {});
  return NextResponse.json({ reply: res.reply, status: res.status }, { headers: CORS });
}
