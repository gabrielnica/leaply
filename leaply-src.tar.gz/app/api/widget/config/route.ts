import { NextRequest, NextResponse } from 'next/server';
import { getAccount } from '../../../../lib/store';
export const dynamic = 'force-dynamic';
const CORS = { 'Access-Control-Allow-Origin': '*' };

export async function GET(req: NextRequest) {
  const acc = getAccount(String(req.nextUrl.searchParams.get('account') || '').slice(0, 40));
  if (!acc) return NextResponse.json({ error: 'Cont necunoscut' }, { status: 404, headers: CORS });
  return NextResponse.json({
    name: acc.config?.businessName || acc.name || 'Asistent',
    welcome: acc.config?.welcome || 'Bună! Cu ce vă putem ajuta?',
    // Pachetul Total (Scale): widget alb, fără „powered by Leaply"
    hideBranding: acc.plan === 'Scale',
    teaser: acc.config?.widgetTeaser || 'Aveți o întrebare? Vă răspundem în sub un minut. 👋',
  }, { headers: CORS });
}
