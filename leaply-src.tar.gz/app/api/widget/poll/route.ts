import { NextRequest, NextResponse } from 'next/server';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

const CORS = { 'Access-Control-Allow-Origin': '*' };

// Polling-ul widgetului: vizitatorul primește răspunsurile scrise MANUAL de owner
// (sender='agent') după ce conversația a fost preluată. Cursor = timestamp ISO.
export async function GET(req: NextRequest) {
  const accId = String(req.nextUrl.searchParams.get('account') || '').slice(0, 40);
  const sid = String(req.nextUrl.searchParams.get('session') || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 48);
  const after = String(req.nextUrl.searchParams.get('after') || '');
  if (!accId || !sid) return NextResponse.json({ error: 'account + session' }, { status: 400, headers: CORS });
  const d = db();
  const conv: any = d.prepare(
    "SELECT c.id, c.status FROM conversations c JOIN leads l ON l.id=c.lead_id WHERE c.account_id=? AND l.phone=? ORDER BY c.created_at DESC LIMIT 1"
  ).get(accId, `widget:${sid}`);
  if (!conv) return NextResponse.json({ messages: [], human: false }, { headers: CORS });
  const rows: any[] = d.prepare(
    "SELECT body, created_at FROM messages WHERE conversation_id=? AND sender='agent' AND created_at > ? ORDER BY created_at LIMIT 20"
  ).all(conv.id, after || '1970');
  return NextResponse.json({
    messages: rows.map(r => ({ body: r.body, at: r.created_at })),
    human: conv.status === 'human',
  }, { headers: CORS });
}
