import { NextRequest, NextResponse } from 'next/server';
import { resolveApiKey } from '../../../../lib/apikey';
import { db } from '../../../../lib/db';
import { createInboundConversation } from '../../../../lib/store';

export const dynamic = 'force-dynamic';

const unauthorized = () => NextResponse.json({ error: 'API key invalid. Trimite header Authorization: Bearer lp_...' }, { status: 401 });

/** GET /api/v1/leads — listă lead-uri (filtre: ?score=hot&limit=50&offset=0) */
export async function GET(req: NextRequest) {
  const accId = resolveApiKey(req.headers.get('authorization'));
  if (!accId) return unauthorized();
  const sp = req.nextUrl.searchParams;
  const limit = Math.min(Number(sp.get('limit')) || 50, 200);
  const offset = Math.max(Number(sp.get('offset')) || 0, 0);
  const score = sp.get('score');
  const rows = db().prepare(`SELECT l.id, l.name, l.phone, l.source, l.score, l.created_at,
      c.id conversation_id, c.channel, c.status, c.qualification
    FROM leads l LEFT JOIN conversations c ON c.lead_id = l.id
    WHERE l.account_id = ? ${score ? 'AND l.score = ?' : ''}
    ORDER BY l.created_at DESC LIMIT ? OFFSET ?`).all(...(score ? [accId, score, limit, offset] : [accId, limit, offset])) as any[];
  return NextResponse.json({ data: rows.map(r => ({ ...r, qualification: JSON.parse(r.qualification || '{}') })), limit, offset });
}

/** POST /api/v1/leads — creează lead + pornește conversația AI. Body: {name, phone, message?, channel?} */
export async function POST(req: NextRequest) {
  const accId = resolveApiKey(req.headers.get('authorization'));
  if (!accId) return unauthorized();
  const b = await req.json().catch(() => ({}));
  const name = String(b.name || '').slice(0, 120);
  const phone = String(b.phone || '').slice(0, 40);
  if (!name || !phone) return NextResponse.json({ error: 'name și phone sunt obligatorii' }, { status: 400 });
  const message = String(b.message || 'Lead nou din API').slice(0, 1000);
  const { convId, leadId } = createInboundConversation(accId, String(b.channel || 'api').slice(0, 20), name, phone, String(b.source || 'API').slice(0, 60), message);
  return NextResponse.json({ ok: true, lead_id: leadId, conversation_id: convId }, { status: 201 });
}
