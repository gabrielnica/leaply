import { NextRequest, NextResponse } from 'next/server';
import { resolveApiKey } from '../../../../lib/apikey';
import { stats } from '../../../../lib/store';
import { usageThisMonth, limitFor } from '../../../../lib/usage';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

/** GET /api/v1/stats — statistici cont: lead-uri, programări, utilizare plan */
export async function GET(req: NextRequest) {
  const accId = resolveApiKey(req.headers.get('authorization'));
  if (!accId) return NextResponse.json({ error: 'API key invalid' }, { status: 401 });
  const s = stats(accId);
  const plan = (db().prepare('SELECT plan FROM accounts WHERE id=?').get(accId) as any)?.plan || 'Trial';
  return NextResponse.json({ data: { ...s, plan, usage_month: usageThisMonth(accId), usage_limit: limitFor(plan) } });
}
