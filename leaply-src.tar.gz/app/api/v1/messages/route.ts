import { NextRequest, NextResponse } from 'next/server';
import { resolveApiKey } from '../../../../lib/apikey';
import { db } from '../../../../lib/db';
import { addMessage } from '../../../../lib/store';
import { sendReply } from '../../../../lib/channels';
export const dynamic = 'force-dynamic';

/** POST /api/v1/messages — trimite un mesaj manual într-o conversație (preia omul controlul).
 * Body: { conversation_id, body } */
export async function POST(req: NextRequest) {
  const accId = resolveApiKey(req.headers.get('authorization'));
  if (!accId) return NextResponse.json({ error: 'API key invalid' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const convId = String(b.conversation_id || '');
  const body = String(b.body || '').slice(0, 2000);
  if (!convId || !body) return NextResponse.json({ error: 'conversation_id și body sunt obligatorii' }, { status: 400 });
  const c: any = db().prepare('SELECT c.*, l.phone FROM conversations c JOIN leads l ON l.id=c.lead_id WHERE c.id=? AND c.account_id=?').get(convId, accId);
  if (!c) return NextResponse.json({ error: 'Conversație inexistentă' }, { status: 404 });
  addMessage(convId, 'out', 'human', body);
  const sent = await sendReply(accId, c.channel, c.phone, body).catch(() => false);
  return NextResponse.json({ ok: true, delivered: Boolean(sent) });
}
