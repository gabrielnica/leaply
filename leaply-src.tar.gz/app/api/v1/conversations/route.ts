import { NextRequest, NextResponse } from 'next/server';
import { resolveApiKey } from '../../../../lib/apikey';
import { db } from '../../../../lib/db';
import { rateLimited } from '../../../../lib/ratelimit';
export const dynamic = 'force-dynamic';

/** GET /api/v1/conversations — ?status=booked&channel=whatsapp&limit=50&offset=0 */
export async function GET(req: NextRequest) {
  const accId = resolveApiKey(req.headers.get('authorization'));
  if (!accId) return NextResponse.json({ error: 'API key invalid' }, { status: 401 });
  if (rateLimited('v1:' + accId)) return NextResponse.json({ error: 'Rate limit: max 120 cereri/minut.' }, { status: 429 });
  const sp = req.nextUrl.searchParams;
  const limit = Math.min(Number(sp.get('limit')) || 50, 200);
  const offset = Math.max(Number(sp.get('offset')) || 0, 0);
  const cond = ['c.account_id = ?']; const args: any[] = [accId];
  if (sp.get('status')) { cond.push('c.status = ?'); args.push(sp.get('status')); }
  if (sp.get('channel')) { cond.push('c.channel = ?'); args.push(sp.get('channel')); }
  const rows = db().prepare(`SELECT c.id, c.channel, c.status, c.qualification, c.created_at, c.updated_at,
      l.name lead_name, l.phone, l.score
    FROM conversations c JOIN leads l ON l.id = c.lead_id
    WHERE ${cond.join(' AND ')} ORDER BY c.updated_at DESC LIMIT ? OFFSET ?`).all(...args, limit, offset) as any[];
  return NextResponse.json({ data: rows.map(r => ({ ...r, qualification: JSON.parse(r.qualification || '{}') })), limit, offset });
}
