import { NextRequest, NextResponse } from 'next/server';
import { resolveApiKey } from '../../../../../lib/apikey';
import { db } from '../../../../../lib/db';
import { rateLimited } from '../../../../../lib/ratelimit';
export const dynamic = 'force-dynamic';

/** GET /api/v1/conversations/{id} — conversația + toate mesajele */
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const accId = resolveApiKey(req.headers.get('authorization'));
  if (!accId) return NextResponse.json({ error: 'API key invalid' }, { status: 401 });
  if (rateLimited('v1:' + accId)) return NextResponse.json({ error: 'Rate limit: max 120 cereri/minut.' }, { status: 429 });
  const c: any = db().prepare(`SELECT c.*, l.name lead_name, l.phone, l.score FROM conversations c
    JOIN leads l ON l.id = c.lead_id WHERE c.id = ? AND c.account_id = ?`).get(params.id, accId);
  if (!c) return NextResponse.json({ error: 'Conversație inexistentă' }, { status: 404 });
  c.qualification = JSON.parse(c.qualification || '{}');
  c.messages = db().prepare('SELECT id, direction, sender, body, created_at FROM messages WHERE conversation_id = ? ORDER BY created_at').all(params.id);
  return NextResponse.json({ data: c });
}
