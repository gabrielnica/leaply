import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { listSettings, setSetting } from '../../../../lib/settings';
import { llmActive } from '../../../../lib/llm';
export const dynamic = 'force-dynamic';

export async function GET() {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  return NextResponse.json({ groups: listSettings(), llmActive: llmActive() });
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  try {
    setSetting(String(b.key || ''), String(b.value ?? '').trim());
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Eroare' }, { status: 400 });
  }
}
