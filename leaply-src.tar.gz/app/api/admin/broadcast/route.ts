import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { audit } from '../../../../lib/audit';
import { sendMail } from '../../../../lib/mail';
import { getOwnerEmail } from '../../../../lib/integrations';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// Anunț către toți clienții (sau test către admin). Batch secvențial, best-effort per cont.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const subject = String(b.subject || '').trim().slice(0, 150);
  const body = String(b.body || '').trim().slice(0, 8000);
  if (!subject || !body) return NextResponse.json({ error: 'Subiect + conținut' }, { status: 400 });
  const html = body.split(/\n{2,}/).map(p => `<p>${p.replace(/\n/g, '<br/>')}</p>`).join('');

  if (b.test) {
    await sendMail(user.email, `[TEST] ${subject}`, html);
    return NextResponse.json({ ok: true, sent: 1, test: true });
  }

  const accounts: any[] = db().prepare("SELECT id FROM accounts WHERE id NOT IN ('acc_demo','acc_leaply') AND (suspended IS NULL OR suspended=0) AND parent_id IS NULL").all();
  let sent = 0;
  for (const a of accounts) {
    try {
      const email = getOwnerEmail(a.id);
      if (!email) continue;
      if (await sendMail(email, subject, html)) sent++;
    } catch { /* per-cont best-effort */ }
  }
  audit(user.email, 'broadcast.send', '', { subject, sent, total: accounts.length });
  return NextResponse.json({ ok: true, sent, total: accounts.length });
}
