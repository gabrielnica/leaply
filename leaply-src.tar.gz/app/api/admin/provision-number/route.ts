import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { provisionNumber } from '../../../../lib/twilio';
export const dynamic = 'force-dynamic';

// Admin: provisionează automat un număr Twilio pentru o cerere („Cere număr de la Leaply").
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin.' }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const reqId = String(b.request_id || '');
  const row: any = db().prepare('SELECT id, account_id, vertical, status FROM demo_requests WHERE id=?').get(reqId);
  if (!row || !row.account_id || !['whatsapp_number', 'voice_number'].includes(row.vertical)) {
    return NextResponse.json({ error: 'Cerere de număr inexistentă.' }, { status: 404 });
  }
  const kind = row.vertical === 'voice_number' ? 'voice' as const : 'whatsapp' as const;
  const res = await provisionNumber(row.account_id, kind);
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
  db().prepare('UPDATE demo_requests SET status=? WHERE id=?')
    .run(kind === 'voice' ? `număr activat: ${res.number}` : `număr rezervat: ${res.number} (de înregistrat pe WhatsApp)`, reqId);
  return NextResponse.json({ ok: true, number: res.number, kind });
}
