import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import { getSessionUser } from '../../../../lib/auth';
import { backupDb, latestBackup, listBackups } from '../../../../lib/backup';
export const dynamic = 'force-dynamic';

/** Admin: GET → listă backup-uri; GET ?download=1 → descarcă cel mai recent (copie off-server);
 *  POST → face un backup pe loc. */
export async function GET(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  if (req.nextUrl.searchParams.get('download')) {
    const last = latestBackup() || (await backupDb().then(b => ({ file: b.file, size: b.size, mtime: new Date().toISOString() })));
    const data = fs.readFileSync(last.file);
    return new NextResponse(data, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${last.file.split('/').pop()}"`,
        'Content-Length': String(data.length),
      },
    });
  }
  return NextResponse.json({ backups: listBackups() });
}
export async function POST() {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const b = await backupDb();
  return NextResponse.json({ ok: true, file: b.file.split('/').pop(), size: b.size });
}
