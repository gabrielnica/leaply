import { NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

// Export CSV cu toate conturile — pentru Excel / analiză / contabilitate.
export async function GET() {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const month = new Date().toISOString().slice(0, 7);
  const rows: any[] = db().prepare(`
    SELECT a.id, a.name, a.plan, a.vertical, a.created_at, a.suspended,
      (SELECT email FROM users u WHERE u.account_id = a.id ORDER BY u.created_at LIMIT 1) owner_email,
      (SELECT COUNT(*) FROM conversations c WHERE c.account_id = a.id) leads,
      (SELECT COUNT(*) FROM conversations c WHERE c.account_id = a.id AND c.status='booked') booked,
      (SELECT COUNT(*) FROM conversations c WHERE c.account_id = a.id AND c.created_at LIKE ? || '%') conv_month,
      (SELECT COUNT(*) FROM channels ch WHERE ch.account_id = a.id AND ch.status='connected') channels_on,
      (SELECT MAX(c.updated_at) FROM conversations c WHERE c.account_id = a.id) last_activity
    FROM accounts a ORDER BY a.created_at`).all(month);
  const esc = (v: any) => { const s = v == null ? '' : String(v); return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const header = 'id,firma,plan,vertical,creat,suspendat,email_owner,leads_total,programari,conversatii_luna,canale_conectate,ultima_activitate';
  const csv = [header, ...rows.map(r => [r.id, r.name, r.plan, r.vertical, r.created_at, r.suspended ? 'da' : '', r.owner_email, r.leads, r.booked, r.conv_month, r.channels_on, r.last_activity].map(esc).join(','))].join('\n');
  return new NextResponse('﻿' + csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="leaply-conturi-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
