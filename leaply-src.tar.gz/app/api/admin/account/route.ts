import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const plan = ['Trial', 'Start', 'Pro', 'Scale'].includes(b.plan) ? b.plan : null;
  if (!b.id || !plan) return NextResponse.json({ error: 'id și plan valide necesare' }, { status: 400 });
  const r = db().prepare('UPDATE accounts SET plan=? WHERE id=?').run(plan, String(b.id));
  if (!r.changes) return NextResponse.json({ error: 'Cont inexistent' }, { status: 404 });
  console.log(`[leaply admin] ${user.email} a schimbat planul contului ${b.id} -> ${plan}`);
  return NextResponse.json({ ok: true });
}
