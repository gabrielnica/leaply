import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { audit } from '../../../../lib/audit';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const b = await req.json().catch(() => ({}));

  // Creare cont cu id fix + config + număr de voce (folosit pt. contul propriu Leaply)
  if (b.action === 'create') {
    const id = String(b.id || '').trim();
    if (!/^acc_[a-z0-9_]{3,30}$/.test(id)) return NextResponse.json({ error: 'id invalid (acc_...)' }, { status: 400 });
    const d = db();
    if (d.prepare('SELECT id FROM accounts WHERE id=?').get(id)) return NextResponse.json({ error: 'Contul există deja' }, { status: 409 });
    const now = new Date().toISOString();
    const { hashPassword } = await import('../../../../lib/auth');
    const { uid } = await import('../../../../lib/db');
    const email = String(b.email || '').trim().toLowerCase();
    const password = String(b.password || '');
    if (!email || password.length < 8) return NextResponse.json({ error: 'email + parolă (min 8)' }, { status: 400 });
    if (d.prepare('SELECT id FROM users WHERE email=?').get(email)) return NextResponse.json({ error: 'Email deja folosit' }, { status: 409 });
    d.transaction(() => {
      d.prepare('INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at) VALUES (?,?,?,?,?,?,?)')
        .run(id, String(b.business || id), String(b.vertical || 'servicii'), String(b.plan || 'Scale'), Number(b.avg_deal_value) || 1000, JSON.stringify(b.config || {}), now);
      d.prepare('INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)')
        .run(uid('us_'), id, email, String(b.ownerName || 'Owner'), hashPassword(password), 'owner', now);
      const chans = [
        ['webform', 'connected', 'Formular / chat web + widget site'],
        ['whatsapp', 'pending', 'WhatsApp Business'],
        ['meta_lead_ads', 'pending', 'Facebook Lead Ads'],
        ['messenger', 'pending', 'Messenger'],
        ['instagram', 'pending', 'Instagram DM'],
        ['voice', b.voiceNumber ? 'connected' : 'pending', b.voiceNumber ? `Număr Leaply: ${b.voiceNumber}` : 'Apeluri telefonice'],
        ['calendar', 'pending', 'Google Calendar'],
      ];
      const ins = d.prepare('INSERT INTO channels (id,account_id,type,status,label,credentials) VALUES (?,?,?,?,?,?)');
      for (const [type, status, label] of chans) {
        const creds = type === 'voice' && b.voiceNumber ? JSON.stringify({ from_number: String(b.voiceNumber) }) : null;
        ins.run(uid('ch_'), id, type, status, label, creds);
      }
    })();
    audit(user.email, 'account.create', id, { email });
    return NextResponse.json({ ok: true, id });
  }

  // Extindere trial (+N zile)
  if (b.action === 'extend_trial') {
    const days = Math.min(60, Math.max(1, Number(b.days) || 7));
    const r = db().prepare("UPDATE accounts SET trial_extra = COALESCE(trial_extra,0) + ? WHERE id=? AND plan='Trial'").run(days, String(b.id));
    if (!r.changes) return NextResponse.json({ error: 'Cont inexistent sau nu e pe Trial.' }, { status: 404 });
    // resetăm flag-ul de avertizare, ca alerta de expirare să poată re-trimite
    try {
      const { setIntegration } = await import('../../../../lib/integrations');
      setIntegration(String(b.id), 'trialWarned', null);
    } catch {}
    audit(user.email, 'trial.extend', String(b.id), { days });
    return NextResponse.json({ ok: true, days });
  }

  // Add-on-uri de resurse (se adună la limitele planului; facturate manual în Stripe ca subscription items)
  if (b.action === 'set_addons') {
    const clamp = (v: any, max: number) => Math.max(0, Math.min(max, Number(v) || 0));
    const addons = {
      conv: clamp(b.addons?.conv, 10000),
      sms: clamp(b.addons?.sms, 10000),
      voice_min: clamp(b.addons?.voice_min, 5000),
      numbers: clamp(b.addons?.numbers, 20),
    };
    const { setIntegration } = await import('../../../../lib/integrations');
    const empty = !addons.conv && !addons.sms && !addons.voice_min && !addons.numbers;
    setIntegration(String(b.id), 'addons', empty ? null : addons);
    audit(user.email, 'addons.set', String(b.id), addons);
    // dacă are abonament Stripe activ, facturăm automat ca subscription items (prorata)
    const { syncAddonItems } = await import('../../../../lib/stripe');
    const billing = await syncAddonItems(String(b.id), addons);
    return NextResponse.json({ ok: true, addons, billing });
  }

  // Alocare manuală de număr pe un canal (RDS/Orange eSIM pe Cloud API, sau orice număr extern)
  if (b.action === 'set_channel') {
    const type = ['whatsapp', 'voice'].includes(b.type) ? b.type : null;
    if (!type) return NextResponse.json({ error: 'Tip de canal invalid (whatsapp/voice).' }, { status: 400 });
    const { setChannelCreds } = await import('../../../../lib/channels');
    if (type === 'voice') {
      const num = String(b.from_number || '').replace(/[^\d+]/g, '');
      if (!/^\+\d{8,}$/.test(num)) return NextResponse.json({ error: 'Număr invalid (format +40...).' }, { status: 400 });
      setChannelCreds(String(b.id), 'voice', { provider: 'twilio', from_number: num }, `Telefon Leaply ${num} — agent vocal activ`);
      audit(user.email, 'number.assign', String(b.id), { type, number: num });
      return NextResponse.json({ ok: true, number: num });
    }
    // whatsapp pe Meta Cloud API: numărul (afișaj) + phone_number_id + access token
    const num = String(b.from_number || '').replace(/[^\d+]/g, '');
    const pnid = String(b.phone_number_id || '').trim();
    const token = String(b.access_token || '').trim();
    if (!pnid || !token) return NextResponse.json({ error: 'phone_number_id și access_token sunt obligatorii pentru WhatsApp.' }, { status: 400 });
    setChannelCreds(String(b.id), 'whatsapp', { provider: 'meta', phone_number_id: pnid, access_token: token, ...(num ? { from_number: num } : {}) }, `WhatsApp Leaply${num ? ' ' + num : ''} (Cloud API)`);
    audit(user.email, 'number.assign', String(b.id), { type, number: num || pnid });
    return NextResponse.json({ ok: true, number: num || pnid });
  }

  // Suspendare / reactivare cont
  if (b.action === 'suspend') {
    const on = b.suspended ? 1 : 0;
    const r = db().prepare('UPDATE accounts SET suspended=? WHERE id=?').run(on, String(b.id));
    if (!r.changes) return NextResponse.json({ error: 'Cont inexistent' }, { status: 404 });
    audit(user.email, 'account.suspend', String(b.id), { suspended: !!on });
    return NextResponse.json({ ok: true, suspended: !!on });
  }

  // Trimite ownerului link de resetare a parolei
  if (b.action === 'reset_password') {
    const owner: any = db().prepare("SELECT id, email, name FROM users WHERE account_id=? AND role='owner' ORDER BY created_at LIMIT 1").get(String(b.id));
    if (!owner) return NextResponse.json({ error: 'Contul nu are owner.' }, { status: 404 });
    const { createResetToken } = await import('../../../../lib/auth');
    const { sendMail } = await import('../../../../lib/mail');
    const { appUrl } = await import('../../../../lib/settings');
    const token = createResetToken(owner.id, 24);
    await sendMail(owner.email, 'Resetare parolă Leaply',
      `<p>Salut${owner.name ? ', ' + owner.name : ''}!</p><p>Echipa Leaply ți-a generat un link de resetare a parolei (valabil 24h):</p><p><a href="${appUrl()}/reset?token=${token}" style="background:#FF4D1F;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Setează o parolă nouă</a></p>`);
    audit(user.email, 'password.reset_sent', String(b.id), { email: owner.email });
    return NextResponse.json({ ok: true, email: owner.email });
  }

  const plan = ['Trial', 'Start', 'Pro', 'Scale'].includes(b.plan) ? b.plan : null;
  if (!b.id || !plan) return NextResponse.json({ error: 'id și plan valide necesare' }, { status: 400 });
  const r = db().prepare('UPDATE accounts SET plan=? WHERE id=?').run(plan, String(b.id));
  if (!r.changes) return NextResponse.json({ error: 'Cont inexistent' }, { status: 404 });
  audit(user.email, 'plan.change', String(b.id), { plan });
  return NextResponse.json({ ok: true });
}
