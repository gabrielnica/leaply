import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { audit } from '../../../../lib/audit';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const b = await req.json().catch(() => ({}));

  // Creare cont cu id fix + config + număr de voce (folosit pt. contul propriu Leaply)
  if (b.action === 'create') {
    const id = String(b.id || '').trim();
    if (!/^acc_[a-z0-9_]{3,30}$/.test(id)) return NextResponse.json({ error: 'id invalid (acc_...)' }, { status: 400 });
    const d = db();
    if (d.prepare('SELECT id FROM accounts WHERE id=?').get(id)) return NextResponse.json({ error: 'Contul există deja' }, { status: 409 });
    const now = new Date().toISOString();
    const { hashPassword } = await import('../../../../lib/auth');
    const { uid } = await import('../../../../lib/db');
    const email = String(b.email || '').trim().toLowerCase();
    const password = String(b.password || '');
    if (!email || password.length < 8) return NextResponse.json({ error: 'email + parolă (min 8)' }, { status: 400 });
    if (d.prepare('SELECT id FROM users WHERE email=?').get(email)) return NextResponse.json({ error: 'Email deja folosit' }, { status: 409 });
    d.transaction(() => {
      d.prepare('INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at) VALUES (?,?,?,?,?,?,?)')
        .run(id, String(b.business || id), String(b.vertical || 'servicii'), String(b.plan || 'Scale'), Number(b.avg_deal_value) || 1000, JSON.stringify(b.config || {}), now);
      d.prepare('INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)')
        .run(uid('us_'), id, email, String(b.ownerName || 'Owner'), hashPassword(password), 'owner', now);
      const chans = [
        ['webform', 'connected', 'Formular / chat web + widget site'],
        ['whatsapp', 'pending', 'WhatsApp Business'],
        ['meta_lead_ads', 'pending', 'Facebook Lead Ads'],
        ['messenger', 'pending', 'Messenger'],
        ['instagram', 'pending', 'Instagram DM'],
        ['voice', b.voiceNumber ? 'connected' : 'pending', b.voiceNumber ? `Număr Leaply: ${b.voiceNumber}` : 'Apeluri telefonice'],
        ['calendar', 'pending', 'Google Calendar'],
      ];
      const ins = d.prepare('INSERT INTO channels (id,account_id,type,status,label,credentials) VALUES (?,?,?,?,?,?)');
      for (const [type, status, label] of chans) {
        const creds = type === 'voice' && b.voiceNumber ? JSON.stringify({ from_number: String(b.voiceNumber) }) : null;
        ins.run(uid('ch_'), id, type, status, label, creds);
      }
    })();
    audit(user.email, 'account.create', id, { email });
    return NextResponse.json({ ok: true, id });
  }

  const plan = ['Trial', 'Start', 'Pro', 'Scale'].includes(b.plan) ? b.plan : null;
  if (!b.id || !plan) return NextResponse.json({ error: 'id și plan valide necesare' }, { status: 400 });
  const r = db().prepare('UPDATE accounts SET plan=? WHERE id=?').run(plan, String(b.id));
  if (!r.changes) return NextResponse.json({ error: 'Cont inexistent' }, { status: 404 });
  audit(user.email, 'plan.change', String(b.id), { plan });
  return NextResponse.json({ ok: true });
}
