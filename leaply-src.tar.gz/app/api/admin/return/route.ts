import { NextRequest, NextResponse } from 'next/server';
import { getUserByToken, SESSION_COOKIE } from '../../../../lib/auth';
import { audit } from '../../../../lib/audit';
import { appUrl } from '../../../../lib/settings';

export const dynamic = 'force-dynamic';

// „Înapoi la admin" după impersonare: restaurăm sesiunea de admin păstrată la impersonate.
export async function GET(req: NextRequest) {
  const adminToken = req.cookies.get('leaply_admin_return')?.value || '';
  const adminUser = adminToken ? getUserByToken(adminToken) : null;
  const secure = process.env.NODE_ENV === 'production';
  const res = NextResponse.redirect(new URL(adminUser && adminUser.role === 'admin' ? '/admin' : '/login', appUrl()));
  if (adminUser && adminUser.role === 'admin') {
    res.cookies.set(SESSION_COOKIE, adminToken, { httpOnly: true, sameSite: 'lax', secure, path: '/' });
    audit(adminUser.email, 'impersonate.return', '', {});
  } else {
    res.cookies.set(SESSION_COOKIE, '', { httpOnly: true, sameSite: 'lax', secure, path: '/', maxAge: 0 });
  }
  res.cookies.set('leaply_admin_return', '', { httpOnly: true, sameSite: 'lax', secure, path: '/', maxAge: 0 });
  res.cookies.set('leaply_imp', '', { httpOnly: false, sameSite: 'lax', secure, path: '/', maxAge: 0 });
  return res;
}
