import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser, createSession, SESSION_COOKIE } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { audit } from '../../../../lib/audit';
import { appUrl } from '../../../../lib/settings';
export const dynamic = 'force-dynamic';

// Admin: „Loghează-te în contul lui" — sesiune pe ownerul contului, cu urmă în audit.
// Nota bene: înlocuiește sesiunea de admin din browser; revii logându-te iar la /admin/login.
export async function GET(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.redirect(new URL('/admin/login', appUrl()));
  const accId = String(new URL(req.url).searchParams.get('id') || '');
  const owner: any = db().prepare("SELECT id, email FROM users WHERE account_id=? AND role='owner' ORDER BY created_at LIMIT 1").get(accId);
  if (!owner) return NextResponse.redirect(new URL('/admin?err=noowner', appUrl()));
  audit(user.email, 'impersonate', accId, { as: owner.email });
  const { token, expires } = createSession(owner.id);
  const res = NextResponse.redirect(new URL('/app', appUrl()));
  // păstrăm sesiunea de ADMIN într-un cookie separat → „Înapoi la admin" fără re-login
  const adminToken = req.cookies.get(SESSION_COOKIE)?.value || '';
  const secure = process.env.NODE_ENV === 'production';
  if (adminToken) {
    res.cookies.set('leaply_admin_return', adminToken, { httpOnly: true, sameSite: 'lax', secure, path: '/', expires });
    res.cookies.set('leaply_imp', '1', { httpOnly: false, sameSite: 'lax', secure, path: '/', expires });
  }
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', secure, path: '/', expires });
  return res;
}
