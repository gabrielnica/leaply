import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db, uid } from '../../../../lib/db';
import { audit } from '../../../../lib/audit';
import { setChannelCreds } from '../../../../lib/channels';

export const dynamic = 'force-dynamic';

// Parcul de numere (eSIM Digi / Twilio): inventar + alocare pe conturi + înregistrare
// semi-automată pe Meta WhatsApp Cloud API (request_code → verify_code → register).

const GRAPH = 'https://graph.facebook.com/v19.0';

async function graph(path: string, token: string, body: any) {
  const r = await fetch(`${GRAPH}/${path}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  const d = await r.json().catch(() => ({}));
  return { ok: r.ok, data: d, error: r.ok ? null : (d?.error?.message || `HTTP ${r.status}`) };
}

export async function GET() {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const d = db();
  const rows = d.prepare(`
    SELECT n.*, a.name AS account_name FROM numbers_pool n
    LEFT JOIN accounts a ON a.id = n.account_id
    ORDER BY CASE n.status WHEN 'liber' THEN 0 WHEN 'in_verificare' THEN 1 ELSE 2 END, n.created_at DESC`).all();
  const accounts = d.prepare("SELECT id, name FROM accounts WHERE id NOT IN ('acc_demo') AND (parent_id IS NULL) ORDER BY name").all();
  return NextResponse.json({ numbers: rows, accounts });
}

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') return NextResponse.json({ error: 'Doar admin' }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const d = db();
  const now = new Date().toISOString();

  // Adaugă număr în inventar
  if (b.action === 'add') {
    const number = String(b.number || '').trim();
    if (!/^\+?\d{9,15}$/.test(number.replace(/\s/g, ''))) return NextResponse.json({ error: 'Număr invalid (ex. +40712345678)' }, { status: 400 });
    const id = uid('np_');
    d.prepare('INSERT INTO numbers_pool (id,number,kind,iccid,status,monthly_cost,note,created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(id, number, String(b.kind || 'esim_digi'), String(b.iccid || '') || null, 'liber', Number(b.monthly_cost) || 0, String(b.note || '') || null, now);
    audit(user.email, 'numpool.add', id, { number, kind: b.kind });
    return NextResponse.json({ ok: true, id });
  }

  const row: any = b.id ? d.prepare('SELECT * FROM numbers_pool WHERE id=?').get(String(b.id)) : null;
  if (!row) return NextResponse.json({ error: 'Numărul nu există în inventar' }, { status: 404 });

  // Salvează detalii Meta (WABA, phone_number_id) pe rând
  if (b.action === 'set_meta') {
    d.prepare('UPDATE numbers_pool SET waba_id=?, phone_number_id=? WHERE id=?')
      .run(String(b.waba_id || '') || null, String(b.phone_number_id || '') || null, row.id);
    audit(user.email, 'numpool.set_meta', row.id, { waba_id: b.waba_id, phone_number_id: b.phone_number_id });
    return NextResponse.json({ ok: true });
  }

  // Înregistrare Cloud API — pas 1: trimite OTP prin SMS pe eSIM
  if (b.action === 'request_code') {
    const pnid = String(b.phone_number_id || row.phone_number_id || '');
    const token = String(b.access_token || '');
    if (!pnid || !token) return NextResponse.json({ error: 'phone_number_id + access token (system user)' }, { status: 400 });
    const r = await graph(`${pnid}/request_code`, token, { code_method: 'SMS', language: 'ro' });
    if (!r.ok) return NextResponse.json({ error: `Meta: ${r.error}` }, { status: 422 });
    d.prepare("UPDATE numbers_pool SET status='in_verificare', phone_number_id=? WHERE id=?").run(pnid, row.id);
    audit(user.email, 'numpool.request_code', row.id, { pnid });
    return NextResponse.json({ ok: true, hint: 'Citește codul SMS de pe telefonul cu eSIM-ul și introdu-l la „Verifică codul".' });
  }

  // Pas 2: verifică OTP
  if (b.action === 'verify_code') {
    const pnid = String(row.phone_number_id || '');
    const token = String(b.access_token || '');
    const code = String(b.code || '').replace(/\D/g, '');
    if (!pnid || !token || !code) return NextResponse.json({ error: 'Lipsește codul sau tokenul' }, { status: 400 });
    const r = await graph(`${pnid}/verify_code`, token, { code });
    if (!r.ok) return NextResponse.json({ error: `Meta: ${r.error}` }, { status: 422 });
    audit(user.email, 'numpool.verify_code', row.id, {});
    return NextResponse.json({ ok: true, hint: 'Verificat. Acum apasă „Înregistrează (PIN)".' });
  }

  // Pas 3: register cu PIN 2FA — numărul devine utilizabil pe Cloud API
  if (b.action === 'register') {
    const pnid = String(row.phone_number_id || '');
    const token = String(b.access_token || '');
    const pin = String(b.pin || '').replace(/\D/g, '');
    if (!pnid || !token || pin.length !== 6) return NextResponse.json({ error: 'PIN de 6 cifre + token' }, { status: 400 });
    const r = await graph(`${pnid}/register`, token, { messaging_product: 'whatsapp', pin });
    if (!r.ok) return NextResponse.json({ error: `Meta: ${r.error}` }, { status: 422 });
    d.prepare("UPDATE numbers_pool SET status='liber', note=COALESCE(note,'') || ' · înregistrat Cloud API' WHERE id=?").run(row.id);
    audit(user.email, 'numpool.register', row.id, { pnid });
    return NextResponse.json({ ok: true, hint: 'Număr înregistrat pe Cloud API. Îl poți aloca unui cont.' });
  }

  // Alocare pe un cont: whatsapp (phone_number_id + token) sau voce (from_number)
  if (b.action === 'assign') {
    const accId = String(b.account_id || '');
    if (!d.prepare('SELECT id FROM accounts WHERE id=?').get(accId)) return NextResponse.json({ error: 'Cont inexistent' }, { status: 404 });
    if (row.status === 'alocat') return NextResponse.json({ error: 'Numărul e deja alocat — eliberează-l întâi' }, { status: 409 });
    const kind = b.channel === 'voice' ? 'voice' : 'whatsapp';
    if (kind === 'whatsapp') {
      const pnid = String(b.phone_number_id || row.phone_number_id || '');
      const token = String(b.access_token || '');
      if (!pnid || !token) return NextResponse.json({ error: 'Pentru WhatsApp: phone_number_id + access token' }, { status: 400 });
      setChannelCreds(accId, 'whatsapp', { provider: 'meta', phone_number_id: pnid, access_token: token, from_number: row.number }, `WhatsApp ${row.number} (număr Leaply)`);
    } else {
      setChannelCreds(accId, 'voice', { from_number: row.number }, `Număr Leaply: ${row.number}`);
    }
    d.prepare("UPDATE numbers_pool SET status='alocat', account_id=?, assigned_at=? WHERE id=?").run(accId, now, row.id);
    audit(user.email, 'numpool.assign', row.id, { account_id: accId, number: row.number, kind });
    return NextResponse.json({ ok: true });
  }

  // Eliberare: canalul contului trece pe pending, numărul revine liber
  if (b.action === 'release') {
    if (row.account_id) {
      try {
        const chans: any[] = d.prepare('SELECT id, type, credentials FROM channels WHERE account_id=?').all(row.account_id);
        const { openJson } = require('../../../../lib/secretbox');
        for (const c of chans) {
          const creds = openJson(c.credentials);
          if (creds && (creds.from_number === row.number || (row.phone_number_id && creds.phone_number_id === row.phone_number_id))) {
            setChannelCreds(row.account_id, c.type, null);
          }
        }
      } catch {}
    }
    d.prepare("UPDATE numbers_pool SET status='liber', account_id=NULL, assigned_at=NULL WHERE id=?").run(row.id);
    audit(user.email, 'numpool.release', row.id, { number: row.number });
    return NextResponse.json({ ok: true });
  }

  // Retragere din inventar (numărul nu mai există fizic)
  if (b.action === 'retire') {
    d.prepare("UPDATE numbers_pool SET status='retras', account_id=NULL WHERE id=?").run(row.id);
    audit(user.email, 'numpool.retire', row.id, { number: row.number });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'Acțiune necunoscută' }, { status: 400 });
}
