import { NextRequest, NextResponse } from 'next/server';
import { createResetToken } from '../../../../lib/auth';
import { sendMail } from '../../../../lib/mail';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const email = String(b.email || '').trim().toLowerCase();
  const user: any = db().prepare('SELECT id, name FROM users WHERE email=?').get(email);
  if (user) {
    const token = createResetToken(user.id);
    const base = process.env.APP_URL || 'https://leaply.ro';
    const url = `${base}/reset?token=${token}`;
    await sendMail(email, 'Resetare parolă Leaply',
      `<p>Salut${user.name ? ', ' + user.name : ''}!</p><p>Ai cerut resetarea parolei Leaply. Linkul e valabil o oră:</p><p><a href="${url}">${url}</a></p><p>Dacă nu ai cerut tu resetarea, ignoră acest mesaj.</p>`);
  }
  // răspuns identic indiferent dacă emailul există (nu divulgăm conturile)
  return NextResponse.json({ ok: true });
}
