import { NextRequest, NextResponse } from 'next/server';
import { createAccountWithOwner, createSession, emailOk, SESSION_COOKIE } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const name = String(b.name || '').trim();
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');
  if (!name) return NextResponse.json({ error: 'Spune-ne cum te cheamă.' }, { status: 400 });
  if (!emailOk(email)) return NextResponse.json({ error: 'Email invalid.' }, { status: 400 });
  if (password.length < 8) return NextResponse.json({ error: 'Parola trebuie să aibă minim 8 caractere.' }, { status: 400 });

  const res = createAccountWithOwner({
    name, email, password,
    business: String(b.business || '').trim() || undefined,
    vertical: String(b.vertical || '').trim() || undefined,
  });
  if ('error' in res) return NextResponse.json({ error: `Ne pare rău — ${res.error}. Încearcă autentificarea.` }, { status: 409 });

  // leagă cererea de demo de contul creat (dacă a venit din formularul de landing)
  const drId = String(b.demoRequestId || '');
  if (drId) {
    try { db().prepare("UPDATE demo_requests SET status='cont creat', account_id=? WHERE id=?").run(res.accountId, drId); } catch {}
  }

  const { token, expires } = createSession(res.userId);
  const out = NextResponse.json({ ok: true });
  out.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', expires });
  return out;
}
