import { NextRequest, NextResponse } from 'next/server';
import { createSession, verifyPassword, SESSION_COOKIE } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');
  const user: any = db().prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !verifyPassword(password, user.password_hash)) {
    return NextResponse.json({ error: 'Email sau parolă greșite.' }, { status: 401 });
  }
  const { token, expires } = createSession(user.id);
  try { db().prepare('UPDATE users SET last_login=? WHERE id=?').run(new Date().toISOString(), user.id); } catch {}
  const out = NextResponse.json({ ok: true, role: user.role });
  out.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/', expires });
  return out;
}
