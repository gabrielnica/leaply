import { NextResponse } from 'next/server';
import { getSessionUser, createVerifyToken } from '../../../../lib/auth';
import { sendMail } from '../../../../lib/mail';
import { appUrl } from '../../../../lib/settings';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const u: any = db().prepare('SELECT email_verified FROM users WHERE id=?').get(user.id);
  if (u?.email_verified) return NextResponse.json({ ok: true, already: true });
  const vt = createVerifyToken(user.id);
  const sent = await sendMail(user.email, 'Confirmă-ți adresa de email — Leaply',
    `<p>Confirmă adresa de email printr-un click:</p><p><a href="${appUrl()}/api/auth/verify?token=${vt}" style="background:#FF4D1F;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Confirmă emailul</a></p>`);
  return NextResponse.json({ ok: sent });
}
