import { NextRequest, NextResponse } from 'next/server';
import { consumeVerifyToken } from '../../../../lib/auth';
import { appUrl } from '../../../../lib/settings';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const ok = consumeVerifyToken(req.nextUrl.searchParams.get('token') || '');
  return NextResponse.redirect(new URL(ok ? '/app?verified=1' : '/app?verified=0', appUrl()));
}
