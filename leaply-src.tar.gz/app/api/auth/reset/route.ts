import { NextRequest, NextResponse } from 'next/server';
import { consumeResetToken, destroyAllSessions, hashPassword } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const token = String(b.token || '');
  const password = String(b.password || '');
  if (password.length < 8) return NextResponse.json({ error: 'Parola trebuie să aibă minim 8 caractere.' }, { status: 400 });
  const userId = consumeResetToken(token);
  if (!userId) return NextResponse.json({ error: 'Link de resetare invalid sau expirat. Cere unul nou.' }, { status: 400 });
  db().prepare('UPDATE users SET password_hash=? WHERE id=?').run(hashPassword(password), userId);
  destroyAllSessions(userId);
  return NextResponse.json({ ok: true });
}
