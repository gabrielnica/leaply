import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { getConversation, getAccount } from '../../../../lib/store';
import { nextReply, Turn } from '../../../../lib/brain';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;

// Sugestie AI la preluare: AI-ul propune draftul răspunsului, omul îl editează și trimite.
// NU salvează nimic — doar generează textul, cu tot contextul (config, documente, memorie).
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const convId = String(b.convId || '');
  const c: any = getConversation(convId);
  if (!c || (c.account_id !== user.account_id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Conversație negăsită' }, { status: 404 });
  }
  const acc = getAccount(c.account_id);
  const config: any = { ...(acc?.config || {}) };
  // același context ca la răspunsurile automate: documente + memorie + exemple apreciate
  try {
    const lastLead = [...c.messages].reverse().find((m: any) => m.sender === 'lead');
    if (lastLead) {
      const { docsContext } = await import('../../../../lib/docs');
      const dc = docsContext(c.account_id, lastLead.body);
      if (dc) config._docsContext = dc;
    }
    const { leadContext } = await import('../../../../lib/memory');
    const lc = leadContext(c.account_id, c.phone, convId);
    if (lc) config._leadContext = lc;
    const { fewShotExamples } = await import('../../../../lib/quality');
    const fs = fewShotExamples(c.account_id);
    if (fs) config._fewShot = fs;
  } catch { /* context opțional */ }

  const history: Turn[] = c.messages
    .filter((m: any) => ['lead', 'ai', 'agent'].includes(m.sender) && m.direction !== 'note')
    .map((m: any) => ({ sender: m.sender === 'lead' ? 'lead' : 'ai', body: m.body }));
  const res = await nextReply(config, history);
  return NextResponse.json({ suggestion: res.reply });
}
