import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { getConversation, addMessage } from '../../../../lib/store';
import { sendReply } from '../../../../lib/channels';
import { sendSms, smsConfigured } from '../../../../lib/sms';
export const dynamic = 'force-dynamic';

// Răspuns MANUAL al ownerului — pleacă pe canalul de proveniență al lead-ului
// (WhatsApp / Messenger / Instagram; voce & lead ads → SMS; widget → apare la
// următorul poll al widgetului). Mesajul se salvează ca 'agent'.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const convId = String(b.convId || '');
  const text = String(b.text || '').trim().slice(0, 2000);
  if (!convId || !text) return NextResponse.json({ error: 'convId și text sunt obligatorii' }, { status: 400 });

  const c: any = getConversation(convId);
  if (!c || (c.account_id !== user.account_id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Conversație negăsită' }, { status: 404 });
  }

  const accId = c.account_id;
  const replyTo = String(c.phone || ''); // pentru messenger/instagram e PSID-ul; pentru rest, numărul
  let delivered = false; let via = c.channel; let error = '';

  if (['whatsapp', 'messenger', 'instagram'].includes(c.channel)) {
    const r = await sendReply(accId, c.channel, replyTo, text);
    delivered = r.sent; error = r.error || '';
  } else if (['voice', 'sms', 'meta_lead_ads'].includes(c.channel)) {
    if (!/^\+?\d{8,}$/.test(replyTo.replace(/\s/g, ''))) error = 'Lead-ul nu are un număr de telefon valid.';
    else if (!smsConfigured()) error = 'SMS-ul nu e configurat pe platformă.';
    else { delivered = await sendSms(replyTo, text).catch(() => false); via = 'sms'; if (!delivered) error = 'SMS-ul nu a putut fi trimis.'; }
  } else if (c.channel === 'webform') {
    delivered = true; via = 'widget'; // vizitatorul îl primește la următorul poll (max 5s)
  } else {
    error = `Canal necunoscut: ${c.channel}`;
  }

  if (!delivered && error) return NextResponse.json({ error }, { status: 400 });
  addMessage(convId, 'out', 'agent', text);
  return NextResponse.json({ ok: true, via });
}
