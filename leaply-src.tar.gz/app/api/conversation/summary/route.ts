import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { llmReply, llmActive } from '../../../../lib/llm';
export const dynamic = 'force-dynamic';

/** Rezumat AI al conversației + motivul scorului. Cache în conversations.summary
 *  (regenerat doar dacă au apărut mesaje noi de la ultimul rezumat). */
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const id = String(b.id || '');
  const d = db();
  const c: any = d.prepare('SELECT c.*, l.name lead_name, l.score FROM conversations c JOIN leads l ON l.id=c.lead_id WHERE c.id=? AND c.account_id=?').get(id, user.account_id);
  if (!c) return NextResponse.json({ error: 'Conversație inexistentă' }, { status: 404 });
  if (!llmActive()) return NextResponse.json({ error: 'Rezumatul are nevoie de un LLM activ (cheie API în Setări platformă).' }, { status: 400 });

  const msgs: any[] = d.prepare("SELECT sender, body, created_at FROM messages WHERE conversation_id=? ORDER BY created_at").all(id);
  const stamp = msgs.length ? msgs[msgs.length - 1].created_at : '';
  // cache: {"at": <created_at ultimul mesaj>, "text": "..."}
  try {
    const cached = JSON.parse(c.summary || 'null');
    if (cached?.at === stamp && cached.text) return NextResponse.json({ summary: cached.text, cached: true });
  } catch {}

  const transcript = msgs.slice(-40).map(m => `${m.sender === 'lead' ? 'CLIENT' : m.sender === 'ai' ? 'AI' : 'ECHIPĂ'}: ${String(m.body).slice(0, 300)}`).join('\n');
  const text = await llmReply(
    `Ești analistul de vânzări al unei firme românești. Primești transcriptul unei conversații cu un potențial client (scor actual: ${c.score}, status: ${c.status}). Răspunde STRICT în acest format, în română, concis:\nREZUMAT: 2-3 fraze — ce vrea clientul, detalii cheie (cantitate, zonă, buget, termen).\nSCOR: de ce e ${c.score} — 1 frază.\nURMĂTORUL PAS: ce ar trebui să facă proprietarul — 1 frază concretă.`,
    [{ role: 'user', content: transcript }]
  );
  if (!text) return NextResponse.json({ error: 'LLM-ul nu a răspuns. Reîncearcă.' }, { status: 502 });
  d.prepare('UPDATE conversations SET summary=? WHERE id=?').run(JSON.stringify({ at: stamp, text }), id);
  return NextResponse.json({ summary: text, cached: false });
}
