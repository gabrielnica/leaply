import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const convId = String(b.convId || '');
  const tags = (Array.isArray(b.tags) ? b.tags : []).map((t: any) => String(t).trim().toLowerCase().slice(0, 24)).filter(Boolean).slice(0, 6);
  const c: any = db().prepare('SELECT account_id FROM conversations WHERE id=?').get(convId);
  if (!c || (c.account_id !== user.account_id && user.role !== 'admin')) return NextResponse.json({ error: 'Negăsit' }, { status: 404 });
  db().prepare('UPDATE conversations SET tags=? WHERE id=?').run(JSON.stringify(tags), convId);
  return NextResponse.json({ ok: true, tags });
}
