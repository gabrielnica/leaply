import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { addMessage } from '../../../../lib/store';
export const dynamic = 'force-dynamic';

// Notă internă pe conversație — vizibilă doar echipei, NU se trimite lead-ului.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const convId = String(b.convId || '');
  const text = String(b.text || '').trim().slice(0, 1000);
  if (!convId || !text) return NextResponse.json({ error: 'convId și text' }, { status: 400 });
  const c: any = db().prepare('SELECT account_id FROM conversations WHERE id=?').get(convId);
  if (!c || (c.account_id !== user.account_id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Negăsit' }, { status: 404 });
  }
  addMessage(convId, 'note', 'system', `📌 Notă internă (${user.name}): ${text}`);
  return NextResponse.json({ ok: true });
}
