import { NextResponse } from 'next/server';
import { updateConversation, addMessage } from '../../../../../lib/store';
export const dynamic = 'force-dynamic';
export async function POST(_req: Request, { params }: { params: { id: string } }) {
  updateConversation(params.id, { status: 'active' });
  addMessage(params.id, 'note', 'system', 'Owner a preluat conversația — asistent oprit.');
  return NextResponse.json({ ok: true });
}
