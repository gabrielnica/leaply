import { NextResponse } from 'next/server';
import { updateConversation, addMessage, getConversation } from '../../../../../lib/store';
export const dynamic = 'force-dynamic';
export async function POST(req: Request, { params }: { params: { id: string } }) {
  if (!getConversation(params.id)) return NextResponse.json({ error: 'Conversație negăsită' }, { status: 404 });
  const body = await req.json().catch(() => ({}));
  if (body?.action === 'release') {
    updateConversation(params.id, { status: 'active' });
    addMessage(params.id, 'note', 'system', 'Owner a redat conversația asistentului.');
  } else {
    updateConversation(params.id, { status: 'human' });
    addMessage(params.id, 'note', 'system', 'Owner a preluat conversația — asistent oprit.');
  }
  return NextResponse.json({ ok: true });
}
