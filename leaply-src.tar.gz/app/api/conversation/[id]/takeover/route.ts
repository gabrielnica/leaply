import { NextResponse } from 'next/server';
import { updateConversation, addMessage, getConversation } from '../../../../../lib/store';
import { getSessionUser } from '../../../../../lib/auth';
export const dynamic = 'force-dynamic';

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const c = getConversation(params.id);
  if (!c) return NextResponse.json({ error: 'Conversație negăsită' }, { status: 404 });
  if (c.account_id !== user.account_id && user.role !== 'admin') {
    return NextResponse.json({ error: 'Acces interzis' }, { status: 403 });
  }
  const body = await req.json().catch(() => ({}));
  if (body?.action === 'release') {
    updateConversation(params.id, { status: 'active' });
    addMessage(params.id, 'note', 'system', 'Owner a redat conversația asistentului.');
  } else {
    updateConversation(params.id, { status: 'human' });
    addMessage(params.id, 'note', 'system', 'Owner a preluat conversația — asistent oprit.');
  }
  return NextResponse.json({ ok: true });
}
