import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const convId = String(b.id || '');
  const to = b.user_id ? String(b.user_id) : null;
  const c: any = db().prepare('SELECT id FROM conversations WHERE id=? AND account_id=?').get(convId, user.account_id);
  if (!c) return NextResponse.json({ error: 'Conversație inexistentă' }, { status: 404 });
  if (to) {
    const m: any = db().prepare('SELECT id FROM users WHERE id=? AND account_id=?').get(to, user.account_id);
    if (!m) return NextResponse.json({ error: 'Coleg inexistent' }, { status: 404 });
  }
  db().prepare('UPDATE conversations SET assigned_to=? WHERE id=?').run(to, convId);
  return NextResponse.json({ ok: true });
}
