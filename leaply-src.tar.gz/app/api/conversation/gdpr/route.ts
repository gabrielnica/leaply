import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { audit } from '../../../../lib/audit';

export const dynamic = 'force-dynamic';

// GDPR per lead: ștergere definitivă (dreptul la ștergere, art. 17).
// Șterge conversația + mesajele; lead-ul dispare complet dacă nu mai are alte conversații.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const id = String(b.id || '');
  const conv: any = db().prepare('SELECT id, account_id, lead_id FROM conversations WHERE id=?').get(id);
  if (!conv || (conv.account_id !== user.account_id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Conversație negăsită' }, { status: 404 });
  }
  const d = db();
  let leadDeleted = false;
  d.transaction(() => {
    d.prepare('DELETE FROM messages WHERE conversation_id=?').run(conv.id);
    d.prepare('DELETE FROM conversations WHERE id=?').run(conv.id);
    const others = (d.prepare('SELECT COUNT(*) n FROM conversations WHERE lead_id=?').get(conv.lead_id) as any).n;
    if (!others) { d.prepare('DELETE FROM leads WHERE id=?').run(conv.lead_id); leadDeleted = true; }
  })();
  audit(user.email, 'gdpr.delete_lead', conv.account_id, { conv: conv.id, leadDeleted });
  return NextResponse.json({ ok: true, leadDeleted });
}
