import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

// Bucla de ROI: marchează o conversație „câștigată" cu valoarea reală (lei).
// value = 0 sau null → demarcată. Intră în KPI-ul de Overview și în raportul săptămânal.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const id = String(b.id || '');
  const value = Math.max(0, Math.min(10_000_000, Math.round(Number(b.value) || 0)));
  const conv: any = db().prepare(`SELECT c.id, c.account_id, c.channel, c.won_value, l.phone
    FROM conversations c JOIN leads l ON l.id=c.lead_id WHERE c.id=?`).get(id);
  if (!conv || (conv.account_id !== user.account_id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Conversație negăsită' }, { status: 404 });
  }
  const firstWin = value > 0 && !conv.won_value;
  db().prepare('UPDATE conversations SET won_value=? WHERE id=?').run(value > 0 ? value : null, id);

  // Recenzie automată: la PRIMA marcare „câștigat", trimitem clientului linkul de recenzie
  // (config.reviewLink din Configurare AI) — pe canalul lui. Best-effort, nu blochează.
  let reviewSent = false;
  if (firstWin) {
    try {
      const acc: any = db().prepare('SELECT config FROM accounts WHERE id=?').get(conv.account_id);
      const cfgA = JSON.parse(acc?.config || '{}');
      const link = String(cfgA.reviewLink || '').trim();
      if (/^https?:\/\//.test(link)) {
        const text = `Mulțumim că ați ales ${cfgA.businessName || 'serviciile noastre'}! 🙏 Dacă ați fost mulțumit, o recenzie ne-ar ajuta enorm: ${link}`;
        const { addMessage } = await import('../../../../lib/store');
        if (['whatsapp', 'messenger', 'instagram'].includes(conv.channel)) {
          const { sendReply } = await import('../../../../lib/channels');
          const r = await sendReply(conv.account_id, conv.channel, String(conv.phone || ''), text);
          reviewSent = r.sent;
        } else if (['voice', 'sms', 'meta_lead_ads'].includes(conv.channel) && /^\+?\d{8,}$/.test(String(conv.phone || '').replace(/\s/g, ''))) {
          const { sendSms, smsConfigured } = await import('../../../../lib/sms');
          if (smsConfigured()) reviewSent = await sendSms(conv.phone, text).catch(() => false);
        } else if (conv.channel === 'webform') {
          reviewSent = true; // vizitatorul o primește prin polling-ul widgetului
        }
        if (reviewSent) {
          addMessage(id, 'out', 'agent', text);
          addMessage(id, 'note', 'system', '⭐ Link de recenzie trimis automat (lead marcat câștigat).');
        }
      }
    } catch { /* best-effort */ }
  }
  return NextResponse.json({ ok: true, won_value: value > 0 ? value : null, reviewSent });
}
