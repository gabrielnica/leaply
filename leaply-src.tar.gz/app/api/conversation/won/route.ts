import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

// Bucla de ROI: marchează o conversație „câștigată" cu valoarea reală (lei).
// value = 0 sau null → demarcată. Intră în KPI-ul de Overview și în raportul săptămânal.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const id = String(b.id || '');
  const value = Math.max(0, Math.min(10_000_000, Math.round(Number(b.value) || 0)));
  const conv: any = db().prepare('SELECT id, account_id FROM conversations WHERE id=?').get(id);
  if (!conv || (conv.account_id !== user.account_id && user.role !== 'admin')) {
    return NextResponse.json({ error: 'Conversație negăsită' }, { status: 404 });
  }
  db().prepare('UPDATE conversations SET won_value=? WHERE id=?').run(value > 0 ? value : null, id);
  return NextResponse.json({ ok: true, won_value: value > 0 ? value : null });
}
