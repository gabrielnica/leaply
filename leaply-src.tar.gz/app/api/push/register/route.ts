import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { saveDeviceToken } from '../../../../lib/push';
import { rateLimited } from '../../../../lib/ratelimit';
export const dynamic = 'force-dynamic';

// Înregistrează un token de dispozitiv nativ (FCM) — apelat de aplicația mobilă (Capacitor)
// după login, folosind cookie-ul de sesiune.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  if (rateLimited('push-reg:' + user.id, 30)) return NextResponse.json({ error: 'Prea multe cereri' }, { status: 429 });
  const b = await req.json().catch(() => ({}));
  const token = String(b.token || '').trim();
  const platform = String(b.platform || 'unknown').trim().slice(0, 20);
  if (!token) return NextResponse.json({ error: 'Token lipsă' }, { status: 400 });
  try {
    saveDeviceToken(user.account_id, user.id, platform, token);
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Eroare' }, { status: 400 });
  }
}
