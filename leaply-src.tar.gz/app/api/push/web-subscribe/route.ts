import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { saveWebSub, removeWebSub } from '../../../../lib/push';
import { rateLimited } from '../../../../lib/ratelimit';
export const dynamic = 'force-dynamic';

// Salvează (sau șterge) un abonament Web Push pentru dispozitivul curent.
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  if (rateLimited('push-sub:' + user.id, 30)) return NextResponse.json({ error: 'Prea multe cereri' }, { status: 429 });
  const b = await req.json().catch(() => ({}));
  if (b.action === 'unsubscribe') {
    if (b.endpoint) removeWebSub(String(b.endpoint), user.account_id);
    return NextResponse.json({ ok: true });
  }
  const sub = b.subscription || b;
  if (!sub?.endpoint) return NextResponse.json({ error: 'Abonament invalid' }, { status: 400 });
  try {
    saveWebSub(user.account_id, user.id, sub);
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'Eroare' }, { status: 400 });
  }
}
