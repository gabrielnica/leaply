import { NextRequest, NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { removeDeviceToken } from '../../../../lib/push';
export const dynamic = 'force-dynamic';

// Șterge un token de dispozitiv nativ (la logout din aplicația mobilă).
export async function POST(req: NextRequest) {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  if (b.token) removeDeviceToken(String(b.token), user.account_id);
  return NextResponse.json({ ok: true });
}
