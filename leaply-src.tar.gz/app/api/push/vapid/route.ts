import { NextResponse } from 'next/server';
import { getVapidPublicKey, webPushConfigured } from '../../../../lib/push';
export const dynamic = 'force-dynamic';

// Cheia publică VAPID — clientul o folosește ca să se aboneze la Web Push.
export async function GET() {
  return NextResponse.json({ configured: webPushConfigured(), key: getVapidPublicKey() });
}
