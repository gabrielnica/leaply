import { NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

// Cel mai recent lead — pentru notificarea în-app (toast + badge) prin polling.
export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const row: any = db().prepare(`
    SELECT c.id, c.channel, c.created_at, l.name AS lead_name
    FROM conversations c JOIN leads l ON l.id = c.lead_id
    WHERE c.account_id = ?
    ORDER BY c.created_at DESC LIMIT 1`).get(user.account_id);
  const todayCount: any = db().prepare(`
    SELECT COUNT(*) n FROM conversations
    WHERE account_id = ? AND created_at > datetime('now','-1 day')`).get(user.account_id);
  return NextResponse.json({
    latest: row ? { id: row.id, name: row.lead_name || 'Lead', channel: row.channel, ts: row.created_at } : null,
    last24h: todayCount?.n || 0,
  });
}
