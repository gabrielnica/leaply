import { NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { pushToUser, pushConfigured } from '../../../../lib/push';
import { appUrl } from '../../../../lib/settings';
export const dynamic = 'force-dynamic';

// Trimite o notificare de test către dispozitivele userului curent (buton din Setări).
export async function POST() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  if (!pushConfigured()) return NextResponse.json({ error: 'Notificările push nu sunt configurate pe server.' }, { status: 400 });
  const r = await pushToUser(user.account_id, user.id, {
    title: 'Leaply — test',
    body: 'Notificările funcționează. Așa te anunțăm când vine un lead nou. 🚀',
    url: `${appUrl()}/app`,
    tag: 'test',
  });
  return NextResponse.json({ ok: true, sent: r.sent });
}
