import { NextResponse } from 'next/server';
import { getSessionUser } from '../../../../lib/auth';
import { listConversationsFiltered } from '../../../../lib/store';
export const dynamic = 'force-dynamic';

export async function GET() {
  const user = getSessionUser();
  if (!user) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 });
  const rows = listConversationsFiltered(user.account_id, {});
  const esc = (v: any) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = ['nume,telefon,canal,sursa,scor,status,asignat,calificare,creat,actualizat']
    .concat(rows.map((r: any) => [r.lead_name, r.phone, r.channel, r.source, r.score, r.status, r.assigned_name || '',
      JSON.stringify(JSON.parse(r.qualification || '{}')), r.created_at, r.updated_at].map(esc).join(',')))
    .join('\n');
  return new NextResponse('﻿' + csv, {
    headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="leaply-leads-${new Date().toISOString().slice(0, 10)}.csv"` },
  });
}
