import { NextRequest, NextResponse } from 'next/server';
import { cfg, appUrl } from '../../../../lib/settings';
import crypto from 'crypto';
import { processInbound } from '../../../../lib/webhook';
import { resolveAccount, getChannel } from '../../../../lib/channels';
export const dynamic = 'force-dynamic';

// Webhook Twilio pentru WhatsApp (form-encoded). Validare X-Twilio-Signature cu auth_token-ul contului.
function validTwilioSig(url: string, params: Record<string, string>, header: string | null, authToken: string): boolean {
  if (!header) return false;
  const data = url + Object.keys(params).sort().map(k => k + params[k]).join('');
  const expected = crypto.createHmac('sha1', authToken).update(Buffer.from(data, 'utf-8')).digest('base64');
  try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(header)); } catch { return false; }
}

export async function POST(req: NextRequest) {
  const form = await req.formData().catch(() => null);
  if (!form) return new NextResponse('bad request', { status: 400 });
  const params: Record<string, string> = {};
  form.forEach((v, k) => { params[k] = String(v); });

  const accId = resolveAccount('whatsapp_twilio', params);
  const ch = getChannel(accId, 'whatsapp');
  if (ch?.creds?.provider === 'twilio' && ch.creds.auth_token) {
    const url = `${appUrl()}/api/webhooks/twilio`;
    if (!validTwilioSig(url, params, req.headers.get('x-twilio-signature'), ch.creds.auth_token) && process.env.NODE_ENV === 'production') {
      return new NextResponse('invalid signature', { status: 401 });
    }
  } else if (process.env.NODE_ENV === 'production') {
    return new NextResponse('unknown number', { status: 404 });
  }

  await processInbound('whatsapp_twilio', params);
  // Răspundem cu TwiML gol — răspunsul efectiv pleacă prin API, nu prin TwiML
  return new NextResponse('<?xml version="1.0" encoding="UTF-8"?><Response></Response>', {
    status: 200, headers: { 'Content-Type': 'text/xml' },
  });
}
