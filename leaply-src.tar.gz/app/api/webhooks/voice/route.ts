import { NextRequest, NextResponse } from 'next/server';
import { db, uid } from '../../../../lib/db';
import { resolveAccount } from '../../../../lib/channels';
import { getAccount, createInboundConversation, addMessage } from '../../../../lib/store';
import { sendSms } from '../../../../lib/sms';
import { getOwnerEmail } from '../../../../lib/integrations';
import { sendMail } from '../../../../lib/mail';
export const dynamic = 'force-dynamic';

// Canal VOCE (Twilio Voice). Apel primit pe numărul clientului (gestionat de Leaply):
// 1. Răspundem cu TwiML în română + înregistrăm mesajul vocal.
// 2. Apelantul devine LEAD instant (conversație canal "voice" în inbox).
// 3. Follow-up automat pe SMS către apelant — restul procesului (calificare,
//    programare, follow-ups) continuă pe SMS/WhatsApp prin motorul existent.
const xml = (body: string) =>
  new NextResponse(`<?xml version="1.0" encoding="UTF-8"?><Response>${body}</Response>`,
    { headers: { 'Content-Type': 'text/xml; charset=utf-8' } });

export async function POST(req: NextRequest) {
  const form = await req.formData().catch(() => null);
  if (!form) return new NextResponse('bad request', { status: 400 });
  const p: Record<string, string> = {};
  form.forEach((v, k) => { p[k] = String(v); });

  const accId = resolveAccount('voice', p);
  const acc = getAccount(accId);
  const biz = acc?.config?.businessName || 'firma noastră';
  const from = p.From || '';
  const callSid = p.CallSid || uid('call_');

  // Callback după înregistrare — atașăm mesajul vocal conversației
  if (p.RecordingUrl) {
    const conv: any = db().prepare(
      "SELECT c.id FROM conversations c JOIN leads l ON l.id=c.lead_id WHERE c.account_id=? AND l.phone=? AND c.channel='voice' ORDER BY c.created_at DESC LIMIT 1"
    ).get(accId, from);
    if (conv) addMessage(conv.id, 'in', 'lead', `🎙️ Mesaj vocal (${p.RecordingDuration || '?'}s): ${p.RecordingUrl}.mp3`);
    return xml('<Say language="ro-RO">Mulțumim! Revenim imediat cu un mesaj. O zi bună!</Say>');
  }

  // Apel nou → lead + conversație în inbox
  const { convId } = createInboundConversation(accId, 'voice', `Apel ${from.slice(-4)}`, from, 'telefon', `📞 Apel primit (${callSid})`);

  // Follow-up instant pe SMS — sub 60s, ca peste tot în Leaply
  const smsText = `Bună ziua! Sunt asistentul ${biz}. Am văzut apelul dvs. — cu ce vă putem ajuta? Răspundeți la acest mesaj și vă preluăm imediat cererea.`;
  sendSms(from, smsText).then(ok => { if (ok) addMessage(convId, 'out', 'ai', smsText); }).catch(() => {});
  const ownerEmail = getOwnerEmail(accId);
  if (ownerEmail) sendMail(ownerEmail, 'Lead nou din apel telefonic', `<p>Ai primit un apel de la <b>${from}</b>. Leaply i-a trimis deja un SMS de follow-up; conversația e în inbox.</p>`).catch(() => {});

  return xml(
    `<Say language="ro-RO">Bună ziua! Ați sunat la ${biz.replace(/[<>&]/g, '')}. Momentan colegii sunt ocupați, dar v-am trimis un SMS și vă răspundem în mai puțin de un minut. După ton, ne puteți lăsa și un mesaj vocal.</Say>` +
    `<Record maxLength="90" playBeep="true" recordingStatusCallback="/api/webhooks/voice" />`
  );
}
