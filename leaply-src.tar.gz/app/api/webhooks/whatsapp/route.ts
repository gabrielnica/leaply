import { NextRequest, NextResponse } from 'next/server';
import { verifyMeta, checkSignature, processInbound } from '../../../../lib/webhook';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const challenge = verifyMeta(new URL(req.url));
  if (challenge !== null) return new NextResponse(challenge, { status: 200 });
  return new NextResponse('forbidden', { status: 403 });
}

export async function POST(req: NextRequest) {
  const raw = await req.text();
  const ok = checkSignature(raw, req.headers.get('x-hub-signature-256'), process.env.WHATSAPP_APP_SECRET);
  if (!ok) return NextResponse.json({ error: 'invalid signature' }, { status: 401 });
  let payload: any = {}; try { payload = JSON.parse(raw); } catch {}
  const result = await processInbound('whatsapp', payload);
  return NextResponse.json(result);
}
