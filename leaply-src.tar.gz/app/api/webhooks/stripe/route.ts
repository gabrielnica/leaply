import { NextRequest, NextResponse } from 'next/server';
import { verifyStripeEvent, applyPlan } from '../../../../lib/stripe';
import { emitWebhookOut, getOwnerEmail, setIntegration } from '../../../../lib/integrations';
import { issueInvoice } from '../../../../lib/smartbill';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const raw = await req.text();
  const event = verifyStripeEvent(raw, req.headers.get('stripe-signature'));
  if (!event) return NextResponse.json({ error: 'invalid signature' }, { status: 401 });

  if (event.type === 'checkout.session.completed') {
    const s = event.data?.object || {};
    const accId = s.metadata?.account_id || s.client_reference_id;
    const plan = s.metadata?.plan;
    if (accId && plan) {
      applyPlan(accId, plan);
      // ținem minte abonamentul — la schimbări de plan îl ACTUALIZĂM (prorata), nu creăm altul
      try { setIntegration(accId, 'stripe', { subscription_id: s.subscription || '', customer_id: s.customer || '', plan }); } catch {}
      emitWebhookOut(accId, 'billing.upgraded', { plan });
      const acc: any = db().prepare('SELECT name FROM accounts WHERE id=?').get(accId);
      issueInvoice(accId, plan, acc?.name || '', getOwnerEmail(accId)); // factura SmartBill, async best-effort
      console.log(`[leaply stripe] cont ${accId} -> plan ${plan}`);
    }
  }
  if (event.type === 'customer.subscription.updated') {
    // acoperă și schimbările făcute direct din dashboard-ul Stripe
    const o = event.data?.object || {};
    const accId = o.metadata?.account_id;
    const plan = o.metadata?.plan;
    if (accId && plan && ['active', 'trialing'].includes(o.status)) applyPlan(accId, plan);
  }
  if (event.type === 'customer.subscription.deleted') {
    const accId = event.data?.object?.metadata?.account_id;
    if (accId) {
      applyPlan(accId, 'Trial');
      try { setIntegration(accId, 'stripe', null); } catch {}
      try { const { audit } = await import('../../../../lib/audit'); audit('stripe', 'billing.churn', accId, { plan: event.data?.object?.metadata?.plan }); } catch {}
    }
  }
  return NextResponse.json({ received: true });
}
