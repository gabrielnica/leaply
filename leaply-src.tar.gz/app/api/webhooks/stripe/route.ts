import { NextRequest, NextResponse } from 'next/server';
import { verifyStripeEvent, applyPlan } from '../../../../lib/stripe';
import { emitWebhookOut, getOwnerEmail } from '../../../../lib/integrations';
import { issueInvoice } from '../../../../lib/smartbill';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const raw = await req.text();
  const event = verifyStripeEvent(raw, req.headers.get('stripe-signature'));
  if (!event) return NextResponse.json({ error: 'invalid signature' }, { status: 401 });

  if (event.type === 'checkout.session.completed') {
    const s = event.data?.object || {};
    const accId = s.metadata?.account_id || s.client_reference_id;
    const plan = s.metadata?.plan;
    if (accId && plan) {
      applyPlan(accId, plan);
      emitWebhookOut(accId, 'billing.upgraded', { plan });
      const acc: any = db().prepare('SELECT name FROM accounts WHERE id=?').get(accId);
      issueInvoice(accId, plan, acc?.name || '', getOwnerEmail(accId)); // factura SmartBill, async best-effort
      console.log(`[leaply stripe] cont ${accId} -> plan ${plan}`);
    }
  }
  if (event.type === 'customer.subscription.deleted') {
    const accId = event.data?.object?.metadata?.account_id;
    if (accId) applyPlan(accId, 'Trial');
  }
  return NextResponse.json({ received: true });
}
