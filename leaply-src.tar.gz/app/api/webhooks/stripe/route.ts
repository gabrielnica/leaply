import { NextRequest, NextResponse } from 'next/server';
import { verifyStripeEvent, applyPlan, fetchSubscriptionMeta } from '../../../../lib/stripe';
import { emitWebhookOut, getOwnerEmail, setIntegration, getIntegrations } from '../../../../lib/integrations';
import { issueInvoice } from '../../../../lib/smartbill';
import { sendMail } from '../../../../lib/mail';
import { appUrl } from '../../../../lib/settings';
import { db } from '../../../../lib/db';
export const dynamic = 'force-dynamic';

const PRICE: Record<string, number> = { Start: 59, Pro: 129, Scale: 299 };
const roDate = (iso?: string | null) => {
  try { return iso ? new Date(iso).toLocaleDateString('ro-RO', { day: 'numeric', month: 'long', year: 'numeric' }) : ''; } catch { return ''; }
};
const accName = (accId: string) => (db().prepare('SELECT name FROM accounts WHERE id=?').get(accId) as any)?.name || '';

export async function POST(req: NextRequest) {
  const raw = await req.text();
  const event = verifyStripeEvent(raw, req.headers.get('stripe-signature'));
  if (!event) return NextResponse.json({ error: 'invalid signature' }, { status: 401 });

  if (event.type === 'checkout.session.completed') {
    const s = event.data?.object || {};
    const accId = s.metadata?.account_id || s.client_reference_id;
    const plan = s.metadata?.plan;
    if (accId && plan) {
      applyPlan(accId, plan);
      // ținem minte abonamentul — la schimbări de plan îl ACTUALIZĂM (prorata), nu creăm altul.
      // salvăm și data de activare + următoarea reînnoire (pentru dashboard client & admin).
      const meta = await fetchSubscriptionMeta(s.subscription || '');
      try {
        setIntegration(accId, 'stripe', {
          subscription_id: s.subscription || '', customer_id: s.customer || '', plan,
          since: new Date().toISOString(), renews_at: meta.renews_at || null, status: 'active',
        });
      } catch {}
      emitWebhookOut(accId, 'billing.upgraded', { plan });
      const name = accName(accId);
      const email = getOwnerEmail(accId);
      issueInvoice(accId, plan, name, email); // factura SmartBill, async best-effort
      // Email de confirmare a plății către client (pe lângă factura SmartBill)
      if (email) {
        const { planLabel } = await import('../../../../lib/plan');
        sendMail(email, `Bun venit pe pachetul ${planLabel(plan)} — Leaply e activ`,
          `<p>Mulțumim, <b>${name || 'echipă'}</b>! Plata a fost înregistrată și pachetul <b>${planLabel(plan)}</b> (${PRICE[plan] || ''}€/lună) e activ acum.</p>
           <p>Asistentul răspunde de acum la toate lead-urile tale, pe toate canalele incluse în plan.${meta.renews_at ? ` Următoarea reînnoire: <b>${roDate(meta.renews_at)}</b>.` : ''}</p>
           <p>Factura o primești separat, pe adresa de facturare din cont.</p>
           <p><a href="${appUrl()}/app" style="background:#FF4D1F;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Deschide dashboard-ul</a></p>
           <p style="color:#888;font-size:13px">Poți schimba sau anula planul oricând din Setări & Plan, fără contract pe termen lung.</p>`).catch(() => {});
      }
      console.log(`[leaply stripe] cont ${accId} -> plan ${plan}`);
    }
  }

  if (event.type === 'customer.subscription.updated') {
    // acoperă și schimbările făcute direct din dashboard-ul Stripe
    const o = event.data?.object || {};
    const accId = o.metadata?.account_id;
    const plan = o.metadata?.plan;
    if (accId && plan && ['active', 'trialing'].includes(o.status)) {
      applyPlan(accId, plan);
      try {
        const prev = getIntegrations(accId).stripe || {};
        const renews = o.current_period_end ? new Date(o.current_period_end * 1000).toISOString() : (prev.renews_at || null);
        setIntegration(accId, 'stripe', { ...prev, plan, renews_at: renews, status: o.status });
      } catch {}
    }
  }

  if (event.type === 'invoice.paid') {
    // Factură SmartBill pe SUMA REALĂ pentru: reînnoiri lunare/anuale, prorate la upgrade, add-on-uri.
    // Prima plată (subscription_create) e facturată deja la checkout.session.completed — nu dublăm.
    const o = event.data?.object || {};
    const reason = String(o.billing_reason || '');
    const accId = o.subscription_details?.metadata?.account_id || o.lines?.data?.[0]?.metadata?.account_id;
    const amount = Math.round((Number(o.amount_paid) || 0)) / 100;
    if (accId && amount > 0 && reason !== 'subscription_create') {
      try {
        const { issueInvoiceAmount } = await import('../../../../lib/smartbill');
        const desc = reason === 'subscription_cycle'
          ? 'Abonament Leaply — reînnoire'
          : 'Servicii Leaply — actualizare abonament / resurse extra (prorata)';
        issueInvoiceAmount(accId, amount, desc, 'LEAPLY-SUB', accName(accId), getOwnerEmail(accId)); // async best-effort
      } catch (e) { console.error('[stripe invoice.paid]', String(e).slice(0, 150)); }
    }
  }

  if (event.type === 'invoice.payment_failed') {
    // card refuzat / plată eșuată → avertizăm clientul (dunning) și admin-ul
    const o = event.data?.object || {};
    const accId = o.subscription_details?.metadata?.account_id || o.lines?.data?.[0]?.metadata?.account_id;
    if (accId) {
      try {
        const prev = getIntegrations(accId).stripe || {};
        setIntegration(accId, 'stripe', { ...prev, status: 'past_due' });
      } catch {}
      try { const { audit } = await import('../../../../lib/audit'); audit('stripe', 'billing.payment_failed', accId, { attempt: o.attempt_count }); } catch {}
      const name = accName(accId);
      const email = getOwnerEmail(accId);
      if (email) {
        sendMail(email, 'Plata pentru abonamentul Leaply nu a reușit',
          `<p>Bună, <b>${name || 'echipă'}</b>. Am încercat să procesăm plata abonamentului tău Leaply, dar cardul a fost refuzat.</p>
           <p>Ca asistentul să rămână activ, actualizează metoda de plată din contul tău. Stripe reîncearcă automat în următoarele zile.</p>
           <p><a href="${appUrl()}/app/settings" style="background:#FF4D1F;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Actualizează plata</a></p>
           <p style="color:#888;font-size:13px">Dacă e o eroare, scrie-ne la salut@leaply.ro și rezolvăm împreună.</p>`).catch(() => {});
      }
      const adminEmail = (db().prepare("SELECT email FROM users WHERE role='admin' ORDER BY created_at LIMIT 1").get() as any)?.email;
      if (adminEmail) sendMail(adminEmail, `⚠️ Plată eșuată: ${name}`, `<p>Plata a eșuat pentru contul <b>${name}</b> (${email || 'fără email'}). <a href="${appUrl()}/admin/account/${accId}">Deschide în admin</a></p>`).catch(() => {});
    }
  }

  if (event.type === 'customer.subscription.deleted') {
    const accId = event.data?.object?.metadata?.account_id;
    if (accId) {
      applyPlan(accId, 'Trial');
      try { setIntegration(accId, 'stripe', null); } catch {}
      try { const { audit } = await import('../../../../lib/audit'); audit('stripe', 'billing.churn', accId, { plan: event.data?.object?.metadata?.plan }); } catch {}
      const name = accName(accId);
      const email = getOwnerEmail(accId);
      if (email) {
        sendMail(email, 'Abonamentul tău Leaply a fost anulat',
          `<p>Bună, <b>${name || 'echipă'}</b>. Am înregistrat anularea abonamentului tău Leaply. Nu se mai fac plăți viitoare.</p>
           <p>Contul tău rămâne, iar lead-urile intră în continuare în inbox — dar asistentul nu le mai răspunde automat. Te poți reabona oricând, în câteva secunde.</p>
           <p><a href="${appUrl()}/app/settings" style="background:#FF4D1F;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Reactivează un plan</a></p>
           <p style="color:#888;font-size:13px">Ne pare rău să te vedem plecând. Dacă a fost ceva ce puteam face mai bine, răspunde la acest email — chiar ne ajută.</p>`).catch(() => {});
      }
    }
  }
  return NextResponse.json({ received: true });
}
