import { NextRequest, NextResponse } from 'next/server';
import { cfg } from '../../../../lib/settings';
import { verifyMeta, checkSignature, processInbound } from '../../../../lib/webhook';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const challenge = verifyMeta(new URL(req.url));
  if (challenge !== null) return new NextResponse(challenge, { status: 200 });
  return new NextResponse('forbidden', { status: 403 });
}

// Meta livrează TOATE evenimentele paginii (Messenger, Instagram DM, Lead Ads) la un
// SINGUR callback. Dispatch după forma payload-ului către canalul corect:
//  - entry[].messaging  → mesaj Messenger (object 'page') sau Instagram DM (object 'instagram')
//  - entry[].changes[].field === 'leadgen' → formular Lead Ads
function channelOf(payload: any): string {
  const obj = payload?.object;
  const entry = payload?.entry?.[0] || {};
  if (Array.isArray(entry.messaging) && entry.messaging.length) {
    return obj === 'instagram' ? 'instagram' : 'messenger';
  }
  const field = entry?.changes?.[0]?.field;
  if (field === 'leadgen') return 'meta_lead_ads';
  if (field === 'messages' || obj === 'instagram') {
    // unele integrări IG livrează mesajele în changes[].value în loc de messaging[]
    return obj === 'instagram' ? 'instagram' : 'messenger';
  }
  return 'meta_lead_ads';
}

export async function POST(req: NextRequest) {
  const raw = await req.text();
  const ok = checkSignature(raw, req.headers.get('x-hub-signature-256'), cfg('META_APP_SECRET'));
  if (!ok) return NextResponse.json({ error: 'invalid signature' }, { status: 401 });
  let payload: any = {}; try { payload = JSON.parse(raw); } catch {}
  const channel = channelOf(payload);
  const result = await processInbound(channel, payload);
  return NextResponse.json(result);
}
