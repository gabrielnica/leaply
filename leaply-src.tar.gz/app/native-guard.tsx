'use client';
import { useEffect } from 'react';

// Rulează pe TOATE paginile (montat în root layout). În aplicația nativă Capacitor:
//  - marchează <html> cu clasa leaply-native (pentru CSS-ul care ascunde plata/înregistrarea)
//  - blochează înregistrarea de cont în app (App Store Guideline 3.1.1): /start și landing → /login.
//    În app-ul iOS/Android se poate DOAR autentifica; contul se creează pe web.
export function NativeGuard() {
  useEffect(() => {
    const w = window as any;
    const native = !!(w.Capacitor && (typeof w.Capacitor.isNativePlatform === 'function' ? w.Capacitor.isNativePlatform() : true));
    if (!native) return;
    try { document.documentElement.classList.add('leaply-native'); } catch {}
    const p = window.location.pathname;
    if (p === '/' || p === '/start' || p.startsWith('/start')) {
      try { window.location.replace('/login'); } catch {}
    }
  }, []);
  return null;
}
