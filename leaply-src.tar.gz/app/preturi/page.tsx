import Link from 'next/link';
import { Logo } from '../../lib/logo';

export const metadata = {
  title: 'Prețuri — Leaply · de la 59€/lună, 14 zile gratuit',
  description: 'Planurile Leaply: Social 59€, Complet 129€ (cu WhatsApp și număr inclus), Total 299€ (cu agent vocal AI). Toate încep cu 14 zile gratuite, fără card.',
};

const PLANS = [
  {
    name: 'Social', price: '59€', hot: false,
    feats: ['Facebook Messenger + Instagram DM', 'Facebook Lead Ads + chat pe site', '300 conversații/lună', 'Google Calendar + follow-up automat'],
  },
  {
    name: 'Complet', price: '129€', hot: true,
    feats: ['Tot din Social + WhatsApp', 'Număr WhatsApp de la Leaply inclus', '800 conversații/lună · echipă 3 colegi', 'API + integrare CRM'],
  },
  {
    name: 'Total', price: '299€', hot: false,
    feats: ['Tot din Complet + agent vocal AI', 'Număr de telefon dedicat · 500 min/lună', '2.500 conversații/lună · echipă 10', 'Multi-locație · onboarding făcut de noi'],
  },
];

export default function Preturi() {
  return (
    <main style={{ maxWidth: 980, margin: '0 auto', padding: '36px 20px 80px', lineHeight: 1.6 }}>
      <p><Link href="/">← leaply.ro</Link></p>
      <div style={{ margin: '10px 0' }}><Logo size={28} /></div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 38, lineHeight: 1.15, margin: '12px 0 6px' }}>Prețuri simple. Un lead salvat îți acoperă abonamentul.</h1>
      <p style={{ fontSize: 18, color: 'var(--muted)', maxWidth: 640 }}>
        <b>Toate planurile încep cu 14 zile gratuite — fără card.</b> Fără cost de instalare la plata anuală (2 luni gratis). Fără contract pe termen lung.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 18, margin: '28px 0' }}>
        {PLANS.map(p => (
          <div key={p.name} style={{ border: p.hot ? '2px solid var(--accent, #FF4D1F)' : '1px solid var(--line)', borderRadius: 18, padding: '22px 22px 18px', position: 'relative', background: '#fff' }}>
            {p.hot && <span style={{ position: 'absolute', top: -12, left: 20, background: 'var(--accent, #FF4D1F)', color: '#fff', borderRadius: 999, padding: '2px 12px', fontSize: 13, fontWeight: 600 }}>Cel mai ales</span>}
            <div style={{ fontWeight: 700, fontSize: 18 }}>{p.name}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 34, margin: '6px 0 12px' }}>{p.price}<span style={{ fontSize: 15, color: 'var(--muted)' }}>/lună</span></div>
            <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 16px' }}>
              {p.feats.map(f => <li key={f} style={{ margin: '7px 0' }}>✓ {f}</li>)}
            </ul>
            <Link href="/start" className={`btn ${p.hot ? 'btn-primary' : 'btn-dark'}`} style={{ width: '100%', justifyContent: 'center' }}>Începe gratuit</Link>
          </div>
        ))}
      </div>
      <p style={{ color: 'var(--muted)' }}>
        Fiecare pachet include tot ce e în cel dinaintea lui. Extra resurse oricând: +200 conversații 19€ · +100 min voce 29€ · +500 SMS 29€ · număr suplimentar 12€/lună.
        Suport în română, date în UE, facturare românească (SmartBill). Întrebări? <Link href="/contact">Contactează-ne</Link>.
      </p>
      <p style={{ marginTop: 20 }}>
        <Link href="/demo" className="btn btn-secondary">Vezi întâi un demo pe afacerea ta</Link>
      </p>
    </main>
  );
}
