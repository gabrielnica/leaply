import Link from 'next/link';
import { Logo } from '../../lib/logo';
import { listAccountsWithStats } from '../../lib/store';
import { llmActive } from '../../lib/llm';
export const dynamic = 'force-dynamic';

export default function Admin() {
  const accs = listAccountsWithStats();
  const totalLeads = accs.reduce((s, a) => s + a.leads, 0);
  return (
    <div className="shell">
      <aside className="side">
        <div className="logo" style={{ color: '#fff' }}><Logo light size={26} /></div>
        <Link href="/admin" className="active"><span>🛡️</span><span>Admin</span></Link>
        <Link href="/app"><span>🏠</span><span>Dashboard client</span></Link>
        <Link href="/"><span>↩</span><span>Site public</span></Link>
      </aside>
      <main className="main">
        <h1 className="h-title">Admin — Leaply Ops</h1>
        <p className="h-sub">Platformă internă · toate conturile & sănătatea sistemului</p>
        <div className="kpis">
          <div className="kpi"><div className="l">Conturi active</div><div className="v">{accs.length}</div></div>
          <div className="kpi"><div className="l">Lead-uri procesate</div><div className="v">{totalLeads}</div></div>
          <div className="kpi"><div className="l">Motor AI</div><div className="v" style={{ fontSize: 18 }}>{llmActive() ? 'LLM real' : 'Reguli RO'}</div></div>
          <div className="kpi hero"><div className="l">SLA răspuns</div><div className="v" style={{ fontSize: 22 }}>&lt;60s ✓</div></div>
        </div>
        <div className="panel">
          <b>Conturi (tenants)</b>
          <div className="row" style={{ fontSize: 12, color: '#64748b', fontWeight: 700 }}>
            <span>FIRMĂ</span><span style={{ display: 'flex', gap: 30 }}><span>LEAD-URI</span><span>PROGRAMĂRI</span><span>RĂSPUNS</span><span>HEALTH</span></span>
          </div>
          {accs.map(a => (
            <div key={a.id} className="row">
              <span><b>{a.name}</b> <span className="pill">{a.plan}</span><br /><span style={{ color: '#64748b', fontSize: 13 }}>{a.vertical}</span></span>
              <span style={{ display: 'flex', gap: 46, alignItems: 'center' }}>
                <span>{a.leads}</span><span>{a.booked}</span><span>{a.avgSec}s</span>
                <span style={{ fontWeight: 700, color: a.health > 70 ? '#16A34A' : '#FFB020' }}>{a.health}</span>
              </span>
            </div>
          ))}
        </div>
        <div className="panel">
          <b>Sănătate sistem</b>
          <div className="row"><span>Bază de date</span><span className="connected">● OK</span></div>
          <div className="row"><span>Webhooks canale (Meta/WhatsApp/Messenger/IG)</span><span className="connected">● Active</span></div>
          <div className="row"><span>Latență răspuns AI (p90)</span><span className="connected">● &lt; 60s</span></div>
          <div className="row"><span>Motor AI</span><span className="pill">{llmActive() ? 'LLM real (cheie prezentă)' : 'Creier pe reguli (fără cheie)'}</span></div>
        </div>
      </main>
    </div>
  );
}
