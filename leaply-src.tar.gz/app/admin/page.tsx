import Link from 'next/link';
import { redirect } from 'next/navigation';
import { listAccountsWithStats, listAccountsPaged } from '../../lib/store';
import { llmActive } from '../../lib/llm';
import { getSessionUser } from '../../lib/auth';
import { db } from '../../lib/db';
import { recentAudit } from '../../lib/audit';
import { ProvisionButton } from './provision-button';
import { CreateAccount } from './create-account';
import { Broadcast } from './broadcast';
import { adminKpis, funnelStats } from '../../lib/adminstats';
import { trialDaysLeft } from '../../lib/plan';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconBuilding = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="4" y="3" width="16" height="18" rx="1.5" /><path d="M9 21v-4h6v4M8 7h.01M12 7h.01M16 7h.01M8 11h.01M12 11h.01M16 11h.01" />
  </svg>
);
const IconUsers = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.85M15.5 3.15a4 4 0 0 1 0 7.7" />
  </svg>
);
const IconCpu = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="6" y="6" width="12" height="12" rx="2" /><rect x="10" y="10" width="4" height="4" /><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" />
  </svg>
);
const IconClock = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />
  </svg>
);

export default function Admin({ searchParams }: { searchParams?: { q?: string; plan?: string; page?: string } }) {
  const q = (searchParams?.q || '').slice(0, 80);
  const planF = ['Trial', 'Start', 'Pro', 'Scale'].includes(searchParams?.plan || '') ? searchParams!.plan! : '';
  const paged = listAccountsPaged({ q, plan: planF || undefined, page: Number(searchParams?.page) || 1, per: 25 });
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'admin') redirect('/app');
  const accs = listAccountsWithStats();
  const totalLeads = accs.reduce((s, a) => s + a.leads, 0);
  const demoReqs: any[] = db().prepare('SELECT * FROM demo_requests ORDER BY created_at DESC LIMIT 50').all();
  const users: any[] = db().prepare(`
    SELECT u.name, u.email, u.role, u.created_at, u.account_id, a.name AS business, a.plan
    FROM users u LEFT JOIN accounts a ON a.id = u.account_id
    ORDER BY u.created_at DESC LIMIT 100`).all();
  const PAID = ['Start', 'Pro', 'Scale'];
  const k = adminKpis();
  const funnel = funnelStats();
  return (
    <>
          <div className="ap-head">
            <div>
              <h1 className="ap-title">Admin — Leaply Ops</h1>
              <p className="ap-sub">Platformă internă · toate conturile & sănătatea sistemului</p>
            </div>
            <a className="btn btn-secondary btn-sm" href="/api/admin/export" download>⬇︎ Export CSV conturi</a>
          </div>

          <div className="ap-kpis">
            <div className="ap-kpi ap-kpi-hero">
              <div className="ap-kpi-l"><IconClock /> MRR</div>
              <div className="ap-kpi-v">{k.mrr} €</div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconUsers /> Plătitori / Trial</div>
              <div className="ap-kpi-v">{k.paidCount}<span style={{ fontSize: 16, color: 'var(--muted)' }}> / {k.trialCount}</span></div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconClock /> Trial expiră ≤3 zile</div>
              <div className="ap-kpi-v" style={k.expiringSoon > 0 ? { color: 'var(--accent)' } : undefined}>{k.expiringSoon}<span style={{ fontSize: 15, color: 'var(--muted)' }}> ({k.expired} expirate)</span></div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconBuilding /> Conturi noi (7 zile)</div>
              <div className="ap-kpi-v">{k.new7d}</div>
            </div>
          </div>
          <div className="ap-kpis">
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconCpu /> Conversații luna asta</div>
              <div className="ap-kpi-v">{k.convMonth}</div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconUsers /> SMS / min voce (luna)</div>
              <div className="ap-kpi-v">{k.smsMonth}<span style={{ fontSize: 16, color: 'var(--muted)' }}> / {k.voiceMinMonth}</span></div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconBuilding /> Numere alocate</div>
              <div className="ap-kpi-v">{k.numbers}</div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconCpu /> Motor AI</div>
              <div className="ap-kpi-v" style={{ fontSize: 22 }}>{llmActive() ? 'LLM real' : 'Reguli RO'}</div>
            </div>
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Funnel: demo → cont → activat → plătitor</span></div>
            <div className="row"><span>Cereri de demo (landing)</span><span className="ap-cell-num">{funnel.demoReqs}</span></div>
            <div className="row"><span>Conturi create</span><span className="ap-cell-num">{funnel.accounts} <span className="muted">({funnel.pctAcc}% din cereri)</span></span></div>
            <div className="row"><span>Activate (canal real conectat)</span><span className="ap-cell-num">{funnel.activated} <span className="muted">({funnel.pctAct}% din conturi)</span></span></div>
            <div className="row"><span>Plătitori</span><span className="ap-cell-num">{funnel.paid} <span className="muted">({funnel.pctPaid}% din conturi)</span></span></div>
          </div>

          <div className="panel">
            <div className="ap-panel-head">
              <span className="ap-panel-title">Conturi ({paged.total}) · pagina {paged.page}/{paged.pages}</span>
              <form method="get" action="/admin" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input className="txt" name="q" defaultValue={q} placeholder="Caută firmă / email / domeniu…" style={{ width: 240 }} aria-label="Caută cont" />
                <select className="txt" name="plan" defaultValue={planF} style={{ width: 110 }} aria-label="Filtru plan">
                  <option value="">Toate</option>
                  <option>Trial</option><option>Start</option><option>Pro</option><option>Scale</option>
                </select>
                <button className="btn btn-dark btn-sm" type="submit">Filtrează</button>
              </form>
            </div>
            <div className="ap-table-head ap-admin-grid">
              <span>Firmă / owner</span><span>Plan</span><span>Conv. luna asta</span><span>Lead-uri</span><span>Programări</span><span>Canale</span><span>Ultima activitate</span>
            </div>
            {paged.rows.map((a: any) => (
              <Link key={a.id} href={`/admin/account/${a.id}`} className="ap-table-row ap-admin-grid" style={{ textDecoration: 'none', color: 'inherit' }}>
                <span className="ap-lead">
                  <span className="ap-lead-name">{a.name}</span>
                  <span className="ap-lead-meta">{a.owner_email || 'fără user'} · {a.vertical || '—'}</span>
                </span>
                <span>
                  {['acc_demo', 'acc_leaply'].includes(a.id)
                    ? <span className="badge b-warm">intern · {a.plan}</span>
                    : <span className={`badge ${['Start','Pro','Scale'].includes(a.plan) ? 'b-booked' : 'b-warm'}`}>{a.plan || 'Trial'}</span>}
                  {(() => {
                    if (['Start', 'Pro', 'Scale'].includes(a.plan)) return null;
                    const left = trialDaysLeft(a.id);
                    if (left === null) return null;
                    return <span className="ap-lead-meta" style={{ display: 'block', marginTop: 3, color: left <= 3 ? 'var(--accent)' : undefined }}>{left > 0 ? `expiră în ${left} z` : 'expirat'}</span>;
                  })()}
                </span>
                <span className="ap-cell-num">{a.usage_month}</span>
                <span className="ap-cell-num">{a.leads}</span>
                <span className="ap-cell-num">{a.booked}</span>
                <span className="ap-cell-num">{a.channels_on}/6</span>
                <span className="ap-lead-meta">{a.last_activity ? new Date(a.last_activity).toLocaleDateString('ro-RO') : '—'}</span>
              </Link>
            ))}
            {paged.pages > 1 && (
              <div style={{ display: 'flex', gap: 8, padding: '12px 4px' }}>
                {Array.from({ length: paged.pages }, (_, i) => i + 1).slice(0, 20).map(n => (
                  <Link key={n} href={`/admin?q=${encodeURIComponent(q)}&plan=${planF}&page=${n}`} className={`pill${n === paged.page ? ' pill-on' : ''}`}>{n}</Link>
                ))}
              </div>
            )}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Utilizatori înregistrați ({users.length}) · {k.paidCount} plătesc · {k.trialCount} pe trial · MRR {k.mrr}€</span></div>
            {users.map((u, i) => (
              <div key={i} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{u.name} {u.role === 'admin' && <span className="pill">admin</span>}</span>
                  <span className="ap-lead-meta">{u.email} · {u.business || 'fără firmă'} · {new Date(u.created_at).toLocaleDateString('ro-RO')}</span>
                </span>
                {['acc_demo', 'acc_leaply'].includes(u.account_id)
                  ? <span className="badge b-warm">intern</span>
                  : <span className={`badge ${PAID.includes(u.plan) ? 'b-booked' : 'b-warm'}`}>{PAID.includes(u.plan) ? `Plătește · ${u.plan}` : (u.plan || 'Trial')}</span>}
              </div>
            ))}
          </div>

          <CreateAccount />
          <Broadcast />
          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Cereri de demo (funnel landing → wizard)</span></div>
            {demoReqs.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Nicio cerere încă.</p>}
            {demoReqs.map(r => (
              <div key={r.id} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{r.name} {r.business ? `· ${r.business}` : ''}</span>
                  <span className="ap-lead-meta">{r.contact} · {r.vertical || 'vertical nespecificat'} · {new Date(r.created_at).toLocaleString('ro-RO')}</span>
                </span>
                {['whatsapp_number', 'voice_number'].includes(r.vertical) && r.account_id && !String(r.status || '').startsWith('număr') ? (
                  <ProvisionButton requestId={r.id} kind={r.vertical === 'voice_number' ? 'voice' : 'whatsapp'} />
                ) : (
                  <span className={`badge ${r.status === 'cont creat' ? 'b-booked' : 'b-warm'}`}>{r.status}</span>
                )}
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Jurnal de audit (ultimele acțiuni sensibile)</span></div>
            {recentAudit(20).length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Nimic încă.</p>}
            {recentAudit(20).map((a: any) => (
              <div key={a.id} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{a.action} <span className="pill">{a.target || '—'}</span></span>
                  <span className="ap-lead-meta">{a.actor} · {new Date(a.created_at).toLocaleString('ro-RO')}</span>
                </span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Sănătate sistem <span className="pill">live</span></span></div>
            {(() => {
              // valori REALE, nu text static
              let cronLast: string | null = null, backupLast: string | null = null, whErr7 = 0;
              try { const { cfg } = require('../../lib/settings'); cronLast = cfg('CRON_LAST_RUN') || null; } catch {}
              try { const { latestBackup } = require('../../lib/backup'); const b = latestBackup(); backupLast = b?.mtime || null; } catch {}
              try { whErr7 = (db().prepare("SELECT COUNT(*) c FROM audit_log WHERE action LIKE 'delivery.%' AND meta LIKE '%error%' AND created_at > datetime('now','-7 days')").get() as any).c; } catch {}
              const cronOk = cronLast && Date.now() - new Date(cronLast).getTime() < 30 * 60_000;
              const bkOk = backupLast && Date.now() - new Date(backupLast).getTime() < 2 * 3600_000;
              const ago = (iso: string | null) => iso ? `${Math.round((Date.now() - new Date(iso).getTime()) / 60000)} min` : '—';
              return (
                <>
                  <div className="row"><span>Bază de date</span><span className="connected">OK</span></div>
                  <div className="row"><span>Cron (ultimul tick)</span><span className={cronOk ? 'connected' : 'badge b-warm'}>{cronOk ? `OK · acum ${ago(cronLast)}` : cronLast ? `⚠ acum ${ago(cronLast)}` : '⚠ n-a rulat'}</span></div>
                  <div className="row"><span>Backup (ultimul)</span><span className={bkOk ? 'connected' : 'badge b-warm'}>{backupLast ? `acum ${ago(backupLast)}` : '⚠ niciun backup'}</span></div>
                  <div className="row"><span>Erori de livrare (7 zile)</span><span className={whErr7 ? 'badge b-warm' : 'connected'}>{whErr7 || 'niciuna'}</span></div>
                  <div className="row"><span>Motor AI</span><span className="pill">{llmActive() ? 'LLM real (cheie prezentă)' : 'Creier pe reguli (fără cheie)'}</span></div>
                </>
              );
            })()}
          </div>
    </>
  );
}
