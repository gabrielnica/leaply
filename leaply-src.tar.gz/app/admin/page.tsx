import Link from 'next/link';
import { redirect } from 'next/navigation';
import { Logo } from '../../lib/logo';
import { listAccountsWithStats, listAccountsPaged } from '../../lib/store';
import { llmActive } from '../../lib/llm';
import { getSessionUser } from '../../lib/auth';
import { db } from '../../lib/db';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconShield = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 3l8 3v6c0 4.8-3.4 8-8 9-4.6-1-8-4.2-8-9V6z" />
  </svg>
);
const IconHome = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M3 10.5 12 3.5l9 7V20a1 1 0 0 1-1 1h-5.5v-6h-5v6H4a1 1 0 0 1-1-1z" />
  </svg>
);
const IconKey = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="8" cy="15" r="4" /><path d="m10.8 12.2 9.2-9.2M15 4l3 3M18 7l2 2" />
  </svg>
);
const IconArrowLeft = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </svg>
);
const IconBuilding = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="4" y="3" width="16" height="18" rx="1.5" /><path d="M9 21v-4h6v4M8 7h.01M12 7h.01M16 7h.01M8 11h.01M12 11h.01M16 11h.01" />
  </svg>
);
const IconUsers = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.85M15.5 3.15a4 4 0 0 1 0 7.7" />
  </svg>
);
const IconCpu = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="6" y="6" width="12" height="12" rx="2" /><rect x="10" y="10" width="4" height="4" /><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" />
  </svg>
);
const IconClock = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />
  </svg>
);

export default function Admin({ searchParams }: { searchParams?: { q?: string; plan?: string; page?: string } }) {
  const q = (searchParams?.q || '').slice(0, 80);
  const planF = ['Trial', 'Start', 'Pro', 'Scale'].includes(searchParams?.plan || '') ? searchParams!.plan! : '';
  const paged = listAccountsPaged({ q, plan: planF || undefined, page: Number(searchParams?.page) || 1, per: 25 });
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'admin') redirect('/app');
  const accs = listAccountsWithStats();
  const totalLeads = accs.reduce((s, a) => s + a.leads, 0);
  const demoReqs: any[] = db().prepare('SELECT * FROM demo_requests ORDER BY created_at DESC LIMIT 50').all();
  const users: any[] = db().prepare(`
    SELECT u.name, u.email, u.role, u.created_at, a.name AS business, a.plan
    FROM users u LEFT JOIN accounts a ON a.id = u.account_id
    ORDER BY u.created_at DESC LIMIT 100`).all();
  const PAID = ['Start', 'Pro', 'Scale'];
  const paidCount = accs.filter(a => PAID.includes(a.plan)).length;
  const trialCount = accs.filter(a => !PAID.includes(a.plan)).length;
  const mrrEur = accs.reduce((s, a) => s + (({ Start: 59, Pro: 129, Scale: 299 } as any)[a.plan] || 0), 0);
  return (
    <div className="ap-shell">
      <aside className="ap-side">
        <div className="ap-side-logo"><Logo light size={26} /></div>
        <nav className="ap-nav">
          <Link href="/admin" className="ap-nav-link is-active"><IconShield /><span className="ap-nav-label">Admin</span></Link>
          <Link href="/admin/settings" className="ap-nav-link"><IconKey /><span className="ap-nav-label">Setări platformă</span></Link>
          <Link href="/app" className="ap-nav-link"><IconHome /><span className="ap-nav-label">Dashboard client</span></Link>
        </nav>
        <div className="ap-side-foot">
          <Link href="/" className="ap-nav-link"><IconArrowLeft /><span className="ap-nav-label">Site public</span></Link>
        </div>
      </aside>
      <main className="ap-main">
        <div className="ap-content">
          <div className="ap-head">
            <div>
              <h1 className="ap-title">Admin — Leaply Ops</h1>
              <p className="ap-sub">Platformă internă · toate conturile & sănătatea sistemului</p>
            </div>
          </div>

          <div className="ap-kpis">
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconBuilding /> Conturi active</div>
              <div className="ap-kpi-v">{accs.length}</div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconUsers /> Lead-uri procesate</div>
              <div className="ap-kpi-v">{totalLeads}</div>
            </div>
            <div className="ap-kpi">
              <div className="ap-kpi-l"><IconCpu /> Motor AI</div>
              <div className="ap-kpi-v" style={{ fontSize: 22 }}>{llmActive() ? 'LLM real' : 'Reguli RO'}</div>
            </div>
            <div className="ap-kpi ap-kpi-hero">
              <div className="ap-kpi-l"><IconClock /> SLA răspuns</div>
              <div className="ap-kpi-v">&lt;60s</div>
            </div>
          </div>

          <div className="panel">
            <div className="ap-panel-head">
              <span className="ap-panel-title">Conturi ({paged.total}) · pagina {paged.page}/{paged.pages}</span>
              <form method="get" action="/admin" style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input className="txt" name="q" defaultValue={q} placeholder="Caută firmă / email / domeniu…" style={{ width: 240 }} aria-label="Caută cont" />
                <select className="txt" name="plan" defaultValue={planF} style={{ width: 110 }} aria-label="Filtru plan">
                  <option value="">Toate</option>
                  <option>Trial</option><option>Start</option><option>Pro</option><option>Scale</option>
                </select>
                <button className="btn btn-dark btn-sm" type="submit">Filtrează</button>
              </form>
            </div>
            <div className="ap-table-head ap-admin-grid">
              <span>Firmă / owner</span><span>Plan</span><span>Conv. luna asta</span><span>Lead-uri</span><span>Programări</span><span>Canale</span><span>Ultima activitate</span>
            </div>
            {paged.rows.map((a: any) => (
              <Link key={a.id} href={`/admin/account/${a.id}`} className="ap-table-row ap-admin-grid" style={{ textDecoration: 'none', color: 'inherit' }}>
                <span className="ap-lead">
                  <span className="ap-lead-name">{a.name}</span>
                  <span className="ap-lead-meta">{a.owner_email || 'fără user'} · {a.vertical || '—'}</span>
                </span>
                <span><span className={`badge ${['Start','Pro','Scale'].includes(a.plan) ? 'b-booked' : 'b-warm'}`}>{a.plan || 'Trial'}</span></span>
                <span className="ap-cell-num">{a.usage_month}</span>
                <span className="ap-cell-num">{a.leads}</span>
                <span className="ap-cell-num">{a.booked}</span>
                <span className="ap-cell-num">{a.channels_on}/6</span>
                <span className="ap-lead-meta">{a.last_activity ? new Date(a.last_activity).toLocaleDateString('ro-RO') : '—'}</span>
              </Link>
            ))}
            {paged.pages > 1 && (
              <div style={{ display: 'flex', gap: 8, padding: '12px 4px' }}>
                {Array.from({ length: paged.pages }, (_, i) => i + 1).slice(0, 20).map(n => (
                  <Link key={n} href={`/admin?q=${encodeURIComponent(q)}&plan=${planF}&page=${n}`} className={`pill${n === paged.page ? ' pill-on' : ''}`}>{n}</Link>
                ))}
              </div>
            )}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Utilizatori înregistrați ({users.length}) · {paidCount} plătesc · {trialCount} pe trial · MRR ~{mrrEur}€</span></div>
            {users.map((u, i) => (
              <div key={i} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{u.name} {u.role === 'admin' && <span className="pill">admin</span>}</span>
                  <span className="ap-lead-meta">{u.email} · {u.business || 'fără firmă'} · {new Date(u.created_at).toLocaleDateString('ro-RO')}</span>
                </span>
                <span className={`badge ${PAID.includes(u.plan) ? 'b-booked' : 'b-warm'}`}>{PAID.includes(u.plan) ? `Plătește · ${u.plan}` : (u.plan || 'Trial')}</span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Cereri de demo (funnel landing → wizard)</span></div>
            {demoReqs.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Nicio cerere încă.</p>}
            {demoReqs.map(r => (
              <div key={r.id} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{r.name} {r.business ? `· ${r.business}` : ''}</span>
                  <span className="ap-lead-meta">{r.contact} · {r.vertical || 'vertical nespecificat'} · {new Date(r.created_at).toLocaleString('ro-RO')}</span>
                </span>
                <span className={`badge ${r.status === 'cont creat' ? 'b-booked' : 'b-warm'}`}>{r.status}</span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Sănătate sistem</span></div>
            <div className="row"><span>Bază de date</span><span className="connected">OK</span></div>
            <div className="row"><span>Webhooks canale (Meta / WhatsApp / Messenger / IG)</span><span className="connected">Active</span></div>
            <div className="row"><span>Latență răspuns AI (p90)</span><span className="connected">&lt;60s</span></div>
            <div className="row"><span>Motor AI</span><span className="pill">{llmActive() ? 'LLM real (cheie prezentă)' : 'Creier pe reguli (fără cheie)'}</span></div>
          </div>
        </div>
      </main>
    </div>
  );
}
