import Link from 'next/link';
import { Logo } from '../../lib/logo';

// Shell comun pentru paginile secundare de admin (billing, consum).
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IcShield = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 3l8 3v6c0 4.8-3.4 8-8 9-4.6-1-8-4.2-8-9V6z" /></svg>;
const IcCoins = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="9" cy="9" r="6" /><path d="M14.2 5.3A6 6 0 1 1 18.7 14" /></svg>;
const IcGauge = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 15l4-6" /><path d="M4 17a9 9 0 1 1 16 0" /></svg>;
const IcKey = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="8" cy="15" r="4" /><path d="M11 12 21 2M17 6l3 3" /></svg>;
const IcHome = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M3 10.5 12 3.5l9 7V20a1 1 0 0 1-1 1h-5.5v-6h-5v6H4a1 1 0 0 1-1-1z" /></svg>;

export function AdminShell({ active, title, sub, children }: { active: 'billing' | 'consum'; title: string; sub: string; children: React.ReactNode }) {
  return (
    <div className="ap-shell">
      <aside className="ap-side">
        <div className="ap-side-logo"><Logo light size={26} /></div>
        <nav className="ap-nav">
          <Link href="/admin" className="ap-nav-link"><IcShield /><span className="ap-nav-label">Admin</span></Link>
          <Link href="/admin/billing" className={`ap-nav-link${active === 'billing' ? ' is-active' : ''}`}><IcCoins /><span className="ap-nav-label">Billing & MRR</span></Link>
          <Link href="/admin/consum" className={`ap-nav-link${active === 'consum' ? ' is-active' : ''}`}><IcGauge /><span className="ap-nav-label">Consum & marje</span></Link>
          <Link href="/admin/settings" className="ap-nav-link"><IcKey /><span className="ap-nav-label">Setări platformă</span></Link>
          <Link href="/app" className="ap-nav-link"><IcHome /><span className="ap-nav-label">Dashboard client</span></Link>
        </nav>
      </aside>
      <main className="ap-main">
        <div className="ap-content">
          <div className="ap-head">
            <div>
              <h1 className="ap-title">{title}</h1>
              <p className="ap-sub">{sub}</p>
            </div>
          </div>
          {children}
        </div>
      </main>
    </div>
  );
}
