// Sidebar-ul e acum în app/admin/layout.tsx (AdminChrome) — aici a rămas doar
// antetul comun al paginilor secundare, ca să nu se schimbe API-ul componentelor.
export function AdminShell({ title, sub, children }: { active?: string; title: string; sub: string; children: React.ReactNode }) {
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">{title}</h1>
          <p className="ap-sub">{sub}</p>
        </div>
      </div>
      {children}
    </>
  );
}
