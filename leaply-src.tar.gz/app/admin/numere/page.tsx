import { redirect } from 'next/navigation';
import { getSessionUser } from '../../../lib/auth';
import { NumbersManager } from './numbers-manager';

export const dynamic = 'force-dynamic';

export default function AdminNumere() {
  const user = getSessionUser();
  if (!user || user.role !== 'admin') redirect('/admin/login');
  return (
    <>
      <div className="ap-head">
        <h1>Parcul de numere</h1>
        <p className="ap-sub">eSIM Digi + Twilio: inventar, înregistrare pe WhatsApp Cloud API și alocare pe conturi. OTP-ul vine o singură dată pe eSIM — după înregistrare, totul merge prin API.</p>
      </div>
      <NumbersManager />
    </>
  );
}
