'use client';
import { useEffect, useState } from 'react';

type Num = {
  id: string; number: string; kind: string; iccid?: string; status: string;
  waba_id?: string; phone_number_id?: string; account_id?: string; account_name?: string;
  monthly_cost?: number; note?: string; created_at: string; assigned_at?: string;
};
type Acc = { id: string; name: string };

const STATUS_RO: Record<string, string> = { liber: '🟢 liber', in_verificare: '🟡 în verificare', alocat: '🔵 alocat', retras: '⚫ retras' };

async function post(body: any) {
  const r = await fetch('/api/admin/numbers', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Eroare');
  return d;
}

export function NumbersManager() {
  const [rows, setRows] = useState<Num[]>([]);
  const [accounts, setAccounts] = useState<Acc[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState<string | null>(null);

  // formular adăugare
  const [fNum, setFNum] = useState(''); const [fKind, setFKind] = useState('esim_digi');
  const [fIccid, setFIccid] = useState(''); const [fCost, setFCost] = useState('4'); const [fNote, setFNote] = useState('');

  // câmpuri per-număr (token nu se salvează nicăieri în clar în UI state persistent)
  const [token, setToken] = useState('');
  const [pnid, setPnid] = useState(''); const [waba, setWaba] = useState('');
  const [code, setCode] = useState(''); const [pin, setPin] = useState('');
  const [assignAcc, setAssignAcc] = useState(''); const [assignKind, setAssignKind] = useState('whatsapp');

  async function load() {
    try {
      const r = await fetch('/api/admin/numbers');
      const d = await r.json();
      setRows(d.numbers || []); setAccounts(d.accounts || []);
    } catch {}
  }
  useEffect(() => { load(); }, []);

  async function run(body: any, okMsg?: string) {
    setBusy(true); setErr(null); setMsg(null);
    try {
      const d = await post(body);
      setMsg(d.hint || okMsg || 'Gata.');
      await load();
    } catch (e: any) { setErr(String(e.message || e)); }
    setBusy(false);
  }

  return (
    <div style={{ display: 'grid', gap: 18 }}>
      {msg && <div className="panel" style={{ borderLeft: '3px solid var(--ok, #2e9e5b)', padding: '10px 14px' }}>{msg}</div>}
      {err && <div className="panel" style={{ borderLeft: '3px solid var(--bad, #d33)', padding: '10px 14px' }}>⚠ {err}</div>}

      <div className="panel">
        <div className="ap-panel-head"><span className="ap-panel-title">Adaugă număr în inventar</span></div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <input className="txt" style={{ maxWidth: 170 }} placeholder="+40712345678" value={fNum} onChange={e => setFNum(e.target.value)} />
          <select className="txt" style={{ maxWidth: 150 }} value={fKind} onChange={e => setFKind(e.target.value)}>
            <option value="esim_digi">eSIM Digi</option>
            <option value="twilio">Twilio</option>
            <option value="alt">Alt operator</option>
          </select>
          <input className="txt" style={{ maxWidth: 200 }} placeholder="ICCID (opțional)" value={fIccid} onChange={e => setFIccid(e.target.value)} />
          <input className="txt" style={{ maxWidth: 110 }} placeholder="cost €/lună" value={fCost} onChange={e => setFCost(e.target.value)} />
          <input className="txt" style={{ maxWidth: 220 }} placeholder="notă (ex. telefon onboarding #1)" value={fNote} onChange={e => setFNote(e.target.value)} />
          <button className="btn btn-primary btn-sm" disabled={busy || !fNum.trim()}
            onClick={() => run({ action: 'add', number: fNum, kind: fKind, iccid: fIccid, monthly_cost: Number(fCost) || 0, note: fNote }, 'Număr adăugat.').then(() => setFNum(''))}>
            Adaugă
          </button>
        </div>
      </div>

      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title">Inventar ({rows.filter(r => r.status !== 'retras').length} numere · {rows.filter(r => r.status === 'liber').length} libere)</span>
        </div>
        <table className="ap-table">
          <thead><tr><th>Număr</th><th>Tip</th><th>Status</th><th>Cont</th><th>phone_number_id</th><th>Cost</th><th></th></tr></thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id}>
                <td><b>{r.number}</b>{r.note ? <div style={{ fontSize: 12, color: 'var(--muted)' }}>{r.note}</div> : null}</td>
                <td>{r.kind === 'esim_digi' ? 'eSIM Digi' : r.kind}</td>
                <td>{STATUS_RO[r.status] || r.status}</td>
                <td>{r.account_name || '—'}</td>
                <td style={{ fontSize: 12 }}>{r.phone_number_id || '—'}</td>
                <td>{r.monthly_cost ? `${r.monthly_cost}€` : '—'}</td>
                <td><button className="btn btn-secondary btn-sm" onClick={() => setOpen(open === r.id ? null : r.id)}>{open === r.id ? 'Închide' : 'Acțiuni'}</button></td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan={7} style={{ color: 'var(--muted)' }}>Niciun număr încă. Adaugă primul eSIM de mai sus.</td></tr>}
          </tbody>
        </table>

        {open && (() => {
          const r = rows.find(x => x.id === open);
          if (!r) return null;
          return (
            <div style={{ borderTop: '1px solid var(--line)', marginTop: 12, paddingTop: 14, display: 'grid', gap: 12 }}>
              <b>{r.number} — acțiuni</b>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                <input className="txt" style={{ maxWidth: 280 }} placeholder="Access token (system user ARHAI)" type="password" value={token} onChange={e => setToken(e.target.value)} />
                <input className="txt" style={{ maxWidth: 180 }} placeholder="phone_number_id" value={pnid || r.phone_number_id || ''} onChange={e => setPnid(e.target.value)} />
                <input className="txt" style={{ maxWidth: 160 }} placeholder="WABA ID" value={waba || r.waba_id || ''} onChange={e => setWaba(e.target.value)} />
                <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => run({ action: 'set_meta', id: r.id, phone_number_id: pnid || r.phone_number_id, waba_id: waba || r.waba_id }, 'Salvat.')}>Salvează ID-uri</button>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                <span style={{ fontSize: 13, color: 'var(--muted)' }}>Înregistrare Cloud API:</span>
                <button className="btn btn-secondary btn-sm" disabled={busy || !token} onClick={() => run({ action: 'request_code', id: r.id, phone_number_id: pnid || r.phone_number_id, access_token: token })}>1. Trimite cod SMS</button>
                <input className="txt" style={{ maxWidth: 110 }} placeholder="cod SMS" value={code} onChange={e => setCode(e.target.value)} />
                <button className="btn btn-secondary btn-sm" disabled={busy || !token || !code} onClick={() => run({ action: 'verify_code', id: r.id, access_token: token, code })}>2. Verifică codul</button>
                <input className="txt" style={{ maxWidth: 110 }} placeholder="PIN 6 cifre" value={pin} onChange={e => setPin(e.target.value)} />
                <button className="btn btn-secondary btn-sm" disabled={busy || !token || pin.length !== 6} onClick={() => run({ action: 'register', id: r.id, access_token: token, pin })}>3. Înregistrează (PIN)</button>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
                <span style={{ fontSize: 13, color: 'var(--muted)' }}>Alocare:</span>
                <select className="txt" style={{ maxWidth: 240 }} value={assignAcc} onChange={e => setAssignAcc(e.target.value)}>
                  <option value="">— alege contul —</option>
                  {accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                </select>
                <select className="txt" style={{ maxWidth: 140 }} value={assignKind} onChange={e => setAssignKind(e.target.value)}>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="voice">Voce</option>
                </select>
                <button className="btn btn-primary btn-sm" disabled={busy || !assignAcc || r.status === 'alocat' || (assignKind === 'whatsapp' && !token)}
                  onClick={() => run({ action: 'assign', id: r.id, account_id: assignAcc, channel: assignKind, phone_number_id: pnid || r.phone_number_id, access_token: token }, 'Alocat — canalul contului e conectat.')}>
                  Alocă pe cont
                </button>
                {r.status === 'alocat' && <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => run({ action: 'release', id: r.id }, 'Eliberat.')}>Eliberează</button>}
                <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => run({ action: 'retire', id: r.id }, 'Retras din inventar.')}>Retrage</button>
              </div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                Pentru WhatsApp, alocarea cere access token-ul de system user + phone_number_id (după înregistrarea Cloud API). Tokenul se salvează criptat pe canalul contului, nu în inventar.
              </div>
            </div>
          );
        })()}
      </div>
    </div>
  );
}
