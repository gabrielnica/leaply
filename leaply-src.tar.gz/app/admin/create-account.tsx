'use client';
import { useState } from 'react';

// Admin: creare cont manual (onboarding concierge / clienți aduși telefonic).
// Folosește API-ul existent /api/admin/account action:create.
export function CreateAccount() {
  const [open, setOpen] = useState(false);
  const [business, setBusiness] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [plan, setPlan] = useState('Trial');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const slug = business.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 24);
  const accId = slug ? `acc_${slug}` : '';

  function genPass() {
    const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
    setPassword(Array.from(crypto.getRandomValues(new Uint32Array(14))).map(x => chars[x % chars.length]).join(''));
  }

  async function create() {
    setBusy(true); setErr(null); setMsg(null);
    try {
      const r = await fetch('/api/admin/account', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create', id: accId, business, email, password, plan, vertical: 'servicii' }),
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d.error || 'Eroare');
      setMsg(`Cont creat: ${accId}. Trimite-i clientului emailul + parola (sau folosește „Trimite reset parolă" din detaliul contului).`);
      setBusiness(''); setEmail('');
    } catch (e: any) { setErr(String(e.message || e)); }
    setBusy(false);
  }

  return (
    <div className="panel" style={{ marginBottom: 18 }}>
      <div className="ap-panel-head" style={{ cursor: 'pointer' }} onClick={() => setOpen(o => !o)}>
        <span className="ap-panel-title">+ Creează cont manual (concierge)</span>
        <span className="pill">{open ? 'închide' : 'deschide'}</span>
      </div>
      {open && (
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <input className="txt" style={{ maxWidth: 220 }} placeholder="Numele firmei" value={business} onChange={e => setBusiness(e.target.value)} />
          <input className="txt" style={{ maxWidth: 220 }} placeholder="Email owner" value={email} onChange={e => setEmail(e.target.value)} />
          <span style={{ display: 'flex', gap: 6 }}>
            <input className="txt" style={{ maxWidth: 160 }} placeholder="Parolă (min 8)" value={password} onChange={e => setPassword(e.target.value)} />
            <button type="button" className="btn btn-secondary btn-sm" onClick={genPass}>Generează</button>
          </span>
          <select className="txt" style={{ maxWidth: 120 }} value={plan} onChange={e => setPlan(e.target.value)}>
            {['Trial', 'Start', 'Pro', 'Scale'].map(p => <option key={p}>{p}</option>)}
          </select>
          <button className="btn btn-primary btn-sm" disabled={busy || !accId || !email || password.length < 8} onClick={create}>
            {busy ? 'Se creează…' : `Creează ${accId || 'contul'}`}
          </button>
          {msg && <span style={{ color: 'var(--ok, #2e9e5b)', fontSize: 13 }}>{msg}</span>}
          {err && <span style={{ color: 'var(--bad, #d33)', fontSize: 13 }}>⚠ {err}</span>}
        </div>
      )}
    </div>
  );
}
