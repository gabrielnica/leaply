'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Logo } from '../../lib/logo';

// Sidebar UNIC pentru tot adminul (înainte existau 3 variante + o pagină fără meniu).
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IcShield = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 3l8 3v6c0 4.8-3.4 8-8 9-4.6-1-8-4.2-8-9V6z" /></svg>;
const IcCoins = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="9" cy="9" r="6" /><path d="M14.2 5.3A6 6 0 1 1 18.7 14" /></svg>;
const IcGauge = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 15l4-6" /><path d="M4 17a9 9 0 1 1 16 0" /></svg>;
const IcList = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" /></svg>;
const IcKey = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="8" cy="15" r="4" /><path d="M11 12 21 2M17 6l3 3" /></svg>;
const IcHome = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M3 10.5 12 3.5l9 7V20a1 1 0 0 1-1 1h-5.5v-6h-5v6H4a1 1 0 0 1-1-1z" /></svg>;
const IcOut = () => <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6" /></svg>;

const NAV = [
  { href: '/admin', label: 'Admin', icon: <IcShield />, exact: true, also: '/admin/account' },
  { href: '/admin/billing', label: 'Billing & MRR', icon: <IcCoins /> },
  { href: '/admin/consum', label: 'Consum & marje', icon: <IcGauge /> },
  { href: '/admin/audit', label: 'Jurnal acțiuni', icon: <IcList /> },
  { href: '/admin/settings', label: 'Setări platformă', icon: <IcKey /> },
  { href: '/app', label: 'Dashboard client', icon: <IcHome /> },
];

export function AdminChrome({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  if (pathname === '/admin/login') return <>{children}</>;
  const isActive = (n: typeof NAV[number]) =>
    n.exact ? (pathname === n.href || (n.also && pathname.startsWith(n.also))) : pathname.startsWith(n.href);
  return (
    <div className="ap-shell">
      <aside className="ap-side">
        <div className="ap-side-logo"><Logo light size={26} /></div>
        <nav className="ap-nav">
          {NAV.map(n => (
            <Link key={n.href} href={n.href} className={`ap-nav-link${isActive(n) ? ' is-active' : ''}`}>
              {n.icon}<span className="ap-nav-label">{n.label}</span>
            </Link>
          ))}
        </nav>
        <div className="ap-side-foot">
          <Link href="/" className="ap-nav-link"><IcOut /><span className="ap-nav-label">Site public</span></Link>
        </div>
      </aside>
      <main className="ap-main"><div className="ap-content">{children}</div></main>
    </div>
  );
}
