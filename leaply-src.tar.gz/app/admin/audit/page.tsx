import { redirect } from 'next/navigation';
import { getSessionUser } from '../../../lib/auth';
import { db } from '../../../lib/db';

export const dynamic = 'force-dynamic';

// Jurnal global de acțiuni: tot audit_log-ul, cu filtru pe tip — cine a făcut ce,
// plus erorile de livrare pe canale (delivery.error, scrise din sendReply).
export default function AdminAudit({ searchParams }: { searchParams?: { type?: string; page?: string } }) {
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'admin') redirect('/app');
  const d = db();
  const type = String(searchParams?.type || '').slice(0, 40);
  const page = Math.max(1, Number(searchParams?.page) || 1);
  const PER = 50;
  const types: any[] = d.prepare('SELECT action, COUNT(*) n FROM audit_log GROUP BY action ORDER BY n DESC').all();
  const where = type ? 'WHERE action = ?' : '';
  const args: any[] = type ? [type] : [];
  const total = (d.prepare(`SELECT COUNT(*) n FROM audit_log ${where}`).get(...args) as any).n;
  const rows: any[] = d.prepare(`SELECT * FROM audit_log ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`).all(...args, PER, (page - 1) * PER);
  const errCount = (d.prepare("SELECT COUNT(*) n FROM audit_log WHERE action='delivery.error' AND created_at > datetime('now','-7 days')").get() as any).n;
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Jurnal acțiuni & erori</h1>
          <p className="ap-sub">{total} intrări{type ? ` · filtru: ${type}` : ''} · {errCount} erori de livrare în ultimele 7 zile</p>
        </div>
      </div>
      <div className="panel">
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', padding: '6px 2px 12px' }}>
          <a className={`pill${!type ? ' pill-on' : ''}`} href="/admin/audit">toate</a>
          {types.map(t => (
            <a key={t.action} className={`pill${type === t.action ? ' pill-on' : ''}`}
              href={`/admin/audit?type=${encodeURIComponent(t.action)}`}
              style={t.action === 'delivery.error' ? { color: '#C0392B' } : undefined}>{t.action} ({t.n})</a>
          ))}
        </div>
        {rows.length === 0 && <p className="muted" style={{ padding: '8px 4px' }}>Nimic aici.</p>}
        {rows.map((a: any) => (
          <div key={a.id} className="row">
            <span className="ap-lead">
              <span className="ap-lead-name" style={a.action === 'delivery.error' ? { color: '#C0392B' } : undefined}>
                {a.action} {a.target && <a className="pill" href={`/admin/account/${a.target}`}>{a.target}</a>}
              </span>
              <span className="ap-lead-meta">
                {a.actor} · {new Date(a.created_at).toLocaleString('ro-RO')}
                {a.meta ? ` · ${(() => { try { return Object.entries(JSON.parse(a.meta)).map(([k, v]) => `${k}: ${String(v).slice(0, 80)}`).join(' · '); } catch { return a.meta.slice(0, 120); } })()}` : ''}
              </span>
            </span>
          </div>
        ))}
        {total > PER && (
          <div style={{ display: 'flex', gap: 8, padding: '12px 4px' }}>
            {Array.from({ length: Math.min(20, Math.ceil(total / PER)) }, (_, i) => i + 1).map(n => (
              <a key={n} className={`pill${n === page ? ' pill-on' : ''}`} href={`/admin/audit?type=${encodeURIComponent(type)}&page=${n}`}>{n}</a>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
