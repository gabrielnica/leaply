'use client';
import { useState } from 'react';

// Buton în admin: provisionează automat un număr Twilio pentru o cerere de număr.
export function ProvisionButton({ requestId, kind }: { requestId: string; kind: 'voice' | 'whatsapp' }) {
  const [state, setState] = useState<'idle' | 'busy' | 'done'>('idle');
  const [msg, setMsg] = useState('');
  const run = async () => {
    if (!confirm(`Cumpăr un număr RO din contul Twilio master pentru ${kind === 'voice' ? 'agent vocal' : 'WhatsApp'}? (cost recurent real)`)) return;
    setState('busy'); setMsg('');
    try {
      const r = await fetch('/api/admin/provision-number', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ request_id: requestId }),
      });
      const j = await r.json().catch(() => ({} as any));
      if (r.ok && j.ok) { setState('done'); setMsg(j.number); }
      else { setState('idle'); setMsg(j.error || 'Eroare — încearcă din nou.'); }
    } catch { setState('idle'); setMsg('Eroare de conexiune.'); }
  };
  if (state === 'done') return <span className="connected">✓ {msg}</span>;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
      <button type="button" className="btn btn-primary btn-sm" onClick={run} disabled={state === 'busy'}>
        {state === 'busy' ? 'Se provisionează…' : 'Provizionează automat'}
      </button>
      {msg && <span className="ap-errmsg" role="alert">{msg}</span>}
    </span>
  );
}
