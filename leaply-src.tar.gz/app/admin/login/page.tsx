'use client';

import { useState, FormEvent } from 'react';
import Link from 'next/link';
import { Logo } from '../../../lib/logo';

function IconArrow() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4.5 12h15" />
      <path d="m13.5 6 6 6-6 6" />
    </svg>
  );
}

function IconAlert() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 8v4.5" />
      <path d="M12 15.8h.01" />
    </svg>
  );
}

function IconLock() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="4.5" y="10.5" width="15" height="10" rx="2.5" />
      <path d="M8 10.5V7.75a4 4 0 0 1 8 0v2.75" />
    </svg>
  );
}

export default function AdminLoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError('');
    if (!email.trim() || !password) {
      setError('Completează emailul și parola.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        if (data.role === 'admin') {
          window.location.href = '/admin';
          return;
        }
        const next = new URLSearchParams(window.location.search).get('next');
        window.location.href = next && next.startsWith('/app') ? next : '/app';
        return;
      }
      setError(data.error || 'Email sau parolă greșită.');
      setLoading(false);
    } catch {
      setError('Nu am putut contacta serverul. Verifică conexiunea și încearcă din nou.');
      setLoading(false);
    }
  }

  return (
    <div className="au-wrap au-dark">
      <div className="au-box">
        <Link href="/" className="au-logo" aria-label="Leaply — înapoi la pagina principală">
          <Logo light />
        </Link>

        <div className="au-card au-card-dark">
          <div className="au-badge-row">
            <span className="eyebrow on-dark">
              <IconLock />
              Admin
            </span>
          </div>
          <h1 className="au-head">Panoul de administrare</h1>
          <p className="au-sub">Zonă restricționată. Autentifică-te cu contul de administrator.</p>

          <form className="au-form" onSubmit={onSubmit} noValidate>
            <label className="fld" htmlFor="au-email">Email</label>
            <input
              id="au-email"
              className="txt"
              type="email"
              autoComplete="email"
              placeholder="admin@leaply.ro"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoFocus
            />

            <label className="fld" htmlFor="au-pass">Parolă</label>
            <div className="au-pw">
              <input
                id="au-pass"
                className="txt"
                type={show ? 'text' : 'password'}
                autoComplete="current-password"
                placeholder="Parola de administrator"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                className="au-toggle"
                onClick={() => setShow((v) => !v)}
                aria-label={show ? 'Ascunde parola' : 'Arată parola'}
              >
                {show ? 'ascunde' : 'arată'}
              </button>
            </div>

            {error && (
              <div className="au-error" role="alert">
                <IconAlert />
                <span>{error}</span>
              </div>
            )}

            <button className="btn btn-ondark au-submit" type="submit" disabled={loading}>
              {loading ? (
                <>
                  <span className="au-spin" aria-hidden="true" />
                  Se verifică…
                </>
              ) : (
                <>
                  Intră în panou
                  <IconArrow />
                </>
              )}
            </button>
          </form>
        </div>

        <div className="au-links">
          <Link href="/">← înapoi la site</Link>
        </div>
      </div>
    </div>
  );
}
