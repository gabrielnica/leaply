'use client';
import { useState } from 'react';

// Admin: anunț pe email către toți clienții activi (cu buton de test către tine întâi).
export function Broadcast() {
  const [open, setOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function send(test: boolean) {
    if (!test && !confirm('Trimiți acest anunț către TOȚI clienții activi. Sigur?')) return;
    setBusy(true); setMsg(null);
    try {
      const r = await fetch('/api/admin/broadcast', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ subject, body, test }) });
      const d = await r.json();
      setMsg(r.ok ? (test ? 'Test trimis pe emailul tău.' : `Trimis către ${d.sent}/${d.total} conturi.`) : `⚠ ${d.error}`);
    } catch { setMsg('⚠ Eroare de rețea'); }
    setBusy(false);
  }

  return (
    <div className="panel" style={{ marginBottom: 18 }}>
      <div className="ap-panel-head" style={{ cursor: 'pointer' }} onClick={() => setOpen(o => !o)}>
        <span className="ap-panel-title">📣 Anunț către toți clienții</span>
        <span className="pill">{open ? 'închide' : 'deschide'}</span>
      </div>
      {open && (
        <div style={{ display: 'grid', gap: 10 }}>
          <input className="txt" placeholder="Subiect" value={subject} onChange={e => setSubject(e.target.value)} />
          <textarea className="txt" rows={5} placeholder="Conținut (paragrafe separate prin linie goală)" value={body} onChange={e => setBody(e.target.value)} />
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <button className="btn btn-secondary btn-sm" disabled={busy || !subject || !body} onClick={() => send(true)}>Trimite-mi un test</button>
            <button className="btn btn-primary btn-sm" disabled={busy || !subject || !body} onClick={() => send(false)}>Trimite tuturor</button>
            {msg && <span style={{ fontSize: 13 }}>{msg}</span>}
          </div>
        </div>
      )}
    </div>
  );
}
