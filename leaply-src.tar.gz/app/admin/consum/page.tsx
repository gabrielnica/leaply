import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getSessionUser } from '../../../lib/auth';
import { AdminShell } from '../shell';
import { accountEconomics, numbersAllocated, UNIT_COST } from '../../../lib/adminstats';

export const dynamic = 'force-dynamic';

export default function AdminConsum() {
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'admin') redirect('/app');
  const rows = accountEconomics();
  const numbers = numbersAllocated();
  const totals = rows.reduce((t, r) => ({ cost: t.cost + r.cost, revenue: t.revenue + r.revenue }), { cost: 0, revenue: 0 });
  const upsell = rows.filter(r => r.pct >= 80);
  return (
    <AdminShell active="consum" title="Consum & marje" sub={`Luna curentă · costuri unitare estimate: ${UNIT_COST.conv} €/conv · ${UNIT_COST.sms} €/SMS · ${UNIT_COST.voiceMin} €/min voce · ${UNIT_COST.numberMonthly} €/număr`}>
      <div className="ap-kpis">
        <div className="ap-kpi"><div className="ap-kpi-l">Venit lunar (MRR)</div><div className="ap-kpi-v">{Math.round(totals.revenue)} €</div></div>
        <div className="ap-kpi"><div className="ap-kpi-l">Cost estimat</div><div className="ap-kpi-v">{Math.round(totals.cost * 100) / 100} €</div></div>
        <div className="ap-kpi ap-kpi-hero"><div className="ap-kpi-l">Marjă</div><div className="ap-kpi-v">{Math.round((totals.revenue - totals.cost) * 100) / 100} €</div></div>
        <div className="ap-kpi"><div className="ap-kpi-l">Peste 80% din plan</div><div className="ap-kpi-v">{upsell.length}</div></div>
      </div>

      {upsell.length > 0 && (
        <div className="panel">
          <div className="ap-panel-head"><span className="ap-panel-title">Candidați de upsell (≥80% din plan)</span></div>
          {upsell.map(r => (
            <Link key={r.id} href={`/admin/account/${r.id}`} className="row" style={{ textDecoration: 'none', color: 'inherit' }}>
              <span className="ap-lead"><span className="ap-lead-name">{r.name}</span><span className="ap-lead-meta">{r.plan}</span></span>
              <span className="ap-cell-num" style={{ color: 'var(--accent)' }}>{r.conv}/{r.limit} conversații ({r.pct}%)</span>
            </Link>
          ))}
        </div>
      )}

      <div className="panel">
        <div className="ap-panel-head"><span className="ap-panel-title">Economia per cont (luna curentă)</span></div>
        <div className="ap-table-head ap-econ-grid">
          <span>Cont</span><span>Plan</span><span>Conv.</span><span>SMS</span><span>Min voce</span><span>Nr.</span><span>Cost</span><span>Venit</span><span>Marjă</span>
        </div>
        {rows.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Niciun cont client încă.</p>}
        {rows.map(r => (
          <Link key={r.id} href={`/admin/account/${r.id}`} className="ap-table-row ap-econ-grid" style={{ textDecoration: 'none', color: 'inherit' }}>
            <span className="ap-lead"><span className="ap-lead-name">{r.name}</span></span>
            <span><span className={`badge ${['Start', 'Pro', 'Scale'].includes(r.plan) ? 'b-booked' : 'b-warm'}`}>{r.plan}</span></span>
            <span className="ap-cell-num" style={r.pct >= 80 ? { color: 'var(--accent)' } : undefined}>{r.conv}/{r.limit}</span>
            <span className="ap-cell-num">{r.sms}</span>
            <span className="ap-cell-num">{r.voiceMin}</span>
            <span className="ap-cell-num">{r.numbers}</span>
            <span className="ap-cell-num">{r.cost} €</span>
            <span className="ap-cell-num">{r.revenue} €</span>
            <span className="ap-cell-num" style={{ color: r.margin >= 0 ? 'var(--ok, #1a7f37)' : 'var(--bad, #c11)', fontWeight: 600 }}>{r.margin} €</span>
          </Link>
        ))}
      </div>

      <div className="panel">
        <div className="ap-panel-head"><span className="ap-panel-title">Registrul numerelor alocate ({numbers.length}) · cost parc ≈ {numbers.length * UNIT_COST.numberMonthly} €/lună</span></div>
        {numbers.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Niciun număr alocat încă.</p>}
        {numbers.map((n, i) => (
          <Link key={i} href={`/admin/account/${n.account_id}`} className="row" style={{ textDecoration: 'none', color: 'inherit' }}>
            <span className="ap-lead">
              <span className="ap-lead-name">{n.number}</span>
              <span className="ap-lead-meta">{n.account} · canal {n.type}</span>
            </span>
            <span className={n.status === 'connected' ? 'connected' : 'muted'}>{n.status === 'connected' ? 'activ' : 'în așteptare'}</span>
          </Link>
        ))}
      </div>
    </AdminShell>
  );
}
