'use client';
import { useEffect, useState } from 'react';

type Key = { key: string; label: string; hint?: string; secret?: boolean; source: 'db' | 'env' | 'unset'; preview: string };
type Group = { group: string; keys: Key[] };

const SRC_LABEL: Record<string, string> = { db: 'setat aici', env: 'din server (env)', unset: 'nesetat' };

function SettingRow({ k, onSaved }: { k: Key; onSaved: () => void }) {
  const [val, setVal] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const save = async (clear = false) => {
    setBusy(true); setMsg('');
    try {
      const r = await fetch('/api/admin/settings', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: k.key, value: clear ? '' : val }),
      });
      const j = await r.json();
      if (!r.ok || j.error) throw new Error(j.error || 'Eroare');
      setMsg(clear ? 'Șters.' : 'Salvat.'); setVal('');
      onSaved();
    } catch (e: any) { setMsg(e.message); }
    setBusy(false);
  };
  return (
    <div className="ap-chan">
      <div className="ap-chan-row" style={{ alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <span className="ap-chan-info" style={{ minWidth: 220 }}>
          <b>{k.label}</b>
          <span>{k.hint || k.key}</span>
          <span style={{ marginTop: 4 }}>
            <span className={`pill`}>{SRC_LABEL[k.source]}</span>{' '}
            {k.preview && <code className="ap-code" style={{ fontSize: 12 }}>{k.preview}</code>}
          </span>
        </span>
        <span style={{ display: 'flex', gap: 8, flex: 1, minWidth: 260, alignItems: 'center' }}>
          <input className="txt" type={k.secret ? 'password' : 'text'} placeholder={k.source === 'unset' ? 'Introdu valoarea…' : 'Valoare nouă…'}
            value={val} onChange={e => setVal(e.target.value)} autoComplete="off" style={{ flex: 1 }} />
          <button className="btn btn-primary btn-sm" disabled={busy || !val.trim()} onClick={() => save(false)}>Salvează</button>
          {k.source === 'db' && <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => save(true)}>Șterge</button>}
        </span>
      </div>
      {msg && <p className="ap-fhint" style={{ margin: '0 4px 12px 60px' }}>{msg}</p>}
    </div>
  );
}

export default function AdminSettings() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [llm, setLlm] = useState(false);
  const [err, setErr] = useState('');
  const load = async () => {
    try {
      const r = await fetch('/api/admin/settings');
      const j = await r.json();
      if (!r.ok || j.error) throw new Error(j.error || 'Eroare');
      setGroups(j.groups); setLlm(j.llmActive);
    } catch (e: any) { setErr(e.message); }
  };
  useEffect(() => { load(); }, []);
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Setări platformă</h1>
          <p className="ap-sub">Chei API și configurări globale — se aplică imediat, fără redeploy. Valorile setate aici au prioritate față de variabilele de mediu.</p>
        </div>
        <span className={`badge ${llm ? 'b-active' : 'b-warm'}`}>{llm ? 'LLM activ' : 'Creier pe reguli'}</span>
      </div>
      {err && <div className="panel" style={{ color: 'var(--bad)' }}>{err}</div>}
      {groups.map(g => (
        <div className="panel" key={g.group}>
          <div className="ap-panel-head"><span className="ap-panel-title">{g.group}</span></div>
          {g.keys.map(k => <SettingRow key={k.key} k={k} onSaved={load} />)}
        </div>
      ))}
    </>
  );
}
