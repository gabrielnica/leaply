import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getSessionUser } from '../../../lib/auth';
import { AdminShell } from '../shell';
import { adminKpis, paidAccounts, recentBillingEvents, PLAN_PRICE } from '../../../lib/adminstats';
import { db } from '../../../lib/db';

export const dynamic = 'force-dynamic';

export default function AdminBilling() {
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'admin') redirect('/app');
  const k = adminKpis();
  const payers = paidAccounts();
  const events = recentBillingEvents(30);
  const byPlan = ['Start', 'Pro', 'Scale'].map(p => {
    const n = payers.filter(a => a.plan === p).length;
    return { plan: p, n, sum: n * PLAN_PRICE[p] };
  });
  const churn30 = (db().prepare("SELECT COUNT(*) c FROM audit_log WHERE action='billing.churn' AND created_at > datetime('now','-30 days')").get() as any).c;
  // istoric MRR (snapshot zilnic din cron) — graficul se umple pe măsură ce trec zilele
  let history: any[] = [];
  try { history = db().prepare('SELECT day, mrr FROM mrr_daily ORDER BY day DESC LIMIT 90').all().reverse(); } catch { /* tabela apare la primul boot nou */ }
  const maxMrr = Math.max(1, ...history.map((h: any) => h.mrr));
  return (
    <AdminShell active="billing" title="Billing & MRR" sub="Venituri recurente, plătitori și mișcări de plan">
      <div className="ap-kpis">
        <div className="ap-kpi ap-kpi-hero"><div className="ap-kpi-l">MRR</div><div className="ap-kpi-v">{k.mrr} €</div></div>
        <div className="ap-kpi"><div className="ap-kpi-l">Plătitori</div><div className="ap-kpi-v">{k.paidCount}</div></div>
        <div className="ap-kpi"><div className="ap-kpi-l">ARPU</div><div className="ap-kpi-v">{k.paidCount ? Math.round(k.mrr / k.paidCount) : 0} €</div></div>
        <div className="ap-kpi"><div className="ap-kpi-l">Churn (30 zile)</div><div className="ap-kpi-v">{churn30}</div></div>
      </div>

      {history.length > 1 && (
        <div className="panel">
          <div className="ap-panel-head"><span className="ap-panel-title">Evoluție MRR (ultimele {history.length} zile)</span></div>
          <svg viewBox={`0 0 640 120`} style={{ width: '100%', height: 'auto' }} role="img" aria-label="Evoluție MRR">
            <polyline fill="none" stroke="#FF4D1F" strokeWidth="2.5" strokeLinejoin="round"
              points={history.map((h: any, i: number) => `${8 + i * (624 / Math.max(1, history.length - 1))},${110 - (h.mrr / maxMrr) * 95}`).join(' ')} />
            <text x="8" y="14" fontSize="11" fill="#9a938a">{maxMrr} €</text>
          </svg>
        </div>
      )}

      <div className="panel">
        <div className="ap-panel-head"><span className="ap-panel-title">MRR pe planuri</span></div>
        {byPlan.map(r => (
          <div key={r.plan} className="row">
            <span>{r.plan} — {PLAN_PRICE[r.plan]} €/lună</span>
            <span className="ap-cell-num">{r.n} conturi · <b>{r.sum} €</b></span>
          </div>
        ))}
        <div className="row" style={{ fontWeight: 700 }}><span>Total</span><span className="ap-cell-num">{k.mrr} € / lună</span></div>
      </div>

      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title">Plătitori ({payers.length})</span>
          <a className="btn btn-secondary btn-sm" href="https://dashboard.stripe.com" target="_blank" rel="noopener">Deschide Stripe →</a>
        </div>
        {payers.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Niciun plătitor încă — primul e cel mai greu 💪</p>}
        {payers.map(a => (
          <Link key={a.id} href={`/admin/account/${a.id}`} className="row" style={{ textDecoration: 'none', color: 'inherit' }}>
            <span className="ap-lead">
              <span className="ap-lead-name">{a.name}</span>
              <span className="ap-lead-meta">{a.owner_email || '—'} · client din {new Date(a.created_at).toLocaleDateString('ro-RO')}</span>
            </span>
            <span className="ap-cell-num"><span className="badge b-booked">{a.plan}</span> {PLAN_PRICE[a.plan]} €</span>
          </Link>
        ))}
      </div>

      <div className="panel">
        <div className="ap-panel-head"><span className="ap-panel-title">Mișcări recente (planuri, upgrades, suspendări)</span></div>
        {events.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Nimic încă.</p>}
        {events.map((e: any, i: number) => (
          <div key={i} className="row">
            <span className="ap-lead">
              <span className="ap-lead-name">{e.action} <span className="pill">{e.target}</span></span>
              <span className="ap-lead-meta">{e.actor} · {new Date(e.created_at).toLocaleString('ro-RO')} · {(() => { try { return Object.entries(JSON.parse(e.meta || '{}')).map(([k2, v]) => `${k2}: ${v}`).join(' · ') || '—'; } catch { return '—'; } })()}</span>
            </span>
          </div>
        ))}
      </div>
    </AdminShell>
  );
}
