import { AdminChrome } from './admin-chrome';

// Layout comun pentru TOT adminul — meniul din stânga nu mai dispare pe nicio pagină.
// (/admin/login e exceptat în AdminChrome.)
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return <AdminChrome>{children}</AdminChrome>;
}
