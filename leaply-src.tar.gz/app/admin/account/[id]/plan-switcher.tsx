'use client';
import { useState } from 'react';

export function PlanSwitcher({ accId, plan }: { accId: string; plan: string }) {
  const [val, setVal] = useState(plan);
  const [msg, setMsg] = useState('');
  async function apply() {
    setMsg('…');
    const r = await fetch('/api/admin/account', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: accId, plan: val }),
    });
    setMsg(r.ok ? 'Salvat ✓' : 'Eroare');
  }
  return (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <select className="txt" value={val} onChange={e => setVal(e.target.value)} aria-label="Planul contului">
        <option>Trial</option><option>Start</option><option>Pro</option><option>Scale</option>
      </select>
      <button className="btn btn-dark btn-sm" onClick={apply}>Schimbă planul</button>
      {msg && <span className="ap-savedmsg">{msg}</span>}
    </div>
  );
}
