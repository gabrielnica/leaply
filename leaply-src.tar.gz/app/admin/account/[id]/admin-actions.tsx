'use client';
import { useState } from 'react';

type Addons = { conv: number; sms: number; voice_min: number; numbers: number };

// Acțiunile de operare per cont: extinde trial, impersonare, reset parolă, suspendare, add-on-uri.
export function AdminActions({ accId, plan, suspended, addons: initialAddons }: { accId: string; plan: string; suspended: boolean; addons: Addons }) {
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [isSusp, setIsSusp] = useState(suspended);
  const [addons, setAddons] = useState<Addons>(initialAddons);
  const setA = (k: keyof Addons) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setAddons(a => ({ ...a, [k]: Math.max(0, Number(e.target.value) || 0) }));

  const post = async (what: string, body: any, okText: (j: any) => string) => {
    setBusy(what); setMsg(null);
    try {
      const r = await fetch('/api/admin/account', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: accId, ...body }) });
      const j = await r.json().catch(() => ({} as any));
      if (r.ok && j.ok) setMsg({ kind: 'ok', text: okText(j) });
      else setMsg({ kind: 'err', text: j.error || 'Eroare — încearcă din nou.' });
      return r.ok && j.ok;
    } catch { setMsg({ kind: 'err', text: 'Eroare de conexiune.' }); return false; }
    finally { setBusy(''); }
  };

  return (
    <div className="panel">
      <div className="ap-panel-head"><span className="ap-panel-title">Acțiuni admin</span></div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', padding: '10px 4px' }}>
        <a
          className="btn btn-primary btn-sm"
          href={`/api/admin/impersonate?id=${encodeURIComponent(accId)}`}
          onClick={e => { if (!confirm('Intri în contul clientului CA EL (sesiunea ta de admin se închide; acțiunea rămâne în audit). Continui?')) e.preventDefault(); }}
        >Loghează-te în contul lui</a>
        {plan === 'Trial' && (
          <>
            <button type="button" className="btn btn-secondary btn-sm" disabled={!!busy}
              onClick={() => post('t7', { action: 'extend_trial', days: 7 }, () => 'Trial extins cu 7 zile.')}>+7 zile trial</button>
            <button type="button" className="btn btn-secondary btn-sm" disabled={!!busy}
              onClick={() => post('t14', { action: 'extend_trial', days: 14 }, () => 'Trial extins cu 14 zile.')}>+14 zile trial</button>
          </>
        )}
        <button type="button" className="btn btn-secondary btn-sm" disabled={!!busy}
          onClick={() => post('rp', { action: 'reset_password' }, j => `Link de resetare trimis către ${j.email}.`)}>Trimite reset parolă</button>
        <button type="button" className={`btn btn-sm ${isSusp ? 'btn-secondary' : 'ap-btn-danger'}`} disabled={!!busy}
          onClick={async () => {
            if (!isSusp && !confirm('Suspend contul? AI-ul nu va mai răspunde lead-urilor lui.')) return;
            const ok = await post('sp', { action: 'suspend', suspended: !isSusp }, j => (j.suspended ? 'Cont suspendat.' : 'Cont reactivat.'));
            if (ok) setIsSusp(v => !v);
          }}>{isSusp ? 'Reactivează contul' : 'Suspendă contul'}</button>
      </div>
      <div style={{ padding: '4px 4px 10px', borderTop: '1px solid rgba(16,18,20,.08)', marginTop: 6 }}>
        <p className="ap-sub" style={{ margin: '8px 0 6px' }}>Add-on-uri resurse (se adună la limitele pachetului · prețuri: +200 conv = 19€ · +100 min voce = 29€ · +500 SMS = 29€ · număr extra = 12€/lună — de adăugat manual ca subscription item în Stripe)</p>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          {([['conv', 'Conversații extra'], ['voice_min', 'Minute voce extra'], ['sms', 'SMS extra'], ['numbers', 'Numere extra']] as [keyof Addons, string][]).map(([k, label]) => (
            <label key={k} style={{ display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12.5, color: 'var(--muted)' }}>
              {label}
              <input className="txt" type="number" min={0} step={k === 'voice_min' ? 100 : k === 'conv' ? 200 : k === 'sms' ? 500 : 1}
                value={addons[k]} onChange={setA(k)} style={{ width: 120 }} />
            </label>
          ))}
          <button type="button" className="btn btn-dark btn-sm" disabled={!!busy}
            onClick={() => post('ad', { action: 'set_addons', addons }, () => 'Add-on-urile au fost salvate.')}>Salvează add-on-urile</button>
        </div>
      </div>
      {msg && <p className={msg.kind === 'ok' ? 'wz-import-ok' : 'ap-errmsg'} role="status" style={{ margin: '0 4px 10px' }}>{msg.text}</p>}
    </div>
  );
}
