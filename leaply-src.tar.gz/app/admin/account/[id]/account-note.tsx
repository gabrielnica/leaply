'use client';
import { useState } from 'react';

// Notă internă per cont + operațiuni sensibile (refund) — doar admin.
export function AccountNote({ accId, initial }: { accId: string; initial: string }) {
  const [text, setText] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function post(body: any) {
    setBusy(true); setMsg(null);
    try {
      const r = await fetch('/api/admin/account', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...body, id: accId }) });
      const d = await r.json().catch(() => ({}));
      setMsg(r.ok ? (body.action === 'refund_last' ? `Refund emis: ${d.amount} €` : 'Notă salvată.') : `⚠ ${d.error}`);
    } catch { setMsg('⚠ Eroare de rețea'); }
    setBusy(false);
  }

  return (
    <div className="panel" style={{ marginTop: 14 }}>
      <div className="ap-panel-head"><span className="ap-panel-title">Notă internă & operațiuni</span></div>
      <textarea className="txt" rows={3} placeholder="Notă vizibilă doar în admin (context client, promisiuni, istoricul discuțiilor)…"
        value={text} onChange={e => setText(e.target.value)} />
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginTop: 10, flexWrap: 'wrap' }}>
        <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => post({ action: 'set_note', text })}>Salvează nota</button>
        <button className="btn btn-secondary btn-sm" disabled={busy}
          onClick={() => { if (confirm('Emiți refund pe ULTIMA plată a acestui cont. Sigur?')) post({ action: 'refund_last' }); }}>
          ↩ Refund ultima plată
        </button>
        {msg && <span style={{ fontSize: 13 }}>{msg}</span>}
      </div>
    </div>
  );
}
