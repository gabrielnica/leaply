import Link from 'next/link';
import { redirect, notFound } from 'next/navigation';
import { getSessionUser } from '../../../../lib/auth';
import { adminAccountDetail } from '../../../../lib/store';
import { limitFor } from '../../../../lib/usage';
import { PlanSwitcher } from './plan-switcher';

export const dynamic = 'force-dynamic';

const CH_LABEL: Record<string, string> = {
  whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram',
  webform: 'Formular site', email: 'Email', sms: 'SMS', voice: 'Telefon / Voce',
};

export default function AdminAccount({ params }: { params: { id: string } }) {
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'admin') redirect('/app');
  const d = adminAccountDetail(params.id);
  if (!d) notFound();
  const { acc, users, channels, convs, usageMonth, integrations } = d;
  const limit = limitFor(acc.plan || 'Trial');
  const cfg = acc.config || {};
  return (
    <div className="ap-shell">
      <main className="ap-main" style={{ marginLeft: 0 }}>
        <div className="ap-content">
          <div className="ap-head">
            <div>
              <p className="ap-sub"><Link href="/admin">← Înapoi la Admin</Link></p>
              <h1 className="ap-title">{acc.name} <span className="pill">{acc.plan || 'Trial'}</span></h1>
              <p className="ap-sub">{acc.vertical || '—'} · creat {new Date(acc.created_at).toLocaleDateString('ro-RO')} · ID {acc.id}</p>
            </div>
            <PlanSwitcher accId={acc.id} plan={acc.plan || 'Trial'} />
          </div>

          <div className="ap-kpis">
            <div className="ap-kpi"><div className="ap-kpi-l">Conversații luna asta</div><div className="ap-kpi-v">{usageMonth}<span style={{ fontSize: 15, color: 'var(--muted)' }}> / {limit}</span></div></div>
            <div className="ap-kpi"><div className="ap-kpi-l">Lead-uri total</div><div className="ap-kpi-v">{convs.length >= 30 ? '30+' : convs.length}</div></div>
            <div className="ap-kpi"><div className="ap-kpi-l">Canale conectate</div><div className="ap-kpi-v">{channels.filter((c: any) => c.status === 'connected').length}/{channels.length}</div></div>
            <div className="ap-kpi"><div className="ap-kpi-l">Utilizatori</div><div className="ap-kpi-v">{users.length}</div></div>
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Utilizatori</span></div>
            {users.map((u: any) => (
              <div key={u.id} className="row">
                <span className="ap-lead"><span className="ap-lead-name">{u.name} {u.role === 'admin' && <span className="pill">admin</span>}</span>
                <span className="ap-lead-meta">{u.email} · {new Date(u.created_at).toLocaleDateString('ro-RO')}</span></span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Canale</span></div>
            {channels.map((c: any, i: number) => (
              <div key={i} className="row">
                <span>{CH_LABEL[c.type] || c.type}</span>
                <span className={c.status === 'connected' ? 'connected' : 'muted'}>{c.status === 'connected' ? 'Conectat' : 'Neconectat'}</span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Configurare AI (rezumat)</span></div>
            <div className="row"><span>Ton</span><span>{cfg.tone || '—'}</span></div>
            <div className="row"><span>Servicii</span><span>{(cfg.services || []).length}</span></div>
            <div className="row"><span>Cunoștințe (site import)</span><span>{cfg.knowledge ? `${String(cfg.knowledge).length} caractere` : '—'}</span></div>
            <div className="row"><span>Reguli / limite</span><span>{cfg.rules ? 'setate' : '—'}</span></div>
            <div className="row"><span>Google Calendar</span><span className={integrations?.google?.refresh_token ? 'connected' : 'muted'}>{integrations?.google?.refresh_token ? `conectat (${integrations.google.email || 'da'})` : 'neconectat'}</span></div>
            <div className="row"><span>Date facturare (CUI)</span><span>{integrations?.billing?.cif || '—'}</span></div>
            <div className="row"><span>Follow-up automat</span><span>{integrations?.followup?.enabled === false ? 'oprit' : `pornit (${integrations?.followup?.hours || 4}h)`}</span></div>
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Ultimele conversații (max 30)</span></div>
            {convs.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Nicio conversație încă.</p>}
            {convs.map((c: any) => (
              <div key={c.id} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{c.lead_name || 'Lead'} <span className="pill">{c.channel}</span></span>
                  <span className="ap-lead-meta">{c.phone || '—'} · {new Date(c.updated_at).toLocaleString('ro-RO')}</span>
                </span>
                <span className={`badge ${c.status === 'booked' ? 'b-booked' : c.status === 'lost' ? 'b-cold' : 'b-warm'}`}>{c.status}</span>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
