import Link from 'next/link';
import { redirect, notFound } from 'next/navigation';
import { getSessionUser } from '../../../../lib/auth';
import { adminAccountDetail } from '../../../../lib/store';
import { limitFor } from '../../../../lib/usage';
import { PlanSwitcher } from './plan-switcher';
import { AdminActions } from './admin-actions';
import { counterThisMonth, planSpec, trialDaysLeft, accountAddons, effectiveLimits, planLabel } from '../../../../lib/plan';
import { db } from '../../../../lib/db';

export const dynamic = 'force-dynamic';

const CH_LABEL: Record<string, string> = {
  whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram',
  webform: 'Formular site', email: 'Email', sms: 'SMS', voice: 'Telefon / Voce',
};

export default function AdminAccount({ params }: { params: { id: string } }) {
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  if (user.role !== 'admin') redirect('/app');
  const d = adminAccountDetail(params.id);
  if (!d) notFound();
  const { acc, users, channels, convs, usageMonth, integrations } = d;
  const limit = limitFor(acc.plan || 'Trial');
  const cfg = acc.config || {};
  const spec = planSpec(acc.plan || 'Trial');
  const addons = accountAddons(acc.id);
  const eff = effectiveLimits(acc.id, acc.plan || 'Trial');
  const smsUsed = counterThisMonth(acc.id, 'sms');
  const voiceUsed = counterThisMonth(acc.id, 'voice_min');
  const trialLeft = trialDaysLeft(acc.id);
  const isPaid = ['Start', 'Pro', 'Scale'].includes(acc.plan || 'Trial');
  const owner = users.find((u: any) => u.role !== 'agent') || users[0];
  const sub = integrations?.stripe || {};
  const roDate = (iso?: string | null) => { try { return iso ? new Date(iso).toLocaleDateString('ro-RO') : '—'; } catch { return '—'; } };
  const roDateTime = (iso?: string | null) => { try { return iso ? new Date(iso).toLocaleString('ro-RO') : 'niciodată'; } catch { return '—'; } };
  const numbers = channels.map((c: any) => { try { return JSON.parse(c.credentials || 'null')?.from_number || null; } catch { return null; } }).filter(Boolean);
  const planHistory: any[] = db().prepare(`
    SELECT actor, action, meta, created_at FROM audit_log
    WHERE target=? AND action IN ('plan.change','billing.upgraded','trial.extend','account.suspend','impersonate','number.provision')
    ORDER BY created_at DESC LIMIT 15`).all(acc.id);
  return (
    <div className="ap-shell">
      <main className="ap-main" style={{ marginLeft: 0 }}>
        <div className="ap-content">
          <div className="ap-head">
            <div>
              <p className="ap-sub"><Link href="/admin">← Înapoi la Admin</Link></p>
              <h1 className="ap-title">{acc.name} <span className="pill">{planLabel(acc.plan || 'Trial')}{acc.plan && acc.plan !== 'Trial' ? ` (${acc.plan})` : ''}</span>{(acc as any).suspended ? <span className="badge b-cold" style={{ marginLeft: 8 }}>SUSPENDAT</span> : null}</h1>
              <p className="ap-sub">{acc.vertical || '—'} · creat {new Date(acc.created_at).toLocaleDateString('ro-RO')} · ID {acc.id}{trialLeft !== null ? ` · trial: ${trialLeft > 0 ? trialLeft + ' zile rămase' : 'EXPIRAT'}` : ''}</p>
            </div>
            <PlanSwitcher accId={acc.id} plan={acc.plan || 'Trial'} />
          </div>

          <div className="ap-kpis">
            <div className="ap-kpi"><div className="ap-kpi-l">Conversații luna asta</div><div className="ap-kpi-v">{usageMonth}<span style={{ fontSize: 15, color: 'var(--muted)' }}> / {limit + addons.conv}{addons.conv ? '*' : ''}</span></div></div>
            <div className="ap-kpi"><div className="ap-kpi-l">SMS luna asta</div><div className="ap-kpi-v">{smsUsed}<span style={{ fontSize: 15, color: 'var(--muted)' }}> / {eff.sms}{addons.sms ? '*' : ''}</span></div></div>
            <div className="ap-kpi"><div className="ap-kpi-l">Minute voce</div><div className="ap-kpi-v">{voiceUsed}<span style={{ fontSize: 15, color: 'var(--muted)' }}> / {eff.voiceMin}{addons.voice_min ? '*' : ''}</span></div></div>
            <div className="ap-kpi"><div className="ap-kpi-l">Canale conectate</div><div className="ap-kpi-v">{channels.filter((c: any) => c.status === 'connected').length}/{channels.length}</div></div>
          </div>

          <AdminActions accId={acc.id} plan={acc.plan || 'Trial'} suspended={Boolean((acc as any).suspended)} addons={addons} />

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Cont, contact & abonament</span></div>
            <div className="row"><span>Owner</span><span>{owner ? `${owner.name} · ${owner.email}` : '—'}</span></div>
            <div className="row"><span>Ultima autentificare owner</span><span>{owner ? roDateTime(owner.last_login) : '—'}</span></div>
            <div className="row"><span>Cont creat</span><span>{roDate(acc.created_at)}</span></div>
            <div className="row"><span>Plan</span><span>{acc.plan || 'Trial'}{(acc as any).suspended ? ' · SUSPENDAT' : ''}</span></div>
            {isPaid ? (
              <>
                <div className="row"><span>Stare abonament</span><span className={sub.status === 'past_due' ? 'muted' : 'connected'}>{sub.status === 'past_due' ? 'PLATĂ EȘUATĂ' : (sub.status || 'activ')}</span></div>
                <div className="row"><span>Activ din</span><span>{roDate(sub.since)}</span></div>
                <div className="row"><span>Următoarea reînnoire</span><span>{roDate(sub.renews_at)}</span></div>
                <div className="row"><span>ID abonament Stripe</span><span>{sub.subscription_id ? <code className="ap-code">{sub.subscription_id}</code> : '—'}</span></div>
              </>
            ) : (
              <div className="row"><span>Trial</span><span>{trialLeft !== null ? (trialLeft > 0 ? `${trialLeft} zile rămase` : 'EXPIRAT') : '—'}</span></div>
            )}
            <div className="row"><span>Valoare medie client (ROI)</span><span>{(acc as any).avg_deal_value ? `${(acc as any).avg_deal_value} lei` : '—'}</span></div>
            <div className="row"><span>Email facturare</span><span>{integrations?.billing?.email || owner?.email || '—'}</span></div>
          </div>

          {numbers.length > 0 && (
            <div className="panel">
              <div className="ap-panel-head"><span className="ap-panel-title">Numere alocate</span></div>
              {numbers.map((n: string, i: number) => <div key={i} className="row"><span>{n}</span><span className="connected">activ</span></div>)}
            </div>
          )}

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Utilizatori</span></div>
            {users.map((u: any) => (
              <div key={u.id} className="row">
                <span className="ap-lead"><span className="ap-lead-name">{u.name} {u.role === 'admin' && <span className="pill">admin</span>}</span>
                <span className="ap-lead-meta">{u.email} · creat {new Date(u.created_at).toLocaleDateString('ro-RO')} · ultima logare {u.last_login ? new Date(u.last_login).toLocaleString('ro-RO') : 'niciodată'}</span></span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Canale</span></div>
            {channels.map((c: any, i: number) => (
              <div key={i} className="row">
                <span>{CH_LABEL[c.type] || c.type}</span>
                <span className={c.status === 'connected' ? 'connected' : 'muted'}>{c.status === 'connected' ? 'Conectat' : 'Neconectat'}</span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Configurare AI (rezumat)</span></div>
            <div className="row"><span>Ton</span><span>{cfg.tone || '—'}</span></div>
            <div className="row"><span>Servicii</span><span>{(cfg.services || []).length}</span></div>
            <div className="row"><span>Cunoștințe (site import)</span><span>{cfg.knowledge ? `${String(cfg.knowledge).length} caractere` : '—'}</span></div>
            <div className="row"><span>Reguli / limite</span><span>{cfg.rules ? 'setate' : '—'}</span></div>
            <div className="row"><span>Google Calendar</span><span className={integrations?.google?.refresh_token ? 'connected' : 'muted'}>{integrations?.google?.refresh_token ? `conectat (${integrations.google.email || 'da'})` : 'neconectat'}</span></div>
            <div className="row"><span>Date facturare (CUI)</span><span>{integrations?.billing?.cif || '—'}</span></div>
            <div className="row"><span>Recomandat de</span><span>{(acc as any).referred_by || '—'}</span></div>
            <div className="row"><span>Follow-up automat</span><span>{integrations?.followup?.enabled === false ? 'oprit' : `pornit (${integrations?.followup?.hours || 4}h)`}</span></div>
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Istoric plan & acțiuni admin</span></div>
            {planHistory.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Nimic încă.</p>}
            {planHistory.map((h: any, i: number) => (
              <div key={i} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{h.action} <span className="pill">{(() => { try { return Object.entries(JSON.parse(h.meta || '{}')).map(([k, v]) => `${k}: ${v}`).join(' · ') || '—'; } catch { return '—'; } })()}</span></span>
                  <span className="ap-lead-meta">{h.actor} · {new Date(h.created_at).toLocaleString('ro-RO')}</span>
                </span>
              </div>
            ))}
          </div>

          <div className="panel">
            <div className="ap-panel-head"><span className="ap-panel-title">Ultimele conversații (max 30)</span></div>
            {convs.length === 0 && <p className="muted" style={{ padding: '10px 4px', margin: 0 }}>Nicio conversație încă.</p>}
            {convs.map((c: any) => (
              <div key={c.id} className="row">
                <span className="ap-lead">
                  <span className="ap-lead-name">{c.lead_name || 'Lead'} <span className="pill">{c.channel}</span></span>
                  <span className="ap-lead-meta">{c.phone || '—'} · {new Date(c.updated_at).toLocaleString('ro-RO')}</span>
                </span>
                <span className={`badge ${c.status === 'booked' ? 'b-booked' : c.status === 'lost' ? 'b-cold' : 'b-warm'}`}>{c.status}</span>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
