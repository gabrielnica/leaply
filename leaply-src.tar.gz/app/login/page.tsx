'use client';

import { useState, useEffect, FormEvent } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';

// Cheia sub care păstrăm credențialele în keychain-ul nativ (protejate biometric).
const BIO_SERVER = 'app.leaply.ro';
// Pluginul NativeBiometric, doar în aplicația nativă Capacitor; null în browser.
function nativeBiometric(): any {
  const w = window as any;
  if (!w.Capacitor || (typeof w.Capacitor.isNativePlatform === 'function' && !w.Capacitor.isNativePlatform())) return null;
  return w.Capacitor.Plugins?.NativeBiometric || null;
}

function IconArrow() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4.5 12h15" />
      <path d="m13.5 6 6 6-6 6" />
    </svg>
  );
}

function IconAlert() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 8v4.5" />
      <path d="M12 15.8h.01" />
    </svg>
  );
}

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [bio, setBio] = useState<{ available: boolean; label: string }>({ available: false, label: 'Face ID' });

  function redirectAfter(data: any) {
    if (data.role === 'admin') { window.location.href = '/admin'; return; }
    const next = new URLSearchParams(window.location.search).get('next');
    window.location.href = next && next.startsWith('/app') ? next : '/app';
  }

  async function doLogin(mail: string, pass: string, storeBio: boolean) {
    setError('');
    if (!mail.trim() || !pass) {
      setError('Completează emailul și parola.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: mail.trim(), password: pass }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        // Salvează credențialele în keychain pentru deblocare cu Face ID/PIN data viitoare.
        if (storeBio) {
          const NB = nativeBiometric();
          if (NB) { try { await NB.setCredentials({ username: mail.trim(), password: pass, server: BIO_SERVER }); } catch {} }
        }
        redirectAfter(data);
        return;
      }
      setError(data.error || 'Email sau parolă greșită.');
      setLoading(false);
    } catch {
      setError('Nu am putut contacta serverul. Verifică conexiunea și încearcă din nou.');
      setLoading(false);
    }
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!loading) doLogin(email, password, true);
  }

  // Deblocare cu Face ID / Touch ID (fallback pe PIN/parola telefonului).
  async function biometricUnlock() {
    const NB = nativeBiometric();
    if (!NB) return;
    setError('');
    try {
      await NB.verifyIdentity({ reason: 'Deblochează Leaply', title: 'Leaply', subtitle: 'Autentificare', useFallback: true });
      const creds = await NB.getCredentials({ server: BIO_SERVER });
      if (creds?.username && creds?.password) {
        setLoading(true);
        await doLogin(creds.username, creds.password, false);
      }
    } catch {
      setError('Deblocarea biometrică a eșuat. Intră cu emailul și parola.');
    }
  }

  // La deschiderea app-ului nativ: dacă avem credențiale salvate și biometrie
  // disponibilă, afișăm butonul și încercăm deblocarea automat.
  useEffect(() => {
    const NB = nativeBiometric();
    if (!NB) return;
    (async () => {
      try {
        const avail = await NB.isAvailable({ useFallback: true });
        if (!avail?.isAvailable) return;
        let creds: any = null;
        try { creds = await NB.getCredentials({ server: BIO_SERVER }); } catch { return; }
        if (!creds?.username) return;
        const label = (avail.biometryType === 1 || avail.biometryType === 3 || avail.biometryType === 'touchId') ? 'Touch ID' : 'Face ID';
        setBio({ available: true, label });
        setTimeout(() => { biometricUnlock(); }, 400);
      } catch {}
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="au-wrap">
      <div className="au-box">
        <Link href="/" className="au-logo" aria-label="Leaply — înapoi la pagina principală">
          <Logo />
        </Link>

        <div className="au-card">
          <h1 className="au-head">Bine ai revenit</h1>
          <p className="au-sub">Intră în cont și vezi ce lead-uri ți-au sosit.</p>

          <form className="au-form" onSubmit={onSubmit} noValidate>
            <label className="fld" htmlFor="au-email">Email</label>
            <input
              id="au-email"
              name="email"
              className="txt"
              type="email"
              autoComplete="email"
              placeholder="nume@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoFocus
            />

            <label className="fld" htmlFor="au-pass">Parolă</label>
            <div className="au-pw">
              <input
                id="au-pass"
                name="password"
                className="txt"
                type={show ? 'text' : 'password'}
                autoComplete="current-password"
                placeholder="Parola ta"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                className="au-toggle"
                onClick={() => setShow((v) => !v)}
                aria-label={show ? 'Ascunde parola' : 'Arată parola'}
              >
                {show ? 'ascunde' : 'arată'}
              </button>
            </div>

            {error && (
              <div className="au-error" role="alert">
                <IconAlert />
                <span>{error}</span>
              </div>
            )}

            <button className="btn btn-primary au-submit" type="submit" disabled={loading}>
              {loading ? (
                <>
                  <span className="au-spin" aria-hidden="true" />
                  Se verifică…
                </>
              ) : (
                <>
                  Intră în cont
                  <IconArrow />
                </>
              )}
            </button>

            {bio.available && (
              <button
                type="button"
                className="btn btn-secondary au-submit"
                style={{ marginTop: 12 }}
                onClick={biometricUnlock}
                disabled={loading}
              >
                Deblochează cu {bio.label}
              </button>
            )}
          </form>
        </div>

        <div className="au-links">
          <span>
            Nu ai cont? <Link href="/start">Fă-ți unul în 2 minute</Link>
          </span>
          <Link href="/forgot">Ai uitat parola?</Link>
        </div>
      </div>
    </div>
  );
}
