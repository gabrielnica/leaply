import Link from 'next/link';
import { Logo } from '../lib/logo';

export default function Home() {
  return (
    <>
      <div className="hero">
        <div className="container">
          <nav className="nav">
            <Logo light />
            <div className="navlinks">
              <a href="#cum">Cum funcționează</a>
              <a href="#verticale">Verticale</a>
              <a href="#preturi">Prețuri</a>
              <Link href="/app" style={{ color: '#fff' }}>Autentificare</Link>
              <Link href="/demo" className="btn btn-primary btn-sm">Vezi demo live</Link>
            </div>
          </nav>
          <div style={{ paddingTop: 40 }}>
            <span className="tag">⚡ Răspuns automat în sub 60 de secunde</span>
            <h1>Răspunde fiecărui lead în sub 60 de secunde. Chiar și la 2 noaptea.</h1>
            <p className="sub">Leaply răspunde automat, în română, fiecărui lead de pe Facebook, Instagram, Messenger, WhatsApp sau site — îl califică și îți programează întâlnirea. Tu vinzi, noi nu lăsăm niciun client să aștepte.</p>
            <div className="cta">
              <Link href="/demo" className="btn btn-primary">Vezi Leaply răspunzând la un lead ▸</Link>
              <Link href="/app" className="btn btn-ghost">Intră în dashboard</Link>
            </div>
            <div className="stats">
              <div className="stat"><div className="n">&lt;60s</div><div className="l">timp de răspuns, 24/7</div></div>
              <div className="stat"><div className="n">2,6×</div><div className="l">rată de închidere vs. răspuns lent</div></div>
              <div className="stat"><div className="n">78%</div><div className="l">cumpără de la primul care răspunde</div></div>
            </div>
          </div>
        </div>
      </div>

      <section className="pad problem">
        <div className="container">
          <span className="eyebrow">Problema</span>
          <h2 className="big">Fiecare minut de întârziere îți costă vânzarea</h2>
          <p className="lead">Un client îți cere ofertă la 21:47. Tu îl vezi mâine la 9. Prea târziu — 78% dintre clienți cumpără de la prima firmă care răspunde. Studiile arată că firmele care răspund în sub 5 minute au șanse de <b>2,6× mai mari</b> să închidă vânzarea și de <b>21× mai mari</b> să califice clientul, față de un răspuns la 30 de minute.</p>
        </div>
      </section>

      <section className="pad" id="cum">
        <div className="container">
          <span className="eyebrow">Cum funcționează</span>
          <h2 className="big">Live în 10 minute, fără programator</h2>
          <div className="grid3">
            <div className="card"><div className="step">1</div><h3>Conectezi sursele de lead-uri</h3><p>Facebook & Instagram Lead Ads, Messenger, WhatsApp, formular web. Un click, fără cod.</p></div>
            <div className="card"><div className="step">2</div><h3>Leaply răspunde instant, în română</h3><p>Pune întrebările corecte, califică clientul și răspunde la obiecții, 24/7 — chiar și noaptea și în weekend.</p></div>
            <div className="card"><div className="step">3</div><h3>Îți apare întâlnirea în calendar</h3><p>Leadul calificat e programat automat. Tu doar te prezinți și vinzi.</p></div>
          </div>
        </div>
      </section>

      <section className="pad problem" id="verticale">
        <div className="container">
          <span className="eyebrow">Pentru cine</span>
          <h2 className="big">Construit pentru afaceri cu lead-uri valoroase</h2>
          <p className="lead">Un singur lead valorează sute sau mii de lei. Leaply se asigură că îl prinzi pe fiecare.</p>
          <div className="vtabs">
            <span className="vtab">🏠 Imobiliare</span>
            <span className="vtab">🪟 Servicii pentru casă (termopane, mobilă, amenajări, solar)</span>
            <span className="vtab">🦷 Clinici private</span>
            <span className="vtab">🚗 Dealeri auto</span>
          </div>
        </div>
      </section>

      <section className="pad" id="preturi">
        <div className="container">
          <span className="eyebrow">Prețuri</span>
          <h2 className="big">Un singur lead salvat îți acoperă abonamentul</h2>
          <p className="lead">Fără costuri de instalare la plata anuală. Fără contract pe termen lung.</p>
          <div className="pricewrap">
            <div className="price"><div className="brandfont" style={{fontWeight:700}}>Start</div><div className="amt">59€<span style={{fontSize:15,color:'#64748B'}}>/lună</span></div><ul><li>WhatsApp + chat web</li><li>300 conversații/lună</li><li>Răspuns + calificare</li><li>Google Calendar</li></ul></div>
            <div className="price hot"><span className="tag" style={{position:'absolute',top:-13,left:24}}>Recomandat</span><div className="brandfont" style={{fontWeight:700}}>Pro</div><div className="amt">129€<span style={{fontSize:15,color:'#64748B'}}>/lună</span></div><ul><li>+ Facebook & Instagram DM</li><li>1.000 conversații/lună</li><li>Booking automat în calendar</li><li>Integrare CRM + Meta Ads</li></ul></div>
            <div className="price"><div className="brandfont" style={{fontWeight:700}}>Scale</div><div className="amt">299€<span style={{fontSize:15,color:'#64748B'}}>/lună</span></div><ul><li>Toate canalele + SMS</li><li>3.000 conversații/lună</li><li>Până la 5 locații</li><li>Account manager dedicat</li></ul></div>
          </div>
          <div className="center" style={{marginTop:40}}>
            <Link href="/demo" className="btn btn-dark">Testează Leaply acum, gratuit ▸</Link>
          </div>
        </div>
      </section>

      <div className="footer">
        <div className="container" style={{display:'flex',justifyContent:'space-between',flexWrap:'wrap',gap:16}}>
          <Logo light />
          <div>Date găzduite în UE · Conform GDPR · Suport în română</div>
          <div>© 2026 Leaply · leaply.ro</div>
        </div>
      </div>
    </>
  );
}
