export const dynamic = 'force-static';

const SCRIPT = `
(function(){
  function fmt(n){return Math.round(n).toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g,'.');}
  function calc(){
    var l=+document.getElementById('r-leads').value, v=+document.getElementById('r-val').value, r=+document.getElementById('r-rate').value;
    document.getElementById('r-leads-v').textContent=l;
    document.getElementById('r-val-v').textContent=fmt(v);
    document.getElementById('r-rate-v').textContent=r+'%';
    var missed=Math.round(l*0.4), rec=Math.round(missed*0.6), deals=Math.round(rec*(r/100)), monthly=deals*v;
    document.getElementById('r-big').textContent='+'+fmt(monthly)+' lei';
    document.getElementById('r-missed').textContent=missed;
    document.getElementById('r-deals').textContent=deals;
  }
  ['r-leads','r-val','r-rate'].forEach(function(id){var e=document.getElementById(id);if(e)e.addEventListener('input',calc);});
  calc();
  var f=document.getElementById('leadform');
  if(f){f.addEventListener('submit',function(ev){ev.preventDefault();
    var body={name:f.name.value,contact:f.contact.value,business:f.business.value,vertical:f.vertical.value};
    if(!body.contact)return;
    fetch('/api/lead',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).catch(function(){});
    document.getElementById('lf-form').style.display='none';
    document.getElementById('lf-sent').style.display='block';
  });}
})();
`;

export default function Home() {
  const Logo = ({ }: any) => (
    <span className="logo" style={{ color: '#fff' }}>
      <svg width="28" height="28" viewBox="0 0 120 120"><path d="M18 8 h84 a18 18 0 0 1 18 18 v56 a18 18 0 0 1 -18 18 h-50 l-22 22 v-22 h-12 a18 18 0 0 1 -18 -18 v-56 a18 18 0 0 1 18 -18 z" fill="#12385F" /><path d="M40 78 L64 54 L80 70 M64 54 L64 86 M64 54 L36 54" fill="none" stroke="#C6F24E" strokeWidth="11" strokeLinecap="round" strokeLinejoin="round" /></svg>
      <span className="brandfont">leaply</span>
    </span>
  );
  return (
    <main className="lp">
      <header className="lp-nav"><div className="container lp-nav-in"><Logo />
        <nav className="lp-links"><a href="#cum">Cum funcționează</a><a href="#verticale">Pentru cine</a><a href="#roi">Calculator</a><a href="#preturi">Prețuri</a><a href="/app">Autentificare</a><a href="#demo" className="btn btn-primary btn-sm">Cere demo</a></nav>
      </div></header>

      <section className="lp-hero"><div className="lp-glow" /><div className="container lp-hero-in">
        <span className="lp-badge">⚡ Răspuns automat în sub 60 de secunde · 24/7</span>
        <h1>Nu mai pierde clienți<br /><span className="hl">pentru că ai răspuns prea târziu.</span></h1>
        <p className="lp-sub">Leaply răspunde automat, în română, fiecărui lead de pe Facebook, Instagram, Messenger, WhatsApp sau site — îl califică și îți programează întâlnirea. Tu vinzi, noi nu lăsăm niciun client să aștepte.</p>
        <div className="lp-cta"><a href="#demo" className="btn btn-primary btn-lg">Vezi Leaply răspunzând la un lead ▸</a><a href="/demo" className="btn btn-ghost btn-lg">Încearcă demo live</a></div>
        <div className="lp-stats"><div><div className="n">&lt;60s</div><div className="l">timp de răspuns, non-stop</div></div><div><div className="n">2,6×</div><div className="l">mai multe vânzări închise</div></div><div><div className="n">21×</div><div className="l">mai multe lead-uri calificate</div></div><div><div className="n">78%</div><div className="l">cumpără de la primul care răspunde</div></div></div>
        <div className="lp-logos">Se integrează cu: <b>WhatsApp</b> · <b>Facebook & Instagram</b> · <b>Messenger</b> · <b>Google Calendar</b></div>
      </div></section>

      <section className="lp-sec lp-problem"><div className="container">
        <span className="eyebrow">Problema</span>
        <h2>Un client îți scrie la 21:47. Tu îl vezi mâine la 9. Prea târziu.</h2>
        <p className="lead">Până răspunzi tu, clientul a cerut deja ofertă la alte 3 firme — și cumpără de la prima care i-a răspuns. Firmele care răspund în sub 5 minute au șanse de <b>2,6× mai mari</b> să închidă și de <b>21× mai mari</b> să califice, față de un răspuns la 30 de minute.</p>
        <div className="lp-painrow"><div className="pain"><span>😴</span><b>Seara și în weekend</b><p>Lead-urile vin non-stop, tu ești închis. Se răcesc până luni.</p></div><div className="pain"><span>📵</span><b>Ești ocupat</b><p>Ești pe teren sau cu alt client. Telefonul sună în gol.</p></div><div className="pain"><span>🤯</span><b>Prea multe canale</b><p>WhatsApp, DM, formular, telefon — imposibil să le prinzi pe toate.</p></div></div>
      </div></section>

      <section className="lp-sec" id="cum"><div className="container">
        <span className="eyebrow">Cum funcționează</span><h2>Live în 10 minute. Fără programator.</h2>
        <div className="lp-steps"><div className="stepc"><div className="stepn">1</div><h3>Conectezi sursele de lead-uri</h3><p>Facebook & Instagram Lead Ads, Messenger, WhatsApp, formular web. Un click, fără cod.</p></div><div className="stepc"><div className="stepn">2</div><h3>Leaply răspunde instant, în română</h3><p>Pune întrebările corecte, califică clientul, răspunde la obiecții — 24/7.</p></div><div className="stepc"><div className="stepn">3</div><h3>Îți apare întâlnirea în calendar</h3><p>Leadul calificat e programat automat. Tu doar te prezinți și vinzi.</p></div></div>
        <div className="center"><a href="/demo" className="btn btn-dark btn-lg">Vezi conversația reală în demo ▸</a></div>
      </div></section>

      <section className="lp-sec lp-verticals" id="verticale"><div className="container">
        <span className="eyebrow">Pentru cine</span><h2>Construit pentru afaceri cu lead-uri valoroase</h2>
        <p className="lead">Un singur lead valorează sute sau mii de lei. Leaply se asigură că îl prinzi pe fiecare.</p>
        <div className="lp-vgrid"><div className="vcard"><span>🏠</span><b>Imobiliare</b><p>„Leadul care întreabă de apartament la 22:00 pleacă la alt agent."</p></div><div className="vcard"><span>🪟</span><b>Servicii pentru casă</b><p>Termopane, mobilă, amenajări, solar. „Ești pe schelă, nu la telefon."</p></div><div className="vcard"><span>🦷</span><b>Clinici private</b><p>„Pacientul sună la clinica ce răspunde prima."</p></div><div className="vcard"><span>🚗</span><b>Dealeri auto</b><p>„Clientul cumpără până luni — de la tine sau de la altul."</p></div></div>
      </div></section>

      <section className="lp-sec lp-roi" id="roi"><div className="container">
        <span className="eyebrow">Calculator</span><h2>Câți bani pierzi lunar din lead-uri nerăspunse?</h2>
        <p className="lead">Mișcă barele și vezi cât ți-ar recupera Leaply. Estimări pe medii de industrie.</p>
        <div className="roi"><div className="roi-controls">
          <label>Lead-uri pe lună<b id="r-leads-v">40</b></label><input id="r-leads" type="range" min={5} max={300} defaultValue={40} />
          <label>Valoarea unui client (lei)<b id="r-val-v">3.000</b></label><input id="r-val" type="range" min={200} max={20000} step={100} defaultValue={3000} />
          <label>Rata ta de închidere<b id="r-rate-v">30%</b></label><input id="r-rate" type="range" min={5} max={60} defaultValue={30} />
        </div><div className="roi-result">
          <div className="roi-big" id="r-big">+50.400 lei<span>/lună</span></div>
          <p>venituri recuperate estimate, din lead-uri la care altfel nu ai fi răspuns la timp</p>
          <div className="roi-sub"><span><b id="r-missed">16</b> pierdute acum</span><span><b id="r-deals">3</b> clienți în plus</span></div>
          <a href="#demo" className="btn btn-primary">Vreau rezultatul ăsta ▸</a>
        </div></div>
      </div></section>

      <section className="lp-sec lp-proof"><div className="container"><div className="lp-quotes">
        <blockquote>„Am prins 6 lead-uri într-un weekend, când eram închiși. Unul s-a transformat în contract de 14.000 lei."<cite>— Firmă de termopane, Oradea</cite></blockquote>
        <blockquote>„Răspunde mai bine și mai repede decât o făceam noi manual. Clienții nici nu-și dau seama."<cite>— Agent imobiliar, Cluj</cite></blockquote>
      </div></div></section>

      <section className="lp-sec" id="preturi"><div className="container">
        <span className="eyebrow">Prețuri</span><h2>Un singur lead salvat îți acoperă abonamentul</h2>
        <p className="lead">Fără cost de instalare la plata anuală. Fără contract pe termen lung.</p>
        <div className="lp-pricing">
          <div className="pcard"><div className="pt">Start</div><div className="pa">59€<span>/lună</span></div><ul><li>WhatsApp + chat web</li><li>300 conversații/lună</li><li>Răspuns + calificare</li><li>Google Calendar</li></ul><a href="#demo" className="btn btn-dark">Începe</a></div>
          <div className="pcard hot"><div className="ptag">Cel mai ales</div><div className="pt">Pro</div><div className="pa">129€<span>/lună</span></div><ul><li>+ Facebook & Instagram DM</li><li>1.000 conversații/lună</li><li>Booking automat în calendar</li><li>Integrare CRM + Meta Ads</li></ul><a href="#demo" className="btn btn-primary">Cere demo</a></div>
          <div className="pcard"><div className="pt">Scale</div><div className="pa">299€<span>/lună</span></div><ul><li>Toate canalele + SMS</li><li>3.000 conversații/lună</li><li>Până la 5 locații</li><li>Account manager dedicat</li></ul><a href="#demo" className="btn btn-dark">Vorbește cu noi</a></div>
        </div>
      </div></section>

      <section className="lp-sec lp-demo" id="demo"><div className="container lp-demo-in">
        <div className="lp-demo-copy"><span className="eyebrow light">Începe azi</span><h2>Îți setăm un asistent pe lead-urile <span className="hl">tale reale</span>. Gratuit.</h2><p>În 48 de ore îți arătăm Leaply răspunzând la lead-urile afacerii tale. Dacă nu-ți prinde măcar 3 clienți pe care i-ai fi pierdut, nu plătești nimic.</p><ul className="lp-checks"><li>✅ Fără card, fără obligații</li><li>✅ Configurare făcută de noi</li><li>✅ Date în UE · conform GDPR</li></ul></div>
        <div className="leadform">
          <div id="lf-form"><h3>Vezi Leaply pe afacerea ta</h3><p>Îți setăm un asistent pe lead-urile tale reale. Fără card, fără obligații.</p>
            <form id="leadform">
              <input name="name" placeholder="Numele tău" /><input name="contact" placeholder="Telefon sau email *" required /><input name="business" placeholder="Numele firmei" />
              <select name="vertical"><option>Servicii casă (termopane, mobilă, amenajări)</option><option>Imobiliare</option><option>Clinică privată</option><option>Dealer auto</option><option>Altceva</option></select>
              <button className="btn btn-primary" type="submit">Cere demo gratuit ▸</button><span className="micro">🔒 Datele tale rămân în UE. Fără spam.</span>
            </form>
          </div>
          <div id="lf-sent" style={{ display: 'none', textAlign: 'center' }}><div style={{ fontSize: 44 }}>🎉</div><h3>Gata! Te contactăm în cel mult o oră.</h3><p>Îți pregătim un asistent Leaply pe lead-urile afacerii tale.</p><a href="/demo" className="btn btn-primary">Deschide demo live ▸</a></div>
        </div>
      </div></section>

      <section className="lp-sec lp-faq"><div className="container">
        <span className="eyebrow">Întrebări frecvente</span><h2>Ce ne întreabă antreprenorii</h2>
        <div className="faq">
          <details><summary>Nu vreau un robot care sperie clienții.</summary><p>Leaply vorbește natural, în română, ca un angajat bun. Îl setăm pe cazurile tale și îl testezi înainte să plătești.</p></details>
          <details><summary>Am deja pe cineva care răspunde.</summary><p>La 2 noaptea? Duminica? În 5 minute de fiecare dată? Leaply prinde lead-urile pe care omul le ratează.</p></details>
          <details><summary>Am încercat chatboturi și n-au mers.</summary><p>Alea erau meniuri cu butoane. Leaply e AI care înțelege, califică și programează.</p></details>
          <details><summary>Cât durează să pornesc?</summary><p>10 minute, sau ți-o facem noi. Ești live în aceeași zi.</p></details>
        </div>
      </div></section>

      <footer className="lp-footer"><div className="container lp-footer-in"><Logo />
        <div className="lp-foot-links"><a href="#cum">Cum funcționează</a><a href="#preturi">Prețuri</a><a href="/demo">Demo</a><a href="/app">Autentificare</a></div>
        <div className="lp-foot-meta">Date în UE · GDPR · Suport în română<br />© 2026 Leaply · leaply.ro</div>
      </div></footer>
      <script dangerouslySetInnerHTML={{ __html: SCRIPT }} />
    </main>
  );
}
