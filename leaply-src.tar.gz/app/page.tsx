export const dynamic = 'force-static';

import { Logo } from '../lib/logo';

// Scriptul folosește DOAR event delegation pe document: hidratarea React poate
// înlocui nodurile DOM (și pierde listenerii legați direct de ele) — delegarea
// supraviețuiește. Nu muta listeneri pe elemente individuale.
const SCRIPT = `
(function(){
  function fmt(n){return Math.round(n).toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g,'.');}
  function set(id,t){var e=document.getElementById(id);if(e)e.textContent=t;}
  function calc(){
    var L=document.getElementById('r-leads'),V=document.getElementById('r-val'),R=document.getElementById('r-rate');
    if(!L||!V||!R)return;
    var l=+L.value,v=+V.value,r=+R.value;
    set('r-leads-v',String(l));set('r-val-v',fmt(v));set('r-rate-v',r+'%');
    var missed=Math.round(l*0.4), rec=Math.round(missed*0.6), deals=Math.round(rec*(r/100)), monthly=deals*v;
    set('r-big','+'+fmt(monthly)+' lei');set('r-missed',String(missed));set('r-deals',String(deals));
  }
  document.addEventListener('input',function(e){
    var id=e.target&&e.target.id;
    if(id==='r-leads'||id==='r-val'||id==='r-rate')calc();
  });
  if(document.readyState!=='loading')calc();else document.addEventListener('DOMContentLoaded',calc);
  window.addEventListener('load',calc);
  /* autocomplete domeniu afacere — apare DOAR când scrii, max 6 sugestii */
  var VERT=['Termopane și tâmplărie PVC','Mobilă la comandă','Amenajări interioare','Construcții și renovări','Instalații sanitare și termice','Acoperișuri','Panouri fotovoltaice','Aer condiționat / HVAC','Ferestre și uși','Firme de curățenie','Dezinsecție și deratizare','Mutări și transport','Stomatologie','Clinică medicală privată','Dermatologie și estetică','Oftalmologie','Kinetoterapie și recuperare','Cabinet veterinar','Imobiliare — agenție','Imobiliare — dezvoltator','Dealer auto','Service auto','Detailing auto','Vulcanizare / anvelope','Salon de înfrumusețare','Frizerie / barbershop','Fitness / sală de sport','Școală de șoferi','Fotografie și video evenimente','Organizare evenimente','Avocatură / notariat','Contabilitate','Asigurări / brokeraj','Agenție de turism','Cursuri și meditații','IT / agenție web','Altceva'];
  function norm(s){return s.toLowerCase().normalize('NFD').replace(/[\\u0300-\\u036f]/g,'');}
  function hideSugg(){var b=document.getElementById('lp-vert-sugg');if(b){b.hidden=true;b.innerHTML='';}}
  document.addEventListener('input',function(e){
    if(!e.target||e.target.id!=='lp-vert-in')return;
    var box=document.getElementById('lp-vert-sugg');
    if(!box)return;
    var q=norm(e.target.value.trim());
    if(q.length<1){hideSugg();return;}
    var hits=VERT.filter(function(v){return norm(v).indexOf(q)>-1;}).slice(0,6);
    if(!hits.length){hideSugg();return;}
    box.innerHTML=hits.map(function(v){return '<button type="button" class="lp-vert-opt">'+v+'</button>';}).join('');
    box.hidden=false;
  });
  document.addEventListener('mousedown',function(e){
    var t=e.target;
    if(t&&t.classList&&t.classList.contains('lp-vert-opt')){
      e.preventDefault();
      var inp=document.getElementById('lp-vert-in');
      if(inp)inp.value=t.textContent;
      hideSugg();
    }else if(!(t&&t.id==='lp-vert-in')){
      hideSugg();
    }
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape')hideSugg();});
  /* meniul mobil se închide după click pe un link */
  document.addEventListener('click',function(e){
    var t=e.target;
    if(t&&t.closest&&t.closest('.lp-nav-links')){var c=document.getElementById('lp-nav-t');if(c)c.checked=false;}
  });
  document.addEventListener('submit',function(ev){
    var f=ev.target;
    if(!f||f.id!=='leadform')return;
    ev.preventDefault();
    function val(n){var x=f.elements.namedItem(n);return x&&x.value?x.value.trim():'';}
    var email=val('email'), phone=val('phone');
    if(!email)return;
    var body={name:val('name'),contact:email||phone,phone:phone,email:email,website:val('website'),business:val('business'),vertical:val('vertical')};
    var btn=f.querySelector('button[type=submit]');
    if(btn){btn.disabled=true;btn.textContent='Se trimite\\u2026';}
    function fallback(){
      var a=document.getElementById('lf-form'),b=document.getElementById('lf-sent');
      if(a)a.style.display='none';
      if(b)b.style.display='block';
    }
    fetch('/api/lead',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
      .then(function(r){if(!r.ok)throw new Error();return r.json();})
      .then(function(d){
        if(d&&d.ok&&d.demoRequestId){
          try{sessionStorage.setItem('leaply_lead',JSON.stringify({name:body.name,phone:body.phone,email:body.email,website:body.website,business:body.business,vertical:body.vertical,demoRequestId:d.demoRequestId}));}catch(e){}
          window.location=d.next||'/start';
        }else{fallback();}
      })
      .catch(function(){fallback();});
  });
})();
`;

/* ---- pictograme SVG minimaliste (stroke 1.75, currentColor) ---- */
const Ic = ({ children, size = 20 }: any) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{children}</svg>
);
const IcBolt = ({ size = 20 }: any) => <Ic size={size}><path d="M13 2 4.8 13.2h6L10 22l8.2-11.2h-6L13 2z" /></Ic>;
const IcArrow = ({ size = 17 }: any) => <Ic size={size}><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></Ic>;
const IcCheck = ({ size = 18 }: any) => <Ic size={size}><path d="M20 6 9 17l-5-5" /></Ic>;
const IcPlus = ({ size = 18 }: any) => <Ic size={size}><path d="M12 5v14" /><path d="M5 12h14" /></Ic>;
const IcLock = ({ size = 15 }: any) => <Ic size={size}><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></Ic>;
const IcMoon = ({ size = 20 }: any) => <Ic size={size}><path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z" /></Ic>;
const IcPhoneOff = ({ size = 20 }: any) => <Ic size={size}><path d="M10.7 13.3a15.8 15.8 0 0 1-2.6-3.5l1.3-1.3a2 2 0 0 0 .5-2.1c-.3-.9-.6-1.9-.7-2.9A2 2 0 0 0 7.2 1.7H5.1a2 2 0 0 0-2 2.2 19.8 19.8 0 0 0 3.1 8.7 19.6 19.6 0 0 0 6.9 6.6 19.8 19.8 0 0 0 7.7 2.5 2 2 0 0 0 2.2-2v-2.1a2 2 0 0 0-1.7-2c-1-.1-2-.4-2.9-.7a2 2 0 0 0-2.1.5l-1.3 1.3" /><path d="m3 3 18 18" /></Ic>;
const IcLayers = ({ size = 20 }: any) => <Ic size={size}><path d="m12 3-9 5 9 5 9-5-9-5z" /><path d="m3 13 9 5 9-5" /></Ic>;
const IcLink = ({ size = 20 }: any) => <Ic size={size}><path d="M10 13.5a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7.1-7.1L11.7 5.6" /><path d="M14 10.5a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7.1 7.1l1.7-1.7" /></Ic>;
const IcChat = ({ size = 20 }: any) => <Ic size={size}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10z" /></Ic>;
const IcChatDots = ({ size = 20 }: any) => <Ic size={size}><path d="M21 11.5a8.4 8.4 0 0 1-8.5 8.4 8.6 8.6 0 0 1-3.9-.9L3 21l2-5.4A8.4 8.4 0 1 1 21 11.5z" /><path d="M8.5 11.5h.01" /><path d="M12 11.5h.01" /><path d="M15.5 11.5h.01" /></Ic>;
const IcCamera = ({ size = 20 }: any) => <Ic size={size}><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="3.5" /><path d="M17.2 6.8h.01" /></Ic>;
const IcForm = ({ size = 20 }: any) => <Ic size={size}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z" /><path d="M14 2v6h6" /><path d="M8 13h8" /><path d="M8 17h5" /></Ic>;
const IcCalendar = ({ size = 20 }: any) => <Ic size={size}><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4" /><path d="M8 3v4" /><path d="M3 11h18" /><path d="m9.5 15.5 2 2 3.5-3.5" /></Ic>;
const IcHome = ({ size = 20 }: any) => <Ic size={size}><path d="m3 10.5 9-7.5 9 7.5" /><path d="M5.5 9v11.5h13V9" /></Ic>;
const IcWindow = ({ size = 20 }: any) => <Ic size={size}><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M12 3v18" /><path d="M4 12h16" /></Ic>;
const IcPulse = ({ size = 20 }: any) => <Ic size={size}><path d="M3 12h4l2.5-6 4.5 12 2.5-6H21" /></Ic>;
const IcCar = ({ size = 20 }: any) => <Ic size={size}><path d="m5.5 11 1.4-4.2A2 2 0 0 1 8.8 5.5h6.4a2 2 0 0 1 1.9 1.3L18.5 11" /><rect x="3" y="11" width="18" height="6" rx="2" /><path d="M7 14h.01" /><path d="M17 14h.01" /><path d="M5.5 17v2" /><path d="M18.5 17v2" /></Ic>;

export default function Home() {
  return (
    <main className="lp">

      {/* ============ NAV ============ */}
      <header className="lp-nav">
        <div className="container lp-nav-in">
          <a href="/" aria-label="Leaply — acasă"><Logo light /></a>
          <input type="checkbox" id="lp-nav-t" className="lp-nav-t" aria-label="Deschide meniul" />
          <label htmlFor="lp-nav-t" className="lp-burger" aria-hidden="true"><span /><span /><span /></label>
          <nav className="lp-nav-links">
            <a className="lp-navlink" href="#cum">Cum funcționează</a>
            <a className="lp-navlink" href="#verticale">Pentru cine</a>
            <a className="lp-navlink" href="#roi">Calculator</a>
            <a className="lp-navlink" href="#preturi">Prețuri</a>
            <a className="lp-navlink" href="#faq">Întrebări</a>
            <a className="lp-navlink" href="/login">Autentificare</a>
            <a href="#demo" className="btn btn-primary btn-sm">Cere demo</a>
          </nav>
        </div>
      </header>

      {/* ============ HERO ============ */}
      <section className="lp-hero">
        <div className="lp-glow" aria-hidden="true" />
        <div className="lp-glow-2" aria-hidden="true" />
        <div className="container lp-hero-in">
          <span className="eyebrow on-dark"><IcBolt size={15} /> Răspuns automat în sub 60 de secunde · 24/7</span>
          <h1>Nu mai pierde clienți<br /><span className="lp-hl">pentru că ai răspuns prea târziu.</span></h1>
          <p className="lp-sub">Leaply răspunde automat, în română, fiecărui lead de pe Facebook, Instagram, Messenger, WhatsApp sau site — îl califică și îți programează întâlnirea. Tu vinzi, noi nu lăsăm niciun client să aștepte.</p>
          <div className="lp-cta">
            <a href="/demo" className="btn btn-primary btn-lg">Încearcă demo live <IcArrow /></a>
            <a href="#demo" className="btn btn-ghost-dark btn-lg">Vezi Leaply pe afacerea ta</a>
          </div>
          <a className="lp-hero-call" href="tel:+40373818737">Sau sună agentul AI, non-stop: <b>0373 818 737</b></a>
          <div className="lp-channels lp-channels-quiet">
            Se integrează cu WhatsApp · Facebook & Instagram · Messenger · formulare web · telefon · Google Calendar
          </div>
          <div className="lp-stats">
            <div className="lp-stat"><div className="n">&lt;60s</div><div className="l">timp de răspuns, non-stop</div></div>
            <div className="lp-stat"><div className="n">2,6×</div><div className="l">mai multe vânzări închise</div></div>
            <div className="lp-stat"><div className="n">21×</div><div className="l">mai multe lead-uri calificate</div></div>
            <div className="lp-stat"><div className="n">78%</div><div className="l">cumpără de la primul care răspunde</div></div>
          </div>
        </div>
      </section>

      {/* ============ PROBLEMA ============ */}
      <section className="lp-sec">
        <div className="container">
          <div className="lp-head">
            <span className="eyebrow">Problema</span>
            <h2>Un client îți scrie la 21:47. Tu îl vezi mâine la 9. Prea târziu.</h2>
            <p className="lp-lead">Până răspunzi tu, clientul a cerut deja ofertă la alte 3 firme — și cumpără de la prima care i-a răspuns. Firmele care răspund în sub 5 minute au șanse de <b>2,6× mai mari</b> să închidă și de <b>21× mai mari</b> să califice, față de un răspuns la 30 de minute.</p>
          </div>
          <div className="lp-bento">
            <div className="lp-chatcard">
              <div className="lp-chatstream">
                <div className="lp-stamp">Lead nou · sâmbătă, 21:47</div>
                <div className="bubble in">Bună seara! Aș vrea o ofertă pentru 5 ferestre cu montaj. În cât timp ați putea veni la măsurători?</div>
                <div className="lp-stamp lp-right">Tu · luni, 09:12</div>
                <div className="bubble out">Bună dimineața! Sigur, cu plăcere. Când v-ar conveni…</div>
              </div>
              <div className="lp-lost"><IcPhoneOff size={18} /> Prea târziu — clientul a semnat deja cu altă firmă.</div>
            </div>
            <div className="lp-pains">
              <div className="lp-pain"><span className="lp-ic"><IcMoon /></span><div><b>Seara și în weekend</b><p>Lead-urile vin non-stop, tu ești închis. Se răcesc până luni.</p></div></div>
              <div className="lp-pain"><span className="lp-ic"><IcPhoneOff /></span><div><b>Ești ocupat</b><p>Ești pe teren sau cu alt client. Telefonul sună în gol.</p></div></div>
              <div className="lp-pain"><span className="lp-ic"><IcLayers /></span><div><b>Prea multe canale</b><p>WhatsApp, DM, formular, telefon — imposibil să le prinzi pe toate.</p></div></div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ CUM FUNCȚIONEAZĂ ============ */}
      <section className="lp-sec lp-sec-alt" id="cum">
        <div className="container">
          <div className="lp-head lp-center">
            <span className="eyebrow">Cum funcționează</span>
            <h2>Live în 10 minute. Fără programator.</h2>
          </div>
          <div className="lp-steps">
            <div className="lp-step"><span className="lp-stepn">1</span><span className="lp-ic"><IcLink /></span><h3>Conectezi sursele de lead-uri</h3><p>Facebook & Instagram Lead Ads, Messenger, WhatsApp, formular web. Un click, fără cod.</p></div>
            <div className="lp-step"><span className="lp-stepn">2</span><span className="lp-ic"><IcChat /></span><h3>Leaply răspunde instant, în română</h3><p>Pune întrebările corecte, califică clientul, răspunde la obiecții — 24/7.</p></div>
            <div className="lp-step"><span className="lp-stepn">3</span><span className="lp-ic"><IcCalendar /></span><h3>Îți apare întâlnirea în calendar</h3><p>Leadul calificat e programat automat. Tu doar te prezinți și vinzi.</p></div>
          </div>
          <div className="center"><a href="/demo" className="btn btn-dark btn-lg">Vezi o conversație reală în demo <IcArrow /></a></div>
        </div>
      </section>

      {/* ============ PENTRU CINE ============ */}
      <section className="lp-sec" id="verticale">
        <div className="container">
          <div className="lp-head">
            <span className="eyebrow">Pentru cine</span>
            <h2>Construit pentru afaceri cu lead-uri valoroase</h2>
            <p className="lp-lead">Un singur lead valorează sute sau mii de lei. Leaply se asigură că îl prinzi pe fiecare.</p>
          </div>
          <div className="lp-vgrid">
            <div className="lp-vcard"><span className="lp-ic"><IcHome /></span><b>Imobiliare</b><p>„Leadul care întreabă de apartament la 22:00 pleacă la alt agent.”</p></div>
            <div className="lp-vcard"><span className="lp-ic"><IcWindow /></span><b>Servicii pentru casă</b><p>Termopane, mobilă, amenajări, solar. „Ești pe schelă, nu la telefon.”</p></div>
            <div className="lp-vcard"><span className="lp-ic"><IcPulse /></span><b>Clinici private</b><p>„Pacientul sună la clinica ce răspunde prima.”</p></div>
            <div className="lp-vcard"><span className="lp-ic"><IcCar /></span><b>Dealeri auto</b><p>„Clientul cumpără până luni — de la tine sau de la altul.”</p></div>
          </div>
        </div>
      </section>

      {/* ============ CALCULATOR ROI ============ */}
      <section className="lp-sec lp-sec-alt" id="roi">
        <div className="container">
          <div className="lp-head">
            <span className="eyebrow">Calculator</span>
            <h2>Câți bani pierzi lunar din lead-uri nerăspunse?</h2>
            <p className="lp-lead">Mișcă barele și vezi cât ți-ar recupera Leaply. Estimări pe medii de industrie.</p>
          </div>
          <div className="lp-roi">
            <div className="lp-roi-controls">
              <label htmlFor="r-leads">Lead-uri pe lună<b id="r-leads-v">40</b></label>
              <input id="r-leads" type="range" min={5} max={300} defaultValue={40} />
              <label htmlFor="r-val">Valoarea unui client (lei)<b id="r-val-v">3.000</b></label>
              <input id="r-val" type="range" min={200} max={20000} step={100} defaultValue={3000} />
              <label htmlFor="r-rate">Rata ta de închidere<b id="r-rate-v">30%</b></label>
              <input id="r-rate" type="range" min={5} max={60} defaultValue={30} />
              <p className="lp-roi-note">Presupunem, conservator, că ~40% din lead-uri rămân azi fără răspuns la timp și că Leaply recuperează ~60% din ele.</p>
            </div>
            <div className="lp-roi-result">
              <div className="lp-roi-big"><b id="r-big">+9.000 lei</b><span>/lună</span></div>
              <p>venituri recuperate estimate, din lead-uri la care altfel nu ai fi răspuns la timp</p>
              <div className="lp-roi-sub"><span><b id="r-missed">16</b> lead-uri pierdute acum</span><span><b id="r-deals">3</b> clienți în plus</span></div>
              <a href="#demo" className="btn btn-primary">Vreau rezultatul ăsta <IcArrow /></a>
            </div>
          </div>
        </div>
      </section>

      {/* ============ TESTIMONIALE ============ */}
      <section className="lp-sec">
        <div className="container">
          <div className="lp-quotes">
            <blockquote>
              <p>„Am prins 6 lead-uri într-un weekend, când eram închiși. Unul s-a transformat în contract de 14.000 lei.”</p>
              <cite>— Firmă de termopane, Oradea</cite>
            </blockquote>
            <blockquote>
              <p>„Răspunde mai bine și mai repede decât o făceam noi manual. Clienții nici nu-și dau seama.”</p>
              <cite>— Agent imobiliar, Cluj</cite>
            </blockquote>
          </div>
        </div>
      </section>

      {/* ============ PREȚURI ============ */}
      <section className="lp-sec" id="preturi">
        <div className="container">
          <div className="lp-head lp-center">
            <span className="eyebrow">Prețuri</span>
            <h2>Un singur lead salvat îți acoperă abonamentul</h2>
            <p className="lp-lead">Fără cost de instalare la plata anuală. Fără contract pe termen lung.</p>
          </div>
          <div className="lp-pricing">
            <div className="lp-pcard">
              <div className="lp-pt">Social</div>
              <div className="lp-pa">59€<span>/lună</span></div>
              <ul>
                <li><IcCheck size={16} /> Facebook Messenger + Instagram DM</li>
                <li><IcCheck size={16} /> Facebook Lead Ads + chat pe site</li>
                <li><IcCheck size={16} /> 300 conversații/lună</li>
                <li><IcCheck size={16} /> Google Calendar + follow-up automat</li>
              </ul>
              <a href="#demo" className="btn btn-dark">Începe</a>
            </div>
            <div className="lp-pcard lp-hot">
              <div className="lp-ptag">Cel mai ales</div>
              <div className="lp-pt">Complet</div>
              <div className="lp-pa">129€<span>/lună</span></div>
              <ul>
                <li><IcCheck size={16} /> Tot din Social + WhatsApp</li>
                <li><IcCheck size={16} /> Număr WhatsApp de la Leaply inclus</li>
                <li><IcCheck size={16} /> 800 conversații/lună · echipă 3 colegi</li>
                <li><IcCheck size={16} /> API + integrare CRM</li>
              </ul>
              <a href="#demo" className="btn btn-primary">Cere demo</a>
            </div>
            <div className="lp-pcard">
              <div className="lp-pt">Total</div>
              <div className="lp-pa">299€<span>/lună</span></div>
              <ul>
                <li><IcCheck size={16} /> Tot din Complet + agent vocal AI</li>
                <li><IcCheck size={16} /> Număr de telefon dedicat · 500 min/lună</li>
                <li><IcCheck size={16} /> 2.500 conversații/lună · echipă 10</li>
                <li><IcCheck size={16} /> Multi-locație · onboarding făcut de noi</li>
              </ul>
              <a href="#demo" className="btn btn-dark">Vorbește cu noi</a>
            </div>
          </div>
          <p className="lp-pricing-note">Fiecare pachet include tot ce e în cel dinaintea lui. <b>Plătește anual și primești 2 luni gratis.</b> Extra resurse oricând: +200 conversații 19€ · +100 min voce 29€ · +500 SMS 29€ · număr suplimentar 12€/lună. Suport în română, date în UE.</p>
        </div>
      </section>

      {/* ============ CTA FINAL / DEMO ============ */}
      <section className="lp-sec lp-demo" id="demo">
        <div className="lp-glow" aria-hidden="true" />
        <div className="container lp-demo-in">
          <div className="lp-demo-copy">
            <span className="eyebrow on-dark">Începe azi</span>
            <h2>Îți setăm un asistent pe lead-urile <span className="lp-hl">tale reale</span>. Gratuit.</h2>
            <p>În 48 de ore îți arătăm Leaply răspunzând la lead-urile afacerii tale. Dacă nu-ți prinde măcar 3 clienți pe care i-ai fi pierdut, nu plătești nimic.</p>
            <ul className="lp-checks">
              <li><IcCheck /> Fără card, fără obligații</li>
              <li><IcCheck /> Configurare făcută de noi</li>
              <li><IcCheck /> Date în UE · conform GDPR</li>
            </ul>
          </div>
          <div className="lp-form">
            <div id="lf-form">
              <h3>Vezi Leaply pe afacerea ta</h3>
              <p className="lp-form-sub">Numele și contactul — iar dacă ne lași și site-ul firmei, îți preconfigurăm asistentul automat din el.</p>
              <form id="leadform">
                <input className="txt" name="name" placeholder="Nume și prenume" autoComplete="name" />
                <div className="lp-form-row">
                  <input className="txt" name="email" type="email" placeholder="Email *" autoComplete="email" required />
                  <input className="txt" name="phone" type="tel" placeholder="Telefon" autoComplete="tel" />
                </div>
                <input className="txt" name="website" inputMode="url" placeholder="Site-ul firmei (opțional — îl importăm automat)" autoComplete="url" />
                <div className="lp-vert">
                  <input className="txt" id="lp-vert-in" name="vertical" placeholder="Domeniul afacerii (opțional)" autoComplete="off" />
                  <div id="lp-vert-sugg" className="lp-vert-sugg" hidden />
                </div>
                <button className="btn btn-primary" type="submit">Cere demo gratuit <IcArrow /></button>
                <span className="lp-micro"><IcLock /> Datele tale se salvează automat și rămân în UE. Fără spam.</span>
              </form>
            </div>
            <div id="lf-sent" className="lp-sent" style={{ display: 'none' }}>
              <span className="lp-ic"><IcCheck size={26} /></span>
              <h3>Gata! Te contactăm în cel mult o oră.</h3>
              <p>Îți pregătim un asistent Leaply pe lead-urile afacerii tale.</p>
              <a href="/demo" className="btn btn-primary">Deschide demo live <IcArrow /></a>
            </div>
          </div>
        </div>
      </section>

      {/* ============ FAQ ============ */}
      <section className="lp-sec" id="faq">
        <div className="container">
          <div className="lp-head lp-center">
            <span className="eyebrow">Întrebări frecvente</span>
            <h2>Ce ne întreabă antreprenorii</h2>
          </div>
          <div className="lp-faq">
            <details>
              <summary>Nu vreau un robot care sperie clienții. <IcPlus /></summary>
              <p>Leaply vorbește natural, în română, ca un angajat bun. Îl setăm pe cazurile tale și îl testezi înainte să plătești.</p>
            </details>
            <details>
              <summary>Am deja pe cineva care răspunde. <IcPlus /></summary>
              <p>La 2 noaptea? Duminica? În 5 minute de fiecare dată? Leaply prinde lead-urile pe care omul le ratează.</p>
            </details>
            <details>
              <summary>Am încercat chatboturi și n-au mers. <IcPlus /></summary>
              <p>Alea erau meniuri cu butoane. Leaply e AI care înțelege, califică și programează.</p>
            </details>
            <details>
              <summary>Cât durează să pornesc? <IcPlus /></summary>
              <p>10 minute, sau ți-o facem noi. Ești live în aceeași zi.</p>
            </details>
          </div>
        </div>
      </section>

      {/* ============ FOOTER ============ */}
      <footer className="lp-footer">
        <div className="container">
          <div className="lp-foot-grid">
            <div className="lp-foot-brand">
              <Logo light />
              <p>Asistentul AI care răspunde lead-urilor tale în sub 60 de secunde. Non-stop, în română.</p>
              <a href="tel:+40373818737">📞 0373 818 737 — sună agentul AI</a>
              <a href="mailto:salut@leaply.ro">salut@leaply.ro</a>
            </div>
            <nav className="lp-foot-col" aria-label="Produs">
              <b>Produs</b>
              <a href="#cum">Cum funcționează</a>
              <a href="#preturi">Prețuri</a>
              <a href="/demo">Demo live</a>
              <a href="/developers">API pentru dezvoltatori</a>
              <a href="/login">Autentificare</a>
            </nav>
            <nav className="lp-foot-col" aria-label="Soluții">
              <b>Soluții</b>
              <a href="/solutii/termopane">Termopane</a>
              <a href="/solutii/stomatologie">Stomatologie</a>
              <a href="/solutii/service-auto">Service auto</a>
              <a href="/solutii/imobiliare">Imobiliare</a>
              <a href="/solutii/instalatii">Instalatori</a>
              <a href="/solutii/saloane">Saloane</a>
            </nav>
            <nav className="lp-foot-col" aria-label="Legal">
              <b>Legal</b>
              <a href="/termeni">Termeni și condiții</a>
              <a href="/confidentialitate">Confidențialitate</a>
              <a href="/cookies">Cookies</a>
              <a href="https://anpc.ro/ce-este-sal/" target="_blank" rel="noopener">ANPC — SAL</a>
              <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener">SOL</a>
            </nav>
          </div>
          <div className="lp-foot-bottom">
            <span>© 2026 Leaply · un produs ARHAI S.R.L. · CUI RO35913161 · Oradea</span>
            <span>Date în UE · GDPR · Suport în română</span>
          </div>
        </div>
      </footer>

      <script src="https://leaply.ro/widget.js" data-leaply="acc_leaply" async />
      <script dangerouslySetInnerHTML={{ __html: SCRIPT }} />
    </main>
  );
}
