import { LegalShell } from '../legal-layout';
export const metadata = { title: 'Politica de confidențialitate — Leaply' };

export default function Confidentialitate() {
  return (
    <LegalShell title="Politica de confidențialitate" updated="2 iulie 2026">
      <p><b>Pe scurt:</b> datele stau pe servere din UE, nu vindem date nimănui, folosim doar furnizori necesari funcționării serviciului, iar pentru datele lead-urilor clienților noștri acționăm ca persoană împuternicită (procesator).</p>

      <h2>1. Operatorul</h2>
      <p><b>ARHAI S.R.L.</b>, CUI RO35913161, Oradea, jud. Bihor — <a href="mailto:salut@leaply.ro">salut@leaply.ro</a>.</p>

      <h2>2. Ce date prelucrăm și de ce</h2>
      <p><b>a) Date de cont (operator):</b> nume, email, parolă (criptată), telefon, date firmă (CUI, adresă — inclusiv preluate de la ANAF la cererea ta), date de facturare și plată (procesate de Stripe; noi nu stocăm numărul cardului). Temei: executarea contractului, obligații fiscale.</p>
      <p><b>b) Cereri de demo (operator):</b> datele din formularul de pe site (nume, contact, firmă). Temei: pași precontractuali la cererea ta.</p>
      <p><b>c) Datele lead-urilor clienților noștri (împuternicit):</b> mesaje, nume, numere de telefon, istoricul conversațiilor purtate cu asistentul AI al clientului. Le prelucrăm strict conform instrucțiunilor clientului (operatorul acestor date) pentru a furniza serviciul.</p>

      <h2>3. Furnizori (sub-împuterniciți)</h2>
      <p>Găzduire pe server propriu în UE; OpenAI (generarea răspunsurilor — fără folosirea datelor la antrenare, conform politicii API); Meta Platforms (mesaje WhatsApp/Messenger/Instagram); Google (Calendar, doar cu autorizarea ta); Stripe (plăți); SmartBill (facturi); SMSLink/Twilio (SMS și telefonie); Resend (emailuri tranzacționale); ANAF (interogare publică date firmă la cererea ta).</p>

      <h2>4. Cât păstrăm datele</h2>
      <p>Datele contului — pe durata contractului și apoi conform obligațiilor legale (ex. documente fiscale 5–10 ani). Conversațiile lead-urilor — cât timp contul clientului e activ sau până la instrucțiunea de ștergere. Backup-urile se rotesc automat (max. 14 zile).</p>

      <h2>5. Drepturile tale</h2>
      <p>Acces, rectificare, ștergere, restricționare, portabilitate, opoziție și retragerea consimțământului — scrie-ne la <a href="mailto:salut@leaply.ro">salut@leaply.ro</a>; răspundem în cel mult 30 de zile. Te poți adresa și ANSPDCP (dataprotection.ro). Dacă ești lead-ul unui client Leaply, adresează-ți cererea afacerii cu care ai comunicat; o sprijinim să o rezolve.</p>

      <h2>6. Securitate</h2>
      <p>Criptare în tranzit (TLS), parole hash-uite (scrypt), chei și token-uri stocate criptat/mascadate, acces pe bază de rol, backup-uri automate. Notificăm incidentele conform art. 33–34 GDPR.</p>

      <h2>7. Transferuri în afara UE</h2>
      <p>Unii furnizori (ex. OpenAI, Stripe, Meta, Twilio) pot prelucra date în SUA — pe baza clauzelor contractuale standard (SCC) și/sau a cadrului UE–SUA de protecție a datelor.</p>
    </LegalShell>
  );
}
