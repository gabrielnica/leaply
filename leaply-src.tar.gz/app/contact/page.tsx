import Link from 'next/link';
import { Logo } from '../../lib/logo';

export const metadata = {
  title: 'Contact — Leaply',
  description: 'Contactează echipa Leaply: email salut@leaply.ro, telefon 0373 818 737 (agent AI non-stop). ARHAI S.R.L., Oradea.',
};

export default function Contact() {
  return (
    <main style={{ maxWidth: 720, margin: '0 auto', padding: '36px 20px 80px', lineHeight: 1.7 }}>
      <p><Link href="/">← leaply.ro</Link></p>
      <div style={{ margin: '10px 0' }}><Logo size={28} /></div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 38, lineHeight: 1.15, margin: '12px 0 10px' }}>Contact</h1>
      <p style={{ fontSize: 18, color: 'var(--muted)' }}>Răspundem în aceeași zi lucrătoare — de obicei în câteva ore. Iar agentul nostru AI răspunde la telefon non-stop (da, chiar produsul nostru).</p>

      <div style={{ margin: '26px 0', display: 'grid', gap: 14 }}>
        <div style={{ border: '1px solid var(--line)', borderRadius: 14, padding: '16px 20px' }}>
          <b>✉️ Email</b><br />
          <a href="mailto:salut@leaply.ro">salut@leaply.ro</a> — vânzări, suport, facturare, GDPR.
        </div>
        <div style={{ border: '1px solid var(--line)', borderRadius: 14, padding: '16px 20px' }}>
          <b>📞 Telefon</b><br />
          <a href="tel:+40373818737">0373 818 737</a> — agentul AI Leaply, non-stop. Îți răspunde, te califică și îți programează o discuție cu noi. Testează-l fără grijă.
        </div>
        <div style={{ border: '1px solid var(--line)', borderRadius: 14, padding: '16px 20px' }}>
          <b>🏢 Firma</b><br />
          ARHAI S.R.L. · CUI RO35913161 · Oradea, România.<br />
          Date găzduite în UE · conform GDPR (<Link href="/confidentialitate">politica de confidențialitate</Link>).
        </div>
      </div>

      <p>
        <Link href="/demo" className="btn btn-primary">Vezi un demo pe afacerea ta</Link>{' '}
        <Link href="/preturi" className="btn btn-secondary" style={{ marginLeft: 8 }}>Vezi prețurile</Link>
      </p>
      <p style={{ color: 'var(--muted)', fontSize: 14, marginTop: 26 }}>
        Protecția consumatorilor: <a href="https://anpc.ro/ce-este-sal/" target="_blank" rel="noopener">ANPC — SAL</a> · <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener">SOL</a>
      </p>
    </main>
  );
}
