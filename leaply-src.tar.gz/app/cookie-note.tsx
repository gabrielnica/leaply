'use client';
import { useEffect, useState } from 'react';

// Notă discretă despre cookie-uri — folosim doar cookie-uri strict necesare,
// deci e informare, nu cerere de consimțământ.
export function CookieNote() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    try { if (!document.cookie.includes('leaply_cookie_ack=1')) setShow(true); } catch {}
  }, []);
  if (!show) return null;
  function ack() {
    document.cookie = 'leaply_cookie_ack=1; max-age=31536000; path=/; SameSite=Lax';
    setShow(false);
  }
  return (
    <div role="region" aria-label="Notă cookie-uri" style={{
      position: 'fixed', left: 16, right: 16, bottom: 16, zIndex: 90, margin: '0 auto', maxWidth: 620,
      background: '#101214', color: '#f2f0eb', borderRadius: 14, padding: '14px 18px',
      display: 'flex', gap: 14, alignItems: 'center', boxShadow: '0 12px 40px rgba(0,0,0,.28)', fontSize: 14,
    }}>
      <span style={{ flex: 1 }}>Folosim doar cookie-uri strict necesare (autentificare). Fără tracking, fără marketing. <a href="/cookies" style={{ color: '#FF8A65' }}>Detalii</a></span>
      <button onClick={ack} style={{ background: '#FF4D1F', color: '#fff', border: 0, borderRadius: 9, padding: '8px 16px', fontWeight: 600, cursor: 'pointer', fontSize: 14 }}>Am înțeles</button>
    </div>
  );
}
