'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';

type Msg = { sender: 'lead' | 'ai'; body: string };

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconBot = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13v1.5M15 13v1.5" /><circle cx="12" cy="3.5" r="1" />
  </svg>
);
const IconArrowLeft = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </svg>
);

export default function Demo() {
  const [history, setHistory] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [meta, setMeta] = useState<any>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => { boxRef.current?.scrollTo(0, boxRef.current.scrollHeight); }, [history, loading]);

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || loading) return;
    const h = [...history, { sender: 'lead' as const, body: msg }];
    setHistory(h); setInput(''); setLoading(true);
    try {
      const r = await fetch('/api/demo/message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ history: h }) });
      const d = await r.json();
      setHistory([...h, { sender: 'ai', body: d.reply }]);
      setMeta(d);
    } catch { setHistory([...h, { sender: 'ai', body: 'Eroare de conexiune.' }]); }
    setLoading(false);
  }

  const starters = ['Bună, aș dori o ofertă pentru termopane.', 'Cât costă geamuri pentru o casă cu 8 ferestre?', 'Aveți și uși de interior?'];
  const scoreColor: Record<string, string> = { hot: 'var(--ok)', warm: 'var(--warn)', cold: 'var(--bad)' };
  const scoreRo: Record<string, string> = { hot: 'Hot', warm: 'Warm', cold: 'Cold' };

  return (
    <div className="ap-demo">
      <div className="container">
        <nav className="ap-demo-nav">
          <Logo light />
          <Link href="/" className="btn btn-ghost-dark btn-sm"><IconArrowLeft /> Înapoi</Link>
        </nav>
      </div>
      <div className="container ap-demo-grid">
        <div className="ap-chat">
          <div className="ap-chat-head">
            <span className="ap-chat-ava"><IconBot /></span>
            <span>
              <b>Termopane Bihor</b>
              <small>asistent Leaply · răspunde instant</small>
            </span>
          </div>
          <div ref={boxRef} className="ap-chat-body">
            {history.length === 0 && (
              <div className="ap-chat-empty">Scrie ca un client real și vezi cum răspunde Leaply în sub o secundă.</div>
            )}
            {history.map((m, i) => (
              <div key={i} className={`bubble ${m.sender === 'lead' ? 'out' : 'in'}`}>{m.body}</div>
            ))}
            {loading && <div className="ap-typing">Leaply scrie…</div>}
          </div>
          <div className="ap-chat-foot">
            <input className="txt" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Scrie un mesaj ca un client…" />
            <button className="btn btn-primary" onClick={() => send()}>Trimite</button>
          </div>
        </div>
        <div>
          <div className="ap-demo-panel">
            <div className="ap-meta-label" style={{ color: 'var(--dark-muted)' }}>Ce vede owner-ul în timp real</div>
            {meta ? (
              <div style={{ marginTop: 12 }}>
                <div className="ap-demo-kv"><span className="ap-k">Timp de răspuns</span><span className="ap-v ap-v-accent">{(meta.latencyMs / 1000).toFixed(2)} sec</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Scor lead</span><span className="ap-v" style={{ color: scoreColor[meta.score] || 'var(--dark-text)' }}>{scoreRo[meta.score] || meta.score}</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Status</span><span className="ap-v">{meta.status}</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Motor</span><span className="ap-v">{meta.usedLLM ? 'LLM real' : 'creier RO (reguli)'}</span></div>
                {meta.qualification && Object.keys(meta.qualification).length > 0 && (
                  <div className="ap-demo-qual">
                    <div className="ap-meta-label" style={{ color: 'var(--dark-muted)', marginBottom: 8 }}>Calificare extrasă</div>
                    {Object.entries(meta.qualification).map(([k, v]: any) => (
                      <div key={k}><b>{k}:</b> {v}</div>
                    ))}
                  </div>
                )}
              </div>
            ) : <div className="ap-demo-hint">Trimite un mesaj ca să vezi calificarea în timp real.</div>}
          </div>
          <div className="ap-starters">
            <div className="ap-starters-label">Încearcă:</div>
            {starters.map((s, i) => <button key={i} className="ap-starter" onClick={() => send(s)}>{s}</button>)}
          </div>
        </div>
      </div>
    </div>
  );
}
