'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';

type Msg = { sender: 'lead' | 'ai'; body: string };
type Preview = { previewId: string; businessName: string; website: string; starters: string[] };

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconBot = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13v1.5M15 13v1.5" /><circle cx="12" cy="3.5" r="1" />
  </svg>
);
const IconArrowLeft = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </svg>
);
const IconArrowRight = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);

const DENTART_STARTERS = ['Bună, cât costă un implant dentar?', 'Aș vrea o programare la igienizare.', 'Mă doare o măsea — mă puteți primi urgent?'];

export default function Demo() {
  const [history, setHistory] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [meta, setMeta] = useState<any>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  /* demo personalizat fără cont: site → asistent efemer pe datele vizitatorului */
  const [site, setSite] = useState('');
  const [pv, setPv] = useState<Preview | null>(null);
  const [pvBusy, setPvBusy] = useState(false);
  const [pvErr, setPvErr] = useState<string | null>(null);

  useEffect(() => { boxRef.current?.scrollTo(0, boxRef.current.scrollHeight); }, [history, loading]);

  async function makePreview() {
    const w = site.trim();
    if (!w || pvBusy) return;
    setPvBusy(true); setPvErr(null);
    try {
      const r = await fetch('/api/demo/preview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ website: w }) });
      const d = await r.json();
      if (r.ok && d.ok) {
        setPv({ previewId: d.previewId, businessName: d.businessName, website: w, starters: d.starters || [] });
        setHistory([]); setMeta(null);
      } else setPvErr(d.error || 'Nu am putut citi site-ul. Verifică adresa.');
    } catch { setPvErr('Eroare de conexiune. Mai încearcă o dată.'); }
    setPvBusy(false);
  }

  function keepAssistant() {
    // handoff: wizard-ul primește site-ul + numele → auto-import la pasul 2
    try {
      sessionStorage.setItem('leaply_lead', JSON.stringify({ website: pv?.website || '', business: pv?.businessName || '' }));
    } catch {}
    window.location.href = '/start';
  }

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || loading) return;
    const h = [...history, { sender: 'lead' as const, body: msg }];
    setHistory(h); setInput(''); setLoading(true);
    try {
      const payload: any = pv ? { history: h, mode: 'preview', previewId: pv.previewId } : { history: h, mode: 'public' };
      const r = await fetch('/api/demo/message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const d = await r.json();
      setHistory([...h, { sender: 'ai', body: d.reply }]);
      setMeta(d);
    } catch { setHistory([...h, { sender: 'ai', body: 'Eroare de conexiune.' }]); }
    setLoading(false);
  }

  const starters = pv?.starters?.length ? pv.starters : DENTART_STARTERS;
  const scoreColor: Record<string, string> = { hot: 'var(--ok)', warm: 'var(--warn)', cold: 'var(--bad)' };
  const scoreRo: Record<string, string> = { hot: 'Hot', warm: 'Warm', cold: 'Cold' };

  return (
    <div className="ap-demo">
      <div className="container">
        <nav className="ap-demo-nav">
          <Logo light />
          <Link href="/" className="btn btn-ghost-dark btn-sm"><IconArrowLeft /> Înapoi</Link>
        </nav>
      </div>
      <div className="container">
        {!pv ? (
          <div className="wz-demo-cta" style={{ cursor: 'default' }}>
            <span className="wz-demo-cta-txt">
              <b>Vezi asistentul chiar pe afacerea TA — fără cont, în ~15 secunde</b>
              <span>Scrie site-ul firmei: îl citim cu AI și pornim asistentul pe serviciile și prețurile tale.</span>
              <span style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
                <input className="txt" style={{ maxWidth: 260 }} value={site} disabled={pvBusy}
                  onChange={e => setSite(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && makePreview()}
                  placeholder="site-ul-firmei.ro" inputMode="url" aria-label="Site-ul firmei tale" />
                <button className="btn btn-primary btn-sm" onClick={makePreview} disabled={pvBusy || !site.trim()}>
                  {pvBusy ? 'Citim site-ul… ~15s' : <>Pornește demo-ul meu <IconArrowRight /></>}
                </button>
              </span>
              {pvErr && <span style={{ color: 'var(--bad)', marginTop: 6 }}>{pvErr}</span>}
            </span>
          </div>
        ) : (
          <button type="button" className="wz-demo-cta" onClick={keepAssistant}>
            <span className="wz-demo-cta-txt">
              <b>Ți-a plăcut? Păstrează-ți asistentul — cont gratuit, 14 zile, fără card</b>
              <span>Totul e deja precompletat din site-ul tău: servicii, prețuri, cunoștințe. Doar îl activezi.</span>
            </span>
            <span className="btn btn-primary btn-sm">Păstrează asistentul <IconArrowRight /></span>
          </button>
        )}
      </div>
      <div className="container ap-demo-grid">
        <div className="ap-chat">
          <div className="ap-chat-head">
            <span className="ap-chat-ava"><IconBot /></span>
            <span>
              <b>{pv ? pv.businessName : 'DentArt Studio'}</b>
              <small>{pv ? 'asistentul TĂU · generat din site-ul tău · răspunde instant' : 'clinică demo · asistent Leaply · răspunde instant'}</small>
            </span>
          </div>
          <div ref={boxRef} className="ap-chat-body">
            {history.length === 0 && (
              <div className="ap-chat-empty">{pv ? `Scrie ca un client de-al tău și vezi cum răspunde asistentul pentru ${pv.businessName}.` : 'Scrie ca un client real și vezi cum răspunde Leaply în sub o secundă.'}</div>
            )}
            {history.map((m, i) => (
              <div key={i} className={`bubble ${m.sender === 'lead' ? 'out' : 'in'}`}>{m.body}</div>
            ))}
            {loading && <div className="ap-typing">Leaply scrie…</div>}
          </div>
          <div className="ap-chat-foot">
            <input className="txt" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Scrie un mesaj ca un client…" />
            <button className="btn btn-primary" onClick={() => send()}>Trimite</button>
          </div>
        </div>
        <div>
          <div className="ap-demo-panel">
            <div className="ap-meta-label" style={{ color: 'var(--dark-muted)' }}>Ce vede owner-ul în timp real</div>
            {meta ? (
              <div style={{ marginTop: 12 }}>
                <div className="ap-demo-kv"><span className="ap-k">Timp de răspuns</span><span className="ap-v ap-v-accent">{(meta.latencyMs / 1000).toFixed(2)} sec</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Scor lead</span><span className="ap-v" style={{ color: scoreColor[meta.score] || 'var(--dark-text)' }}>{scoreRo[meta.score] || meta.score}</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Status</span><span className="ap-v">{meta.status}</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Motor</span><span className="ap-v">{meta.usedLLM ? 'LLM real' : 'creier RO (reguli)'}</span></div>
                {meta.qualification && Object.keys(meta.qualification).length > 0 && (
                  <div className="ap-demo-qual">
                    <div className="ap-meta-label" style={{ color: 'var(--dark-muted)', marginBottom: 8 }}>Calificare extrasă</div>
                    {Object.entries(meta.qualification).map(([k, v]: any) => (
                      <div key={k}><b>{k}:</b> {v}</div>
                    ))}
                  </div>
                )}
              </div>
            ) : <div className="ap-demo-hint">Trimite un mesaj ca să vezi calificarea în timp real.</div>}
          </div>
          <div className="ap-starters">
            <div className="ap-starters-label">Încearcă:</div>
            {starters.map((s, i) => <button key={i} className="ap-starter" onClick={() => send(s)}>{s}</button>)}
          </div>
        </div>
      </div>
    </div>
  );
}
