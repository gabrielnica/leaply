'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';

type Msg = { sender: 'lead' | 'ai'; body: string };

export default function Demo() {
  const [history, setHistory] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [meta, setMeta] = useState<any>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => { boxRef.current?.scrollTo(0, boxRef.current.scrollHeight); }, [history, loading]);

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || loading) return;
    const h = [...history, { sender: 'lead' as const, body: msg }];
    setHistory(h); setInput(''); setLoading(true);
    try {
      const r = await fetch('/api/demo/message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ history: h }) });
      const d = await r.json();
      setHistory([...h, { sender: 'ai', body: d.reply }]);
      setMeta(d);
    } catch { setHistory([...h, { sender: 'ai', body: 'Eroare de conexiune.' }]); }
    setLoading(false);
  }

  const starters = ['Bună, aș dori o ofertă pentru termopane.', 'Cât costă geamuri pentru o casă cu 8 ferestre?', 'Aveți și uși de interior?'];
  const scoreColor: any = { hot: '#16A34A', warm: '#FFB020', cold: '#EF4444' };

  return (
    <div style={{ minHeight: '100vh', background: '#0B2A4A' }}>
      <div className="container" style={{ paddingTop: 18 }}>
        <nav className="nav"><Logo light /><Link href="/" className="btn btn-ghost btn-sm">← Înapoi</Link></nav>
      </div>
      <div className="container" style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 22, paddingBottom: 40, alignItems: 'start' }}>
        <div style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', display: 'flex', flexDirection: 'column', height: 560 }}>
          <div style={{ background: '#075E54', color: '#fff', padding: '14px 18px', fontWeight: 600 }}>
            Termopane Bihor · <span style={{ fontWeight: 400, opacity: .85 }}>asistent Leaply</span>
          </div>
          <div ref={boxRef} style={{ flex: 1, overflowY: 'auto', padding: 18, background: '#ECE5DD', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {history.length === 0 && <div style={{ color: '#667', textAlign: 'center', marginTop: 30, fontSize: 14 }}>Scrie ca un client real și vezi cum răspunde Leaply în sub o secundă 👇</div>}
            {history.map((m, i) => (
              <div key={i} style={{ alignSelf: m.sender === 'lead' ? 'flex-end' : 'flex-start', background: m.sender === 'lead' ? '#DCF8C6' : '#fff', padding: '9px 13px', borderRadius: 10, maxWidth: '78%', fontSize: 14.5, lineHeight: 1.45, boxShadow: '0 1px 1px rgba(0,0,0,.08)' }}>{m.body}</div>
            ))}
            {loading && <div style={{ alignSelf: 'flex-start', background: '#fff', padding: '9px 13px', borderRadius: 10, fontSize: 14, color: '#888' }}>Leaply scrie…</div>}
          </div>
          <div style={{ display: 'flex', gap: 8, padding: 12, borderTop: '1px solid #eee' }}>
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Scrie un mesaj ca un client…" style={{ flex: 1, border: '1px solid #ddd', borderRadius: 10, padding: '11px 14px', fontSize: 14, outline: 'none' }} />
            <button className="btn btn-primary" onClick={() => send()}>Trimite</button>
          </div>
        </div>
        <div>
          <div style={{ background: '#12385F', color: '#fff', borderRadius: 16, padding: 20 }}>
            <div style={{ fontSize: 13, color: '#9fb0c4', textTransform: 'uppercase', letterSpacing: '.06em', fontWeight: 700 }}>Ce vede owner-ul în timp real</div>
            {meta ? (
              <div style={{ marginTop: 14 }}>
                <Row l="Timp de răspuns" v={`${(meta.latencyMs/1000).toFixed(2)} sec`} lime />
                <Row l="Scor lead" v={<span style={{ color: scoreColor[meta.score], fontWeight: 700, textTransform: 'uppercase' }}>{meta.score}</span>} />
                <Row l="Status" v={meta.status} />
                <Row l="Motor" v={meta.usedLLM ? 'LLM real' : 'creier RO (reguli)'} />
                {meta.qualification && Object.keys(meta.qualification).length > 0 && (
                  <div style={{ marginTop: 12, borderTop: '1px solid #24486b', paddingTop: 12 }}>
                    <div style={{ fontSize: 12, color: '#9fb0c4', marginBottom: 6 }}>CALIFICARE EXTRASĂ</div>
                    {Object.entries(meta.qualification).map(([k, v]: any) => (
                      <div key={k} style={{ fontSize: 13, marginBottom: 4 }}><b style={{ color: '#C6F24E' }}>{k}:</b> {v}</div>
                    ))}
                  </div>
                )}
              </div>
            ) : <div style={{ color: '#9fb0c4', fontSize: 13, marginTop: 12 }}>Trimite un mesaj ca să vezi calificarea în timp real.</div>}
          </div>
          <div style={{ marginTop: 14 }}>
            <div style={{ color: '#9fb0c4', fontSize: 13, marginBottom: 8 }}>Încearcă:</div>
            {starters.map((s, i) => <button key={i} onClick={() => send(s)} style={{ display: 'block', width: '100%', textAlign: 'left', background: '#173d61', color: '#dbe6f2', border: '1px solid #24486b', borderRadius: 10, padding: '10px 12px', marginBottom: 8, cursor: 'pointer', fontSize: 13 }}>{s}</button>)}
          </div>
        </div>
      </div>
    </div>
  );
}

function Row({ l, v, lime }: any) {
  return <div style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '1px solid #1c4067' }}><span style={{ color: '#9fb0c4', fontSize: 13 }}>{l}</span><span style={{ fontWeight: 600, color: lime ? '#C6F24E' : '#fff', fontSize: 14 }}>{v}</span></div>;
}
