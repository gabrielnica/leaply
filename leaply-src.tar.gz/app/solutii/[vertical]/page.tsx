import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Logo } from '../../../lib/logo';

// Pagini de vertical pentru SEO — conținut dedicat per industrie, static la build.
const V: Record<string, {
  name: string; h1: string; meta: string; pains: string[]; wins: string[]; example: { q: string; a: string };
}> = {
  'termopane': {
    name: 'Termopane și tâmplărie PVC',
    h1: 'Asistent AI pentru firme de termopane',
    meta: 'Răspunde automat cererilor de oferte pentru termopane pe WhatsApp, Facebook și site, califică lead-urile și programează măsurători — în sub 60 de secunde, 24/7.',
    pains: ['Cererile de ofertă vin seara și în weekend, când echipa e pe teren', 'Lead-urile din Facebook Ads rămân fără răspuns ore întregi', 'Timpul se pierde cu curioși care „doar întreabă de preț"'],
    wins: ['Răspuns instant la fiecare cerere, inclusiv noaptea', 'Calificare automată: câte ferestre, ce termen, ce zonă', 'Programare de măsurătoare direct în calendarul tău'],
    example: { q: 'Bună, cât costă termopanele pentru un apartament cu 3 camere?', a: 'Bună ziua! Vă ajut imediat 😊 Aproximativ câte ferestre și uși ar fi de înlocuit? Vă pot programa și o măsurătoare gratuită, fără obligații.' },
  },
  'stomatologie': {
    name: 'Clinici stomatologice',
    h1: 'Asistent AI pentru clinici stomatologice',
    meta: 'Pacienții noi primesc răspuns instant pe WhatsApp și Instagram, sunt triați după urgență și primesc programare direct în calendarul clinicii.',
    pains: ['Recepția nu poate răspunde la telefoane și mesaje în același timp', 'Pacienții care nu primesc răspuns sună la clinica următoare', 'Programările prin telefon ocupă ore din ziua recepției'],
    wins: ['Triaj automat: urgență, consultație, igienizare, estetică', 'Programări direct în calendar, cu confirmare pe SMS', 'Reamintiri automate — mai puține neprezentări'],
    example: { q: 'Aveți loc pentru o urgență? Mă doare o măsea de azi-noapte.', a: 'Îmi pare rău să aud! Pentru urgențe avem locuri rezervate zilnic. Vă pot programa astăzi la 14:00 sau 17:30 — care vă convine?' },
  },
  'service-auto': {
    name: 'Service-uri auto',
    h1: 'Asistent AI pentru service-uri auto',
    meta: 'Programări la service fără telefoane pierdute: clienții scriu pe WhatsApp, AI-ul preia mașina, problema și programează intervenția.',
    pains: ['Mecanicii nu pot răspunde la telefon din atelier', 'Clienții sună pentru „cât costă" și blochează linia', 'Programările se suprapun sau se uită'],
    wins: ['Preluare automată: marcă, model, problemă, urgență', 'Programare în sloturile libere reale din calendar', 'Confirmare și reamintire pe SMS pentru fiecare client'],
    example: { q: 'Salut, îmi bate ceva la roata din față, aveți loc săptămâna asta?', a: 'Salut! Sigur — ce mașină e (marcă, model, an)? Avem loc joi la 10:00 sau vineri la 16:00 pentru verificare.' },
  },
  'imobiliare': {
    name: 'Agenții imobiliare',
    h1: 'Asistent AI pentru agenții imobiliare',
    meta: 'Fiecare lead de pe Imobiliare.ro, OLX sau Facebook primește răspuns în sub un minut, e calificat (buget, zonă, finanțare) și primește vizionare programată.',
    pains: ['Lead-urile de pe portaluri se răcesc în ore, nu în zile', 'Agenții pierd timp cu cereri fără buget real', 'Vizionările se programează greu, cu zeci de telefoane'],
    wins: ['Răspuns instant la fiecare cerere de pe orice canal', 'Calificare: buget, zonă, cash sau credit, termen', 'Vizionări programate direct în calendarul agentului'],
    example: { q: 'Mai e disponibil apartamentul de 2 camere din centru?', a: 'Bună ziua! Da, e disponibil 😊 Căutați pentru dumneavoastră sau ca investiție? Vă pot programa o vizionare chiar mâine.' },
  },
  'instalatii': {
    name: 'Instalatori și construcții',
    h1: 'Asistent AI pentru instalatori și firme de construcții',
    meta: 'Cererile de intervenții și oferte primesc răspuns automat, sunt triate după urgență și intră programate în calendarul echipei.',
    pains: ['Ești pe șantier — telefonul sună degeaba', 'Urgențele reale se amestecă cu cereri de ofertă generale', 'Seara ai 15 mesaje necitite și nu știi cu care începi'],
    wins: ['Fiecare cerere preluată și triată automat: urgență vs. ofertă', 'Detalii strânse din prima: ce problemă, unde, când', 'Programări și follow-up automat pentru cei care nu răspund'],
    example: { q: 'Îmi curge țeava sub chiuvetă, puteți veni azi?', a: 'Bună ziua! Da, la urgențe răspundem în aceeași zi. În ce zonă sunteți? Colegul poate ajunge azi între 15:00 și 17:00.' },
  },
  'saloane': {
    name: 'Saloane și beauty',
    h1: 'Asistent AI pentru saloane de înfrumusețare',
    meta: 'Programări automate pe Instagram și WhatsApp, non-stop: clientele primesc răspuns instant, aleg ora liberă și primesc reamintire.',
    pains: ['Mesajele pe Instagram se adună cât timp lucrezi', 'Programările prin DM iau zeci de mesaje dus-întors', 'Neprezentările strică ziua întreagă'],
    wins: ['Răspuns instant la DM-uri, chiar și cu mâinile ocupate', 'Programare în sloturile libere reale, fără dus-întors', 'Confirmări și reamintiri pe SMS — mai puține neprezentări'],
    example: { q: 'Bună! Aveți loc sâmbătă pentru vopsit + tuns?', a: 'Bună! 😊 Sâmbătă mai avem liber la 11:00 și la 15:30 (aprox. 3 ore pentru vopsit + tuns). Care oră vă convine?' },
  },
};

export function generateStaticParams() { return Object.keys(V).map(vertical => ({ vertical })); }
export function generateMetadata({ params }: { params: { vertical: string } }) {
  const v = V[params.vertical];
  if (!v) return {};
  return { title: `${v.h1} — Leaply`, description: v.meta };
}

export default function VerticalPage({ params }: { params: { vertical: string } }) {
  const v = V[params.vertical];
  if (!v) notFound();
  return (
    <main style={{ maxWidth: 860, margin: '0 auto', padding: '36px 20px 80px', lineHeight: 1.6 }}>
      <p><Link href="/">← leaply.ro</Link></p>
      <div style={{ margin: '10px 0' }}><Logo size={28} /></div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 38, lineHeight: 1.15, margin: '12px 0 10px' }}>{v.h1}</h1>
      <p style={{ fontSize: 18, color: 'var(--muted)', maxWidth: 640 }}>{v.meta}</p>
      <p style={{ margin: '22px 0 34px', display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <Link href={`/start?v=${params.vertical}`} className="btn btn-primary btn-lg">Încearcă gratuit</Link>
        <Link href="/demo" className="btn btn-secondary btn-lg">Vezi demo live</Link>
      </p>

      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, margin: '30px 0 10px' }}>Problema, pe scurt</h2>
      {v.pains.map((x, i) => <p key={i} style={{ margin: '6px 0' }}>✗ {x}</p>)}

      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, margin: '30px 0 10px' }}>Cu Leaply</h2>
      {v.wins.map((x, i) => <p key={i} style={{ margin: '6px 0' }}>✓ {x}</p>)}

      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, margin: '30px 0 12px' }}>Cum sună în practică</h2>
      <div style={{ background: '#101214', color: '#f2f0eb', borderRadius: 16, padding: '18px 20px', maxWidth: 560 }}>
        <p style={{ margin: '0 0 10px' }}><b style={{ opacity: .65 }}>Client:</b> {v.example.q}</p>
        <p style={{ margin: 0 }}><b style={{ color: '#FF8A65' }}>Leaply (AI):</b> {v.example.a}</p>
      </div>

      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, margin: '34px 0 8px' }}>Pornești în 10 minute</h2>
      <p>Îți creezi contul, dai CUI-ul (restul îl luăm de la ANAF), importăm serviciile de pe site-ul tău cu AI și conectezi WhatsApp / Facebook / Instagram / telefonul cu câte un click. Primele 30 de conversații sunt gratuite — fără card.</p>
      <p style={{ marginTop: 18 }}><Link href={`/start?v=${params.vertical}`} className="btn btn-primary btn-lg">Începe acum — gratuit</Link></p>
    </main>
  );
}
