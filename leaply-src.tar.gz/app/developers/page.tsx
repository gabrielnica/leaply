import Link from 'next/link';
import { Logo } from '../../lib/logo';

export const metadata = { title: 'Leaply API — documentație pentru dezvoltatori' };

const BASE = 'https://leaply.ro/api/v1';
function Code({ children }: { children: string }) {
  return <pre style={{ background: '#101214', color: '#e8e6e1', padding: '14px 16px', borderRadius: 12, overflowX: 'auto', fontSize: 13, lineHeight: 1.55 }}><code>{children}</code></pre>;
}
function H2({ children }: { children: React.ReactNode }) {
  return <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, margin: '36px 0 8px' }}>{children}</h2>;
}

export default function Developers() {
  return (
    <main style={{ maxWidth: 860, margin: '0 auto', padding: '40px 20px 80px' }}>
      <p><Link href="/">← leaply.ro</Link></p>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '8px 0 4px' }}><Logo size={30} /></div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 36, margin: '8px 0' }}>API pentru dezvoltatori</h1>
      <p style={{ color: 'var(--muted)', fontSize: 17 }}>
        Conectează Leaply la CRM-ul tău, la site, la Zapier/Make sau la orice altă platformă.
        API REST simplu, JSON, autentificat cu cheie per cont.
      </p>

      <H2>Autentificare</H2>
      <p>Generezi cheia din <b>Setări & Plan → API</b> (o vezi o singură dată — păstreaz-o în siguranță). O trimiți în header la fiecare request:</p>
      <Code>{`Authorization: Bearer lp_xxxxxxxxxxxxxxxx`}</Code>
      <p>Toate endpoint-urile au baza <code>{BASE}</code>. Răspunsurile sunt JSON; erorile au forma <code>{`{"error":"mesaj"}`}</code> cu status 4xx.</p>

      <H2>Lead-uri</H2>
      <p><b>POST /leads</b> — creezi un lead (ex. dintr-un formular propriu sau CRM). Leaply pornește conversația și îl califică automat.</p>
      <Code>{`curl -X POST ${BASE}/leads \\
  -H "Authorization: Bearer lp_..." -H "Content-Type: application/json" \\
  -d '{"name":"Ion Popescu","phone":"+40712345678","message":"Vreau o ofertă pentru termopane","source":"site-propriu","channel":"api"}'

// 201 → {"ok":true,"lead_id":"ld_...","conversation_id":"cv_..."}`}</Code>
      <p><b>GET /leads</b> — listă lead-uri, cele mai noi primele. Parametri: <code>score</code> (hot/warm/cold), <code>limit</code> (max 200), <code>offset</code>.</p>
      <Code>{`curl "${BASE}/leads?score=hot&limit=50" -H "Authorization: Bearer lp_..."

// {"data":[{"id":"ld_...","name":"Ion Popescu","phone":"+40712...","score":"hot",
//   "conversation_id":"cv_...","channel":"whatsapp","status":"booked",
//   "qualification":{"q1":"tripan","q2":"urgent","q3":"Oradea"},"created_at":"..."}], "limit":50,"offset":0}`}</Code>

      <H2>Conversații</H2>
      <p><b>GET /conversations</b> — filtre: <code>status</code> (active/qualified/booked/lost), <code>channel</code> (whatsapp/messenger/instagram/webform/voice/api), <code>limit</code>, <code>offset</code>.</p>
      <Code>{`curl "${BASE}/conversations?status=booked" -H "Authorization: Bearer lp_..."`}</Code>
      <p><b>GET /conversations/{'{id}'}</b> — conversația completă, cu toate mesajele (direcție, expeditor, text, timestamp).</p>
      <Code>{`curl ${BASE}/conversations/cv_abc123 -H "Authorization: Bearer lp_..."

// {"data":{"id":"cv_...","status":"booked","lead_name":"Ion Popescu",
//   "messages":[{"direction":"in","sender":"lead","body":"Bună ziua...","created_at":"..."}, ...]}}`}</Code>

      <H2>Mesaje</H2>
      <p><b>POST /messages</b> — trimiți un mesaj manual într-o conversație (de la un agent uman, din CRM-ul tău). Mesajul pleacă pe canalul original al lead-ului.</p>
      <Code>{`curl -X POST ${BASE}/messages \\
  -H "Authorization: Bearer lp_..." -H "Content-Type: application/json" \\
  -d '{"conversation_id":"cv_abc123","body":"Bună ziua! Sunt Andrei, colegul care vine la măsurătoare."}'

// {"ok":true,"delivered":true}`}</Code>

      <H2>Statistici</H2>
      <p><b>GET /stats</b> — KPI-urile contului: lead-uri, calificate, programări, timp mediu de răspuns, plan și utilizare lunară.</p>
      <Code>{`curl ${BASE}/stats -H "Authorization: Bearer lp_..."

// {"data":{"leads":124,"qualified":61,"booked":38,"avgSec":4,"savedLei":64050,
//   "plan":"Pro","usage_month":212,"usage_limit":1000}}`}</Code>

      <H2>Webhooks (Leaply → platforma ta)</H2>
      <p>Pe lângă API, Leaply poate <b>împinge evenimente</b> către un URL al tău (setat în <b>Setări & Plan → CRM / Webhook</b>), semnate HMAC-SHA256 în header-ul <code>X-Leaply-Signature</code>:</p>
      <Code>{`POST https://crm-ul-tau.ro/webhook
{"event":"lead.created","account_id":"acc_...","data":{"lead":{...},"conversation":{...}}}

// evenimente: lead.created (lead nou), lead.updated (mesaj nou / schimbare status, inclusiv qualified și booked), billing.upgraded`}</Code>
      <p>Verifici semnătura: <code>{`"sha256=" + hex(hmac_sha256(secret, raw_body)) === X-Leaply-Signature`}</code>.</p>

      <H2>Limite & bune practici</H2>
      <p>Max 200 de rezultate per pagină (folosește <code>offset</code>). Cheia se poate regenera oricând din Setări (cea veche moare instant). Pentru volume mari sau nevoi speciale: <a href="mailto:salut@leaply.ro">salut@leaply.ro</a>.</p>
    </main>
  );
}
