import { LegalShell } from '../legal-layout';
export const metadata = { title: 'Politica de cookies — Leaply' };

export default function Cookies() {
  return (
    <LegalShell title="Politica de cookies" updated="2 iulie 2026">
      <p><b>Vestea bună:</b> leaply.ro folosește doar cookie-uri strict necesare. Nu avem cookie-uri de marketing, tracking sau analytics de la terți.</p>
      <h2>Cookie-urile pe care le folosim</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 15 }}>
        <thead><tr><th style={{ textAlign: 'left', padding: 8, borderBottom: '1px solid #ddd' }}>Nume</th><th style={{ textAlign: 'left', padding: 8, borderBottom: '1px solid #ddd' }}>Scop</th><th style={{ textAlign: 'left', padding: 8, borderBottom: '1px solid #ddd' }}>Durată</th></tr></thead>
        <tbody>
          <tr><td style={{ padding: 8 }}><code>leaply_session</code></td><td style={{ padding: 8 }}>Te ține autentificat în cont (strict necesar)</td><td style={{ padding: 8 }}>30 de zile</td></tr>
          <tr><td style={{ padding: 8 }}><code>leaply_cookie_ack</code></td><td style={{ padding: 8 }}>Reține că ai văzut nota despre cookie-uri</td><td style={{ padding: 8 }}>12 luni</td></tr>
        </tbody>
      </table>
      <p style={{ marginTop: 16 }}>Cookie-urile strict necesare nu necesită consimțământ conform legislației (Directiva ePrivacy / Legea 506/2004). Dacă vom introduce vreodată cookie-uri opționale, îți vom cere acordul explicit înainte.</p>
      <p>Le poți șterge oricând din setările browserului — vei fi deconectat din cont.</p>
    </LegalShell>
  );
}
