import { redirect } from 'next/navigation';
import { getSessionUser } from '../../lib/auth';
import { getAccount } from '../../lib/store';
import { Sidebar } from './sidebar';
import { VerifyBanner } from './verify-banner';
import { AppAssistant } from './assistant';
import { LeadNotifier } from './lead-notifier';
import { CapacitorBridge } from './capacitor-bridge';
import { GlobalSearch } from './global-search';
import { trialDaysLeft } from '../../lib/plan';
import { db } from '../../lib/db';

export const dynamic = 'force-dynamic';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const user = getSessionUser();
  if (!user) redirect('/login?next=/app');
  const acc = getAccount(user.account_id);
  const verified = Boolean((db().prepare('SELECT email_verified v FROM users WHERE id=?').get(user.id) as any)?.v);
  const trialLeft = trialDaysLeft(user.account_id);
  const trialBanner = trialLeft === null ? null : trialLeft > 0 ? (
    <div className="ap-banner ap-trial ap-planbanner" role="status">
      Trial gratuit — mai ai <b>{trialLeft} {trialLeft === 1 ? 'zi' : 'zile'}</b>. Ca asistentul să răspundă și după, <a href="/app/settings">alege un plan</a>.
    </div>
  ) : (
    <div className="ap-banner is-err ap-planbanner" role="alert">
      Trialul a expirat — lead-urile intră în inbox, dar asistentul nu mai răspunde automat. <a href="/app/settings"><b>Alege un plan</b></a> și se reactivează instant.
    </div>
  );
  return (
    <div className="ap-shell">
      <Sidebar userName={user.name} businessName={acc?.name || ''} isAdmin={user.role === 'admin'} />
      <main className="ap-main">
        <div className="ap-content">{trialBanner}{!verified && <VerifyBanner />}{children}</div>
      </main>
      <AppAssistant proactive={(() => {
        try {
          const fresh = Date.now() - new Date((acc as any)?.created_at || 0).getTime() < 48 * 3600_000;
          if (!fresh) return false;
          const real = (db().prepare("SELECT COUNT(*) c FROM channels WHERE account_id=? AND status='connected' AND type != 'webform'").get(user.account_id) as any).c;
          return real === 0;
        } catch { return false; }
      })()} />
      <LeadNotifier />
      <GlobalSearch />
      <CapacitorBridge />
    </div>
  );
}
