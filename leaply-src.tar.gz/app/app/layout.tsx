import Link from 'next/link';
import { Logo } from '../../lib/logo';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="shell">
      <aside className="side">
        <div className="logo brandfont" style={{ color: '#fff' }}><Logo light size={26} /></div>
        <Link href="/app"><span>🏠</span><span>Overview</span></Link>
        <Link href="/app/inbox"><span>💬</span><span>Lead-uri / Inbox</span></Link>
        <Link href="/app/channels"><span>🔌</span><span>Canale</span></Link>
        <Link href="/app/config"><span>🧠</span><span>Configurare AI</span></Link>
        <Link href="/admin"><span>🛡️</span><span>Admin</span></Link>
        <div style={{ marginTop: 'auto', paddingTop: 20 }}>
          <Link href="/"><span>↩</span><span>Site public</span></Link>
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
