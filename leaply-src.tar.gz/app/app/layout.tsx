'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Logo } from '../../lib/logo';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconHome = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M3 10.5 12 3.5l9 7V20a1 1 0 0 1-1 1h-5.5v-6h-5v6H4a1 1 0 0 1-1-1z" />
  </svg>
);
const IconChat = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" />
  </svg>
);
const IconPlug = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M9 7V3M15 7V3M7 7h10v4a5 5 0 0 1-5 5 5 5 0 0 1-5-5zM12 16v5" />
  </svg>
);
const IconSparkles = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 4l1.8 4.7L18.5 10.5l-4.7 1.8L12 17l-1.8-4.7L5.5 10.5l4.7-1.8zM19 16l.9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9z" />
  </svg>
);
const IconShield = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 3l8 3v6c0 4.8-3.4 8-8 9-4.6-1-8-4.2-8-9V6z" />
  </svg>
);
const IconArrowLeft = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </svg>
);

type NavItem = { href: string; label: string; icon: React.ReactNode; exact?: boolean; also?: string };
const NAV: NavItem[] = [
  { href: '/app', label: 'Overview', icon: <IconHome />, exact: true },
  { href: '/app/inbox', label: 'Lead-uri / Inbox', icon: <IconChat />, also: '/app/conversation' },
  { href: '/app/channels', label: 'Canale', icon: <IconPlug /> },
  { href: '/app/config', label: 'Configurare AI', icon: <IconSparkles /> },
  { href: '/admin', label: 'Admin', icon: <IconShield /> },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isActive = (item: NavItem) => {
    if (item.exact) return pathname === item.href;
    if (item.also && pathname.startsWith(item.also)) return true;
    return pathname.startsWith(item.href);
  };
  return (
    <div className="ap-shell">
      <aside className="ap-side">
        <div className="ap-side-logo"><Logo light size={26} /></div>
        <nav className="ap-nav">
          {NAV.map(item => (
            <Link key={item.href} href={item.href} className={`ap-nav-link${isActive(item) ? ' is-active' : ''}`}>
              {item.icon}
              <span className="ap-nav-label">{item.label}</span>
            </Link>
          ))}
        </nav>
        <div className="ap-side-foot">
          <Link href="/" className="ap-nav-link">
            <IconArrowLeft />
            <span className="ap-nav-label">Site public</span>
          </Link>
        </div>
      </aside>
      <main className="ap-main">
        <div className="ap-content">{children}</div>
      </main>
    </div>
  );
}
