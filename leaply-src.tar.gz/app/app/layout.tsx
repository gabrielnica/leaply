import { redirect } from 'next/navigation';
import { getSessionUser } from '../../lib/auth';
import { getAccount } from '../../lib/store';
import { Sidebar } from './sidebar';
import { VerifyBanner } from './verify-banner';
import { db } from '../../lib/db';

export const dynamic = 'force-dynamic';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const user = getSessionUser();
  if (!user) redirect('/login?next=/app');
  const acc = getAccount(user.account_id);
  const verified = Boolean((db().prepare('SELECT email_verified v FROM users WHERE id=?').get(user.id) as any)?.v);
  return (
    <div className="ap-shell">
      <Sidebar userName={user.name} businessName={acc?.name || ''} isAdmin={user.role === 'admin'} />
      <main className="ap-main">
        <div className="ap-content">{!verified && <VerifyBanner />}{children}</div>
      </main>
    </div>
  );
}
