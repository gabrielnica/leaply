'use client';
import { useEffect, useRef, useState } from 'react';

// Notificare în-app: verifică periodic dacă a intrat un lead nou și afișează un toast.
// Nu depinde de push — merge oricând dashboard-ul e deschis (desktop sau mobil).
type Toast = { id: string; name: string; channel: string };
const CH_RO: Record<string, string> = {
  whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram', webform: 'Formular web',
  voice: 'Telefon', meta_lead_ads: 'Lead Ads', landing: 'Landing', import: 'Import', api: 'API',
};

export function LeadNotifier() {
  const lastId = useRef<string | null>(null);
  const primed = useRef(false);
  const [toast, setToast] = useState<Toast | null>(null);

  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const r = await fetch('/api/push/recent', { cache: 'no-store' });
        if (!r.ok) return;
        const j = await r.json();
        const latest = j?.latest;
        if (!latest) return;
        if (!primed.current) { lastId.current = latest.id; primed.current = true; return; }
        if (latest.id !== lastId.current) {
          lastId.current = latest.id;
          if (alive) setToast({ id: latest.id, name: latest.name || 'Lead', channel: latest.channel });
        }
      } catch {}
    };
    tick();
    const iv = setInterval(tick, 20000);
    const onVis = () => { if (document.visibilityState === 'visible') tick(); };
    document.addEventListener('visibilitychange', onVis);
    return () => { alive = false; clearInterval(iv); document.removeEventListener('visibilitychange', onVis); };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 9000);
    return () => clearTimeout(t);
  }, [toast]);

  if (!toast) return null;
  return (
    <a
      href={`/app/conversation/${toast.id}`}
      onClick={() => setToast(null)}
      style={{
        position: 'fixed', right: 20, bottom: 20, zIndex: 9999, maxWidth: 340,
        display: 'flex', gap: 12, alignItems: 'center', textDecoration: 'none',
        background: '#101214', color: '#fff', borderRadius: 14, padding: '14px 16px',
        boxShadow: '0 12px 40px rgba(0,0,0,.28)', animation: 'none',
      }}
      role="status"
    >
      <span style={{
        flex: '0 0 auto', width: 38, height: 38, borderRadius: 10, background: '#FF4D1F',
        display: 'grid', placeItems: 'center', fontSize: 20,
      }}>⚡</span>
      <span style={{ lineHeight: 1.35 }}>
        <b style={{ display: 'block', fontSize: 14 }}>Lead nou — {toast.name}</b>
        <span style={{ fontSize: 12.5, opacity: 0.8 }}>{CH_RO[toast.channel] || toast.channel} · atinge ca să deschizi</span>
      </span>
    </a>
  );
}
