'use client';
import { useState } from 'react';

// GDPR: ștergerea definitivă a conversației + datelor lead-ului (dreptul la ștergere).
export function GdprDelete({ convId }: { convId: string }) {
  const [busy, setBusy] = useState(false);
  async function del() {
    if (!confirm('Ștergi DEFINITIV această conversație și datele lead-ului (GDPR). Acțiunea nu se poate anula. Continui?')) return;
    setBusy(true);
    try {
      const r = await fetch('/api/conversation/gdpr', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: convId }) });
      if (r.ok) { window.location.href = '/app/inbox'; return; }
      alert('Nu am putut șterge. Mai încearcă o dată.');
    } catch { alert('Eroare de rețea.'); }
    setBusy(false);
  }
  return (
    <button className="btn btn-secondary btn-sm" style={{ color: 'var(--bad, #c0392b)' }} disabled={busy} onClick={del} title="Ștergere definitivă (GDPR art. 17)">
      🗑 Șterge lead (GDPR)
    </button>
  );
}
