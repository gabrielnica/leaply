'use client';
import { useState } from 'react';

const PRESETS = ['urgent', 'ofertă trimisă', 'de sunat', 'client vechi', 'VIP'];

// Etichete pe conversație — filtrabile din inbox.
export function TagEditor({ convId, initial }: { convId: string; initial: string[] }) {
  const [tags, setTags] = useState<string[]>(initial);
  const [input, setInput] = useState('');
  async function save(next: string[]) {
    setTags(next);
    try {
      await fetch('/api/conversation/tags', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ convId, tags: next }) });
    } catch { /* best-effort */ }
  }
  const toggle = (t: string) => save(tags.includes(t) ? tags.filter(x => x !== t) : [...tags, t].slice(0, 6));
  return (
    <div className="panel">
      <div className="ap-meta-label">Etichete</div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 8 }}>
        {[...new Set([...PRESETS, ...tags])].map(t => (
          <button key={t} type="button" className={`pill${tags.includes(t) ? ' pill-on' : ''}`} onClick={() => toggle(t)}>{t}</button>
        ))}
      </div>
      <form style={{ display: 'flex', gap: 6 }} onSubmit={e => { e.preventDefault(); const t = input.trim().toLowerCase().slice(0, 24); if (t && !tags.includes(t)) save([...tags, t].slice(0, 6)); setInput(''); }}>
        <input className="txt" style={{ flex: 1, padding: '6px 10px', fontSize: 13 }} placeholder="etichetă nouă…" value={input} onChange={e => setInput(e.target.value)} />
        <button className="btn btn-sm" type="submit">+</button>
      </form>
    </div>
  );
}
