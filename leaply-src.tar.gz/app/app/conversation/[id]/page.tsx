import Link from 'next/link';
import { getConversation } from '../../../../lib/store';
import { TakeOver } from './takeover';
export const dynamic = 'force-dynamic';

export default function ConversationPage({ params }: { params: { id: string } }) {
  const c = getConversation(params.id);
  if (!c) return <div><Link href="/app/inbox">← Inbox</Link><p>Conversație negăsită.</p></div>;
  return (
    <>
      <Link href="/app/inbox" style={{ color: '#1E5BFF', fontSize: 14 }}>← Inbox</Link>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20, marginTop: 12, alignItems: 'start' }}>
        <div className="panel">
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
            <b>{c.lead_name}</b><span className={`badge b-${c.status}`}>{c.status}</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {c.messages.map((m: any) => m.direction === 'note' ? (
              <div key={m.id} style={{ textAlign: 'center', fontSize: 12, color: '#94a3b8', margin: '8px 0' }}>{m.body}</div>
            ) : (
              <div key={m.id} className={`bubble ${m.direction === 'in' ? 'in' : 'out'}`}>
                {m.sender === 'ai' && <div style={{ fontSize: 11, opacity: .7, marginBottom: 2 }}>🤖 Leaply</div>}
                {m.body}
              </div>
            ))}
          </div>
          <TakeOver id={c.id} initialTaken={c.status === 'human'} />
        </div>
        <div>
          <div className="panel">
            <div style={{ fontSize: 12, color: '#64748b', fontWeight: 700, textTransform: 'uppercase' }}>Info lead</div>
            <div style={{ fontSize: 14, marginTop: 10, lineHeight: 1.9 }}>
              <div><b>Telefon:</b> {c.phone}</div>
              <div><b>Sursă:</b> {c.source}</div>
              <div><b>Canal:</b> {c.channel}</div>
              <div><b>Răspuns:</b> {Math.round((c.first_response_ms || 0) / 1000)}s</div>
            </div>
          </div>
          <div className="panel">
            <div style={{ fontSize: 12, color: '#64748b', fontWeight: 700, textTransform: 'uppercase' }}>Calificare</div>
            <div style={{ fontSize: 14, marginTop: 10, lineHeight: 1.9 }}>
              {Object.entries(c.qualification || {}).map(([k, v]: any) => <div key={k}><b>{k}:</b> {v}</div>)}
              {Object.keys(c.qualification || {}).length === 0 && <span style={{ color: '#94a3b8' }}>—</span>}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
