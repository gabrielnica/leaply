import Link from 'next/link';
import { getConversation, getAccount } from '../../../../lib/store';
import { getSessionUser } from '../../../../lib/auth';
import { db } from '../../../../lib/db';
import { TagEditor } from './tags';
import { TakeOver } from './takeover';
import { AiSummary } from './summary';
import { AssignSelect } from './assign';
import { MarkWon } from './mark-won';
import { RateMsg } from './rate-msg';
import { LiveRefresh } from './live-refresh';
import { ReplyBox } from './reply-box';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconArrowLeft = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </svg>
);
const IconBot = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13v1.5M15 13v1.5" /><circle cx="12" cy="3.5" r="1" />
  </svg>
);

const STATUS_RO: Record<string, string> = {
  active: 'Activ', human: 'Preluat', booked: 'Programat', qualified: 'Calificat', lost: 'Pierdut',
};
const fmtResp = (ms: number) => (!ms || ms < 1000) ? '<1s' : `${Math.round(ms / 1000)}s`;
const hhmm = (iso: string) => { try { return new Date(iso).toLocaleTimeString('ro-RO', { hour: '2-digit', minute: '2-digit' }); } catch { return ''; } };
const dayLabel = (iso: string) => {
  try {
    const d = new Date(iso); const today = new Date();
    const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
    if (same(d, today)) return 'Azi';
    if (same(d, new Date(Date.now() - 86400_000))) return 'Ieri';
    return d.toLocaleDateString('ro-RO', { day: 'numeric', month: 'long' });
  } catch { return ''; }
};

export default function ConversationPage({ params }: { params: { id: string } }) {
  const user = getSessionUser()!;
  let c = getConversation(params.id);
  if (c && c.account_id !== user.account_id && user.role !== 'admin') c = null;
  if (c && (c as any).unread) { try { db().prepare('UPDATE conversations SET unread = 0 WHERE id = ?').run(c.id); } catch { /* coloană nouă */ } }
  if (!c) {
    return (
      <div>
        <Link href="/app/inbox" className="ap-back"><IconArrowLeft /> Inbox</Link>
        <p className="ap-sub">Conversație negăsită.</p>
      </div>
    );
  }
  return (
    <>
      <Link href="/app/inbox" className="ap-back"><IconArrowLeft /> Inbox</Link>
      <div className="ap-cols">
        <div className="panel">
          <div className="ap-thread-head">
            <span className="ap-thread-name">{c.lead_name}</span>
            <span className={`badge b-${c.status}`}>{STATUS_RO[c.status] || c.status}</span>
          </div>
          <div className="ap-msgs">
            {c.messages.map((m: any, i: number) => {
              const prev = c.messages[i - 1];
              const sep = (!prev || String(prev.created_at).slice(0, 10) !== String(m.created_at).slice(0, 10))
                ? <div className="ap-day-sep"><span>{dayLabel(m.created_at)}</span></div> : null;
              if (m.direction === 'note') return <div key={m.id}>{sep}<div className="bubble-note">{m.body}</div></div>;
              return (
                <div key={m.id}>
                  {sep}
                  <div className={`bubble ${m.direction === 'in' ? 'in' : 'out'}`}>
                    {m.sender === 'ai' && <div className="ap-msg-tag"><IconBot /> Leaply <RateMsg msgId={m.id} initial={(m as any).rating ?? null} /></div>}
                    {m.sender === 'agent' && <div className="ap-msg-tag">✋ Tu</div>}
                    {m.body}
                    <span className="ap-msg-time">{hhmm(m.created_at)}</span>
                  </div>
                </div>
              );
            })}
          </div>
          <TakeOver id={c.id} initialTaken={c.status === 'human'} />
          <ReplyBox convId={c.id} channel={c.channel} quickReplies={(getAccount(user.account_id)?.config?.quickReplies || []).slice(0, 8)} />
          <LiveRefresh convId={c.id} />
        </div>
        <div>
          <div className="panel">
            <div className="ap-meta-label">Info lead</div>
            <div className="ap-meta-list">
              <div><b>Telefon:</b> {c.phone}</div>
              <div><b>Sursă:</b> {c.source}</div>
              <div><b>Canal:</b> {c.channel}</div>
              <div><b>Răspuns:</b> {fmtResp(c.first_response_ms)}</div>
            </div>
          </div>
          <TagEditor convId={c.id} initial={(() => { try { return JSON.parse((c as any).tags || '[]'); } catch { return []; } })()} />
          <MarkWon convId={c.id} initial={(c as any).won_value || null} />
          <AssignSelect convId={c.id} current={(c as any).assigned_to || null} />
          <AiSummary id={c.id} initial={(() => { try { return JSON.parse((c as any).summary || 'null')?.text || null; } catch { return null; } })()} />
          <div className="panel">
            <div className="ap-meta-label">Calificare</div>
            <div className="ap-meta-list">
              {Object.entries(c.qualification || {}).map(([k, v]: any) => <div key={k}><b>{k}:</b> {v}</div>)}
              {Object.keys(c.qualification || {}).length === 0 && <span className="muted">Nicio informație extrasă încă</span>}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
