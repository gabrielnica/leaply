import Link from 'next/link';
import { getConversation } from '../../../../lib/store';
import { getSessionUser } from '../../../../lib/auth';
import { TakeOver } from './takeover';
import { AiSummary } from './summary';
import { AssignSelect } from './assign';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconArrowLeft = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M19 12H5M11 6l-6 6 6 6" />
  </svg>
);
const IconBot = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13v1.5M15 13v1.5" /><circle cx="12" cy="3.5" r="1" />
  </svg>
);

const STATUS_RO: Record<string, string> = {
  active: 'Activ', human: 'Preluat', booked: 'Programat', qualified: 'Calificat', lost: 'Pierdut',
};
const fmtResp = (ms: number) => (!ms || ms < 1000) ? '<1s' : `${Math.round(ms / 1000)}s`;

export default function ConversationPage({ params }: { params: { id: string } }) {
  const user = getSessionUser()!;
  let c = getConversation(params.id);
  if (c && c.account_id !== user.account_id && user.role !== 'admin') c = null;
  if (!c) {
    return (
      <div>
        <Link href="/app/inbox" className="ap-back"><IconArrowLeft /> Inbox</Link>
        <p className="ap-sub">Conversație negăsită.</p>
      </div>
    );
  }
  return (
    <>
      <Link href="/app/inbox" className="ap-back"><IconArrowLeft /> Inbox</Link>
      <div className="ap-cols">
        <div className="panel">
          <div className="ap-thread-head">
            <span className="ap-thread-name">{c.lead_name}</span>
            <span className={`badge b-${c.status}`}>{STATUS_RO[c.status] || c.status}</span>
          </div>
          <div className="ap-msgs">
            {c.messages.map((m: any) => m.direction === 'note' ? (
              <div key={m.id} className="bubble-note">{m.body}</div>
            ) : (
              <div key={m.id} className={`bubble ${m.direction === 'in' ? 'in' : 'out'}`}>
                {m.sender === 'ai' && <div className="ap-msg-tag"><IconBot /> Leaply</div>}
                {m.body}
              </div>
            ))}
          </div>
          <TakeOver id={c.id} initialTaken={c.status === 'human'} />
        </div>
        <div>
          <div className="panel">
            <div className="ap-meta-label">Info lead</div>
            <div className="ap-meta-list">
              <div><b>Telefon:</b> {c.phone}</div>
              <div><b>Sursă:</b> {c.source}</div>
              <div><b>Canal:</b> {c.channel}</div>
              <div><b>Răspuns:</b> {fmtResp(c.first_response_ms)}</div>
            </div>
          </div>
          <AssignSelect convId={c.id} current={(c as any).assigned_to || null} />
          <AiSummary id={c.id} initial={(() => { try { return JSON.parse((c as any).summary || 'null')?.text || null; } catch { return null; } })()} />
          <div className="panel">
            <div className="ap-meta-label">Calificare</div>
            <div className="ap-meta-list">
              {Object.entries(c.qualification || {}).map(([k, v]: any) => <div key={k}><b>{k}:</b> {v}</div>)}
              {Object.keys(c.qualification || {}).length === 0 && <span className="muted">Nicio informație extrasă încă</span>}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
