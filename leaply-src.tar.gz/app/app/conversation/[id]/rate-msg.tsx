'use client';
import { useState } from 'react';

// 👍/👎 discret pe bulele AI — 👍 învață asistentul stilul preferat.
export function RateMsg({ msgId, initial }: { msgId: string; initial: number | null }) {
  const [rating, setRating] = useState<number | null>(initial);
  const send = async (r: number) => {
    const next = rating === r ? 0 : r; // click pe același = anulează
    setRating(next === 0 ? null : next);
    try {
      await fetch('/api/message/rate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: msgId, rating: next }) });
    } catch { /* best-effort */ }
  };
  return (
    <span className="ap-rate" aria-label="Evaluează răspunsul">
      <button type="button" className={`ap-rate-btn${rating === 1 ? ' is-on' : ''}`} title="Răspuns bun — asistentul învață din el" onClick={() => send(1)}>👍</button>
      <button type="button" className={`ap-rate-btn${rating === -1 ? ' is-on' : ''}`} title="Răspuns slab" onClick={() => send(-1)}>👎</button>
    </span>
  );
}
