'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

const CHANNEL_HINT: Record<string, string> = {
  whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram',
  voice: 'SMS', sms: 'SMS', webform: 'widgetul de pe site', meta_lead_ads: 'SMS',
};

// Răspuns manual, ca pe WhatsApp: mesajul pleacă pe canalul lead-ului.
export function ReplyBox({ convId, channel, quickReplies = [] }: { convId: string; channel: string; quickReplies?: string[] }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [sugBusy, setSugBusy] = useState(false);
  const [err, setErr] = useState('');
  const router = useRouter();
  async function suggest() {
    if (sugBusy) return;
    setSugBusy(true); setErr('');
    try {
      const r = await fetch('/api/conversation/suggest', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ convId }) });
      const d = await r.json();
      if (!r.ok) setErr(d.error || 'Nu am putut genera sugestia.');
      else setText(d.suggestion || '');
    } catch { setErr('Eroare de rețea.'); }
    setSugBusy(false);
  }
  async function send() {
    const t = text.trim();
    if (!t || busy) return;
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/conversation/reply', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ convId, text: t }),
      });
      const d = await r.json();
      if (!r.ok) setErr(d.error || 'Nu am putut trimite.');
      else { setText(''); router.refresh(); }
    } catch { setErr('Eroare de rețea.'); }
    setBusy(false);
  }
  return (
    <div className="ap-replybox">
      <textarea
        className="txt" rows={1} placeholder={`Scrie un răspuns (pleacă pe ${CHANNEL_HINT[channel] || channel})…`}
        value={text} onChange={e => setText(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
      />
      <button type="button" className="btn btn-secondary" disabled={sugBusy} onClick={suggest} title="AI-ul propune un răspuns; îl poți edita înainte de trimitere">
        {sugBusy ? '…' : '✨'}
      </button>
      <button className="btn btn-primary" disabled={busy || !text.trim()} onClick={send}>
        {busy ? '…' : 'Trimite'}
      </button>
      {err && <div className="ap-replyerr">{err}</div>}
      {quickReplies.length > 0 && (
        <div className="ap-quick" style={{ flexBasis: '100%' }}>
          {quickReplies.map(qr => (
            <button key={qr} type="button" onClick={() => setText(t => (t ? t + ' ' : '') + qr)} title="Adaugă în mesaj">{qr.slice(0, 42)}{qr.length > 42 ? '…' : ''}</button>
          ))}
        </div>
      )}
    </div>
  );
}
