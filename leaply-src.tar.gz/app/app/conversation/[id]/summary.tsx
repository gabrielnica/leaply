'use client';
import { useState } from 'react';

export function AiSummary({ id, initial }: { id: string; initial: string | null }) {
  const [text, setText] = useState<string | null>(initial);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function generate() {
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/conversation/summary', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }),
      });
      const j = await r.json();
      if (r.ok && j.summary) setText(j.summary);
      else setErr(j.error || 'Nu am putut genera rezumatul.');
    } catch { setErr('Eroare de conexiune.'); }
    setBusy(false);
  }
  return (
    <div className="panel">
      <div className="ap-meta-label">Rezumat AI</div>
      {text ? (
        <div className="ap-meta-list" style={{ whiteSpace: 'pre-wrap', fontSize: 13.5, lineHeight: 1.55 }}>{text}</div>
      ) : (
        <p className="muted" style={{ margin: '4px 0 10px', fontSize: 13.5 }}>Rezumatul conversației, de ce are scorul actual și pasul următor recomandat.</p>
      )}
      <button type="button" className="btn btn-secondary btn-sm" onClick={generate} disabled={busy} style={{ marginTop: 8 }}>
        {busy ? 'Se generează…' : text ? 'Actualizează rezumatul' : 'Generează rezumat'}
      </button>
      {err && <span className="ap-errmsg" role="alert" style={{ display: 'block', marginTop: 6 }}>{err}</span>}
    </div>
  );
}
