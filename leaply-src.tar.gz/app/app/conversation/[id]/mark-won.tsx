'use client';
import { useState } from 'react';

// Bucla de ROI: „Am câștigat clientul ăsta" + valoarea în lei.
export function MarkWon({ convId, initial }: { convId: string; initial: number | null }) {
  const [won, setWon] = useState<number | null>(initial);
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const save = async (v: number) => {
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/conversation/won', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: convId, value: v }) });
      const j = await r.json().catch(() => ({} as any));
      if (r.ok && j.ok) { setWon(j.won_value); setEditing(false); setValue(''); }
      else setErr(j.error || 'Eroare — mai încearcă.');
    } catch { setErr('Eroare de conexiune.'); }
    setBusy(false);
  };

  return (
    <div className="panel">
      <div className="ap-meta-label">Rezultat</div>
      {won ? (
        <div style={{ padding: '6px 0' }}>
          <p style={{ margin: '0 0 8px', fontWeight: 700, color: 'var(--ok, #1a7f37)' }}>🏆 Client câștigat — {won.toLocaleString('ro-RO')} lei</p>
          <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={() => save(0)}>Anulează marcajul</button>
        </div>
      ) : editing ? (
        <form style={{ display: 'flex', gap: 8, padding: '6px 0', flexWrap: 'wrap' }} onSubmit={e => { e.preventDefault(); const v = Math.round(Number(value)); if (v > 0) save(v); }}>
          <input className="txt" type="number" min={1} step={50} value={value} onChange={e => setValue(e.target.value)} placeholder="Valoare (lei)" autoFocus style={{ width: 140 }} />
          <button type="submit" className="btn btn-primary btn-sm" disabled={busy || !(Number(value) > 0)}>{busy ? 'Se salvează…' : 'Salvează'}</button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => setEditing(false)}>Renunță</button>
        </form>
      ) : (
        <div style={{ padding: '6px 0' }}>
          <p className="ap-sub" style={{ margin: '0 0 8px' }}>Ai închis vânzarea cu acest lead? Marcheaz-o — vezi în rapoarte exact câți bani ți-a adus Leaply.</p>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setEditing(true)}>💰 Marchează câștigat</button>
        </div>
      )}
      {err && <p className="ap-errmsg" role="alert">{err}</p>}
    </div>
  );
}
