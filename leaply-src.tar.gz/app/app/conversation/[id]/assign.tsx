'use client';
import { useEffect, useState } from 'react';

export function AssignSelect({ convId, current }: { convId: string; current: string | null }) {
  const [members, setMembers] = useState<{ id: string; name: string }[]>([]);
  const [val, setVal] = useState(current || '');
  const [msg, setMsg] = useState('');
  useEffect(() => { fetch('/api/team').then(r => r.json()).then(j => setMembers(j.members || [])).catch(() => {}); }, []);
  async function apply(v: string) {
    setVal(v); setMsg('…');
    const r = await fetch('/api/conversation/assign', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: convId, user_id: v || null }),
    });
    setMsg(r.ok ? 'Salvat ✓' : 'Eroare');
  }
  return (
    <div className="panel">
      <div className="ap-meta-label">Responsabil</div>
      <select className="txt" value={val} onChange={e => apply(e.target.value)} aria-label="Asignează conversația">
        <option value="">Neasignat</option>
        {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
      </select>
      {msg && <span className="ap-savedmsg" style={{ marginLeft: 8 }}>{msg}</span>}
    </div>
  );
}
