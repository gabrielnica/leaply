'use client';
import { useState } from 'react';
export function TakeOver({ id, initialTaken = false }: { id: string; initialTaken?: boolean }) {
  const [taken, setTaken] = useState(initialTaken);
  const [busy, setBusy] = useState(false);
  const call = async (action: 'take' | 'release') => {
    setBusy(true);
    try {
      await fetch(`/api/conversation/${id}/takeover`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      setTaken(action === 'take');
    } catch {}
    setBusy(false);
  };
  return (
    <div style={{ marginTop: 16, borderTop: '1px solid #E4EAF2', paddingTop: 14 }}>
      {taken ? (
        <div style={{ background: '#fef3c7', color: '#92620a', padding: '10px 14px', borderRadius: 10, fontSize: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>✋ Ai preluat conversația — asistentul nu mai răspunde aici.</span>
          <button className="btn btn-sm btn-dark" disabled={busy} onClick={() => call('release')}>Redă asistentului</button>
        </div>
      ) : (
        <button className="btn btn-primary" disabled={busy} onClick={() => call('take')}>✋ Preiau eu conversația</button>
      )}
    </div>
  );
}
