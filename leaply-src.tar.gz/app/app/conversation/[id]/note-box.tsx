'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

// Notă internă — o vede doar echipa, în firul conversației (cu 📌), nu și lead-ul.
export function NoteBox({ convId }: { convId: string }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function save() {
    const t = text.trim();
    if (!t || busy) return;
    setBusy(true);
    try {
      const r = await fetch('/api/conversation/note', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ convId, text: t }) });
      if (r.ok) { setText(''); router.refresh(); }
    } catch { /* best-effort */ }
    setBusy(false);
  }
  return (
    <div className="panel">
      <div className="ap-meta-label">Notă internă <span className="muted" style={{ fontWeight: 400 }}>(doar echipa o vede)</span></div>
      <form style={{ display: 'flex', gap: 6 }} onSubmit={e => { e.preventDefault(); save(); }}>
        <input className="txt" style={{ flex: 1, padding: '6px 10px', fontSize: 13 }} placeholder="ex. a cerut factură pe firmă…" value={text} onChange={e => setText(e.target.value)} />
        <button className="btn btn-sm" type="submit" disabled={busy || !text.trim()}>📌</button>
      </form>
    </div>
  );
}
