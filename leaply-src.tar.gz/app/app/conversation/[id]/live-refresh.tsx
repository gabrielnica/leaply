'use client';
import { useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';

// Real-time: ascultă SSE-ul contului și reîncarcă conversația când apare un mesaj nou.
// Fallback: dacă SSE cade (proxy, mobil), poll la 15s.
export function LiveRefresh({ convId }: { convId?: string }) {
  const router = useRouter();
  const last = useRef(0);
  useEffect(() => {
    const refresh = () => {
      const now = Date.now();
      if (now - last.current < 800) return; // debounce
      last.current = now;
      router.refresh();
    };
    let es: EventSource | null = null;
    let poll: any = null;
    try {
      es = new EventSource('/api/events');
      es.onmessage = e => {
        try {
          const ev = JSON.parse(e.data);
          if (ev.type === 'message' && (!ev.convId || ev.convId === convId)) refresh();
        } catch { /* ignor */ }
      };
      es.onerror = () => { if (!poll) poll = setInterval(refresh, 15_000); };
    } catch { poll = setInterval(refresh, 15_000); }
    return () => { es?.close(); if (poll) clearInterval(poll); };
  }, [convId, router]);
  return null;
}
