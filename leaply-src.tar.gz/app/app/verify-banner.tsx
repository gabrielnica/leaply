'use client';
import { useEffect, useState } from 'react';

const KEY = 'leaply_verify_snooze';

export function VerifyBanner() {
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [hidden, setHidden] = useState(true); // pornim ascuns ca să nu clipească
  useEffect(() => {
    try {
      const until = Number(localStorage.getItem(KEY) || 0);
      setHidden(Date.now() < until);
    } catch { setHidden(false); }
  }, []);
  if (hidden) return null;
  function snooze() {
    try { localStorage.setItem(KEY, String(Date.now() + 7 * 86400000)); } catch { /* private mode */ }
    setHidden(true);
  }
  async function resend() {
    setBusy(true);
    const r = await fetch('/api/auth/resend-verify', { method: 'POST' });
    setBusy(false);
    if (r.ok) setSent(true);
  }
  return (
    <div className="ap-banner" role="status" style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
      <span style={{ flex: 1 }}>📬 <b>Confirmă-ți adresa de email</b> — ți-am trimis un link la înregistrare. Așa ne asigurăm că primești notificările despre lead-uri.</span>
      {sent
        ? <span className="ap-okmsg">Trimis! Verifică inboxul (și spamul).</span>
        : <button type="button" className="btn btn-secondary btn-sm" onClick={resend} disabled={busy}>{busy ? 'Se trimite…' : 'Retrimite linkul'}</button>}
      <button type="button" className="btn btn-secondary btn-sm" onClick={snooze} aria-label="Ascunde 7 zile">×</button>
    </div>
  );
}
