'use client';
import { useState } from 'react';

export function VerifyBanner() {
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [hidden, setHidden] = useState(false);
  if (hidden) return null;
  async function resend() {
    setBusy(true);
    const r = await fetch('/api/auth/resend-verify', { method: 'POST' });
    setBusy(false);
    if (r.ok) setSent(true);
  }
  return (
    <div className="ap-banner" role="status" style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
      <span style={{ flex: 1 }}>📬 <b>Confirmă-ți adresa de email</b> — ți-am trimis un link la înregistrare. Așa ne asigurăm că primești notificările despre lead-uri.</span>
      {sent
        ? <span className="ap-okmsg">Trimis! Verifică inboxul (și spamul).</span>
        : <button type="button" className="btn btn-secondary btn-sm" onClick={resend} disabled={busy}>{busy ? 'Se trimite…' : 'Retrimite linkul'}</button>}
      <button type="button" className="btn btn-secondary btn-sm" onClick={() => setHidden(true)} aria-label="Ascunde">×</button>
    </div>
  );
}
