'use client';
import { useEffect } from 'react';

// Punte pentru aplicația mobilă nativă (Capacitor). No-op în browser normal.
// Rulează în contextul nativ, unde Capacitor injectează window.Capacitor.Plugins.
// La login, cere permisiunea de push, obține tokenul FCM și îl trimite la server.
export function CapacitorBridge() {
  useEffect(() => {
    const w = window as any;
    const Cap = w.Capacitor;
    if (!Cap || typeof Cap.isNativePlatform !== 'function' || !Cap.isNativePlatform()) return;
    const Push = Cap.Plugins?.PushNotifications;
    const App = Cap.Plugins?.App;
    if (!Push) return;
    const platform = Cap.getPlatform ? Cap.getPlatform() : 'unknown';

    (async () => {
      try {
        let perm = await Push.checkPermissions();
        if (perm.receive === 'prompt') perm = await Push.requestPermissions();
        if (perm.receive !== 'granted') return;
        await Push.register();
      } catch {}
    })();

    const regHandle = Push.addListener('registration', async (t: any) => {
      const token = t?.value;
      if (!token) return;
      try {
        await fetch('/api/push/register', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ platform, token }),
        });
      } catch {}
    });

    const tapHandle = Push.addListener('pushNotificationActionPerformed', (action: any) => {
      const url = action?.notification?.data?.url;
      if (url) { try { window.location.href = url; } catch {} }
    });

    return () => {
      try { regHandle?.remove?.(); tapHandle?.remove?.(); } catch {}
    };
  }, []);

  return null;
}
