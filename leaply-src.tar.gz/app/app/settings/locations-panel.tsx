'use client';
import { useEffect, useState } from 'react';

type Loc = { id: string; name: string; primary: boolean; active: boolean };

// Multi-locație (pachetul Total): listă, comutare și adăugare locații.
export function LocationsPanel() {
  const [data, setData] = useState<{ locations: Loc[]; canManage: boolean; maxLocations: number } | null>(null);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState('');
  const [err, setErr] = useState('');

  const load = () => fetch('/api/locations').then(r => r.json()).then(setData).catch(() => {});
  useEffect(() => { load(); }, []);

  if (!data) return null;
  const { locations, canManage, maxLocations } = data;
  // panoul apare doar dacă are voie să gestioneze locații SAU are deja mai multe
  if (!canManage && locations.length <= 1) return null;

  const post = async (body: any) => {
    setErr('');
    try {
      const r = await fetch('/api/locations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const j = await r.json().catch(() => ({} as any));
      if (!r.ok || j.error) { setErr(j.error || 'Eroare — mai încearcă o dată.'); return false; }
      return true;
    } catch { setErr('Eroare de conexiune.'); return false; }
  };

  const switchTo = async (id: string) => {
    setBusy(id);
    if (await post({ action: 'switch', account_id: id })) window.location.reload();
    else setBusy('');
  };

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy('create');
    if (await post({ action: 'create', name: name.trim() })) { setName(''); load(); }
    setBusy('');
  };

  return (
    <div className="panel">
      <div className="ap-panel-head">
        <span className="ap-panel-title">Locațiile tale ({locations.length}/{maxLocations})</span>
      </div>
      <p className="ap-form-p">Fiecare locație are propriul inbox, propriile canale și propria configurare AI — sub același abonament. Comută oricând între ele.</p>
      {locations.map(l => (
        <div key={l.id} className="row">
          <span className="ap-lead">
            <span className="ap-lead-name">{l.name} {l.primary && <span className="pill">sediu principal</span>}</span>
          </span>
          {l.active
            ? <span className="connected">Activă acum</span>
            : <button type="button" className="btn btn-secondary btn-sm" disabled={!!busy} onClick={() => switchTo(l.id)}>{busy === l.id ? 'Se comută…' : 'Comută aici'}</button>}
        </div>
      ))}
      {canManage && locations.length < maxLocations && (
        <form onSubmit={create} style={{ display: 'flex', gap: 8, padding: '10px 4px', flexWrap: 'wrap' }}>
          <input className="txt" value={name} onChange={e => setName(e.target.value)} placeholder="Numele locației noi — ex. Sediul Cluj" style={{ flex: 1, minWidth: 220 }} maxLength={120} />
          <button type="submit" className="btn btn-primary btn-sm" disabled={busy === 'create' || !name.trim()}>{busy === 'create' ? 'Se creează…' : 'Adaugă locația'}</button>
        </form>
      )}
      {err && <p className="ap-errmsg" role="alert" style={{ margin: '0 4px 10px' }}>{err}</p>}
    </div>
  );
}
