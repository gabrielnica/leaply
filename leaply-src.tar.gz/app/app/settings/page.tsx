'use client';
import { useCallback, useEffect, useState } from 'react';

/* ---------- icons (stroke 1.75, currentColor) ---------- */
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconCheck = ({ size = 15 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="m4.5 12.5 5 5 10-11" /></svg>
);
const IconCard = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><rect x="2.5" y="5" width="19" height="14" rx="2.5" /><path d="M2.5 10h19M6.5 14.5h4" /></svg>
);
const IconBell = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M18 9a6 6 0 1 0-12 0c0 5-2 6-2 6h16s-2-1-2-6M10.3 19.5a2 2 0 0 0 3.4 0" /></svg>
);
const IconLink = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M10 13.5a4 4 0 0 0 6 .5l3-3a4 4 0 1 0-5.7-5.7l-1.5 1.5" /><path d="M14 10.5a4 4 0 0 0-6-.5l-3 3a4 4 0 1 0 5.7 5.7l1.5-1.5" /></svg>
);
const IconCalendar = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" /></svg>
);
const IconReply = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M9 14 4 9l5-5" /><path d="M4 9h10.5A5.5 5.5 0 0 1 20 14.5V20" /></svg>
);
const IconInvoice = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" /><path d="M14 3v5h5M9 13h6M9 17h4" /></svg>
);

/* ---------- types ---------- */
type Integrations = {
  plan: string;
  google: { configured: boolean; connected: boolean; email: string };
  webhookOut: { url: string; hasSecret: boolean };
  notify: { email: boolean };
  stripe: { configured: boolean };
  usage?: { used: number; limit: number };
  followup?: { enabled: boolean; hours: number; text: string };
  billing?: { company: string; cif: string; address: string; city: string; email: string };
};

const FU_HOURS = [2, 4, 8, 24];

const PLANS = [
  { name: 'Start', price: 59, feats: ['WhatsApp + chat web', '300 conversații/lună', 'Răspuns + calificare', 'Google Calendar'] },
  { name: 'Pro', price: 129, hot: true, feats: ['+ Facebook & Instagram DM', '1.000 conversații/lună', 'Booking automat în calendar', 'Integrare CRM + Meta Ads'] },
  { name: 'Scale', price: 299, feats: ['Toate canalele + SMS', '3.000 conversații/lună', 'Până la 5 locații', 'Account manager dedicat'] },
] as const;

async function postJSON(url: string, body: unknown) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  let j: any = null;
  try { j = await r.json(); } catch { /* ignore */ }
  if (!r.ok || !j || j.error) throw new Error((j && j.error) || 'Ceva nu a mers. Încearcă din nou.');
  return j;
}

export default function Settings() {
  const [integ, setInteg] = useState<Integrations | null>(null);
  const [loadErr, setLoadErr] = useState('');
  const [banner, setBanner] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  // plan
  const [planBusy, setPlanBusy] = useState<string | null>(null);
  const [planErr, setPlanErr] = useState('');
  // notificări
  const [notifyBusy, setNotifyBusy] = useState(false);
  const [notifyErr, setNotifyErr] = useState('');
  // webhook CRM
  const [whUrl, setWhUrl] = useState('');
  const [whSecret, setWhSecret] = useState('');
  const [whBusy, setWhBusy] = useState(false);
  const [whMsg, setWhMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  // google
  const [gBusy, setGBusy] = useState(false);
  const [gConfirm, setGConfirm] = useState(false);
  const [gErr, setGErr] = useState('');
  // follow-up automat
  const [fuEnabled, setFuEnabled] = useState(true);
  const [fuHours, setFuHours] = useState(4);
  const [fuText, setFuText] = useState('');
  const [fuBusy, setFuBusy] = useState(false);
  const [fuMsg, setFuMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  // date de facturare
  const [bill, setBill] = useState({ company: '', cif: '', address: '', city: '', email: '' });
  const [billBusy, setBillBusy] = useState(false);
  const [billMsg, setBillMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoadErr('');
    try {
      const r = await fetch('/api/integrations');
      const j = await r.json();
      setInteg(j);
      setWhUrl(j?.webhookOut?.url || '');
      if (j?.followup) {
        setFuEnabled(j.followup.enabled !== false);
        setFuHours(FU_HOURS.includes(Number(j.followup.hours)) ? Number(j.followup.hours) : 4);
        setFuText(j.followup.text || '');
      }
      if (j?.billing) {
        setBill(b => ({
          company: j.billing.company || b.company,
          cif: j.billing.cif || b.cif,
          address: j.billing.address || b.address,
          city: j.billing.city || b.city,
          email: j.billing.email || b.email,
        }));
      }
    } catch {
      setLoadErr('Nu am putut încărca setările. Reîmprospătează pagina.');
    }
  }, []);

  useEffect(() => {
    load();
    const q = new URLSearchParams(window.location.search);
    if (q.get('billing') === 'success') setBanner({ kind: 'ok', text: 'Plata a fost înregistrată — planul tău se activează în câteva momente.' });
    const g = q.get('google');
    if (g === 'connected') setBanner({ kind: 'ok', text: 'Google Calendar a fost conectat.' });
    else if (g === 'error') setBanner({ kind: 'err', text: 'Conectarea Google a eșuat. Încearcă din nou.' });
    else if (g === 'unconfigured') setBanner({ kind: 'err', text: 'Integrarea Google nu e configurată încă pe server.' });
    if (q.get('billing') || g) window.history.replaceState(null, '', '/app/settings');
  }, [load]);

  const checkout = async (plan: string) => {
    setPlanErr('');
    setPlanBusy(plan);
    try {
      const j = await postJSON('/api/billing/checkout', { plan });
      if (j.url) { window.location.href = j.url; return; }
      throw new Error('Nu am primit link-ul de plată. Încearcă din nou.');
    } catch (ex: any) {
      setPlanErr(ex.message);
      setPlanBusy(null);
    }
  };

  const toggleNotify = async () => {
    if (!integ || notifyBusy) return;
    const next = !integ.notify.email;
    setNotifyErr('');
    setNotifyBusy(true);
    setInteg({ ...integ, notify: { email: next } });
    try {
      await postJSON('/api/integrations', { action: 'notify', email: next });
    } catch (ex: any) {
      setInteg(i => (i ? { ...i, notify: { email: !next } } : i));
      setNotifyErr(ex.message);
    }
    setNotifyBusy(false);
  };

  const saveWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    setWhMsg(null);
    const url = whUrl.trim();
    if (url && !/^https:\/\/.+/.test(url)) {
      setWhMsg({ kind: 'err', text: 'URL-ul trebuie să înceapă cu https://' });
      return;
    }
    setWhBusy(true);
    try {
      const body: any = { action: 'webhook_out', url };
      if (whSecret.trim()) body.secret = whSecret.trim();
      await postJSON('/api/integrations', body);
      setWhMsg({ kind: 'ok', text: 'Webhook salvat.' });
      setWhSecret('');
      load();
    } catch (ex: any) {
      setWhMsg({ kind: 'err', text: ex.message });
    }
    setWhBusy(false);
  };

  const saveFollowup = async (e: React.FormEvent) => {
    e.preventDefault();
    setFuMsg(null);
    setFuBusy(true);
    try {
      await postJSON('/api/integrations', { action: 'followup', enabled: fuEnabled, hours: fuHours, text: fuText.trim() });
      setFuMsg({ kind: 'ok', text: 'Follow-up salvat.' });
    } catch (ex: any) {
      setFuMsg({ kind: 'err', text: ex.message });
    }
    setFuBusy(false);
  };

  const setBillField = (k: keyof typeof bill) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setBill(b => ({ ...b, [k]: e.target.value }));

  const saveBilling = async (e: React.FormEvent) => {
    e.preventDefault();
    setBillMsg(null);
    const email = bill.email.trim();
    if (email && !/^\S+@\S+\.\S+$/.test(email)) {
      setBillMsg({ kind: 'err', text: 'Emailul de facturare nu pare valid.' });
      return;
    }
    setBillBusy(true);
    try {
      await postJSON('/api/integrations', {
        action: 'billing',
        company: bill.company.trim(),
        cif: bill.cif.trim(),
        address: bill.address.trim(),
        city: bill.city.trim(),
        email,
      });
      setBillMsg({ kind: 'ok', text: 'Datele de facturare au fost salvate.' });
    } catch (ex: any) {
      setBillMsg({ kind: 'err', text: ex.message });
    }
    setBillBusy(false);
  };

  const googleDisconnect = async () => {
    setGBusy(true);
    setGErr('');
    try {
      await postJSON('/api/integrations', { action: 'google_disconnect' });
      setGConfirm(false);
      setBanner({ kind: 'ok', text: 'Google Calendar a fost deconectat.' });
      load();
    } catch (ex: any) {
      setGErr(ex.message);
    }
    setGBusy(false);
  };

  const currentPlan = integ?.plan || '';
  const usage = integ?.usage && integ.usage.limit > 0 ? integ.usage : null;
  const usagePct = usage ? Math.min(100, Math.round((usage.used / usage.limit) * 100)) : 0;
  const usageHot = usage ? usage.used / usage.limit >= 0.9 : false;

  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Setări & Plan</h1>
          <p className="ap-sub">Abonament, notificări și integrări pentru contul tău</p>
        </div>
      </div>

      {banner && <div className={`ap-banner${banner.kind === 'err' ? ' is-err' : ''}`} role="status">{banner.text}</div>}
      {loadErr && <div className="ap-banner is-err" role="alert">{loadErr}</div>}

      {/* ---------- planul tău ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconCard /> Planul tău</span>
          {integ && <span className="pill">Plan curent: {currentPlan || 'Trial'}</span>}
        </div>
        {usage && (
          <div className="ap-usage">
            <div className="ap-usage-head">
              <b>Utilizare luna aceasta</b>
              <span>{usage.used} din {usage.limit} conversații incluse</span>
            </div>
            <div className="ap-usage-bar" role="progressbar" aria-valuenow={usage.used} aria-valuemin={0} aria-valuemax={usage.limit} aria-label="Conversații folosite luna aceasta">
              <div className={`ap-usage-fill${usageHot ? ' is-hot' : ''}`} style={{ width: `${usagePct}%` }} />
            </div>
            {usage.used >= usage.limit && (
              <div className="ap-banner is-err ap-usage-warn" role="alert">
                Ai atins limita — asistentul nu mai răspunde automat la lead-uri noi. Treci pe un plan mai mare.
              </div>
            )}
          </div>
        )}
        <div className="ap-plans">
          {PLANS.map(p => {
            const isCurrent = currentPlan.toLowerCase() === p.name.toLowerCase();
            return (
              <div key={p.name} className={`ap-plan${isCurrent ? ' is-current' : ''}`}>
                <div className="ap-plan-name">
                  {p.name}
                  {isCurrent && <span className="badge b-active">Activ</span>}
                  {!isCurrent && 'hot' in p && p.hot ? <span className="badge b-warm">Popular</span> : null}
                </div>
                <div className="ap-plan-price">{p.price}€<span className="ap-plan-per">/lună</span></div>
                <ul className="ap-plan-feats">
                  {p.feats.map(f => <li key={f}><IconCheck /> {f}</li>)}
                </ul>
                {isCurrent ? (
                  <button type="button" className="btn btn-secondary btn-sm" disabled>Planul curent</button>
                ) : (
                  <button type="button" className="btn btn-primary btn-sm" disabled={planBusy !== null} onClick={() => checkout(p.name)}>
                    {planBusy === p.name ? 'Se deschide plata…' : `Treci pe ${p.name}`}
                  </button>
                )}
              </div>
            );
          })}
        </div>
        {planErr && <p className="ap-errmsg ap-plan-err" role="alert">{planErr}</p>}
        <p className="ap-fhint">Plata e procesată securizat prin Stripe. Poți anula oricând, fără contract pe termen lung.</p>
      </div>

      {/* ---------- date de facturare ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconInvoice /> Date de facturare</span>
        </div>
        <p className="ap-form-p">Completează datele firmei tale — factura SmartBill se emite și se trimite automat la fiecare plată.</p>
        <form onSubmit={saveBilling}>
          <div className="ap-bill-grid">
            <div>
              <label className="fld" htmlFor="bill-company">Firmă</label>
              <input id="bill-company" className="txt" type="text" autoComplete="organization" placeholder="ex. Termopan Expert SRL" value={bill.company} onChange={setBillField('company')} />
            </div>
            <div>
              <label className="fld" htmlFor="bill-cif">CIF</label>
              <input id="bill-cif" className="txt" type="text" placeholder="ex. RO12345678" value={bill.cif} onChange={setBillField('cif')} />
            </div>
            <div>
              <label className="fld" htmlFor="bill-address">Adresă</label>
              <input id="bill-address" className="txt" type="text" autoComplete="street-address" placeholder="ex. Str. Fabricii 12" value={bill.address} onChange={setBillField('address')} />
            </div>
            <div>
              <label className="fld" htmlFor="bill-city">Oraș</label>
              <input id="bill-city" className="txt" type="text" placeholder="ex. Cluj-Napoca" value={bill.city} onChange={setBillField('city')} />
            </div>
          </div>
          <label className="fld" htmlFor="bill-email">Email facturare</label>
          <input id="bill-email" className="txt" type="email" autoComplete="email" placeholder="facturi@firma.ro" value={bill.email} onChange={setBillField('email')} />
          <p className="ap-fhint">Pe această adresă trimitem facturile emise automat.</p>
          <div className="ap-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={billBusy || !integ}>{billBusy ? 'Se salvează…' : 'Salvează'}</button>
            {billMsg && <span className={billMsg.kind === 'ok' ? 'ap-okmsg' : 'ap-errmsg'} role="status">{billMsg.text}</span>}
          </div>
        </form>
      </div>

      {/* ---------- notificări ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconBell /> Notificări</span>
        </div>
        <label className="ap-switch">
          <input
            type="checkbox"
            checked={!!integ?.notify.email}
            disabled={!integ || notifyBusy}
            onChange={toggleNotify}
          />
          <span className="ap-switch-track" aria-hidden="true" />
          <span className="ap-switch-label">
            <b>Primește email la lead fierbinte / programare</b>
            <span>Te anunțăm imediat ce AI-ul califică un lead fierbinte sau confirmă o programare.</span>
          </span>
        </label>
        {notifyErr && <p className="ap-errmsg" role="alert">{notifyErr}</p>}
      </div>

      {/* ---------- follow-up automat ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconReply /> Follow-up automat</span>
          {fuEnabled ? <span className="badge b-active">Activ</span> : null}
        </div>
        <p className="ap-form-p">Dacă lead-ul nu mai răspunde, Leaply revine singur cu un mesaj — exact ca un coleg care nu uită de nimeni.</p>
        <form onSubmit={saveFollowup}>
          <label className="ap-switch">
            <input type="checkbox" checked={fuEnabled} disabled={!integ || fuBusy} onChange={() => setFuEnabled(v => !v)} />
            <span className="ap-switch-track" aria-hidden="true" />
            <span className="ap-switch-label">
              <b>Trimite follow-up automat</b>
              <span>Un singur mesaj de revenire per conversație, la intervalul ales de tine.</span>
            </span>
          </label>
          <label className="fld" htmlFor="fu-hours">După câte ore fără răspuns</label>
          <select id="fu-hours" className="txt ap-fu-hours" value={fuHours} disabled={!fuEnabled} onChange={e => setFuHours(Number(e.target.value))}>
            <option value={2}>2 ore</option>
            <option value={4}>4 ore</option>
            <option value={8}>8 ore</option>
            <option value={24}>24 de ore</option>
          </select>
          <label className="fld" htmlFor="fu-text">Mesajul de follow-up</label>
          <textarea id="fu-text" className="txt ap-fu-text" rows={3} placeholder="Bună! Mai putem ajuta cu ceva…" value={fuText} disabled={!fuEnabled} onChange={e => setFuText(e.target.value)} />
          <p className="ap-fhint">Lasă gol și folosim un mesaj standard, politicos, în tonul asistentului tău.</p>
          <div className="ap-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={fuBusy || !integ}>{fuBusy ? 'Se salvează…' : 'Salvează'}</button>
            {fuMsg && <span className={fuMsg.kind === 'ok' ? 'ap-okmsg' : 'ap-errmsg'} role="status">{fuMsg.text}</span>}
          </div>
        </form>
      </div>

      {/* ---------- webhook CRM ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconLink /> Integrare CRM (webhook)</span>
          {integ?.webhookOut.url ? <span className="badge b-active">Activ</span> : null}
        </div>
        <p className="ap-form-p">Trimitem POST JSON la fiecare lead nou/actualizat — compatibil Zapier, Make, orice CRM.</p>
        <form onSubmit={saveWebhook}>
          <label className="fld" htmlFor="wh-url">URL webhook</label>
          <input id="wh-url" className="txt" type="url" placeholder="https://hooks.zapier.com/…" value={whUrl} onChange={e => setWhUrl(e.target.value)} />
          <p className="ap-fhint">Doar HTTPS. Lasă gol și salvează ca să dezactivezi trimiterea.</p>
          <label className="fld" htmlFor="wh-secret">Secret (opțional)</label>
          <input id="wh-secret" className="txt" type="password" autoComplete="off"
            placeholder={integ?.webhookOut.hasSecret ? 'Secret setat — completează doar ca să-l schimbi' : 'Semnăm fiecare request cu acest secret'}
            value={whSecret} onChange={e => setWhSecret(e.target.value)} />
          <p className="ap-fhint">Îl trimitem în header ca să poți verifica autenticitatea request-urilor.</p>
          <div className="ap-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={whBusy || !integ}>{whBusy ? 'Se salvează…' : 'Salvează'}</button>
            {whMsg && <span className={whMsg.kind === 'ok' ? 'ap-okmsg' : 'ap-errmsg'} role="status">{whMsg.text}</span>}
          </div>
        </form>
      </div>

      {/* ---------- API pentru dezvoltatori ---------- */}
      <ApiKeyPanel />

      {/* ---------- google calendar ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconCalendar /> Google Calendar</span>
          {integ?.google.connected ? <span className="connected">Conectat</span> : <span className="pending">Neconectat</span>}
        </div>
        {integ?.google.connected ? (
          <>
            <p className="ap-form-p">Conectat ca <b>{integ.google.email}</b>. Programările confirmate de AI apar direct în calendarul tău.</p>
            <div className="ap-actions">
              {gConfirm ? (
                <span className="ap-confirm">
                  Sigur deconectezi?
                  <button type="button" className="btn btn-sm ap-btn-danger" disabled={gBusy} onClick={googleDisconnect}>{gBusy ? 'Se deconectează…' : 'Da, deconectează'}</button>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={() => setGConfirm(false)}>Anulează</button>
                </span>
              ) : (
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => setGConfirm(true)}>Deconectează</button>
              )}
              {gErr && <span className="ap-errmsg" role="alert">{gErr}</span>}
            </div>
          </>
        ) : (
          <>
            <p className="ap-form-p">Autorizezi accesul o singură dată — AI-ul verifică disponibilitatea și adaugă programările automat în calendarul tău.</p>
            <a className="btn btn-primary btn-sm" href="/api/integrations/google/connect">Conectează Google Calendar</a>
          </>
        )}
      </div>
    </>
  );
}


function ApiKeyPanel() {
  const [info, setInfo] = useState<{ prefix: string; created_at: string } | null>(null);
  const [fresh, setFresh] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { fetch('/api/account/apikey').then(r => r.json()).then(j => { setInfo(j.key || null); setLoaded(true); }).catch(() => setLoaded(true)); }, []);
  async function generate() {
    setBusy(true);
    const r = await fetch('/api/account/apikey', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    const j = await r.json().catch(() => ({} as any));
    if (j.key) { setFresh(j.key); setInfo({ prefix: j.key.slice(0, 8), created_at: new Date().toISOString() }); }
    setBusy(false);
  }
  async function revoke() {
    setBusy(true);
    await fetch('/api/account/apikey', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'revoke' }) });
    setInfo(null); setFresh(null); setBusy(false);
  }
  return (
    <div className="panel">
      <div className="ap-panel-head">
        <span className="ap-panel-title ap-sec-title">API pentru dezvoltatori</span>
        {info ? <span className="badge b-active">Cheie activă</span> : null}
      </div>
      <p className="ap-form-p">Conectează Leaply la CRM-ul tău sau la orice platformă. <a href="/developers" target="_blank">Documentația completă →</a></p>
      {fresh && (
        <div className="ap-banner" role="status">
          Cheia ta (o vezi doar acum — copiaz-o): <code style={{ userSelect: 'all', wordBreak: 'break-all' }}>{fresh}</code>
        </div>
      )}
      {!fresh && info && <p className="ap-fhint">Cheie activă: <code>{info.prefix}…</code> · creată {new Date(info.created_at).toLocaleDateString('ro-RO')}. Din motive de siguranță nu o mai putem afișa — poți genera una nouă (cea veche se dezactivează).</p>}
      <div className="ap-actions">
        <button type="button" className="btn btn-primary btn-sm" onClick={generate} disabled={busy || !loaded}>
          {busy ? 'Se generează…' : info ? 'Regenerează cheia' : 'Generează cheie API'}
        </button>
        {info && <button type="button" className="btn btn-secondary btn-sm" onClick={revoke} disabled={busy}>Revocă</button>}
      </div>
    </div>
  );
}
