'use client';
import { useCallback, useEffect, useState } from 'react';
import { enableWebPush, pushSupported, pushPermission } from '../../../lib/pushClient';
import { LocationsPanel } from './locations-panel';
import { AddonsPanel } from './addons-panel';

/* ---------- icons (stroke 1.75, currentColor) ---------- */
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconCheck = ({ size = 15 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="m4.5 12.5 5 5 10-11" /></svg>
);
const IconCard = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><rect x="2.5" y="5" width="19" height="14" rx="2.5" /><path d="M2.5 10h19M6.5 14.5h4" /></svg>
);
const IconBell = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M18 9a6 6 0 1 0-12 0c0 5-2 6-2 6h16s-2-1-2-6M10.3 19.5a2 2 0 0 0 3.4 0" /></svg>
);
const IconLink = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M10 13.5a4 4 0 0 0 6 .5l3-3a4 4 0 1 0-5.7-5.7l-1.5 1.5" /><path d="M14 10.5a4 4 0 0 0-6-.5l-3 3a4 4 0 1 0 5.7 5.7l1.5-1.5" /></svg>
);
const IconCalendar = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" /></svg>
);
const IconReply = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M9 14 4 9l5-5" /><path d="M4 9h10.5A5.5 5.5 0 0 1 20 14.5V20" /></svg>
);
const IconInvoice = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" /><path d="M14 3v5h5M9 13h6M9 17h4" /></svg>
);

/* ---------- types ---------- */
type Integrations = {
  plan: string;
  accountName?: string;
  canDelete?: boolean;
  google: { configured: boolean; connected: boolean; email: string };
  webhookOut: { url: string; hasSecret: boolean };
  notify: { email: boolean; push?: boolean };
  stripe: { configured: boolean };
  usage?: { used: number; limit: number };
  trial?: { daysLeft: number | null; endsAt: string | null } | null;
  subscription?: { since: string | null; renewsAt: string | null; status: string } | null;
  followup?: { enabled: boolean; hours: number; text: string };
  billing?: { company: string; cif: string; address: string; city: string; email: string };
};

const roDate = (iso?: string | null) => {
  if (!iso) return '';
  try { return new Date(iso).toLocaleDateString('ro-RO', { day: 'numeric', month: 'long', year: 'numeric' }); } catch { return ''; }
};

const FU_HOURS = [2, 4, 8, 24];

// name = identificatorul intern (Stripe/DB); label = numele afișat clientului (repachetare 2026-07-08)
const PLANS = [
  { name: 'Start', label: 'Social', price: 59, feats: ['Facebook Messenger + Instagram DM', 'Facebook Lead Ads + chat pe site', '300 conversații/lună', 'Google Calendar + follow-up automat'] },
  { name: 'Pro', label: 'Complet', price: 129, hot: true, feats: ['Tot din Social + WhatsApp', 'Număr WhatsApp de la Leaply inclus', '800 conversații/lună · echipă 3 colegi', 'API + integrare CRM'] },
  { name: 'Scale', label: 'Total', price: 299, feats: ['Tot din Complet + agent vocal AI', 'Număr de telefon dedicat · 500 min/lună', '2.500 conversații/lună · echipă 10', 'Multi-locație · onboarding făcut de noi'] },
] as const;

async function postJSON(url: string, body: unknown) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  let j: any = null;
  try { j = await r.json(); } catch { /* ignore */ }
  if (!r.ok || !j || j.error) throw new Error((j && j.error) || 'Ceva nu a mers. Încearcă din nou.');
  return j;
}

export default function Settings() {
  const [integ, setInteg] = useState<Integrations | null>(null);
  const [loadErr, setLoadErr] = useState('');
  const [banner, setBanner] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  // plan
  const [planBusy, setPlanBusy] = useState<string | null>(null);
  const [planErr, setPlanErr] = useState('');
  // notificări
  const [notifyBusy, setNotifyBusy] = useState(false);
  const [notifyErr, setNotifyErr] = useState('');
  // push (preferință + dispozitiv curent)
  const [pushPrefBusy, setPushPrefBusy] = useState(false);
  const [deviceBusy, setDeviceBusy] = useState(false);
  const [deviceMsg, setDeviceMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [deviceState, setDeviceState] = useState<{ enabled: boolean; unsupported: boolean; label: string }>({
    enabled: false, unsupported: false, label: 'Verific…',
  });
  // webhook CRM
  const [whUrl, setWhUrl] = useState('');
  const [whSecret, setWhSecret] = useState('');
  const [whBusy, setWhBusy] = useState(false);
  const [whMsg, setWhMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  // google
  const [gBusy, setGBusy] = useState(false);
  const [gConfirm, setGConfirm] = useState(false);
  const [gErr, setGErr] = useState('');
  // follow-up automat
  const [fuEnabled, setFuEnabled] = useState(true);
  const [fuHours, setFuHours] = useState(4);
  const [fuText, setFuText] = useState('');
  const [fuSteps, setFuSteps] = useState('');
  const [fuBusy, setFuBusy] = useState(false);
  const [fuMsg, setFuMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  // date de facturare
  const [bill, setBill] = useState({ company: '', cif: '', address: '', city: '', email: '' });
  const [billBusy, setBillBusy] = useState(false);
  const [billMsg, setBillMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoadErr('');
    try {
      const r = await fetch('/api/integrations');
      const j = await r.json();
      setInteg(j);
      setWhUrl(j?.webhookOut?.url || '');
      if (j?.followup) {
        setFuEnabled(j.followup.enabled !== false);
        setFuHours(FU_HOURS.includes(Number(j.followup.hours)) ? Number(j.followup.hours) : 4);
        setFuText(j.followup.text || '');
        setFuSteps(Array.isArray(j.followup.steps) ? j.followup.steps.join(', ') : '');
      }
      if (j?.billing) {
        setBill(b => ({
          company: j.billing.company || b.company,
          cif: j.billing.cif || b.cif,
          address: j.billing.address || b.address,
          city: j.billing.city || b.city,
          email: j.billing.email || b.email,
        }));
      }
    } catch {
      setLoadErr('Nu am putut încărca setările. Reîmprospătează pagina.');
    }
  }, []);

  useEffect(() => {
    load();
    const q = new URLSearchParams(window.location.search);
    if (q.get('billing') === 'success') setBanner({ kind: 'ok', text: 'Plata a fost înregistrată — planul tău se activează în câteva momente.' });
    const g = q.get('google');
    if (g === 'connected') setBanner({ kind: 'ok', text: 'Google Calendar a fost conectat.' });
    else if (g === 'error') setBanner({ kind: 'err', text: 'Conectarea Google a eșuat. Încearcă din nou.' });
    else if (g === 'unconfigured') setBanner({ kind: 'err', text: 'Integrarea Google nu e configurată încă pe server.' });
    if (q.get('billing') || g) window.history.replaceState(null, '', '/app/settings');
  }, [load]);

  const [interval, setIntervalKind] = useState<'month' | 'year'>('month');
  const checkout = async (plan: string) => {
    setPlanErr('');
    setPlanBusy(plan);
    try {
      const j = await postJSON('/api/billing/checkout', { plan, interval });
      if (j.url) { window.location.href = j.url; return; }
      if (j.updated) {
        setBanner({ kind: 'ok', text: `Pachetul tău e acum ${PLANS.find(x => x.name === plan)?.label || plan} — diferența pe zilele rămase se facturează automat, prorata.` });
        setPlanBusy(null);
        load();
        return;
      }
      throw new Error('Nu am primit link-ul de plată. Încearcă din nou.');
    } catch (ex: any) {
      setPlanErr(ex.message);
      setPlanBusy(null);
    }
  };

  const toggleNotify = async () => {
    if (!integ || notifyBusy) return;
    const next = !integ.notify.email;
    setNotifyErr('');
    setNotifyBusy(true);
    setInteg({ ...integ, notify: { email: next } });
    try {
      await postJSON('/api/integrations', { action: 'notify', email: next });
    } catch (ex: any) {
      setInteg(i => (i ? { ...i, notify: { email: !next } } : i));
      setNotifyErr(ex.message);
    }
    setNotifyBusy(false);
  };

  const refreshDeviceState = useCallback(async () => {
    if (!pushSupported()) {
      setDeviceState({ enabled: false, unsupported: true, label: 'Browserul acesta nu suportă notificări push. Pe iPhone, adaugă aplicația Leaply pe ecranul principal sau folosește aplicația din App Store.' });
      return;
    }
    const perm = pushPermission();
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = await reg?.pushManager.getSubscription();
      if (perm === 'granted' && sub) setDeviceState({ enabled: true, unsupported: false, label: 'Activ pe acest dispozitiv. Vei primi notificări aici.' });
      else if (perm === 'denied') setDeviceState({ enabled: false, unsupported: false, label: 'Blocate din setările browserului. Deblochează notificările pentru leaply.ro ca să le poți activa.' });
      else setDeviceState({ enabled: false, unsupported: false, label: 'Nu sunt activate pe acest dispozitiv.' });
    } catch {
      setDeviceState({ enabled: false, unsupported: false, label: 'Nu sunt activate pe acest dispozitiv.' });
    }
  }, []);

  useEffect(() => { refreshDeviceState(); }, [refreshDeviceState]);

  const togglePush = async () => {
    if (!integ || pushPrefBusy) return;
    const next = !(integ.notify.push !== false);
    setPushPrefBusy(true);
    setInteg({ ...integ, notify: { ...integ.notify, push: next } });
    try {
      await postJSON('/api/integrations', { action: 'notify', push: next });
    } catch {
      setInteg(i => (i ? { ...i, notify: { ...i.notify, push: !next } } : i));
    }
    setPushPrefBusy(false);
  };

  const enableDevicePush = async () => {
    setDeviceBusy(true);
    setDeviceMsg(null);
    const r = await enableWebPush();
    setDeviceBusy(false);
    if (r.ok) { setDeviceMsg({ kind: 'ok', text: 'Gata! Notificările sunt active pe acest dispozitiv.' }); refreshDeviceState(); }
    else setDeviceMsg({ kind: 'err', text: r.error || 'Nu am putut activa notificările.' });
  };

  const sendTestPush = async () => {
    setDeviceBusy(true);
    setDeviceMsg(null);
    try {
      const j = await postJSON('/api/push/test', {});
      setDeviceMsg({ kind: 'ok', text: j.sent > 0 ? 'Trimis! Verifică notificarea.' : 'Trimis, dar niciun dispozitiv activ nu a primit-o încă.' });
    } catch (ex: any) {
      setDeviceMsg({ kind: 'err', text: ex.message });
    }
    setDeviceBusy(false);
  };

  const saveWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    setWhMsg(null);
    const url = whUrl.trim();
    if (url && !/^https:\/\/.+/.test(url)) {
      setWhMsg({ kind: 'err', text: 'URL-ul trebuie să înceapă cu https://' });
      return;
    }
    setWhBusy(true);
    try {
      const body: any = { action: 'webhook_out', url };
      if (whSecret.trim()) body.secret = whSecret.trim();
      await postJSON('/api/integrations', body);
      setWhMsg({ kind: 'ok', text: 'Webhook salvat.' });
      setWhSecret('');
      load();
    } catch (ex: any) {
      setWhMsg({ kind: 'err', text: ex.message });
    }
    setWhBusy(false);
  };

  const saveFollowup = async (e: React.FormEvent) => {
    e.preventDefault();
    setFuMsg(null);
    setFuBusy(true);
    try {
      const steps = fuSteps.split(',').map(x => Number(x.trim())).filter(x => x >= 1 && x <= 720).slice(0, 5);
      await postJSON('/api/integrations', { action: 'followup', enabled: fuEnabled, hours: fuHours, text: fuText.trim(), steps });
      setFuMsg({ kind: 'ok', text: 'Follow-up salvat.' });
    } catch (ex: any) {
      setFuMsg({ kind: 'err', text: ex.message });
    }
    setFuBusy(false);
  };

  const setBillField = (k: keyof typeof bill) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setBill(b => ({ ...b, [k]: e.target.value }));

  const saveBilling = async (e: React.FormEvent) => {
    e.preventDefault();
    setBillMsg(null);
    const email = bill.email.trim();
    if (email && !/^\S+@\S+\.\S+$/.test(email)) {
      setBillMsg({ kind: 'err', text: 'Emailul de facturare nu pare valid.' });
      return;
    }
    setBillBusy(true);
    try {
      await postJSON('/api/integrations', {
        action: 'billing',
        company: bill.company.trim(),
        cif: bill.cif.trim(),
        address: bill.address.trim(),
        city: bill.city.trim(),
        email,
      });
      setBillMsg({ kind: 'ok', text: 'Datele de facturare au fost salvate.' });
    } catch (ex: any) {
      setBillMsg({ kind: 'err', text: ex.message });
    }
    setBillBusy(false);
  };

  const googleDisconnect = async () => {
    setGBusy(true);
    setGErr('');
    try {
      await postJSON('/api/integrations', { action: 'google_disconnect' });
      setGConfirm(false);
      setBanner({ kind: 'ok', text: 'Google Calendar a fost deconectat.' });
      load();
    } catch (ex: any) {
      setGErr(ex.message);
    }
    setGBusy(false);
  };

  const currentPlan = integ?.plan || '';
  const usage = integ?.usage && integ.usage.limit > 0 ? integ.usage : null;
  const usagePct = usage ? Math.min(100, Math.round((usage.used / usage.limit) * 100)) : 0;
  const usageHot = usage ? usage.used / usage.limit >= 0.9 : false;

  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Setări & Plan</h1>
          <p className="ap-sub">Abonament, notificări și integrări pentru contul tău</p>
        </div>
      </div>

      {banner && <div className={`ap-banner${banner.kind === 'err' ? ' is-err' : ''}`} role="status">{banner.text}</div>}
      {loadErr && <div className="ap-banner is-err" role="alert">{loadErr}</div>}

      {/* ---------- planul tău ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconCard /> Planul tău</span>
          {integ && <span className="pill">Pachetul curent: {PLANS.find(x => x.name === currentPlan)?.label || currentPlan || 'Trial'}</span>}
        </div>
        {integ?.trial && (
          <div className={`ap-banner${(integ.trial.daysLeft ?? 0) <= 0 ? ' is-err' : ''}`} role="status" style={{ marginBottom: 14 }}>
            {(integ.trial.daysLeft ?? 0) > 0 ? (
              <>Ești pe <b>trial gratuit</b> — mai ai <b>{integ.trial.daysLeft} {integ.trial.daysLeft === 1 ? 'zi' : 'zile'}</b>{integ.trial.endsAt ? `, expiră pe ${roDate(integ.trial.endsAt)}` : ''}. Alege un plan mai jos ca asistentul să răspundă și după.</>
            ) : (
              <><b>Trialul a expirat</b>{integ.trial.endsAt ? ` pe ${roDate(integ.trial.endsAt)}` : ''} — asistentul nu mai răspunde automat. Alege un plan mai jos și se reactivează instant.</>
            )}
          </div>
        )}
        {integ?.subscription && (
          <p className="ap-fhint" style={{ marginTop: -2, marginBottom: 14 }}>
            Abonament <b>{PLANS.find(x => x.name === currentPlan)?.label || currentPlan}</b> {integ.subscription.status === 'past_due' ? <span className="badge b-cold">plată eșuată</span> : <span className="badge b-active">activ</span>}
            {integ.subscription.since ? ` · activ din ${roDate(integ.subscription.since)}` : ''}
            {integ.subscription.renewsAt ? ` · se reînnoiește pe ${roDate(integ.subscription.renewsAt)}` : ''}
          </p>
        )}
        {usage && (
          <div className="ap-usage">
            <div className="ap-usage-head">
              <b>Utilizare luna aceasta</b>
              <span>{usage.used} din {usage.limit} conversații incluse</span>
            </div>
            <div className="ap-usage-bar" role="progressbar" aria-valuenow={usage.used} aria-valuemin={0} aria-valuemax={usage.limit} aria-label="Conversații folosite luna aceasta">
              <div className={`ap-usage-fill${usageHot ? ' is-hot' : ''}`} style={{ width: `${usagePct}%` }} />
            </div>
            {usage.used >= usage.limit && (
              <div className="ap-banner is-err ap-usage-warn" role="alert">
                Ai atins limita — asistentul nu mai răspunde automat la lead-uri noi. Treci pe un plan mai mare.
              </div>
            )}
          </div>
        )}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '4px 0 12px' }}>
          <button type="button" className={`btn btn-sm ${interval === 'month' ? 'btn-dark' : 'btn-secondary'}`} onClick={() => setIntervalKind('month')}>Lunar</button>
          <button type="button" className={`btn btn-sm ${interval === 'year' ? 'btn-dark' : 'btn-secondary'}`} onClick={() => setIntervalKind('year')}>Anual — 2 luni gratis</button>
        </div>
        <div className="ap-plans">
          {PLANS.map(p => {
            const isCurrent = currentPlan.toLowerCase() === p.name.toLowerCase();
            return (
              <div key={p.name} className={`ap-plan${isCurrent ? ' is-current' : ''}`}>
                <div className="ap-plan-name">
                  {p.label}
                  {isCurrent && <span className="badge b-active">Activ</span>}
                  {!isCurrent && 'hot' in p && p.hot ? <span className="badge b-warm">Popular</span> : null}
                </div>
                <div className="ap-plan-price">
                  {interval === 'year' ? <>{p.price * 10}€<span className="ap-plan-per">/an</span></> : <>{p.price}€<span className="ap-plan-per">/lună</span></>}
                </div>
                {interval === 'year' && <p className="ap-fhint" style={{ marginTop: -6 }}>echivalent {Math.round(p.price * 10 / 12)}€/lună</p>}
                <ul className="ap-plan-feats">
                  {p.feats.map(f => <li key={f}><IconCheck /> {f}</li>)}
                </ul>
                {isCurrent ? (
                  <button type="button" className="btn btn-secondary btn-sm" disabled>Planul curent</button>
                ) : (
                  <button type="button" className="btn btn-primary btn-sm" disabled={planBusy !== null} onClick={() => checkout(p.name)}>
                    {planBusy === p.name ? 'Se deschide plata…' : `Treci pe ${p.label}`}
                  </button>
                )}
              </div>
            );
          })}
        </div>
        {planErr && <p className="ap-errmsg ap-plan-err" role="alert">{planErr}</p>}
        <p className="ap-fhint">Plata e procesată securizat prin Stripe. Poți anula oricând, fără contract pe termen lung.</p>
      </div>

      {/* ---------- extra resurse (add-on-uri, self-serve) ---------- */}
      <AddonsPanel addons={(usage as any)?.addons} hasSub={Boolean(integ?.subscription)} onChanged={load} />

      {/* ---------- multi-locație (Total) ---------- */}
      <LocationsPanel />

      {/* ---------- date de facturare ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconInvoice /> Date de facturare</span>
        </div>
        <p className="ap-form-p">Completează datele firmei tale — factura SmartBill se emite și se trimite automat la fiecare plată.</p>
        <form onSubmit={saveBilling}>
          <div className="ap-bill-grid">
            <div>
              <label className="fld" htmlFor="bill-company">Firmă</label>
              <input id="bill-company" className="txt" type="text" autoComplete="organization" placeholder="ex. Termopan Expert SRL" value={bill.company} onChange={setBillField('company')} />
            </div>
            <div>
              <label className="fld" htmlFor="bill-cif">CIF</label>
              <input id="bill-cif" className="txt" type="text" placeholder="ex. RO12345678" value={bill.cif} onChange={setBillField('cif')} />
            </div>
            <div>
              <label className="fld" htmlFor="bill-address">Adresă</label>
              <input id="bill-address" className="txt" type="text" autoComplete="street-address" placeholder="ex. Str. Fabricii 12" value={bill.address} onChange={setBillField('address')} />
            </div>
            <div>
              <label className="fld" htmlFor="bill-city">Oraș</label>
              <input id="bill-city" className="txt" type="text" placeholder="ex. Cluj-Napoca" value={bill.city} onChange={setBillField('city')} />
            </div>
          </div>
          <label className="fld" htmlFor="bill-email">Email facturare</label>
          <input id="bill-email" className="txt" type="email" autoComplete="email" placeholder="facturi@firma.ro" value={bill.email} onChange={setBillField('email')} />
          <p className="ap-fhint">Pe această adresă trimitem facturile emise automat.</p>
          <div className="ap-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={billBusy || !integ}>{billBusy ? 'Se salvează…' : 'Salvează'}</button>
            {billMsg && <span className={billMsg.kind === 'ok' ? 'ap-okmsg' : 'ap-errmsg'} role="status">{billMsg.text}</span>}
          </div>
        </form>
      </div>

      {/* ---------- notificări ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconBell /> Notificări</span>
        </div>
        <label className="ap-switch">
          <input
            type="checkbox"
            checked={!!integ?.notify.email}
            disabled={!integ || notifyBusy}
            onChange={toggleNotify}
          />
          <span className="ap-switch-track" aria-hidden="true" />
          <span className="ap-switch-label">
            <b>Primește email la lead fierbinte / programare</b>
            <span>Te anunțăm imediat ce AI-ul califică un lead fierbinte sau confirmă o programare.</span>
          </span>
        </label>
        {notifyErr && <p className="ap-errmsg" role="alert">{notifyErr}</p>}

        <label className="ap-switch" style={{ marginTop: 14 }}>
          <input
            type="checkbox"
            checked={integ?.notify.push !== false}
            disabled={!integ || pushPrefBusy}
            onChange={togglePush}
          />
          <span className="ap-switch-track" aria-hidden="true" />
          <span className="ap-switch-label">
            <b>Notificări push la lead nou</b>
            <span>Notificare instant pe telefon și pe desktop când intră un lead nou — chiar dacă nu ai Leaply deschis.</span>
          </span>
        </label>

        <div className="ap-chan" style={{ marginTop: 8 }}>
          <div className="ap-chan-row" style={{ alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
            <span className="ap-chan-info" style={{ flex: 1, minWidth: 220 }}>
              <b>Notificări pe acest dispozitiv</b>
              <span>{deviceState.label}</span>
            </span>
            <span style={{ display: 'flex', gap: 8 }}>
              {deviceState.enabled ? (
                <button type="button" className="btn btn-primary btn-sm" disabled={deviceBusy} onClick={sendTestPush}>
                  {deviceBusy ? 'Se trimite…' : 'Trimite test'}
                </button>
              ) : (
                <button type="button" className="btn btn-primary btn-sm" disabled={deviceBusy || deviceState.unsupported} onClick={enableDevicePush}>
                  {deviceBusy ? 'Se activează…' : 'Activează pe acest dispozitiv'}
                </button>
              )}
            </span>
          </div>
          {deviceMsg && <p className={deviceMsg.kind === 'ok' ? 'ap-okmsg' : 'ap-errmsg'} style={{ margin: '2px 4px' }} role="status">{deviceMsg.text}</p>}
        </div>
      </div>

      {/* ---------- follow-up automat ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconReply /> Follow-up automat</span>
          {fuEnabled ? <span className="badge b-active">Activ</span> : null}
        </div>
        <p className="ap-form-p">Dacă lead-ul nu mai răspunde, Leaply revine singur cu un mesaj — exact ca un coleg care nu uită de nimeni.</p>
        <form onSubmit={saveFollowup}>
          <label className="ap-switch">
            <input type="checkbox" checked={fuEnabled} disabled={!integ || fuBusy} onChange={() => setFuEnabled(v => !v)} />
            <span className="ap-switch-track" aria-hidden="true" />
            <span className="ap-switch-label">
              <b>Trimite follow-up automat</b>
              <span>Secvență de reveniri (multi-touch) până răspunde lead-ul — se oprește automat la primul răspuns.</span>
            </span>
          </label>
          <label className="fld" htmlFor="fu-hours">După câte ore fără răspuns</label>
          <select id="fu-hours" className="txt ap-fu-hours" value={fuHours} disabled={!fuEnabled} onChange={e => setFuHours(Number(e.target.value))}>
            <option value={2}>2 ore</option>
            <option value={4}>4 ore</option>
            <option value={8}>8 ore</option>
            <option value={24}>24 de ore</option>
          </select>
          <label className="fld" htmlFor="fu-steps">Cadența completă <span className="muted" style={{ fontWeight: 400 }}>(ore între pași, separate prin virgulă — max 5)</span></label>
          <input id="fu-steps" className="txt" value={fuSteps} disabled={!fuEnabled} onChange={e => setFuSteps(e.target.value)} placeholder="ex. 4, 24, 72 (implicit) sau 2, 24, 72, 168" />
          <p className="ap-fhint">Primul pas folosește mesajul tău de mai jos; pașii următori folosesc variații politicoase, tot mai scurte.</p>

          <label className="fld" htmlFor="fu-text">Mesajul de follow-up</label>
          <textarea id="fu-text" className="txt ap-fu-text" rows={3} placeholder="Bună! Mai putem ajuta cu ceva…" value={fuText} disabled={!fuEnabled} onChange={e => setFuText(e.target.value)} />
          <p className="ap-fhint">Lasă gol și folosim un mesaj standard, politicos, în tonul asistentului tău.</p>
          <div className="ap-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={fuBusy || !integ}>{fuBusy ? 'Se salvează…' : 'Salvează'}</button>
            {fuMsg && <span className={fuMsg.kind === 'ok' ? 'ap-okmsg' : 'ap-errmsg'} role="status">{fuMsg.text}</span>}
          </div>
        </form>
      </div>

      {/* ---------- webhook CRM ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconLink /> Integrare CRM (webhook)</span>
          {integ?.webhookOut.url ? <span className="badge b-active">Activ</span> : null}
        </div>
        <p className="ap-form-p">Trimitem POST JSON la fiecare lead nou/actualizat — compatibil Zapier, Make, orice CRM.</p>
        <form onSubmit={saveWebhook}>
          <label className="fld" htmlFor="wh-url">URL webhook</label>
          <input id="wh-url" className="txt" type="url" placeholder="https://hooks.zapier.com/…" value={whUrl} onChange={e => setWhUrl(e.target.value)} />
          <p className="ap-fhint">Doar HTTPS. Lasă gol și salvează ca să dezactivezi trimiterea.</p>
          <label className="fld" htmlFor="wh-secret">Secret (opțional)</label>
          <input id="wh-secret" className="txt" type="password" autoComplete="off"
            placeholder={integ?.webhookOut.hasSecret ? 'Secret setat — completează doar ca să-l schimbi' : 'Semnăm fiecare request cu acest secret'}
            value={whSecret} onChange={e => setWhSecret(e.target.value)} />
          <p className="ap-fhint">Îl trimitem în header ca să poți verifica autenticitatea request-urilor.</p>
          <div className="ap-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={whBusy || !integ}>{whBusy ? 'Se salvează…' : 'Salvează'}</button>
            {whMsg && <span className={whMsg.kind === 'ok' ? 'ap-okmsg' : 'ap-errmsg'} role="status">{whMsg.text}</span>}
          </div>
        </form>
      </div>

      {/* ---------- echipă ---------- */}
      <TeamPanel />

      {/* ---------- recomandă și câștigă ---------- */}
      <ReferralPanel />

      {/* ---------- API pentru dezvoltatori ---------- */}
      <ApiKeyPanel />

      {/* ---------- google calendar ---------- */}
      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title ap-sec-title"><IconCalendar /> Google Calendar</span>
          {integ?.google.connected ? <span className="connected">Conectat</span> : <span className="pending">Neconectat</span>}
        </div>
        {integ?.google.connected ? (
          <>
            <p className="ap-form-p">Conectat ca <b>{integ.google.email}</b>. Programările confirmate de AI apar direct în calendarul tău.</p>
            <div className="ap-actions">
              {gConfirm ? (
                <span className="ap-confirm">
                  Sigur deconectezi?
                  <button type="button" className="btn btn-sm ap-btn-danger" disabled={gBusy} onClick={googleDisconnect}>{gBusy ? 'Se deconectează…' : 'Da, deconectează'}</button>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={() => setGConfirm(false)}>Anulează</button>
                </span>
              ) : (
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => setGConfirm(true)}>Deconectează</button>
              )}
              {gErr && <span className="ap-errmsg" role="alert">{gErr}</span>}
            </div>
          </>
        ) : (
          <>
            <p className="ap-form-p">Autorizezi accesul o singură dată — AI-ul verifică disponibilitatea și adaugă programările automat în calendarul tău.</p>
            <a className="btn btn-primary btn-sm" href="/api/integrations/google/connect">Conectează Google Calendar</a>
          </>
        )}
      </div>

      {/* ---------- ștergere cont (zonă periculoasă) ---------- */}
      {integ?.canDelete && <DeleteAccountPanel name={integ?.accountName || ''} />}
    </>
  );
}

function DeleteAccountPanel({ name }: { name: string }) {
  const [open, setOpen] = useState(false);
  const [typed, setTyped] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const match = typed.trim().toLowerCase() === (name || '').trim().toLowerCase() && typed.trim().length > 0;

  const remove = async () => {
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/account/delete', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ confirmName: typed.trim() }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.error) throw new Error(j.error || 'Ștergerea a eșuat.');
      window.location.href = '/?deleted=1';
    } catch (ex: any) {
      setErr(ex.message); setBusy(false);
    }
  };

  return (
    <div className="panel" style={{ border: '1.5px solid var(--bad, #D64545)' }}>
      <div className="ap-panel-head">
        <span className="ap-panel-title ap-sec-title" style={{ color: 'var(--bad, #D64545)' }}>Șterge contul</span>
      </div>
      <p className="ap-form-p">
        Ștergerea contului este <b>definitivă</b>: se șterg toate conversațiile, lead-urile, canalele și datele echipei, iar abonamentul se anulează. Acțiunea nu poate fi anulată.
      </p>
      {!open ? (
        <button type="button" className="btn btn-secondary btn-sm ap-btn-danger" onClick={() => setOpen(true)}>Vreau să șterg contul</button>
      ) : (
        <>
          <label className="fld" htmlFor="del-confirm">Scrie numele firmei <b>{name}</b> ca să confirmi</label>
          <input id="del-confirm" className="txt" value={typed} onChange={e => setTyped(e.target.value)} placeholder={name} autoComplete="off" />
          <div className="ap-actions" style={{ marginTop: 10 }}>
            <button type="button" className="btn btn-sm ap-btn-danger" disabled={!match || busy} onClick={remove}>
              {busy ? 'Se șterge…' : 'Șterge definitiv contul'}
            </button>
            <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={() => { setOpen(false); setTyped(''); setErr(''); }}>Anulează</button>
            {err && <span className="ap-errmsg" role="alert">{err}</span>}
          </div>
        </>
      )}
    </div>
  );
}


function ApiKeyPanel() {
  const [info, setInfo] = useState<{ prefix: string; created_at: string } | null>(null);
  const [fresh, setFresh] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { fetch('/api/account/apikey').then(r => r.json()).then(j => { setInfo(j.key || null); setLoaded(true); }).catch(() => setLoaded(true)); }, []);
  async function generate() {
    setBusy(true);
    const r = await fetch('/api/account/apikey', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    const j = await r.json().catch(() => ({} as any));
    if (j.key) { setFresh(j.key); setInfo({ prefix: j.key.slice(0, 8), created_at: new Date().toISOString() }); }
    setBusy(false);
  }
  async function revoke() {
    setBusy(true);
    await fetch('/api/account/apikey', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'revoke' }) });
    setInfo(null); setFresh(null); setBusy(false);
  }
  return (
    <div className="panel">
      <div className="ap-panel-head">
        <span className="ap-panel-title ap-sec-title">API pentru dezvoltatori</span>
        {info ? <span className="badge b-active">Cheie activă</span> : null}
      </div>
      <p className="ap-form-p">Conectează Leaply la CRM-ul tău sau la orice platformă. <a href="/developers" target="_blank">Documentația completă →</a></p>
      {fresh && (
        <div className="ap-banner" role="status">
          Cheia ta (o vezi doar acum — copiaz-o): <code style={{ userSelect: 'all', wordBreak: 'break-all' }}>{fresh}</code>
        </div>
      )}
      {!fresh && info && <p className="ap-fhint">Cheie activă: <code>{info.prefix}…</code> · creată {new Date(info.created_at).toLocaleDateString('ro-RO')}. Din motive de siguranță nu o mai putem afișa — poți genera una nouă (cea veche se dezactivează).</p>}
      <div className="ap-actions">
        <button type="button" className="btn btn-primary btn-sm" onClick={generate} disabled={busy || !loaded}>
          {busy ? 'Se generează…' : info ? 'Regenerează cheia' : 'Generează cheie API'}
        </button>
        {info && <button type="button" className="btn btn-secondary btn-sm" onClick={revoke} disabled={busy}>Revocă</button>}
      </div>
    </div>
  );
}


function TeamPanel() {
  const [members, setMembers] = useState<any[]>([]);
  const [canManage, setCanManage] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const load = () => fetch('/api/team').then(r => r.json()).then(j => { setMembers(j.members || []); setCanManage(Boolean(j.canManage)); }).catch(() => {});
  useEffect(() => { load(); }, []);
  async function add(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMsg('');
    const r = await fetch('/api/team', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, email }) });
    const j = await r.json().catch(() => ({} as any));
    setMsg(r.ok ? `Adăugat! ${email} primește parola pe email.` : (j.error || 'Eroare.'));
    if (r.ok) { setName(''); setEmail(''); load(); }
    setBusy(false);
  }
  async function remove(id: string) {
    await fetch('/api/team?id=' + id, { method: 'DELETE' });
    load();
  }
  return (
    <div className="panel">
      <div className="ap-panel-head"><span className="ap-panel-title ap-sec-title">Echipa ta</span></div>
      <p className="ap-form-p">Colegii văd același inbox și pot prelua conversații; le poți asigna lead-uri direct din conversație.</p>
      {members.map(m => (
        <div key={m.id} className="row">
          <span className="ap-lead"><span className="ap-lead-name">{m.name} {m.role !== 'agent' && <span className="pill">{m.role}</span>}</span>
          <span className="ap-lead-meta">{m.email}</span></span>
          {canManage && m.role === 'agent' && <button type="button" className="btn btn-secondary btn-sm" onClick={() => remove(m.id)}>Elimină</button>}
        </div>
      ))}
      {canManage && (
        <form onSubmit={add} style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 10 }}>
          <input className="txt" value={name} onChange={e => setName(e.target.value)} placeholder="Numele colegului" style={{ flex: 1, minWidth: 140 }} required />
          <input className="txt" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="email@firma.ro" style={{ flex: 1, minWidth: 160 }} required />
          <button className="btn btn-primary btn-sm" type="submit" disabled={busy}>{busy ? 'Se adaugă…' : 'Adaugă coleg'}</button>
          {msg && <span className="ap-okmsg" style={{ alignSelf: 'center' }}>{msg}</span>}
        </form>
      )}
    </div>
  );
}

function ReferralPanel() {
  const [accId, setAccId] = useState('');
  const [copied, setCopied] = useState(false);
  useEffect(() => { fetch('/api/channels').then(r => r.json()).then(j => setAccId(j.accountId || '')).catch(() => {}); }, []);
  const link = accId ? `https://leaply.ro/start?ref=${accId}` : '';
  return (
    <div className="panel">
      <div className="ap-panel-head"><span className="ap-panel-title ap-sec-title">Recomandă și câștigă</span></div>
      <p className="ap-form-p">Pentru fiecare firmă care activează un plan plătit prin linkul tău, primești <b>o lună gratis</b>. Trimite-l cui vrei:</p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <input className="txt" readOnly value={link} style={{ flex: 1, minWidth: 220 }} aria-label="Linkul tău de recomandare" onFocus={e => e.currentTarget.select()} />
        <button type="button" className="btn btn-secondary btn-sm" disabled={!link}
          onClick={() => { navigator.clipboard?.writeText(link).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }); }}>
          {copied ? 'Copiat ✓' : 'Copiază'}
        </button>
      </div>
    </div>
  );
}
