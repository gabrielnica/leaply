'use client';
import { useState } from 'react';

type Addons = { conv: number; sms: number; voice_min: number; numbers: number };
const ROWS: { kind: keyof Addons; unit: number; price: number; label: string }[] = [
  { kind: 'conv', unit: 200, price: 19, label: 'Conversații extra' },
  { kind: 'voice_min', unit: 100, price: 29, label: 'Minute agent vocal' },
  { kind: 'sms', unit: 500, price: 29, label: 'SMS-uri extra' },
  { kind: 'numbers', unit: 1, price: 12, label: 'Numere suplimentare (locație/brand)' },
];

// Extra resurse self-serve: + / − pe fiecare add-on, facturat instant cu prorare.
export function AddonsPanel({ addons, hasSub, onChanged }: { addons?: Addons; hasSub: boolean; onChanged: () => void }) {
  const [busy, setBusy] = useState('');
  const [err, setErr] = useState('');
  const a: Addons = addons || { conv: 0, sms: 0, voice_min: 0, numbers: 0 };

  const change = async (kind: string, delta: 1 | -1) => {
    setBusy(kind + delta); setErr('');
    try {
      const r = await fetch('/api/billing/addon', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind, delta }) });
      const j = await r.json().catch(() => ({} as any));
      if (r.ok && j.ok) onChanged();
      else setErr(j.error || 'Eroare — mai încearcă o dată.');
    } catch { setErr('Eroare de conexiune.'); }
    setBusy('');
  };

  return (
    <div className="panel">
      <div className="ap-panel-head">
        <span className="ap-panel-title">Extra resurse</span>
      </div>
      <p className="ap-form-p">Ai nevoie de mai mult fără să schimbi pachetul? Adaugă pachete de resurse — se activează instant și plătești doar diferența pe zilele rămase din lună (prorare automată prin Stripe).</p>
      {ROWS.map(r => {
        const packs = Math.round((a[r.kind] || 0) / r.unit);
        return (
          <div key={r.kind} className="row">
            <span className="ap-lead">
              <span className="ap-lead-name">{r.label}</span>
              <span className="ap-lead-meta">+{r.unit === 1 ? '1' : r.unit} / pachet · {r.price} €/lună{packs > 0 ? ` · activ: ${packs} ${packs === 1 ? 'pachet' : 'pachete'} (+${a[r.kind]})` : ''}</span>
            </span>
            <span style={{ display: 'inline-flex', gap: 6 }}>
              {packs > 0 && (
                <button type="button" className="btn btn-secondary btn-sm" disabled={!!busy || !hasSub} onClick={() => change(r.kind, -1)}>
                  {busy === r.kind + '-1' ? '…' : '− Scoate'}
                </button>
              )}
              <button type="button" className="btn btn-primary btn-sm" disabled={!!busy || !hasSub} onClick={() => change(r.kind, 1)}>
                {busy === r.kind + '1' ? 'Se activează…' : '+ Adaugă'}
              </button>
            </span>
          </div>
        );
      })}
      {!hasSub && <p className="ap-fhint" style={{ marginTop: 8 }}>Extra resursele se activează pe un abonament plătit — alege întâi un pachet de mai sus.</p>}
      {err && <p className="ap-errmsg" role="alert" style={{ marginTop: 8 }}>{err}</p>}
    </div>
  );
}
