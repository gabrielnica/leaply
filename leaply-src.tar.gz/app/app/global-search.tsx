'use client';
import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';

type Result = { title: string; hint: string; url: string };

// Căutare globală: Cmd+K / Ctrl+K oriunde în aplicație.
export function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Result[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const timer = useRef<any>(null);
  const router = useRouter();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setOpen(o => !o); }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => { if (open) setTimeout(() => inputRef.current?.focus(), 30); else { setQ(''); setResults([]); } }, [open]);

  const search = (val: string) => {
    setQ(val);
    clearTimeout(timer.current);
    if (val.trim().length < 2) { setResults([]); return; }
    timer.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/search?q=${encodeURIComponent(val.trim())}`);
        const d = await r.json();
        setResults(d.results || []);
      } catch { /* offline */ }
    }, 180);
  };
  const go = (url: string) => { setOpen(false); router.push(url); };

  if (!open) return null;
  return (
    <div className="ap-cmdk-overlay" onClick={() => setOpen(false)}>
      <div className="ap-cmdk" onClick={e => e.stopPropagation()}>
        <input ref={inputRef} placeholder="Caută lead, telefon, etichetă sau pagină…" value={q}
          onChange={e => search(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && results[0]) go(results[0].url); }} />
        <div className="ap-cmdk-list">
          {results.map((r, i) => (
            <a key={r.url + i} className={`ap-cmdk-item${i === 0 ? ' is-hot' : ''}`} href={r.url}
              onClick={e => { e.preventDefault(); go(r.url); }}>
              <span>{r.title}</span><small>{r.hint}</small>
            </a>
          ))}
          {q.trim().length >= 2 && results.length === 0 && <div className="ap-cmdk-item"><span className="muted">Niciun rezultat.</span></div>}
        </div>
        <div className="ap-cmdk-hint">Enter deschide primul rezultat · Esc închide · Cmd/Ctrl+K oriunde</div>
      </div>
    </div>
  );
}
