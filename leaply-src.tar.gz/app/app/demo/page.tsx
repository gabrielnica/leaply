'use client';
export const dynamic = 'force-dynamic';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';

type Msg = { sender: 'lead' | 'ai'; body: string };
type DemoCtx = { personalized: boolean; businessName: string; welcome: string; starters: string[]; configured: boolean };

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconBot = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13v1.5M15 13v1.5" /><circle cx="12" cy="3.5" r="1" />
  </svg>
);
const IconRefresh = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M21 12a9 9 0 1 1-2.64-6.36M21 3v6h-6" /></svg>
);

export default function AppDemo() {
  const [history, setHistory] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [meta, setMeta] = useState<any>(null);
  const [ctx, setCtx] = useState<DemoCtx | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => { fetch('/api/demo/context').then(r => r.json()).then(setCtx).catch(() => {}); }, []);
  useEffect(() => { boxRef.current?.scrollTo(0, boxRef.current.scrollHeight); }, [history, loading]);

  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || loading) return;
    const h = [...history, { sender: 'lead' as const, body: msg }];
    setHistory(h); setInput(''); setLoading(true);
    try {
      const r = await fetch('/api/demo/message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ history: h, mode: 'account' }) });
      const d = await r.json();
      setHistory([...h, { sender: 'ai', body: d.reply }]);
      setMeta(d);
    } catch { setHistory([...h, { sender: 'ai', body: 'Eroare de conexiune.' }]); }
    setLoading(false);
  }

  const scoreColor: Record<string, string> = { hot: 'var(--ok)', warm: 'var(--warn)', cold: 'var(--bad)' };
  const scoreRo: Record<string, string> = { hot: 'Hot', warm: 'Warm', cold: 'Cold' };
  const starters = ctx?.starters || [];

  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Testează asistentul — pe datele tale</h1>
          <p className="ap-sub">
            Scrie ca un client real. Asistentul folosește serviciile, prețurile, cunoștințele și documentele firmei tale — exact ca pe canalele reale.
          </p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={() => { setHistory([]); setMeta(null); }}><IconRefresh /> Conversație nouă</button>
      </div>

      {ctx && !ctx.configured && (
        <div className="panel" style={{ borderLeft: '3px solid var(--warn)' }}>
          <b>Asistentul tău nu are încă date despre afacere.</b>
          <p className="ap-sub" style={{ margin: '4px 0 8px' }}>Fără servicii și cunoștințe, va răspunde generic. Le poate importa singur de pe site-ul tău, în câteva secunde.</p>
          <Link href="/app/config" className="btn btn-dark btn-sm">Completează datele în Configurare AI</Link>
        </div>
      )}

      <div className="ap-cols ap-cols-wide">
        <div className="ap-chat" style={{ minHeight: 480 }}>
          <div className="ap-chat-head">
            <span className="ap-chat-ava"><IconBot /></span>
            <span>
              <b>{ctx?.businessName || '…'}</b>
              <small>demo pe datele afacerii tale · răspunde instant</small>
            </span>
          </div>
          <div ref={boxRef} className="ap-chat-body">
            {history.length === 0 && (
              <div className="ap-chat-empty">Scrie un mesaj ca un client, sau alege una dintre întrebările de test din dreapta.</div>
            )}
            {history.map((m, i) => (
              <div key={i} className={`bubble ${m.sender === 'lead' ? 'out' : 'in'}`}>{m.body}</div>
            ))}
            {loading && <div className="ap-typing">Asistentul scrie…</div>}
          </div>
          <div className="ap-chat-foot">
            <input className="txt" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Scrie un mesaj ca un client…" />
            <button className="btn btn-primary" onClick={() => send()}>Trimite</button>
          </div>
        </div>

        <div>
          <div className="panel">
            <div className="ap-meta-label">Întrebări de test — din datele tale</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 10 }}>
              {starters.length === 0 && <span className="muted" style={{ fontSize: 13.5 }}>Se pregătesc întrebările…</span>}
              {starters.map((s, i) => (
                <button key={i} className="ap-starter" onClick={() => send(s)}>{s}</button>
              ))}
            </div>
          </div>
          <div className="panel">
            <div className="ap-meta-label">Analiza conversației</div>
            {meta ? (
              <div style={{ marginTop: 10 }}>
                <div className="ap-demo-kv"><span className="ap-k">Timp de răspuns</span><span className="ap-v ap-v-accent">{(meta.latencyMs / 1000).toFixed(2)} sec</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Scor lead</span><span className="ap-v" style={{ color: scoreColor[meta.score] || 'inherit' }}>{scoreRo[meta.score] || meta.score}</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Status</span><span className="ap-v">{meta.status}</span></div>
                <div className="ap-demo-kv"><span className="ap-k">Motor</span><span className="ap-v">{meta.usedLLM ? 'LLM real' : 'creier RO (reguli)'}</span></div>
                {meta.qualification && Object.keys(meta.qualification).length > 0 && (
                  <div className="ap-demo-qual">
                    <div className="ap-meta-label" style={{ marginBottom: 8 }}>Calificare extrasă</div>
                    {Object.entries(meta.qualification).map(([k, v]: any) => (
                      <div key={k}><b>{k}:</b> {v}</div>
                    ))}
                  </div>
                )}
              </div>
            ) : <p className="muted" style={{ fontSize: 13.5, marginTop: 8 }}>Trimite un mesaj ca să vezi scorul și calificarea în timp real.</p>}
          </div>
          <div className="panel">
            <div className="ap-meta-label">Nu răspunde cum vrei?</div>
            <p className="muted" style={{ fontSize: 13.5, margin: '8px 0 10px' }}>Ajustează serviciile, cunoștințele și regulile — modificările se aplică aici imediat.</p>
            <Link href="/app/config" className="btn btn-dark btn-sm">Deschide Configurare AI</Link>
          </div>
        </div>
      </div>
    </>
  );
}
