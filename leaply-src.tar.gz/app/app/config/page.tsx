'use client';
export const dynamic = 'force-dynamic';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { DocsPanel } from './docs-panel';
import { SiteImport } from './site-import';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconSparkles = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 4l1.8 4.7L18.5 10.5l-4.7 1.8L12 17l-1.8-4.7L5.5 10.5l4.7-1.8zM19 16l.9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9z" />
  </svg>
);
const IconBook = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5v14zM4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5" />
  </svg>
);
const IconPlay = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M6 4.5v15l13-7.5z" />
  </svg>
);

export default function Config() {
  const [cfg, setCfg] = useState<any>(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => { fetch('/api/account/config').then(r => r.json()).then(setCfg); }, []);
  if (!cfg) return <p className="ap-loading">Se încarcă…</p>;
  const upd = (k: string, v: any) => { setCfg({ ...cfg, [k]: v }); setSaved(false); };
  async function save() {
    await fetch('/api/account/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cfg) });
    setSaved(true);
  }
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Configurare AI — „creierul” Leaply</h1>
          <p className="ap-sub">Ce știe și cum vorbește asistentul tău. Se aplică pe toate canalele.</p>
        </div>
      </div>
      <div className="ap-cols ap-cols-wide">
        <div>
          <div className="panel">
            <div className="ap-group-title"><IconSparkles /> Identitate & ton</div>
            <label className="fld">Numele afacerii</label>
            <input className="txt" value={cfg.businessName || ''} onChange={e => upd('businessName', e.target.value)} />
            <label className="fld">Ton</label>
            <input className="txt" value={cfg.tone || ''} onChange={e => upd('tone', e.target.value)} />
            <label className="fld">Mesaj de bun venit</label>
            <textarea className="txt" rows={2} value={cfg.welcome || ''} onChange={e => upd('welcome', e.target.value)} />
          </div>
          <div className="panel">
            <div className="ap-group-title"><IconBook /> Cunoștințe & calificare</div>
            <label className="fld">Servicii & prețuri (un rând: Nume | preț)</label>
            <textarea className="txt" rows={3} value={(cfg.services || []).map((s: any) => `${s.name} | ${s.price}`).join('\n')}
              onChange={e => upd('services', e.target.value.split('\n').filter(Boolean).map(l => { const [name, price] = l.split('|'); return { name: (name || '').trim(), price: (price || '').trim() }; }))} />
            <label className="fld">Întrebări de calificare (o întrebare pe rând)</label>
            <textarea className="txt" rows={3} value={(cfg.qualificationQuestions || []).map((q: any) => q.q).join('\n')}
              onChange={e => upd('qualificationQuestions', e.target.value.split('\n').filter(Boolean).map((q, i) => ({ key: `q${i + 1}`, q: q.trim() })))} />
            <label className="fld">Cunoștințe despre afacere (importate de pe site + orice altceva vrei să știe)</label>
            <textarea className="txt" rows={5} value={cfg.knowledge || ''} onChange={e => upd('knowledge', e.target.value)}
              placeholder="Program, zonă de acoperire, garanții, diferențiatori, întrebări frecvente…" />
            <label className="fld">Reguli și limite (asistentul le respectă STRICT)</label>
            <textarea className="txt" rows={4} value={cfg.rules || ''} onChange={e => upd('rules', e.target.value)}
              placeholder="ex. Nu promite termene. Nu oferi discounturi. Nu discuta concurența. Nu prelua comenzi telefonice." />
          </div>
          <SiteImport initialUrl={cfg.website || ''} />
          <DocsPanel />
          <div className="panel">
            <div className="ap-group-title">📞 Telefon, widget & automatizări</div>
            <label className="fld">Transfer la om — numărul tău (apelantul poate cere să vorbească cu cineva)</label>
            <input className="txt" placeholder="+407xxxxxxxx" value={cfg.transferPhone || ''} onChange={e => upd('transferPhone', e.target.value)} />
            <label className="fld">Mesajul proactiv al widgetului de pe site (apare după 30 de secunde)</label>
            <input className="txt" placeholder="Aveți o întrebare? Vă răspundem în sub un minut. 👋" value={cfg.widgetTeaser || ''} onChange={e => upd('widgetTeaser', e.target.value)} />
            <label className="fld">Răspunsuri rapide (unul pe rând — apar ca butoane când răspunzi manual)</label>
            <textarea className="txt" rows={3} value={(cfg.quickReplies || []).join('\n')}
              onChange={e => upd('quickReplies', e.target.value.split('\n').map(s => s.trim()).filter(Boolean).slice(0, 8))}
              placeholder={'Bună ziua! Revin imediat cu detalii.\nVă pot suna în 10 minute?\nGăsiți prețurile aici: …'} />
            <label className="fld">Ore de liniște (nu primești notificări push în acest interval; AI-ul răspunde în continuare)</label>
            <input className="txt" placeholder="ex. 22-08 (gol = notificări oricând)" value={cfg.quietHours || ''} onChange={e => upd('quietHours', e.target.value)} />
            <label className="fld">Link recenzie Google (trimis automat clientului când marchezi lead-ul „câștigat")</label>
            <input className="txt" placeholder="https://g.page/r/…/review" value={cfg.reviewLink || ''} onChange={e => upd('reviewLink', e.target.value)} />
          </div>
          <div className="panel">
            <div className="ap-group-title">📅 Program & sloturi de programare</div>
            <label className="fld">Zilele în care primești programări</label>
            <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', padding: '4px 0 2px' }}>
              {([['Lun', 1], ['Mar', 2], ['Mie', 3], ['Joi', 4], ['Vin', 5], ['Sâm', 6], ['Dum', 0]] as [string, number][]).map(([lbl, d]) => {
                const days: number[] = Array.isArray(cfg.workDays) && cfg.workDays.length ? cfg.workDays : [1, 2, 3, 4, 5];
                const on = days.includes(d);
                return (
                  <label key={lbl} style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', fontSize: 14 }}>
                    <input type="checkbox" checked={on} onChange={() => {
                      const next = on ? days.filter(x => x !== d) : [...days, d];
                      upd('workDays', next.length ? next : [1, 2, 3, 4, 5]);
                    }} />
                    {lbl}
                  </label>
                );
              })}
            </div>
            <label className="fld">Orele propuse pentru programări (separate prin virgulă, max 4)</label>
            <input className="txt" placeholder="ex. 10:00, 16:00"
              defaultValue={(Array.isArray(cfg.bookingSlots) ? cfg.bookingSlots : []).join(', ')}
              onChange={e => upd('bookingSlots', e.target.value.split(',').map(s => s.trim()).filter(s => /\d{1,2}[:.]\d{2}/.test(s)).slice(0, 4))} />
            <p className="muted" style={{ fontSize: 13, margin: '6px 0 0' }}>
              AI-ul propune clienților doar sloturi libere din calendarul tău, în aceste zile și la aceste ore. Gol = luni-vineri, 10:00 & 16:00.
            </p>
          </div>
          <div className="ap-savebar">
            <button className="btn btn-primary" onClick={save}>Salvează modificările</button>
            {saved && <span className="ap-savedmsg">Salvat ✓</span>}
          </div>
        </div>
        <div className="ap-darkcard">
          <b><IconPlay /> Testează pe viu</b>
          <p>Ai un demo pe datele afacerii tale (servicii, prețuri, cunoștințe, documente). Salvează, apoi testează exact cum le răspunde asistentul clienților tăi.</p>
          <Link href="/app/demo" className="btn btn-ondark btn-sm">Deschide „Testează AI"</Link>
        </div>
      </div>
    </>
  );
}
