'use client';
export const dynamic = 'force-dynamic';
import { useEffect, useState } from 'react';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconSparkles = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 4l1.8 4.7L18.5 10.5l-4.7 1.8L12 17l-1.8-4.7L5.5 10.5l4.7-1.8zM19 16l.9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9z" />
  </svg>
);
const IconBook = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5v14zM4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5" />
  </svg>
);
const IconPlay = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M6 4.5v15l13-7.5z" />
  </svg>
);

export default function Config() {
  const [cfg, setCfg] = useState<any>(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => { fetch('/api/account/config').then(r => r.json()).then(setCfg); }, []);
  if (!cfg) return <p className="ap-loading">Se încarcă…</p>;
  const upd = (k: string, v: any) => { setCfg({ ...cfg, [k]: v }); setSaved(false); };
  async function save() {
    await fetch('/api/account/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cfg) });
    setSaved(true);
  }
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Configurare AI — „creierul” Leaply</h1>
          <p className="ap-sub">Ce știe și cum vorbește asistentul tău. Se aplică pe toate canalele.</p>
        </div>
      </div>
      <div className="ap-cols ap-cols-wide">
        <div>
          <div className="panel">
            <div className="ap-group-title"><IconSparkles /> Identitate & ton</div>
            <label className="fld">Numele afacerii</label>
            <input className="txt" value={cfg.businessName || ''} onChange={e => upd('businessName', e.target.value)} />
            <label className="fld">Ton</label>
            <input className="txt" value={cfg.tone || ''} onChange={e => upd('tone', e.target.value)} />
            <label className="fld">Mesaj de bun venit</label>
            <textarea className="txt" rows={2} value={cfg.welcome || ''} onChange={e => upd('welcome', e.target.value)} />
          </div>
          <div className="panel">
            <div className="ap-group-title"><IconBook /> Cunoștințe & calificare</div>
            <label className="fld">Servicii & prețuri (un rând: Nume | preț)</label>
            <textarea className="txt" rows={3} value={(cfg.services || []).map((s: any) => `${s.name} | ${s.price}`).join('\n')}
              onChange={e => upd('services', e.target.value.split('\n').filter(Boolean).map(l => { const [name, price] = l.split('|'); return { name: (name || '').trim(), price: (price || '').trim() }; }))} />
            <label className="fld">Întrebări de calificare (o întrebare pe rând)</label>
            <textarea className="txt" rows={3} value={(cfg.qualificationQuestions || []).map((q: any) => q.q).join('\n')}
              onChange={e => upd('qualificationQuestions', e.target.value.split('\n').filter(Boolean).map((q, i) => ({ key: `q${i + 1}`, q: q.trim() })))} />
            <label className="fld">Cunoștințe despre afacere (importate de pe site + orice altceva vrei să știe)</label>
            <textarea className="txt" rows={5} value={cfg.knowledge || ''} onChange={e => upd('knowledge', e.target.value)}
              placeholder="Program, zonă de acoperire, garanții, diferențiatori, întrebări frecvente…" />
            <label className="fld">Reguli și limite (asistentul le respectă STRICT)</label>
            <textarea className="txt" rows={4} value={cfg.rules || ''} onChange={e => upd('rules', e.target.value)}
              placeholder="ex. Nu promite termene. Nu oferi discounturi. Nu discuta concurența. Nu prelua comenzi telefonice." />
          </div>
          <div className="ap-savebar">
            <button className="btn btn-primary" onClick={save}>Salvează modificările</button>
            {saved && <span className="ap-savedmsg">Salvat ✓</span>}
          </div>
        </div>
        <div className="ap-darkcard">
          <b><IconPlay /> Testează pe viu</b>
          <p>Modificările se aplică imediat. Deschide pagina de demo ca să vezi cum răspunde asistentul cu noua configurare.</p>
          <a href="/demo" target="_blank" className="btn btn-ondark btn-sm">Deschide demo</a>
        </div>
      </div>
    </>
  );
}
