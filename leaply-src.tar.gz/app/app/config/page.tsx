'use client';
import { useEffect, useState } from 'react';

export default function Config() {
  const [cfg, setCfg] = useState<any>(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => { fetch('/api/account/config').then(r => r.json()).then(setCfg); }, []);
  if (!cfg) return <p>Se încarcă…</p>;
  const upd = (k: string, v: any) => { setCfg({ ...cfg, [k]: v }); setSaved(false); };
  async function save() {
    await fetch('/api/account/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cfg) });
    setSaved(true);
  }
  return (
    <>
      <h1 className="h-title">Configurare AI — „creierul" Leaply</h1>
      <p className="h-sub">Ce știe și cum vorbește asistentul tău. Se aplică pe toate canalele.</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20, alignItems: 'start' }}>
        <div className="panel">
          <label className="fld">Numele afacerii</label>
          <input className="txt" value={cfg.businessName || ''} onChange={e => upd('businessName', e.target.value)} />
          <label className="fld">Ton</label>
          <input className="txt" value={cfg.tone || ''} onChange={e => upd('tone', e.target.value)} />
          <label className="fld">Mesaj de bun venit</label>
          <textarea className="txt" rows={2} value={cfg.welcome || ''} onChange={e => upd('welcome', e.target.value)} />
          <label className="fld">Servicii & prețuri (un rând: Nume | preț)</label>
          <textarea className="txt" rows={3} value={(cfg.services || []).map((s: any) => `${s.name} | ${s.price}`).join('\n')}
            onChange={e => upd('services', e.target.value.split('\n').filter(Boolean).map(l => { const [name, price] = l.split('|'); return { name: (name || '').trim(), price: (price || '').trim() }; }))} />
          <label className="fld">Întrebări de calificare (o întrebare pe rând)</label>
          <textarea className="txt" rows={3} value={(cfg.qualificationQuestions || []).map((q: any) => q.q).join('\n')}
            onChange={e => upd('qualificationQuestions', e.target.value.split('\n').filter(Boolean).map((q, i) => ({ key: `q${i + 1}`, q: q.trim() })))} />
          <div style={{ marginTop: 18, display: 'flex', gap: 12, alignItems: 'center' }}>
            <button className="btn btn-primary" onClick={save}>Salvează</button>
            {saved && <span style={{ color: '#16A34A', fontWeight: 600 }}>✓ Salvat</span>}
          </div>
        </div>
        <div className="panel" style={{ background: '#0B2A4A', color: '#fff', border: 'none' }}>
          <b style={{ color: '#C6F24E' }}>Testează pe viu</b>
          <p style={{ color: '#b9c6d6', fontSize: 14, lineHeight: 1.5 }}>Modificările se aplică imediat. Deschide pagina de demo ca să vezi cum răspunde asistentul cu noua configurare.</p>
          <a href="/demo" target="_blank" className="btn btn-primary btn-sm">Deschide demo ▸</a>
        </div>
      </div>
    </>
  );
}
