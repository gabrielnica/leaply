'use client';
import { useState } from 'react';

// Reimport de cunoștințe de pe site — oricând, nu doar la crearea contului.
export function SiteImport({ initialUrl, onDone }: { initialUrl: string; onDone?: () => void }) {
  const [url, setUrl] = useState(initialUrl);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  async function run() {
    if (!url.trim() || busy) return;
    setBusy(true); setMsg(null);
    try {
      const r = await fetch('/api/knowledge/site', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: url.trim() }) });
      const d = await r.json();
      if (!r.ok) setMsg({ ok: false, text: d.error || 'Nu am putut citi site-ul.' });
      else {
        setMsg({
          ok: true,
          text: `Am citit ${d.pages} pagin${d.pages === 1 ? 'ă' : 'i'} și am actualizat documentul „Site". ${d.addedServices?.length ? `Servicii noi adăugate: ${d.addedServices.join(', ')}.` : 'Niciun serviciu nou — lista ta rămâne neatinsă.'}`,
        });
        onDone?.();
      }
    } catch { setMsg({ ok: false, text: 'Eroare de rețea.' }); }
    setBusy(false);
  }
  return (
    <div className="panel">
      <div className="ap-group-title">🌐 Site-ul tău</div>
      <p className="ap-sub" style={{ marginTop: 0 }}>Asistentul citește site-ul (prima pagină + servicii/prețuri/contact/despre) și învață singur. Serviciile deja editate de tine nu se ating.</p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <input className="txt" style={{ flex: 1, minWidth: 200 }} placeholder="firma.ro" value={url} onChange={e => setUrl(e.target.value)} />
        <button className="btn btn-dark btn-sm" disabled={busy || !url.trim()} onClick={run}>{busy ? 'Citesc site-ul…' : '↻ Reimportă de pe site'}</button>
      </div>
      {msg && <p style={{ color: msg.ok ? '#1E7B44' : '#C0392B', fontSize: 13.5, marginBottom: 0 }}>{msg.text}</p>}
      <p className="muted" style={{ fontSize: 12.5, marginBottom: 0 }}>Se actualizează automat și lunar, în fundal.</p>
    </div>
  );
}
