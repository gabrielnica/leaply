'use client';
import { useEffect, useRef, useState } from 'react';

// Documente firmă: PDF / TXT / CSV / MD — asistentul citește din ele când răspunde.
export function DocsPanel() {
  const [docs, setDocs] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const load = () => fetch('/api/knowledge/docs').then(r => r.json()).then(d => setDocs(d.docs || [])).catch(() => {});
  useEffect(() => { load(); }, []);

  async function upload(f: File) {
    setBusy(true); setErr('');
    const fd = new FormData(); fd.append('file', f);
    try {
      const r = await fetch('/api/knowledge/docs', { method: 'POST', body: fd });
      const d = await r.json();
      if (!r.ok) setErr(d.error || 'Eroare la upload'); else load();
    } catch { setErr('Eroare de rețea'); }
    setBusy(false);
    if (fileRef.current) fileRef.current.value = '';
  }
  async function del(id: string) {
    await fetch(`/api/knowledge/docs?id=${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
    load();
  }
  const kb = (n: number) => n > 1024 ? `${Math.round(n / 1024)} KB` : `${n} B`;
  return (
    <div className="panel">
      <div className="ap-group-title">📄 Documente firmă (PDF, TXT, CSV)</div>
      <p className="ap-sub" style={{ marginTop: 0 }}>Liste de prețuri, oferte, regulamente — asistentul citește din ele când răspunde lead-urilor. Max 10 documente.</p>
      {docs.map(d => (
        <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '7px 0', borderBottom: '1px solid rgba(16,18,20,.07)', fontSize: 14 }}>
          <span>📎 <b>{d.name}</b> <span className="muted" style={{ fontSize: 12 }}>({kb(d.size)})</span></span>
          <button className="btn btn-sm" onClick={() => del(d.id)}>Șterge</button>
        </div>
      ))}
      {docs.length === 0 && <p className="muted" style={{ fontSize: 13 }}>Niciun document încă.</p>}
      <div style={{ marginTop: 10 }}>
        <input ref={fileRef} type="file" accept=".pdf,.txt,.csv,.md" style={{ display: 'none' }}
          onChange={e => { const f = e.target.files?.[0]; if (f) upload(f); }} />
        <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => fileRef.current?.click()}>
          {busy ? 'Se încarcă…' : '+ Adaugă document'}
        </button>
        {err && <span style={{ color: '#C0392B', fontSize: 13, marginLeft: 10 }}>{err}</span>}
      </div>
    </div>
  );
}
