'use client';
import { useEffect } from 'react';

// UX nativ (doar în app-ul Capacitor): pull-to-refresh + haptic feedback la atingeri.
// No-op în browser normal.
export function NativeUX() {
  useEffect(() => {
    const w = window as any;
    const Cap = w.Capacitor;
    if (!Cap || typeof Cap.isNativePlatform !== 'function' || !Cap.isNativePlatform()) return;
    const Haptics = Cap.Plugins?.Haptics;
    const buzz = (style: string) => { try { Haptics?.impact?.({ style }); } catch {} };

    // 1) Haptic ușor la tap pe butoane / linkuri de navigație
    const onClick = (e: any) => {
      const t = e.target?.closest?.('button, .btn, .ap-nav-link, .ap-asst-chip');
      if (t && !t.hasAttribute('disabled')) buzz('LIGHT');
    };
    document.addEventListener('click', onClick, true);

    // 2) Pull-to-refresh: tragi în jos din capul paginii → reîncarcă
    const ptr = document.createElement('div');
    ptr.className = 'ap-ptr';
    ptr.innerHTML = '<span class="ap-ptr-spin"></span>';
    document.body.appendChild(ptr);
    let startY = 0, pulling = false, dist = 0;
    const THRESH = 72, MAX = 88;
    const onStart = (e: any) => {
      if (window.scrollY <= 0) { startY = e.touches[0].clientY; pulling = true; dist = 0; }
    };
    const onMove = (e: any) => {
      if (!pulling) return;
      dist = e.touches[0].clientY - startY;
      if (dist > 0 && window.scrollY <= 0) {
        ptr.style.height = Math.min(dist * 0.5, MAX) + 'px';
      } else { pulling = false; ptr.style.height = '0px'; }
    };
    const onEnd = () => {
      if (pulling && dist > THRESH) {
        buzz('MEDIUM');
        ptr.style.height = MAX + 'px';
        setTimeout(() => { try { location.reload(); } catch {} }, 130);
      } else {
        ptr.style.height = '0px';
      }
      pulling = false; dist = 0;
    };
    document.addEventListener('touchstart', onStart, { passive: true });
    document.addEventListener('touchmove', onMove, { passive: true });
    document.addEventListener('touchend', onEnd, { passive: true });

    return () => {
      document.removeEventListener('click', onClick, true);
      document.removeEventListener('touchstart', onStart);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onEnd);
      try { ptr.remove(); } catch {}
    };
  }, []);
  return null;
}
