'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Logo } from '../../lib/logo';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconHome = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M3 10.5 12 3.5l9 7V20a1 1 0 0 1-1 1h-5.5v-6h-5v6H4a1 1 0 0 1-1-1z" /></svg>
);
const IconChat = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" /></svg>
);
const IconPlug = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M9 7V3M15 7V3M7 7h10v4a5 5 0 0 1-5 5 5 5 0 0 1-5-5zM12 16v5" /></svg>
);
const IconSparkles = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 4l1.8 4.7L18.5 10.5l-4.7 1.8L12 17l-1.8-4.7L5.5 10.5l4.7-1.8zM19 16l.9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9z" /></svg>
);
const IconChart = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M3 3v18h18M8 16v-5M13 16V8M18 16v-8" /></svg>
);
const IconSettings = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="12" cy="12" r="3.2" /><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.11-1.56 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.56-1.11 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.09a1.7 1.7 0 0 0 1.03-1.56V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.09a1.7 1.7 0 0 0 1.56 1.03H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.51 1.87z" /></svg>
);
const IconShield = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 3l8 3v6c0 4.8-3.4 8-8 9-4.6-1-8-4.2-8-9V6z" /></svg>
);
const IconOut = () => (
  <svg width="19" height="19" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><path d="m16 17 5-5-5-5" /><path d="M21 12H9" /></svg>
);

type NavItem = { href: string; label: string; icon: React.ReactNode; exact?: boolean; also?: string };

export function Sidebar({ userName, businessName, isAdmin }: { userName: string; businessName: string; isAdmin: boolean }) {
  const pathname = usePathname();
  const router = useRouter();
  const NAV: NavItem[] = [
    { href: '/app', label: 'Overview', icon: <IconHome />, exact: true },
    { href: '/app/inbox', label: 'Lead-uri / Inbox', icon: <IconChat />, also: '/app/conversation' },
    { href: '/app/channels', label: 'Canale', icon: <IconPlug /> },
    { href: '/app/config', label: 'Configurare AI', icon: <IconSparkles /> },
    { href: '/app/reports', label: 'Rapoarte', icon: <IconChart /> },
    { href: '/app/settings', label: 'Setări & Plan', icon: <IconSettings /> },
    ...(isAdmin ? [{ href: '/admin', label: 'Admin', icon: <IconShield /> }] : []),
  ];
  const isActive = (item: NavItem) => {
    if (item.exact) return pathname === item.href;
    if (item.also && pathname.startsWith(item.also)) return true;
    return pathname.startsWith(item.href);
  };
  const logout = async () => {
    try { await fetch('/api/auth/logout', { method: 'POST' }); } catch {}
    router.push('/login');
    router.refresh();
  };
  return (
    <aside className="ap-side">
      <div className="ap-side-logo"><Logo light size={26} /></div>
      <nav className="ap-nav">
        {NAV.map(item => (
          <Link key={item.href} href={item.href} className={`ap-nav-link${isActive(item) ? ' is-active' : ''}`}>
            {item.icon}
            <span className="ap-nav-label">{item.label}</span>
          </Link>
        ))}
      </nav>
      <div className="ap-side-foot">
        <div className="ap-user">
          <span className="ap-user-avatar">{(userName || '?').charAt(0).toUpperCase()}</span>
          <span className="ap-user-info"><b>{userName}</b><span>{businessName}</span></span>
        </div>
        <button type="button" className="ap-nav-link ap-logout" onClick={logout}>
          <IconOut />
          <span className="ap-nav-label">Ieși din cont</span>
        </button>
      </div>
    </aside>
  );
}
