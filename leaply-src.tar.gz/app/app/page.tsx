import Link from 'next/link';
import { getAccount, stats, listConversations, listChannels } from '../../lib/store';
import { getIntegrations } from '../../lib/integrations';
import { funnelByChannel } from '../../lib/store';
import { getSessionUser } from '../../lib/auth';
import { usageThisMonth, limitFor } from '../../lib/usage';
import { trialDaysLeft } from '../../lib/plan';
import { db } from '../../lib/db';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconUsers = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.85M15.5 3.15a4 4 0 0 1 0 7.7" />
  </svg>
);
const IconClock = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />
  </svg>
);
const IconCalendar = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" />
  </svg>
);
const IconCoins = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 7v10M15.5 9.5c-.7-1-1.9-1.5-3.5-1.5-1.9 0-3 1-3 2.2 0 3 6.8 1.5 6.8 4.4 0 1.3-1.4 2.4-3.3 2.4-1.7 0-3-.6-3.7-1.6" />
  </svg>
);
const IconZap = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12z" />
  </svg>
);
const IconChevron = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M9 6l6 6-6 6" />
  </svg>
);

const STATUS_RO: Record<string, string> = {
  active: 'Activ', human: 'Preluat', booked: 'Programat', qualified: 'Calificat', lost: 'Pierdut',
};
const fmtResp = (ms: number) => (!ms || ms < 1000) ? '<1s' : `${Math.round(ms / 1000)}s`;

export default function Overview() {
  const user = getSessionUser()!;
  const acc = getAccount(user.account_id);
  const s = stats(user.account_id);
  const allConvs = listConversations(user.account_id);
  const convs = allConvs.slice(0, 6);
  const fmt = (n: number) => n.toLocaleString('ro-RO');

  // utilizare plan (luna curentă)
  const used = usageThisMonth(user.account_id);
  const limit = limitFor(acc.plan);
  const usagePct = limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const usageHot = limit > 0 && used / limit >= 0.9;
  const savedHours = Math.round((used * 10) / 60);

  // checklist de activare — „3 pași până la primul lead"
  const chans = listChannels(user.account_id);
  const integ = getIntegrations(user.account_id);
  const cfgA = acc.config || {};
  const steps = [
    { done: Boolean((cfgA.services || []).length || cfgA.knowledge), label: 'Configurează asistentul', desc: 'Servicii, cunoștințe, reguli — ca să răspundă corect.', href: '/app/config', cta: 'Configurează' },
    { done: chans.some((c: any) => c.status === 'connected' && !['webform', 'calendar'].includes(c.type)), label: 'Conectează un canal', desc: 'WhatsApp, Messenger, Instagram sau telefon — de unde vin lead-urile.', href: '/app/channels', cta: 'Conectează' },
    { done: Boolean(integ.google?.refresh_token), label: 'Conectează calendarul', desc: 'Ca AI-ul să propună ore reale și să adauge programările.', href: '/app/settings', cta: 'Conectează' },
  ];
  const stepsDone = steps.filter(x => x.done).length;
  const showChecklist = stepsDone < steps.length;
  const funnel = funnelByChannel(user.account_id);
  const CH_RO: Record<string, string> = { whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram', webform: 'Formular web', voice: 'Telefon', meta_lead_ads: 'Lead Ads', landing: 'Landing', import: 'Import', api: 'API' };

  // activitate ultimele 14 zile — grupare pe ziua din created_at
  const byDay = new Map<string, number>();
  for (const c of allConvs) {
    const k = String(c.created_at || '').slice(0, 10);
    if (k) byDay.set(k, (byDay.get(k) || 0) + 1);
  }
  const days = Array.from({ length: 14 }, (_, i) => {
    const key = new Date(Date.now() - (13 - i) * 86400000).toISOString().slice(0, 10);
    return { key, day: key.slice(8, 10), label: `${key.slice(8, 10)}.${key.slice(5, 7)}`, count: byDay.get(key) || 0 };
  });
  const maxCount = Math.max(1, ...days.map(d => d.count));
  const total14 = days.reduce((s, d) => s + d.count, 0);
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Bună, {(user.name || '').split(' ')[0] || acc.name}</h1>
          <p className="ap-sub">Iată ce a lucrat Leaply pentru tine</p>
        </div>
        {(() => {
          const tl = trialDaysLeft(user.account_id);
          const { planLabel } = require('../../lib/plan');
          return <span className="pill">Pachet {planLabel(acc.plan)}{tl !== null ? ` · ${tl > 0 ? `${tl} ${tl === 1 ? 'zi' : 'zile'} rămase` : 'expirat'}` : ''}</span>;
        })()}
      </div>

      {showChecklist && (
        <div className="panel ap-onboard" style={{ border: '1.5px solid var(--accent, #FF4D1F)', marginBottom: 18 }}>
          <div className="ap-panel-head">
            <span className="ap-panel-title">Pornește motorul — {stepsDone}/3 pași</span>
            <span className="pill">{stepsDone === 0 ? 'să începem' : stepsDone === steps.length - 1 ? 'ultimul pas' : 'aproape gata'}</span>
          </div>
          <div className="ap-onboard-bar"><div style={{ width: `${Math.round((stepsDone / steps.length) * 100)}%` }} /></div>
          {steps.map((st, i) => {
            const isCurrent = !st.done && steps.slice(0, i).every(x => x.done);
            const cls = st.done ? 'is-done' : isCurrent ? 'is-current' : 'is-todo';
            return (
              <div key={i} className={`ap-onboard-step ${cls}`}>
                <span className="ap-onboard-num">{st.done ? '✓' : i + 1}</span>
                <span className="ap-lead">
                  <span className="ap-lead-name">{st.label}</span>
                  {!st.done && <span className="ap-lead-meta">{st.desc}</span>}
                </span>
                {st.done
                  ? <span className="connected">Gata</span>
                  : <Link href={st.href} className={`btn btn-sm ${isCurrent ? 'btn-primary' : 'btn-secondary'}`}>{st.cta}</Link>}
              </div>
            );
          })}
        </div>
      )}

      {funnel.length > 0 && (
        <div className="panel">
          <div className="ap-panel-head"><span className="ap-panel-title">Funnel pe canale — lead → calificat → programat</span></div>
          <div className="ap-table-head" style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr 1fr' }}>
            <span>Canal</span><span>Lead-uri</span><span>Calificați</span><span>Programați</span><span>Conversie</span>
          </div>
          {funnel.map((f: any) => (
            <div key={f.channel} className="ap-table-row" style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr 1fr' }}>
              <span>{CH_RO[f.channel] || f.channel}</span>
              <span className="ap-cell-num">{f.leads}</span>
              <span className="ap-cell-num">{f.qualified}</span>
              <span className="ap-cell-num">{f.booked}</span>
              <span className="ap-cell-num ap-cell-conv">{f.leads ? Math.round((f.booked / f.leads) * 100) : 0}%</span>
            </div>
          ))}
        </div>
      )}

      <div className="ap-kpis">
        <div className="ap-kpi">
          <span className="ap-kpi-ico"><IconUsers /></span>
          <div className="ap-kpi-l">Lead-uri captate</div>
          <div className="ap-kpi-v">{s.leads}</div>
        </div>
        <div className="ap-kpi">
          <span className="ap-kpi-ico"><IconClock /></span>
          <div className="ap-kpi-l">Timp mediu de răspuns</div>
          <div className="ap-kpi-v">{s.avgSec < 1 ? '<1s' : `${s.avgSec}s`}</div>
        </div>
        <div className="ap-kpi">
          <span className="ap-kpi-ico"><IconCalendar /></span>
          <div className="ap-kpi-l">Programări făcute</div>
          <div className="ap-kpi-v">{s.booked}</div>
        </div>
        {(() => {
          // ROI real: suma lead-urilor marcate „câștigate" luna asta; fallback pe estimare
          const won = (db().prepare("SELECT COALESCE(SUM(won_value),0) s FROM conversations WHERE account_id=? AND won_value IS NOT NULL AND created_at >= date('now','start of month')").get(user.account_id) as any).s;
          return (
            <div className="ap-kpi ap-kpi-hero">
              <span className="ap-kpi-ico"><IconCoins /></span>
              <div className="ap-kpi-l">{won > 0 ? 'Venit adus (confirmat de tine)' : 'Lead-uri salvate (estimat)'}</div>
              <div className="ap-kpi-v">{fmt(won > 0 ? won : s.savedLei)}<span className="ap-kpi-unit">lei</span></div>
            </div>
          );
        })()}
      </div>

      <div className="ap-ov-grid">
        <div className="panel ap-ov-usage">
          <div className="ap-panel-head">
            <span className="ap-panel-title">Utilizare plan</span>
            <Link href="/app/settings" className="ap-link">Setări</Link>
          </div>
          <div className="ap-ov-usage-num">
            {fmt(used)}<span>din {fmt(limit)} conversații</span>
          </div>
          <div className="ap-usage-bar" role="progressbar" aria-valuenow={used} aria-valuemin={0} aria-valuemax={limit} aria-label="Conversații folosite luna aceasta">
            <div className={`ap-usage-fill${usageHot ? ' is-hot' : ''}`} style={{ width: `${usagePct}%` }} />
          </div>
          <p className="ap-ov-usage-hint">
            Pachetul {require('../../lib/plan').planLabel(acc.plan)}, luna aceasta. Ai nevoie de mai mult? <Link href="/app/settings" className="ap-link">Treci pe un pachet mai mare sau adaugă resurse</Link>.
          </p>
        </div>

        <div className="panel ap-ov-chart">
          <div className="ap-panel-head">
            <span className="ap-panel-title">Activitate ultimele 14 zile</span>
            <span className="pill">{fmt(total14)} conversații</span>
          </div>
          <svg className="ap-chart" viewBox="0 0 560 102" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Număr de conversații pe zi în ultimele 14 zile">
            {days.map((d, i) => {
              const h = d.count > 0 ? Math.max(5, Math.round((d.count / maxCount) * 58)) : 0;
              const bx = i * 40 + 6, top = 74 - h;
              return (
                <g key={d.key} className="ap-bar">
                  <title>{`${d.label}: ${d.count} ${d.count === 1 ? 'conversație' : 'conversații'}`}</title>
                  <rect x={bx} y={14} width={28} height={60} rx={5} className="ap-bar-bg" />
                  {h > 0 && <rect x={bx} y={top} width={28} height={h} rx={4} className="ap-bar-fill" />}
                  {d.count > 0 && <text x={bx + 14} y={top - 4} textAnchor="middle" className="ap-bar-val">{d.count}</text>}
                  <text x={bx + 14} y={94} textAnchor="middle">{d.day}</text>
                </g>
              );
            })}
          </svg>
          {used > 0 && (
            <p className="ap-ov-moto">
              Leaply a răspuns la <b>{fmt(used)}</b> lead-uri luna aceasta — echivalentul a <b>~{fmt(savedHours)} ore</b> de muncă.
            </p>
          )}
        </div>
      </div>

      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title">Ce s-a întâmplat cât nu erai</span>
          <Link href="/app/inbox" className="ap-link">Vezi toate</Link>
        </div>
        {convs.length === 0 && (
          <div className="ap-empty">
            <span className="ap-empty-ico"><svg viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" /></svg></span>
            <h3>Încă niciun lead aici</h3>
            <p>Conectează un canal sau testează-ți asistentul — lead-urile vor apărea aici automat, în timp real.</p>
            <div className="ap-empty-cta">
              <Link href="/app/channels" className="btn btn-primary btn-sm">Conectează un canal</Link>
              <Link href="/app/config" className="btn btn-secondary btn-sm">Testează asistentul</Link>
            </div>
          </div>
        )}
        {convs.map(c => (
          <Link key={c.id} href={`/app/conversation/${c.id}`} className="row ap-rowlink">
            <span className="ap-lead">
              <span className="ap-lead-name">{c.lead_name}</span>
              <span className="ap-lead-meta">{c.source}</span>
            </span>
            <span className="ap-row-right">
              <span className="pill">{fmtResp(c.first_response_ms)}</span>
              <span className={`badge b-${c.status}`}>{STATUS_RO[c.status] || c.status}</span>
              <span className="ap-row-chev"><IconChevron /></span>
            </span>
          </Link>
        ))}
      </div>

      <div className="ap-note">
        <IconZap />
        <div>
          <b>Leaply lucrează când tu dormi.</b>
          <p>Lead-urile care vin seara, în weekend sau când ești ocupat primesc răspuns în sub o secundă — exact cele care altfel s-ar pierde.</p>
        </div>
      </div>
    </>
  );
}
