import Link from 'next/link';
import { getAccount, stats, listConversations } from '../../lib/store';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconUsers = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.85M15.5 3.15a4 4 0 0 1 0 7.7" />
  </svg>
);
const IconClock = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" />
  </svg>
);
const IconCalendar = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" />
  </svg>
);
const IconCoins = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 7v10M15.5 9.5c-.7-1-1.9-1.5-3.5-1.5-1.9 0-3 1-3 2.2 0 3 6.8 1.5 6.8 4.4 0 1.3-1.4 2.4-3.3 2.4-1.7 0-3-.6-3.7-1.6" />
  </svg>
);
const IconZap = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12z" />
  </svg>
);
const IconChevron = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M9 6l6 6-6 6" />
  </svg>
);

const STATUS_RO: Record<string, string> = {
  active: 'Activ', human: 'Preluat', booked: 'Programat', qualified: 'Calificat', lost: 'Pierdut',
};
const fmtResp = (ms: number) => (!ms || ms < 1000) ? '<1s' : `${Math.round(ms / 1000)}s`;

export default function Overview() {
  const acc = getAccount();
  const s = stats();
  const convs = listConversations().slice(0, 6);
  const fmt = (n: number) => n.toLocaleString('ro-RO');
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Bună, {acc.name}</h1>
          <p className="ap-sub">Iată ce a lucrat Leaply pentru tine</p>
        </div>
        <span className="pill">Plan {acc.plan}</span>
      </div>

      <div className="ap-kpis">
        <div className="ap-kpi">
          <div className="ap-kpi-l"><IconUsers /> Lead-uri captate</div>
          <div className="ap-kpi-v">{s.leads}</div>
        </div>
        <div className="ap-kpi">
          <div className="ap-kpi-l"><IconClock /> Timp mediu de răspuns</div>
          <div className="ap-kpi-v">{s.avgSec < 1 ? '<1s' : `${s.avgSec}s`}</div>
        </div>
        <div className="ap-kpi">
          <div className="ap-kpi-l"><IconCalendar /> Programări făcute</div>
          <div className="ap-kpi-v">{s.booked}</div>
        </div>
        <div className="ap-kpi ap-kpi-hero">
          <div className="ap-kpi-l"><IconCoins /> Lead-uri salvate (estimat)</div>
          <div className="ap-kpi-v">{fmt(s.savedLei)}<span className="ap-kpi-unit">lei</span></div>
        </div>
      </div>

      <div className="panel">
        <div className="ap-panel-head">
          <span className="ap-panel-title">Ce s-a întâmplat cât nu erai</span>
          <Link href="/app/inbox" className="ap-link">Vezi toate</Link>
        </div>
        {convs.map(c => (
          <Link key={c.id} href={`/app/conversation/${c.id}`} className="row ap-rowlink">
            <span className="ap-lead">
              <span className="ap-lead-name">{c.lead_name}</span>
              <span className="ap-lead-meta">{c.source}</span>
            </span>
            <span className="ap-row-right">
              <span className="pill">{fmtResp(c.first_response_ms)}</span>
              <span className={`badge b-${c.status}`}>{STATUS_RO[c.status] || c.status}</span>
              <span className="ap-row-chev"><IconChevron /></span>
            </span>
          </Link>
        ))}
      </div>

      <div className="ap-note">
        <IconZap />
        <div>
          <b>Leaply lucrează când tu dormi.</b>
          <p>3 din lead-urile de mai sus au venit seara sau în weekend — când firma era închisă. Fără răspuns instant, s-ar fi pierdut.</p>
        </div>
      </div>
    </>
  );
}
