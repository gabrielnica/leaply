import Link from 'next/link';
import { getAccount, stats, listConversations } from '../../lib/store';

export const dynamic = 'force-dynamic';

export default function Overview() {
  const acc = getAccount();
  const s = stats();
  const convs = listConversations().slice(0, 6);
  const fmt = (n: number) => n.toLocaleString('ro-RO');
  return (
    <>
      <div className="topbar">
        <div><h1 className="h-title">Bună, {acc.name} 👋</h1><p className="h-sub">Iată ce a lucrat Leaply pentru tine</p></div>
        <span className="pill">Plan {acc.plan}</span>
      </div>
      <div className="kpis">
        <div className="kpi"><div className="l">Lead-uri captate</div><div className="v">{s.leads}</div></div>
        <div className="kpi"><div className="l">Timp mediu de răspuns</div><div className="v">{s.avgSec}s</div></div>
        <div className="kpi"><div className="l">Programări făcute</div><div className="v">{s.booked}</div></div>
        <div className="kpi hero"><div className="l">Lead-uri salvate (estimat)</div><div className="v">{fmt(s.savedLei)} lei</div></div>
      </div>
      <div className="panel">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          <b>Ce s-a întâmplat cât nu erai</b><Link href="/app/inbox" style={{ color: '#1E5BFF', fontSize: 14 }}>Vezi toate →</Link>
        </div>
        {convs.map(c => (
          <Link key={c.id} href={`/app/conversation/${c.id}`} className="row" style={{ color: 'inherit' }}>
            <span><b>{c.lead_name}</b> · <span style={{ color: '#64748b' }}>{c.source}</span></span>
            <span style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <span className="pill">{Math.round((c.first_response_ms || 0) / 1000)}s</span>
              <span className={`badge b-${c.status}`}>{c.status}</span>
            </span>
          </Link>
        ))}
      </div>
      <div className="panel" style={{ background: '#0B2A4A', color: '#fff', border: 'none' }}>
        <b style={{ color: '#C6F24E' }}>💡 Leaply lucrează când tu dormi.</b> 3 din lead-urile de mai sus au venit seara sau în weekend — când firma era închisă. Fără răspuns instant, s-ar fi pierdut.
      </div>
    </>
  );
}
