'use client';
import { useState } from 'react';

export function ImportPanel() {
  const [open, setOpen] = useState(false);
  const [csv, setCsv] = useState('');
  const [campaign, setCampaign] = useState(false);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<string>('');
  async function run() {
    setBusy(true); setRes('');
    try {
      const r = await fetch('/api/leads/import', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csv, campaign, message }),
      });
      const j = await r.json();
      setRes(r.ok ? `Import gata: ${j.imported} lead-uri noi, ${j.skipped} sărite (duplicate/telefon invalid)${campaign ? `, ${j.sent} SMS-uri trimise` : ''}.` : (j.error || 'Eroare.'));
      if (r.ok) { setCsv(''); }
    } catch { setRes('Eroare de conexiune.'); }
    setBusy(false);
  }
  if (!open) return <button type="button" className="btn btn-secondary btn-sm" onClick={() => setOpen(true)}>Importă CSV</button>;
  return (
    <div className="panel" style={{ marginBottom: 14 }}>
      <div className="ap-panel-head"><span className="ap-panel-title">Import lead-uri din CSV</span>
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => setOpen(false)}>Închide</button></div>
      <p className="ap-fhint">Un lead pe rând: <code>nume,telefon</code> (opțional și sursa: <code>nume,telefon,sursă</code>). Max 200 pe import; duplicatele se sar automat.</p>
      <textarea className="txt" rows={5} value={csv} onChange={e => setCsv(e.target.value)} placeholder={'Ion Popescu,+40712345678\nMaria Ionescu,0723456789,targ 2025'} />
      <label style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '10px 0 6px', fontSize: 14 }}>
        <input type="checkbox" checked={campaign} onChange={e => setCampaign(e.target.checked)} />
        Trimite-le și un SMS de reactivare (max 100)
      </label>
      {campaign && (
        <>
          <textarea className="txt" rows={2} value={message} onChange={e => setMessage(e.target.value)} placeholder="ex. Bună! Suntem [firma]. Avem o ofertă nouă la ... — răspundeți la acest mesaj și vă spunem detaliile." />
          <p className="ap-fhint">⚠️ Trimite doar persoanelor care și-au dat acordul să fie contactate — e responsabilitatea ta legală (GDPR).</p>
        </>
      )}
      <div className="ap-actions">
        <button type="button" className="btn btn-primary btn-sm" onClick={run} disabled={busy || !csv.trim()}>{busy ? 'Se importă…' : 'Importă'}</button>
        {res && <span className="ap-okmsg">{res}</span>}
      </div>
    </div>
  );
}
