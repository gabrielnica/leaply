import Link from 'next/link';
import { listConversations } from '../../../lib/store';
export const dynamic = 'force-dynamic';
export default function Inbox() {
  const convs = listConversations();
  return (
    <>
      <h1 className="h-title">Lead-uri / Inbox</h1>
      <p className="h-sub">Toate conversațiile, din toate canalele, într-un singur loc</p>
      <div className="panel">
        {convs.map(c => (
          <Link key={c.id} href={`/app/conversation/${c.id}`} className="row" style={{ color: 'inherit' }}>
            <span style={{ display: 'flex', flexDirection: 'column' }}>
              <b>{c.lead_name}</b>
              <span style={{ color: '#64748b', fontSize: 13 }}>{c.channel} · {c.phone}</span>
            </span>
            <span style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <span className="pill">{Math.round((c.first_response_ms || 0) / 1000)}s</span>
              <span className={`badge b-${c.status}`}>{c.status}</span>
            </span>
          </Link>
        ))}
      </div>
    </>
  );
}
