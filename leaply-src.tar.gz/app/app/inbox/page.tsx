import Link from 'next/link';
import { listConversationsFiltered } from '../../../lib/store';
import { ImportPanel } from './import-panel';
import { getSessionUser } from '../../../lib/auth';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconWhatsApp = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" />
    <path d="M9 9.5c.5 2.5 3 5 5.5 5.5l1-1.5-2-1-1 .5c-.8-.5-1.5-1.2-2-2l.5-1-1-2z" />
  </svg>
);
const IconMessenger = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 3C7 3 3 6.7 3 11.4c0 2.6 1.2 4.9 3.2 6.4V21l3-1.6c.9.25 1.8.4 2.8.4 5 0 9-3.7 9-8.4S17 3 12 3z" />
    <path d="m7.5 13 3-3 2 2 4-2.5-3 3-2-2z" fill="currentColor" stroke="none" />
  </svg>
);
const IconInstagram = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.2" cy="6.8" r="0.5" fill="currentColor" />
  </svg>
);
const IconMegaphone = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M3 10v4a1 1 0 0 0 1 1h2l4 4V5L6 9H4a1 1 0 0 0-1 1zM14 8a4 4 0 0 1 0 8M17 5a8 8 0 0 1 0 14" />
  </svg>
);
const IconGlobe = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a13.5 13.5 0 0 1 0 18 13.5 13.5 0 0 1 0-18z" />
  </svg>
);
const IconChevron = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M9 6l6 6-6 6" />
  </svg>
);

const CHANNEL_META: Record<string, { label: string; icon: React.ReactNode }> = {
  whatsapp: { label: 'WhatsApp', icon: <IconWhatsApp /> },
  messenger: { label: 'Messenger', icon: <IconMessenger /> },
  instagram: { label: 'Instagram', icon: <IconInstagram /> },
  meta_lead_ads: { label: 'Lead Ads', icon: <IconMegaphone /> },
  webform: { label: 'Formular web', icon: <IconGlobe /> },
  voice: { label: 'Telefon', icon: <IconGlobe /> },
  import: { label: 'Import', icon: <IconGlobe /> },
  api: { label: 'API', icon: <IconGlobe /> },
};
const STATUS_RO: Record<string, string> = {
  active: 'Activ', human: 'Preluat', booked: 'Programat', qualified: 'Calificat', lost: 'Pierdut',
};
const fmtResp = (ms: number) => (!ms || ms < 1000) ? '<1s' : `${Math.round(ms / 1000)}s`;

export default function Inbox({ searchParams }: { searchParams?: { q?: string; status?: string; channel?: string } }) {
  const user = getSessionUser()!;
  const q = (searchParams?.q || '').slice(0, 80);
  const status = ['active', 'qualified', 'booked', 'human', 'lost'].includes(searchParams?.status || '') ? searchParams!.status! : '';
  const channel = (searchParams?.channel || '').slice(0, 20);
  const convs = listConversationsFiltered(user.account_id, { q, status: status || undefined, channel: channel || undefined });
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Lead-uri / Inbox</h1>
          <p className="ap-sub">Toate conversațiile, din toate canalele, într-un singur loc</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <ImportPanel />
          <a className="btn btn-secondary btn-sm" href="/api/inbox/export">Exportă CSV</a>
        </div>
      </div>
      <form method="get" action="/app/inbox" className="panel" style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', padding: '12px 16px', marginBottom: 14 }}>
        <input className="txt" name="q" defaultValue={q} placeholder="Caută nume sau telefon…" style={{ flex: 1, minWidth: 180 }} aria-label="Caută lead" />
        <select className="txt" name="status" defaultValue={status} style={{ width: 150 }} aria-label="Filtru status">
          <option value="">Toate statusurile</option>
          <option value="active">Activ</option><option value="qualified">Calificat</option>
          <option value="booked">Programat</option><option value="human">Preluat</option><option value="lost">Pierdut</option>
        </select>
        <select className="txt" name="channel" defaultValue={channel} style={{ width: 150 }} aria-label="Filtru canal">
          <option value="">Toate canalele</option>
          <option value="whatsapp">WhatsApp</option><option value="messenger">Messenger</option>
          <option value="instagram">Instagram</option><option value="webform">Formular web</option>
          <option value="voice">Telefon</option><option value="meta_lead_ads">Lead Ads</option>
          <option value="import">Import</option><option value="api">API</option>
        </select>
        <button className="btn btn-dark btn-sm" type="submit">Filtrează</button>
      </form>
      <div className="panel">
        {convs.length === 0 && (
          <p className="muted" style={{ padding: '14px 4px', margin: 0 }}>
            Inbox-ul e gol deocamdată. Conversațiile de pe WhatsApp, Facebook, Instagram și formularul web vor apărea aici automat.
          </p>
        )}
        {convs.map(c => {
          const ch = CHANNEL_META[c.channel] || { label: c.channel, icon: <IconGlobe /> };
          return (
            <Link key={c.id} href={`/app/conversation/${c.id}`} className="row ap-rowlink">
              <span className="ap-lead">
                <span className="ap-lead-name">{c.lead_name}</span>
                <span className="ap-lead-meta">{ch.icon} {ch.label} · {c.phone}{c.assigned_name ? <> · 👤 {c.assigned_name}</> : null}</span>
              </span>
              <span className="ap-row-right">
                <span className="pill">{fmtResp(c.first_response_ms)}</span>
                <span className={`badge b-${c.status}`}>{STATUS_RO[c.status] || c.status}</span>
                <span className="ap-row-chev"><IconChevron /></span>
              </span>
            </Link>
          );
        })}
      </div>
    </>
  );
}
