import Link from 'next/link';
import { listConversations } from '../../../lib/store';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconWhatsApp = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" />
    <path d="M9 9.5c.5 2.5 3 5 5.5 5.5l1-1.5-2-1-1 .5c-.8-.5-1.5-1.2-2-2l.5-1-1-2z" />
  </svg>
);
const IconMessenger = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 3C7 3 3 6.7 3 11.4c0 2.6 1.2 4.9 3.2 6.4V21l3-1.6c.9.25 1.8.4 2.8.4 5 0 9-3.7 9-8.4S17 3 12 3z" />
    <path d="m7.5 13 3-3 2 2 4-2.5-3 3-2-2z" fill="currentColor" stroke="none" />
  </svg>
);
const IconInstagram = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.2" cy="6.8" r="0.5" fill="currentColor" />
  </svg>
);
const IconMegaphone = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M3 10v4a1 1 0 0 0 1 1h2l4 4V5L6 9H4a1 1 0 0 0-1 1zM14 8a4 4 0 0 1 0 8M17 5a8 8 0 0 1 0 14" />
  </svg>
);
const IconGlobe = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a13.5 13.5 0 0 1 0 18 13.5 13.5 0 0 1 0-18z" />
  </svg>
);
const IconChevron = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M9 6l6 6-6 6" />
  </svg>
);

const CHANNEL_META: Record<string, { label: string; icon: React.ReactNode }> = {
  whatsapp: { label: 'WhatsApp', icon: <IconWhatsApp /> },
  messenger: { label: 'Messenger', icon: <IconMessenger /> },
  instagram: { label: 'Instagram', icon: <IconInstagram /> },
  meta_lead_ads: { label: 'Lead Ads', icon: <IconMegaphone /> },
  webform: { label: 'Formular web', icon: <IconGlobe /> },
};
const STATUS_RO: Record<string, string> = {
  active: 'Activ', human: 'Preluat', booked: 'Programat', qualified: 'Calificat', lost: 'Pierdut',
};
const fmtResp = (ms: number) => (!ms || ms < 1000) ? '<1s' : `${Math.round(ms / 1000)}s`;

export default function Inbox() {
  const convs = listConversations();
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Lead-uri / Inbox</h1>
          <p className="ap-sub">Toate conversațiile, din toate canalele, într-un singur loc</p>
        </div>
      </div>
      <div className="panel">
        {convs.map(c => {
          const ch = CHANNEL_META[c.channel] || { label: c.channel, icon: <IconGlobe /> };
          return (
            <Link key={c.id} href={`/app/conversation/${c.id}`} className="row ap-rowlink">
              <span className="ap-lead">
                <span className="ap-lead-name">{c.lead_name}</span>
                <span className="ap-lead-meta">{ch.icon} {ch.label} · {c.phone}</span>
              </span>
              <span className="ap-row-right">
                <span className="pill">{fmtResp(c.first_response_ms)}</span>
                <span className={`badge b-${c.status}`}>{STATUS_RO[c.status] || c.status}</span>
                <span className="ap-row-chev"><IconChevron /></span>
              </span>
            </Link>
          );
        })}
      </div>
    </>
  );
}
