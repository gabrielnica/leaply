import Link from 'next/link';
import { getSessionUser } from '../../../lib/auth';
import { db } from '../../../lib/db';

export const dynamic = 'force-dynamic';

// Programările făcute de AI — vederea principală pentru cabinete/saloane/service-uri.
const CH_RO: Record<string, string> = {
  whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram',
  webform: 'Site', meta_lead_ads: 'Lead Ads', voice: 'Telefon', sms: 'SMS',
};

export default function BookingsPage() {
  const user = getSessionUser()!;
  const rows: any[] = db().prepare(`
    SELECT c.id, c.channel, c.qualification, c.updated_at, c.created_at, l.name lead_name, l.phone
    FROM conversations c JOIN leads l ON l.id = c.lead_id
    WHERE c.account_id = ? AND c.status = 'booked'
    ORDER BY c.updated_at DESC LIMIT 200`).all(user.account_id);
  const parse = (q: string) => { try { return JSON.parse(q || '{}'); } catch { return {}; } };
  // nota de programare din conversație (dacă există) e cea mai precisă sursă
  const bookingNote = (id: string) => {
    const n: any = db().prepare("SELECT body FROM messages WHERE conversation_id=? AND direction='note' AND (body LIKE '%rogram%' OR body LIKE '%alendar%') ORDER BY created_at DESC LIMIT 1").get(id);
    return n?.body || null;
  };
  const now = Date.now();
  const buckets: { label: string; items: any[] }[] = [
    { label: 'Ultimele 7 zile', items: rows.filter(r => now - +new Date(r.updated_at) <= 7 * 86400_000) },
    { label: 'Mai vechi', items: rows.filter(r => now - +new Date(r.updated_at) > 7 * 86400_000) },
  ];
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Programări</h1>
          <p className="ap-sub">{rows.length} programări făcute de asistent · cele confirmate apar și în Google Calendar</p>
        </div>
        <Link className="btn btn-secondary btn-sm" href="/app/settings#crm">Conectează calendarul →</Link>
      </div>
      {rows.length === 0 && (
        <div className="panel"><div className="ap-empty">
          <span className="ap-empty-ico"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" /></svg></span>
          <h3>Nicio programare încă</h3>
          <p>Când asistentul confirmă o programare cu un lead, apare aici — și primești notificare instant. Cele confirmate ajung și în Google Calendar.</p>
          <div className="ap-empty-cta"><Link href="/app/settings#crm" className="btn btn-secondary btn-sm">Conectează calendarul</Link></div>
        </div></div>
      )}
      {buckets.map(b => b.items.length > 0 && (
        <div className="panel" key={b.label}>
          <div className="ap-panel-head"><span className="ap-panel-title">{b.label} ({b.items.length})</span></div>
          {b.items.map(r => {
            const q = parse(r.qualification);
            const note = bookingNote(r.id);
            const detail = note || Object.entries(q).map(([k, v]) => `${k}: ${v}`).join(' · ');
            return (
              <Link key={r.id} href={`/app/conversation/${r.id}`} className="row ap-rowlink">
                <span className="ap-lead">
                  <span className="ap-lead-name">📅 {r.lead_name}</span>
                  {detail ? <span className="ap-lead-meta">{String(detail).slice(0, 110)}</span> : null}
                  <span className="ap-lead-meta">{CH_RO[r.channel] || r.channel} · {r.phone || '—'} · {new Date(r.updated_at).toLocaleString('ro-RO')}</span>
                </span>
                <span className="badge b-booked">Programat</span>
              </Link>
            );
          })}
        </div>
      ))}
    </>
  );
}
