'use client';
import { useCallback, useEffect, useState } from 'react';

/* ---------- icons (stroke 1.75, currentColor) ---------- */
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconWhatsApp = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" />
    <path d="M9 9.5c.5 2.5 3 5 5.5 5.5l1-1.5-2-1-1 .5c-.8-.5-1.5-1.2-2-2l.5-1-1-2z" />
  </svg>
);
const IconMessenger = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 3C7 3 3 6.7 3 11.4c0 2.6 1.2 4.9 3.2 6.4V21l3-1.6c.9.25 1.8.4 2.8.4 5 0 9-3.7 9-8.4S17 3 12 3z" />
    <path d="m7.5 13 3-3 2 2 4-2.5-3 3-2-2z" fill="currentColor" stroke="none" />
  </svg>
);
const IconInstagram = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.2" cy="6.8" r="0.5" fill="currentColor" />
  </svg>
);
const IconMegaphone = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M3 10v4a1 1 0 0 0 1 1h2l4 4V5L6 9H4a1 1 0 0 0-1 1zM14 8a4 4 0 0 1 0 8M17 5a8 8 0 0 1 0 14" />
  </svg>
);
const IconGlobe = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a13.5 13.5 0 0 1 0 18 13.5 13.5 0 0 1 0-18z" />
  </svg>
);
const IconCalendar = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" />
  </svg>
);
const IconInfo = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" />
  </svg>
);
const IconPlus = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg>
);
const IconCheck = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="m4.5 12.5 5 5 10-11" /></svg>
);

/* ---------- types ---------- */
type Channel = {
  id: string;
  type: string;
  status: 'connected' | 'pending';
  label: string;
  provider: 'meta' | 'twilio' | null;
  masked: Record<string, string> | null;
};
type Integrations = {
  plan: string;
  google: { configured: boolean; connected: boolean; email: string };
  meta?: { configured: boolean; pendingPages: number };
  webhookOut: { url: string; hasSecret: boolean };
  notify: { email: boolean };
  stripe: { configured: boolean };
};
type MetaPage = { id: string; name: string; ig?: string };

const META: Record<string, { label: string; icon: React.ReactNode; desc: string }> = {
  whatsapp: { label: 'WhatsApp Business', icon: <IconWhatsApp />, desc: 'Răspuns instant pe numărul tău de WhatsApp' },
  meta_lead_ads: { label: 'Facebook Lead Ads', icon: <IconMegaphone />, desc: 'Lead-urile din campanii intră automat' },
  messenger: { label: 'Messenger', icon: <IconMessenger />, desc: 'Mesajele paginii tale de Facebook' },
  instagram: { label: 'Instagram DM', icon: <IconInstagram />, desc: 'DM-urile contului tău de business' },
  webform: { label: 'Formular web', icon: <IconGlobe />, desc: 'Formularul și chat-ul de pe site' },
  calendar: { label: 'Google Calendar', icon: <IconCalendar />, desc: 'Programări direct în calendarul tău' },
};

const CRED_LABELS: Record<string, string> = {
  phone_number_id: 'Phone Number ID',
  access_token: 'Access token',
  account_sid: 'Account SID',
  auth_token: 'Auth token',
  from_number: 'Număr expeditor',
  page_id: 'Page ID',
  page_access_token: 'Page access token',
};

async function postJSON(url: string, body: unknown) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  let j: any = null;
  try { j = await r.json(); } catch { /* ignore */ }
  if (!r.ok || !j || j.error) throw new Error((j && j.error) || 'Ceva nu a mers. Încearcă din nou.');
  return j;
}

/* ---------- small building blocks ---------- */
function Field({ label, hint, value, onChange, placeholder, secret }: {
  label: string; hint?: string; value: string; onChange: (v: string) => void; placeholder?: string; secret?: boolean;
}) {
  return (
    <div>
      <label className="fld">{label}</label>
      <input
        className="txt"
        type={secret ? 'password' : 'text'}
        autoComplete="off"
        value={value}
        placeholder={placeholder}
        onChange={e => onChange(e.target.value)}
      />
      {hint && <p className="ap-fhint">{hint}</p>}
    </div>
  );
}

function CopyField({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch { /* clipboard indisponibil */ }
  };
  return (
    <div className="ap-copyrow">
      <code className="ap-code">{value}</code>
      <button type="button" className="btn btn-secondary btn-sm" onClick={copy}>
        {copied ? <><IconCheck /> Copiat</> : 'Copiază'}
      </button>
    </div>
  );
}

/* ---------- connect forms ---------- */
function WhatsAppForm({ onConnected }: { onConnected: () => void }) {
  const [prov, setProv] = useState<'meta' | 'twilio'>('meta');
  const [f, setF] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const set = (k: string) => (v: string) => setF(p => ({ ...p, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr('');
    const need = prov === 'meta' ? ['phone_number_id', 'access_token'] : ['account_sid', 'auth_token', 'from_number'];
    if (need.some(k => !(f[k] || '').trim())) { setErr('Completează toate câmpurile.'); return; }
    if (prov === 'twilio' && !/^\+\d{6,}$/.test(f.from_number.trim())) { setErr('Numărul trebuie să fie în format internațional, ex. +40712345678.'); return; }
    setBusy(true);
    try {
      const credentials = prov === 'meta'
        ? { provider: 'meta', phone_number_id: f.phone_number_id.trim(), access_token: f.access_token.trim() }
        : { provider: 'twilio', account_sid: f.account_sid.trim(), auth_token: f.auth_token.trim(), from_number: f.from_number.trim() };
      await postJSON('/api/channels', { type: 'whatsapp', credentials });
      onConnected();
    } catch (ex: any) {
      setErr(ex.message);
      setBusy(false);
    }
  };

  return (
    <form className="ap-form" onSubmit={submit}>
      <div className="ap-tabs" role="tablist" aria-label="Furnizor WhatsApp">
        <button type="button" role="tab" aria-selected={prov === 'meta'} className={`ap-tab${prov === 'meta' ? ' is-active' : ''}`} onClick={() => { setProv('meta'); setErr(''); }}>Meta Cloud API</button>
        <button type="button" role="tab" aria-selected={prov === 'twilio'} className={`ap-tab${prov === 'twilio' ? ' is-active' : ''}`} onClick={() => { setProv('twilio'); setErr(''); }}>Twilio</button>
      </div>
      {prov === 'meta' ? (
        <>
          <Field label="Phone Number ID" value={f.phone_number_id || ''} onChange={set('phone_number_id')} placeholder="ex. 106540352242922"
            hint="Îl găsești în Meta for Developers → WhatsApp → API Setup." />
          <Field label="Access token" secret value={f.access_token || ''} onChange={set('access_token')} placeholder="EAAG…"
            hint="Token permanent de sistem — Meta for Developers → WhatsApp → API Setup." />
        </>
      ) : (
        <>
          <Field label="Account SID" value={f.account_sid || ''} onChange={set('account_sid')} placeholder="AC…"
            hint="Îl găsești în Twilio Console → Account Info." />
          <Field label="Auth token" secret value={f.auth_token || ''} onChange={set('auth_token')}
            hint="Twilio Console → Account Info → Auth Token." />
          <Field label="Număr expeditor" value={f.from_number || ''} onChange={set('from_number')} placeholder="+40712345678"
            hint="Numărul tău WhatsApp din Twilio, în format internațional (+40…)." />
        </>
      )}
      <div className="ap-actions">
        <button type="submit" className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Se conectează…' : 'Conectează canalul'}</button>
        {err && <span className="ap-errmsg" role="alert">{err}</span>}
      </div>
    </form>
  );
}

function MetaPageForm({ type, metaConfigured, onConnected }: { type: 'messenger' | 'instagram'; metaConfigured: boolean; onConnected: () => void }) {
  const [pageId, setPageId] = useState('');
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr('');
    if (!pageId.trim() || !token.trim()) { setErr('Completează ambele câmpuri.'); return; }
    setBusy(true);
    try {
      await postJSON('/api/channels', { type, credentials: { provider: 'meta', page_id: pageId.trim(), page_access_token: token.trim() } });
      onConnected();
    } catch (ex: any) {
      setErr(ex.message);
      setBusy(false);
    }
  };

  return (
    <div className="ap-form">
      <div className="ap-oauth">
        {metaConfigured ? (
          <a className="btn btn-primary" href="/api/integrations/meta/connect">Conectează cu Facebook — un click</a>
        ) : (
          <button type="button" className="btn btn-primary" disabled>Conectează cu Facebook — un click</button>
        )}
        <p className="ap-oauth-hint">
          {metaConfigured
            ? 'Alegi pagina, noi facem restul — inclusiv Instagram DM dacă e legat de pagină.'
            : 'Se activează după configurarea aplicației Meta (Admin → Setări platformă).'}
        </p>
      </div>
      <details className="ap-adv">
        <summary>Introdu manual (avansat)</summary>
        <form className="ap-adv-form" onSubmit={submit}>
          <Field label="Page ID" value={pageId} onChange={setPageId} placeholder="ex. 104283911234567"
            hint="Meta Business Suite → Setări pagină → Despre, sau Meta for Developers." />
          <Field label="Page access token" secret value={token} onChange={setToken} placeholder="EAAG…"
            hint={type === 'instagram'
              ? 'Token al paginii de Facebook legate de contul tău Instagram de business.'
              : 'Meta for Developers → aplicația ta → Messenger → Access Tokens.'} />
          <div className="ap-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Se conectează…' : 'Conectează canalul'}</button>
            {err && <span className="ap-errmsg" role="alert">{err}</span>}
          </div>
        </form>
      </details>
    </div>
  );
}

function PagePicker({ onDone }: { onDone: (msg: string) => void }) {
  const [pages, setPages] = useState<MetaPage[] | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    let alive = true;
    fetch('/api/integrations/meta/select')
      .then(r => r.json())
      .then(j => { if (alive) setPages(j.pages || []); })
      .catch(() => { if (alive) setErr('Nu am putut încărca paginile. Reîmprospătează pagina.'); });
    return () => { alive = false; };
  }, []);

  const pick = async (id: string) => {
    setBusyId(id);
    setErr('');
    try {
      const j = await postJSON('/api/integrations/meta/select', { page_id: id });
      onDone(j.instagram
        ? 'Pagina Facebook e conectată — Messenger și Instagram active.'
        : 'Pagina Facebook e conectată — Messenger activ.');
    } catch (ex: any) {
      setErr(ex.message);
      setBusyId(null);
    }
  };

  return (
    <div className="panel ap-pagepick">
      <div className="ap-panel-head">
        <span className="ap-panel-title ap-sec-title"><IconMessenger /> Alege pagina de conectat</span>
      </div>
      {pages === null && !err && <div className="ap-loading">Se încarcă paginile…</div>}
      {pages?.length === 0 && <p className="ap-form-p">Contul tău Facebook nu administrează nicio pagină.</p>}
      {pages?.map(p => (
        <div key={p.id} className="ap-pagepick-row">
          <span className="ap-pagepick-info">
            <b>{p.name}</b>
            {p.ig && <span className="ap-pagepick-ig">· Instagram: @{p.ig}</span>}
          </span>
          <button type="button" className="btn btn-primary btn-sm" disabled={busyId !== null} onClick={() => pick(p.id)}>
            {busyId === p.id ? 'Se conectează…' : 'Conectează'}
          </button>
        </div>
      ))}
      {err && <p className="ap-errmsg" role="alert">{err}</p>}
    </div>
  );
}

function WebhookInfo({ type }: { type: 'meta_lead_ads' | 'webform' }) {
  return (
    <div className="ap-form">
      {type === 'meta_lead_ads' ? (
        <p className="ap-form-p">Lead Ads intră prin webhook-ul global Meta — nu ai nimic de configurat în plus dacă pagina e conectată. Dacă îl setezi manual în Meta for Developers, folosește URL-ul de mai jos.</p>
      ) : (
        <p className="ap-form-p">Formularul web e deja activ — lead-urile de pe site intră direct în inbox. Pentru integrări custom sau SMS prin Twilio, folosește webhook-urile de mai jos.</p>
      )}
      <label className="fld">Webhook Meta</label>
      <CopyField value="https://leaply.ro/api/webhooks/meta" />
      <label className="fld">Webhook Twilio</label>
      <CopyField value="https://leaply.ro/api/webhooks/twilio" />
    </div>
  );
}

function GooglePanel({ integ, onChanged }: { integ: Integrations | null; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [err, setErr] = useState('');
  const disconnect = async () => {
    setBusy(true); setErr('');
    try {
      await postJSON('/api/integrations', { action: 'google_disconnect' });
      setConfirm(false);
      onChanged();
    } catch (ex: any) { setErr(ex.message); }
    setBusy(false);
  };
  if (!integ) return <div className="ap-form"><p className="ap-form-p">Se încarcă…</p></div>;
  if (integ.google.connected) {
    return (
      <div className="ap-form">
        <p className="ap-form-p">Conectat ca <b>{integ.google.email}</b>. Programările confirmate de AI apar direct în calendarul tău.</p>
        <div className="ap-actions">
          {confirm ? (
            <span className="ap-confirm">
              Sigur deconectezi?
              <button type="button" className="btn btn-sm ap-btn-danger" disabled={busy} onClick={disconnect}>{busy ? 'Se deconectează…' : 'Da, deconectează'}</button>
              <button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirm(false)}>Anulează</button>
            </span>
          ) : (
            <button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirm(true)}>Deconectează</button>
          )}
          {err && <span className="ap-errmsg" role="alert">{err}</span>}
        </div>
      </div>
    );
  }
  return (
    <div className="ap-form">
      <p className="ap-form-p">Autorizezi accesul o singură dată — AI-ul verifică disponibilitatea și adaugă programările automat.</p>
      <a className="btn btn-primary btn-sm" href="/api/integrations/google/connect">Conectează Google Calendar</a>
    </div>
  );
}

/* ---------- page ---------- */
export default function Channels() {
  const [chans, setChans] = useState<Channel[] | null>(null);
  const [integ, setInteg] = useState<Integrations | null>(null);
  const [loadErr, setLoadErr] = useState('');
  const [openId, setOpenId] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [discBusy, setDiscBusy] = useState(false);
  const [discErr, setDiscErr] = useState('');
  const [banner, setBanner] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [showPicker, setShowPicker] = useState(false);

  const load = useCallback(async () => {
    setLoadErr('');
    try {
      const [rc, ri] = await Promise.all([fetch('/api/channels'), fetch('/api/integrations')]);
      const jc = await rc.json();
      const ji = await ri.json();
      setChans(jc.channels || []);
      setInteg(ji);
    } catch {
      setLoadErr('Nu am putut încărca canalele. Reîmprospătează pagina.');
    }
  }, []);

  useEffect(() => {
    load();
    const q = new URLSearchParams(window.location.search);
    const g = q.get('google');
    if (g === 'connected') setBanner({ kind: 'ok', text: 'Google Calendar a fost conectat.' });
    else if (g === 'error') setBanner({ kind: 'err', text: 'Conectarea Google a eșuat. Încearcă din nou.' });
    else if (g === 'unconfigured') setBanner({ kind: 'err', text: 'Integrarea Google nu e configurată încă pe server. Scrie-ne la salut@leaply.ro.' });
    const m = q.get('meta');
    if (m === 'connected') setBanner({ kind: 'ok', text: 'Pagina Facebook e conectată — Messenger activ.' });
    else if (m === 'connected_ig') setBanner({ kind: 'ok', text: 'Pagina Facebook e conectată — Messenger și Instagram active.' });
    else if (m === 'choose') setShowPicker(true);
    else if (m === 'nopages') setBanner({ kind: 'err', text: 'Contul tău Facebook nu administrează nicio pagină.' });
    else if (m === 'error') setBanner({ kind: 'err', text: 'Conectarea cu Facebook a eșuat. Încearcă din nou.' });
    else if (m === 'unconfigured') setBanner({ kind: 'err', text: 'Aplicația Meta nu e configurată încă (Admin → Setări platformă).' });
    if (g || m) window.history.replaceState(null, '', '/app/channels');
  }, [load]);

  useEffect(() => {
    if (integ?.meta && integ.meta.pendingPages > 0) setShowPicker(true);
  }, [integ]);

  const onConnected = (msg: string) => {
    setOpenId(null);
    setBanner({ kind: 'ok', text: msg });
    load();
  };

  const disconnect = async (c: Channel) => {
    setDiscBusy(true); setDiscErr('');
    try {
      await postJSON('/api/channels', { type: c.type, disconnect: true });
      setConfirmId(null);
      setBanner({ kind: 'ok', text: `${META[c.type]?.label || c.type} a fost deconectat.` });
      load();
    } catch (ex: any) {
      setDiscErr(ex.message);
    }
    setDiscBusy(false);
  };

  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Canale & Integrări</h1>
          <p className="ap-sub">Conectează sursele de lead-uri și canalele de răspuns</p>
        </div>
      </div>

      {banner && <div className={`ap-banner${banner.kind === 'err' ? ' is-err' : ''}`} role="status">{banner.text}</div>}
      {loadErr && <div className="ap-banner is-err" role="alert">{loadErr}</div>}

      {showPicker && (
        <PagePicker onDone={msg => { setShowPicker(false); setBanner({ kind: 'ok', text: msg }); load(); }} />
      )}

      <div className="panel">
        {chans === null && !loadErr && <div className="ap-loading">Se încarcă canalele…</div>}
        {chans?.map(c => {
          const m = META[c.type] || { label: c.type, icon: <IconGlobe />, desc: c.label };
          const isCalendar = c.type === 'calendar';
          const connected = isCalendar && integ ? integ.google.connected : c.status === 'connected';
          const isOpen = openId === c.id;
          return (
            <div key={c.id} className="ap-chan">
              <div className="ap-chan-row">
                <span className="ap-chan-ico">{m.icon}</span>
                <span className="ap-chan-info">
                  <b>{m.label}</b>
                  <span>{isCalendar && connected && integ?.google.email ? integ.google.email : c.label || m.desc}</span>
                </span>
                {connected ? <span className="connected">Conectat</span> : <span className="pending">În așteptare</span>}
              </div>

              {/* credențiale mascate + deconectare */}
              {connected && !isCalendar && (
                <div className="ap-chan-foot">
                  {c.masked && (
                    <div className="ap-masked">
                      {c.provider && <span className="ap-masked-kv"><b>Furnizor</b>{c.provider === 'meta' ? 'Meta' : 'Twilio'}</span>}
                      {Object.entries(c.masked).map(([k, v]) => (
                        <span key={k} className="ap-masked-kv"><b>{CRED_LABELS[k] || k}</b><code>{v}</code></span>
                      ))}
                    </div>
                  )}
                  {['whatsapp', 'messenger', 'instagram'].includes(c.type) && (
                    <div className="ap-actions ap-actions-tight">
                      {confirmId === c.id ? (
                        <span className="ap-confirm">
                          Sigur deconectezi canalul?
                          <button type="button" className="btn btn-sm ap-btn-danger" disabled={discBusy} onClick={() => disconnect(c)}>{discBusy ? 'Se deconectează…' : 'Da, deconectează'}</button>
                          <button type="button" className="btn btn-secondary btn-sm" onClick={() => { setConfirmId(null); setDiscErr(''); }}>Anulează</button>
                        </span>
                      ) : (
                        <button type="button" className="btn btn-secondary btn-sm" onClick={() => { setConfirmId(c.id); setDiscErr(''); }}>Deconectează</button>
                      )}
                      {confirmId === c.id && discErr && <span className="ap-errmsg" role="alert">{discErr}</span>}
                    </div>
                  )}
                </div>
              )}

              {/* buton conectare / detalii */}
              {(!connected || ['meta_lead_ads', 'webform'].includes(c.type) || isCalendar) && (
                <button
                  type="button"
                  className={`ap-connect-btn${isOpen ? ' is-open' : ''}`}
                  aria-expanded={isOpen}
                  onClick={() => setOpenId(isOpen ? null : c.id)}
                >
                  <IconPlus />
                  {connected || ['meta_lead_ads', 'webform'].includes(c.type) ? 'Detalii' : 'Conectează'}
                </button>
              )}

              {/* formular inline */}
              {isOpen && c.type === 'whatsapp' && !connected && <WhatsAppForm onConnected={() => onConnected('WhatsApp Business a fost conectat.')} />}
              {isOpen && (c.type === 'messenger' || c.type === 'instagram') && !connected && (
                <MetaPageForm type={c.type} metaConfigured={!!integ?.meta?.configured} onConnected={() => onConnected(`${m.label} a fost conectat.`)} />
              )}
              {isOpen && (c.type === 'meta_lead_ads' || c.type === 'webform') && <WebhookInfo type={c.type} />}
              {isOpen && isCalendar && <GooglePanel integ={integ} onChanged={() => { setBanner({ kind: 'ok', text: 'Google Calendar a fost deconectat.' }); load(); }} />}
            </div>
          );
        })}
      </div>

      <div className="ap-note">
        <IconInfo />
        <div>
          <b>Cheile tale sunt în siguranță</b>
          <p>Token-urile sunt criptate pe server și nu le afișăm niciodată complet. WhatsApp prin Meta Cloud API necesită aprobarea Meta App Review — dacă te blochezi, scrie-ne la salut@leaply.ro și îl activăm împreună în aceeași zi.</p>
        </div>
      </div>
    </>
  );
}
