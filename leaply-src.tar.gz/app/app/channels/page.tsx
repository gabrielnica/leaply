import { listChannels } from '../../../lib/store';

export const dynamic = 'force-dynamic';

const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IconWhatsApp = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" />
    <path d="M9 9.5c.5 2.5 3 5 5.5 5.5l1-1.5-2-1-1 .5c-.8-.5-1.5-1.2-2-2l.5-1-1-2z" />
  </svg>
);
const IconMessenger = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 3C7 3 3 6.7 3 11.4c0 2.6 1.2 4.9 3.2 6.4V21l3-1.6c.9.25 1.8.4 2.8.4 5 0 9-3.7 9-8.4S17 3 12 3z" />
    <path d="m7.5 13 3-3 2 2 4-2.5-3 3-2-2z" fill="currentColor" stroke="none" />
  </svg>
);
const IconInstagram = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.2" cy="6.8" r="0.5" fill="currentColor" />
  </svg>
);
const IconMegaphone = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M3 10v4a1 1 0 0 0 1 1h2l4 4V5L6 9H4a1 1 0 0 0-1 1zM14 8a4 4 0 0 1 0 8M17 5a8 8 0 0 1 0 14" />
  </svg>
);
const IconGlobe = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a13.5 13.5 0 0 1 0 18 13.5 13.5 0 0 1 0-18z" />
  </svg>
);
const IconCalendar = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" />
  </svg>
);
const IconInfo = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" />
  </svg>
);
const IconPlus = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true">
    <path d="M12 5v14M5 12h14" />
  </svg>
);

const META: Record<string, { label: string; icon: React.ReactNode; step1: string }> = {
  whatsapp: { label: 'WhatsApp Business', icon: <IconWhatsApp />, step1: 'Ai nevoie de un număr de telefon dedicat pentru WhatsApp Business.' },
  meta_lead_ads: { label: 'Facebook Lead Ads', icon: <IconMegaphone />, step1: 'Ne dai acces de partener la pagina ta de Facebook din Meta Business Suite (durează 2 minute).' },
  messenger: { label: 'Messenger', icon: <IconMessenger />, step1: 'Ne dai acces de partener la pagina ta de Facebook din Meta Business Suite (durează 2 minute).' },
  instagram: { label: 'Instagram DM', icon: <IconInstagram />, step1: 'Contul tău de Instagram trebuie să fie cont de business, legat de pagina de Facebook.' },
  webform: { label: 'Formular web', icon: <IconGlobe />, step1: 'Îți dăm un snippet de o linie pe care îl pui pe site (sau îl punem noi).' },
  calendar: { label: 'Google Calendar', icon: <IconCalendar />, step1: 'Ne dai acces la un calendar dedicat programărilor din contul tău Google.' },
};

export default function Channels() {
  const chans = listChannels();
  return (
    <>
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Canale & Integrări</h1>
          <p className="ap-sub">Conectează sursele de lead-uri și canalele de răspuns</p>
        </div>
      </div>
      <div className="panel">
        {chans.map(c => {
          const m = META[c.type] || { label: c.type, icon: <IconGlobe />, step1: 'Ne dai detaliile canalului tău.' };
          return (
            <div key={c.id} className="ap-chan">
              <div className="ap-chan-row">
                <span className="ap-chan-ico">{m.icon}</span>
                <span className="ap-chan-info">
                  <b>{m.label}</b>
                  <span>{c.label}</span>
                </span>
                {c.status === 'connected'
                  ? <span className="connected">Conectat</span>
                  : <span className="pending">În așteptare</span>}
              </div>
              {c.status !== 'connected' && (
                <details className="ap-connect">
                  <summary><IconPlus /> Conectează</summary>
                  <div className="ap-connect-steps">
                    <ol>
                      <li>{m.step1}</li>
                      <li>Noi configurăm conexiunea din Coolify / Meta Business și testăm împreună fluxul.</li>
                      <li>Gata — lead-urile de pe acest canal intră automat în inbox și primesc răspuns instant.</li>
                    </ol>
                    <p className="ap-connect-cta">Contactează-ne și îl activăm în aceeași zi: salut@leaply.ro</p>
                  </div>
                </details>
              )}
            </div>
          );
        })}
      </div>
      <div className="ap-note">
        <IconInfo />
        <div>
          <b>MVP — canale active</b>
          <p>WhatsApp, Facebook & Instagram Lead Ads, Messenger, Instagram DM, formular web, Google Calendar. Fluxurile live necesită cheile API și aprobarea Meta App Review.</p>
        </div>
      </div>
    </>
  );
}
