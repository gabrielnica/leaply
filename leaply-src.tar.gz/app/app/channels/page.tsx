import { listChannels } from '../../../lib/store';
export const dynamic = 'force-dynamic';
const LABELS: any = { whatsapp: 'WhatsApp Business', meta_lead_ads: 'Facebook Lead Ads', messenger: 'Messenger', instagram: 'Instagram DM', webform: 'Formular web', calendar: 'Google Calendar' };
export default function Channels() {
  const chans = listChannels();
  return (
    <>
      <h1 className="h-title">Canale & Integrări</h1>
      <p className="h-sub">Conectează sursele de lead-uri și canalele de răspuns</p>
      <div className="panel">
        {chans.map(c => (
          <div key={c.id} className="row">
            <span><b>{LABELS[c.type] || c.type}</b><br /><span style={{ color: '#64748b', fontSize: 13 }}>{c.label}</span></span>
            {c.status === 'connected'
              ? <span className="connected">● Conectat</span>
              : <span className="pending">● În așteptare · <a style={{ color: '#1E5BFF' }} href="#">Conectează</a></span>}
          </div>
        ))}
      </div>
      <div className="panel" style={{ background: '#F4F7FB' }}>
        <b>MVP — canale active:</b> WhatsApp, Facebook & Instagram Lead Ads, Messenger, Instagram DM, formular web, Google Calendar. Fluxurile live necesită cheile API + aprobarea Meta App Review.
      </div>
    </>
  );
}
