import { getSessionUser } from '../../../lib/auth';
import { db } from '../../../lib/db';
import { getAccount, funnelByChannel } from '../../../lib/store';
import { planLabel } from '../../../lib/plan';
import { PrintBtn } from './print-btn';

export const dynamic = 'force-dynamic';

// Raport de agenție: grafice + PDF brandat (window.print cu stiluri @media print).
// Gândit ca să poată fi trimis lunar clientului / contabilului / asociatului.

const CH_RO: Record<string, string> = {
  whatsapp: 'WhatsApp', messenger: 'Messenger', instagram: 'Instagram',
  webform: 'Site (widget)', meta_lead_ads: 'Facebook Leads', voice: 'Telefon', sms: 'SMS',
};

function Trend({ days }: { days: { d: string; n: number }[] }) {
  const W = 640, H = 150, P = 8;
  const max = Math.max(1, ...days.map(x => x.n));
  const bw = (W - P * 2) / days.length;
  return (
    <svg viewBox={`0 0 ${W} ${H + 22}`} style={{ width: '100%', height: 'auto' }} role="img" aria-label="Lead-uri pe zile">
      {days.map((x, i) => {
        const h = Math.max(2, (x.n / max) * H);
        return <rect key={x.d} x={P + i * bw + 1} y={H - h} width={Math.max(2, bw - 2)} height={h} rx="2" fill={x.n ? '#FF4D1F' : 'rgba(16,18,20,.12)'} />;
      })}
      {days.map((x, i) => (i % 5 === 0) && (
        <text key={'t' + x.d} x={P + i * bw + bw / 2} y={H + 15} fontSize="9" fill="#9a938a" textAnchor="middle">{x.d.slice(8)}.{x.d.slice(5, 7)}</text>
      ))}
    </svg>
  );
}

function Hours({ hours }: { hours: number[] }) {
  const W = 640, H = 110, P = 8;
  const max = Math.max(1, ...hours);
  const bw = (W - P * 2) / 24;
  return (
    <svg viewBox={`0 0 ${W} ${H + 22}`} style={{ width: '100%', height: 'auto' }} role="img" aria-label="Ore de vârf">
      {hours.map((n, h) => {
        const bh = Math.max(2, (n / max) * H);
        return <rect key={h} x={P + h * bw + 1} y={H - bh} width={bw - 2} height={bh} rx="2" fill={n === max && n > 0 ? '#101214' : n ? '#FF8A5C' : 'rgba(16,18,20,.10)'} />;
      })}
      {[0, 6, 12, 18, 23].map(h => (
        <text key={h} x={P + h * bw + bw / 2} y={H + 15} fontSize="9" fill="#9a938a" textAnchor="middle">{h}:00</text>
      ))}
    </svg>
  );
}

export default function ReportsPage({ searchParams }: { searchParams?: { days?: string } }) {
  const DAYS = [7, 30, 90].includes(Number(searchParams?.days)) ? Number(searchParams?.days) : 30;
  const user = getSessionUser()!;
  const accId = user.account_id;
  const acc = getAccount(accId);
  const d = db();

  // ultimele 30 de zile, zi cu zi
  const byDay = new Map<string, number>();
  for (let i = DAYS - 1; i >= 0; i--) {
    const dt = new Date(Date.now() - i * 86400_000).toISOString().slice(0, 10);
    byDay.set(dt, 0);
  }
  (d.prepare("SELECT substr(created_at,1,10) d, COUNT(*) n FROM conversations WHERE account_id=? AND created_at > datetime('now','-' || ? || ' days') GROUP BY 1").all(accId, DAYS) as any[])
    .forEach(r => { if (byDay.has(r.d)) byDay.set(r.d, r.n); });
  const days = [...byDay.entries()].map(([dd, n]) => ({ d: dd, n }));
  const total30 = days.reduce((s, x) => s + x.n, 0);

  // ore de vârf (mesaje de la lead-uri)
  const hours = new Array(24).fill(0);
  (d.prepare(`SELECT substr(m.created_at,12,2) h, COUNT(*) n FROM messages m JOIN conversations c ON c.id=m.conversation_id
    WHERE c.account_id=? AND m.sender='lead' AND m.created_at > datetime('now','-' || ? || ' days') GROUP BY 1`).all(accId, DAYS) as any[])
    .forEach(r => { const h = parseInt(r.h, 10); if (h >= 0 && h < 24) hours[h] = r.n; });
  const peakH = hours.indexOf(Math.max(...hours));

  const funnel = funnelByChannel(accId);
  const agg = (d.prepare(`SELECT COUNT(*) leads,
      SUM(CASE WHEN status IN ('qualified','booked') THEN 1 ELSE 0 END) q,
      SUM(CASE WHEN status='booked' THEN 1 ELSE 0 END) b,
      AVG(first_response_ms) ms FROM conversations WHERE account_id=? AND created_at > datetime('now','-' || ? || ' days')`).get(accId, DAYS) as any);
  const won = (d.prepare("SELECT COALESCE(SUM(won_value),0) s, COUNT(*) n FROM conversations WHERE account_id=? AND won_value IS NOT NULL AND created_at > datetime('now','-' || ? || ' days')").get(accId, DAYS) as any);
  const outsideHours = (d.prepare(`SELECT COUNT(*) n FROM conversations c WHERE c.account_id=? AND c.created_at > datetime('now','-' || ? || ' days')
    AND (CAST(substr(c.created_at,12,2) AS INTEGER) >= 18 OR CAST(substr(c.created_at,12,2) AS INTEGER) < 9)`).get(accId, DAYS) as any).n;

  const today = new Date().toLocaleDateString('ro-RO', { day: 'numeric', month: 'long', year: 'numeric' });
  return (
    <div className="ap-report">
      <div className="ap-head">
        <div>
          <h1 className="ap-title">Raport de activitate — ultimele {DAYS} de zile</h1>
          <p className="ap-sub">{acc?.config?.businessName || acc?.name} · plan {planLabel(acc?.plan)} · generat {today} de Leaply</p>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }} className="ap-noprint">
          {[7, 30, 90].map(n => (
            <a key={n} className={`pill${DAYS === n ? ' pill-on' : ''}`} href={`/app/reports?days=${n}`}>{n} zile</a>
          ))}
          <PrintBtn />
        </div>
      </div>

      <div className="ap-kpis">
        <div className="panel ap-kpi"><b>{total30}</b><span>lead-uri noi</span></div>
        <div className="panel ap-kpi"><b>{agg.q || 0}</b><span>calificate de AI</span></div>
        <div className="panel ap-kpi"><b>{agg.b || 0}</b><span>programări</span></div>
        <div className="panel ap-kpi"><b>{agg.ms ? (agg.ms < 1000 ? '<1s' : Math.round(agg.ms / 1000) + 's') : '—'}</b><span>timp mediu de răspuns</span></div>
        <div className="panel ap-kpi"><b>{won.s ? won.s.toLocaleString('ro-RO') + ' lei' : '—'}</b><span>valoare câștigată (marcată de tine)</span></div>
      </div>

      <div className="panel">
        <div className="ap-group-title">Lead-uri pe zile</div>
        {total30 ? <Trend days={days} /> : <p className="muted">Încă nu ai lead-uri în perioada aleasă.</p>}
      </div>

      <div className="panel">
        <div className="ap-group-title">Orele la care îți scriu clienții</div>
        {hours.some(Boolean) ? <>
          <Hours hours={hours} />
          <p className="ap-sub" style={{ marginBottom: 0 }}>
            Ora de vârf: <b>{peakH}:00–{peakH + 1}:00</b>. {outsideHours > 0 && <>Din {total30} lead-uri, <b>{outsideHours}</b> au venit în afara programului (18:00–9:00) — pe acestea le-a preluat Leaply în locul tău.</>}
          </p>
        </> : <p className="muted">Încă nu sunt mesaje de analizat.</p>}
      </div>

      <div className="panel">
        <div className="ap-group-title">Funnel pe canale</div>
        {funnel.length ? (
          <table className="ap-table">
            <thead><tr><th>Canal</th><th>Lead-uri</th><th>Calificate</th><th>Programate</th><th>Conversie</th></tr></thead>
            <tbody>
              {funnel.map((f: any) => (
                <tr key={f.channel}>
                  <td>{CH_RO[f.channel] || f.channel}</td><td>{f.leads}</td><td>{f.qualified}</td><td>{f.booked}</td>
                  <td>{f.leads ? Math.round((f.booked / f.leads) * 100) + '%' : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : <p className="muted">Conectează un canal ca să vezi funnel-ul.</p>}
      </div>

      <div className="ap-report-foot">
        Raport generat automat de <b>Leaply</b> — asistentul AI care răspunde lead-urilor tale în sub 60 de secunde. leaply.ro
      </div>
    </div>
  );
}
