'use client';
export function PrintBtn() {
  return (
    <button className="btn btn-primary ap-noprint" onClick={() => window.print()}>
      📄 Descarcă PDF / Printează
    </button>
  );
}
