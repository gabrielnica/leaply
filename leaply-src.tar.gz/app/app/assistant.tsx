'use client';
import { useEffect, useRef, useState } from 'react';

type Msg = { role: 'user' | 'assistant'; content: string };

const HELLO: Msg = {
  role: 'assistant',
  content: 'Salut! Sunt asistentul tău de configurare 👋 Te ajut să pui totul în funcțiune: chat-ul pe site, WhatsApp, Facebook/Instagram, telefonul sau Google Calendar. Ce vrei să configurăm?',
};

const SUGGESTIONS = [
  'Cum instalez chat-ul pe site?',
  'Cum conectez WhatsApp?',
  'Care e următorul pas la contul meu?',
];

export function AppAssistant() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([HELLO]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [msgs, open, busy]);

  const send = async (text?: string) => {
    const q = (text ?? input).trim();
    if (!q || busy) return;
    const next: Msg[] = [...msgs, { role: 'user', content: q }];
    setMsgs(next);
    setInput('');
    setBusy(true);
    try {
      const r = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ history: next.slice(1) }), // fără mesajul de salut
      });
      const j = await r.json().catch(() => ({} as any));
      setMsgs(m => [...m, { role: 'assistant', content: j.reply || j.error || 'Nu am reușit să răspund — mai încearcă o dată.' }]);
    } catch {
      setMsgs(m => [...m, { role: 'assistant', content: 'Nu am reușit să răspund — verifică conexiunea și mai încearcă o dată.' }]);
    }
    setBusy(false);
  };

  // linkuri simple pentru căile /app/... menționate în răspunsuri
  const render = (t: string) => {
    const parts = t.split(/(\/app\/?[a-z-]*)/g);
    return parts.map((p, i) =>
      /^\/app\/?[a-z-]*$/.test(p) ? <a key={i} href={p} className="ap-asst-link">{p}</a> : <span key={i}>{p}</span>
    );
  };

  return (
    <>
      {open && (
        <div className="ap-asst-panel" role="dialog" aria-label="Asistent de configurare">
          <div className="ap-asst-head">
            <span className="ap-asst-title">Asistent de configurare</span>
            <button type="button" className="ap-asst-x" aria-label="Închide" onClick={() => setOpen(false)}>×</button>
          </div>
          <div className="ap-asst-body" ref={bodyRef}>
            {msgs.map((m, i) => (
              <div key={i} className={`ap-asst-msg${m.role === 'user' ? ' is-user' : ''}`}>{render(m.content)}</div>
            ))}
            {busy && <div className="ap-asst-msg ap-asst-typing">Scrie…</div>}
            {msgs.length === 1 && (
              <div className="ap-asst-sugg">
                {SUGGESTIONS.map(s => (
                  <button key={s} type="button" className="ap-asst-chip" onClick={() => send(s)}>{s}</button>
                ))}
              </div>
            )}
          </div>
          <form className="ap-asst-input" onSubmit={e => { e.preventDefault(); send(); }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Întreabă orice despre configurare…"
              aria-label="Mesaj pentru asistent"
              maxLength={1500}
            />
            <button type="submit" className="btn btn-primary btn-sm" disabled={busy || !input.trim()}>Trimite</button>
          </form>
        </div>
      )}
      <button type="button" className={`ap-asst-fab${open ? ' is-open' : ''}`} aria-label={open ? 'Închide asistentul' : 'Deschide asistentul de configurare'} onClick={() => setOpen(o => !o)}>
        {open ? '×' : (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z" />
            <path d="M8.5 10.5h7M8.5 13.5h4.5" />
          </svg>
        )}
      </button>
    </>
  );
}
