'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';

/* ---- tipuri ---- */
type Msg = { sender: 'lead' | 'ai'; body: string };
type SvcRow = { name: string; price: string };
type Question = { key: string; q: string };
type Cfg = {
  businessName: string;
  vertical: string;
  tone: string;
  welcome: string;
  services: { name: string; price: string }[];
  qualificationQuestions: Question[];
  bookingSlots: string[];
  redFlags: string[];
};
type Lead = { name?: string; contact?: string; business?: string; vertical?: string; demoRequestId?: string };

const VERTICALS = ['Servicii pentru casă', 'Imobiliare', 'Clinică privată', 'Dealer auto', 'Altceva'];
const TONES = [
  { v: 'prietenos', label: 'Prietenos — cald, apropiat' },
  { v: 'profesional', label: 'Profesional — sobru, la obiect' },
  { v: 'energic', label: 'Energic — entuziast, rapid' },
];
const STEP_NAMES = ['Contul tău', 'Afacerea ta', 'Asistentul tău', 'Testează-l'];

function normVertical(v?: string): string {
  const s = (v || '').toLowerCase();
  if (s.includes('cas')) return 'Servicii pentru casă';
  if (s.includes('imobil')) return 'Imobiliare';
  if (s.includes('clinic')) return 'Clinică privată';
  if (s.includes('auto') || s.includes('dealer')) return 'Dealer auto';
  return 'Altceva';
}

/* ---- pictograme SVG minimaliste (stroke 1.75, currentColor) ---- */
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IcArrowR = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></svg>
);
const IcArrowL = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M19 12H5" /><path d="m11 6-6 6 6 6" /></svg>
);
const IcEye = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></svg>
);
const IcEyeOff = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M9.9 4.9A9.8 9.8 0 0 1 12 4.7c6.5 0 10 7 10 7a17.8 17.8 0 0 1-2.2 3.1M6.4 6.4A17 17 0 0 0 2 11.7s3.5 7 10 7a9.7 9.7 0 0 0 5.6-1.7" /><path d="M10 10a3 3 0 0 0 4.2 4.2" /><path d="m3 3 18 18" /></svg>
);
const IcPlus = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 5v14" /><path d="M5 12h14" /></svg>
);
const IcX = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>
);
const IcAlert = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="12" cy="12" r="9" /><path d="M12 8v4.5" /><path d="M12 16h.01" /></svg>
);
const IcCheck = ({ size = 15 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M20 6 9 17l-5-5" /></svg>
);
const IcBot = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" {...S} aria-hidden="true"><rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13v1.5M15 13v1.5" /><circle cx="12" cy="3.5" r="1" /></svg>
);
const IcBolt = ({ size = 15 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M13 2 4.8 13.2h6L10 22l8.2-11.2h-6L13 2z" /></svg>
);

async function fetchCfg(): Promise<Cfg | null> {
  try {
    const r = await fetch('/api/account/config');
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}
async function postCfg(cfg: Cfg): Promise<boolean> {
  try {
    const r = await fetch('/api/account/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cfg) });
    if (!r.ok) return false;
    const d = await r.json().catch(() => ({} as any));
    return !!d.ok;
  } catch { return false; }
}

export default function Start() {
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);

  /* pasul 1 — cont */
  const [lead, setLead] = useState<Lead | null>(null);
  const [hasPrefill, setHasPrefill] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [err1, setErr1] = useState<{ msg: string; conflict?: boolean } | null>(null);

  /* pasul 2 — afacere */
  const [bizName, setBizName] = useState('');
  const [vertical, setVertical] = useState(VERTICALS[0]);
  const [services, setServices] = useState<SvcRow[]>([{ name: '', price: '' }]);
  const [err2, setErr2] = useState<string | null>(null);

  /* pasul 3 — asistent */
  const [cfg, setCfg] = useState<Cfg | null>(null);
  const [tone, setTone] = useState('prietenos');
  const [welcome, setWelcome] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [slots, setSlots] = useState<[string, string]>(['', '']);
  const [err3, setErr3] = useState<string | null>(null);

  /* pasul 4 — test */
  const [history, setHistory] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [chatBusy, setChatBusy] = useState(false);
  const [meta, setMeta] = useState<any>(null);
  const [err4, setErr4] = useState<string | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem('leaply_lead');
      if (!raw) return;
      const l: Lead = JSON.parse(raw);
      setLead(l);
      if (l.name) setName(l.name);
      if (l.contact && l.contact.includes('@')) setEmail(l.contact.trim());
      if (l.business) setBizName(l.business);
      if (l.vertical) setVertical(normVertical(l.vertical));
      if (l.name || l.contact || l.business) setHasPrefill(true);
    } catch { /* prefill opțional */ }
  }, []);

  useEffect(() => { boxRef.current?.scrollTo(0, boxRef.current.scrollHeight); }, [history, chatBusy]);

  /* umple pasul 3 din config-ul contului */
  function seedStep3(c: Cfg) {
    setTone(TONES.some(t => t.v === c.tone) ? c.tone : 'prietenos');
    setWelcome(c.welcome || '');
    const qq = Array.isArray(c.qualificationQuestions) && c.qualificationQuestions.length > 0
      ? c.qualificationQuestions.map(x => ({ key: x.key, q: x.q || '' }))
      : [{ key: 'q1', q: '' }, { key: 'q2', q: '' }, { key: 'q3', q: '' }];
    setQuestions(qq);
    const bs = Array.isArray(c.bookingSlots) ? c.bookingSlots : [];
    setSlots([bs[0] || '', bs[1] || '']);
  }

  /* umple pașii 2–3 din config (păstrând ce a scris deja utilizatorul) */
  function seedFromConfig(c: Cfg) {
    setCfg(c);
    setBizName(prev => prev || c.businessName || '');
    if (c.vertical && VERTICALS.includes(c.vertical)) setVertical(prev => (lead?.vertical ? prev : c.vertical));
    if (Array.isArray(c.services) && c.services.length > 0) {
      setServices(c.services.map(s => ({ name: String(s.name ?? ''), price: String(s.price ?? '') })));
    }
    seedStep3(c);
  }

  /* ---- pasul 1: signup ---- */
  async function submitAccount(e: React.FormEvent) {
    e.preventDefault();
    setErr1(null);
    if (!name.trim()) { setErr1({ msg: 'Spune-ne cum te cheamă.' }); return; }
    if (!email.includes('@')) { setErr1({ msg: 'Adresa de email nu pare validă.' }); return; }
    if (password.length < 8) { setErr1({ msg: 'Parola trebuie să aibă minim 8 caractere.' }); return; }
    setBusy(true);
    try {
      const r = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          password,
          business: bizName.trim() || undefined,
          vertical: vertical || undefined,
          demoRequestId: lead?.demoRequestId || undefined,
        }),
      });
      const d = await r.json().catch(() => ({} as any));
      if (r.ok && d.ok) {
        const c = await fetchCfg();
        if (c) seedFromConfig(c);
        setStep(2);
      } else if (r.status === 409) {
        setErr1({ msg: d.error || 'Există deja un cont cu acest email.', conflict: true });
      } else {
        setErr1({ msg: d.error || 'Nu am putut crea contul. Mai încearcă o dată.' });
      }
    } catch {
      setErr1({ msg: 'Eroare de conexiune. Verifică internetul și încearcă din nou.' });
    }
    setBusy(false);
  }

  /* ---- pasul 2: firmă + servicii ---- */
  async function submitBusiness(e: React.FormEvent) {
    e.preventDefault();
    setErr2(null);
    setBusy(true);
    const base = cfg ?? await fetchCfg();
    if (!base) {
      setErr2('Nu am putut încărca setările contului. Mai încearcă o dată.');
      setBusy(false);
      return;
    }
    if (!cfg) seedStep3(base);
    const merged: Cfg = {
      ...base,
      businessName: bizName.trim() || base.businessName,
      vertical,
      services: services
        .filter(s => s.name.trim())
        .map(s => ({ name: s.name.trim(), price: s.price.trim() })),
    };
    if (await postCfg(merged)) {
      setCfg(merged);
      setStep(3);
    } else {
      setErr2('Nu am putut salva. Verifică conexiunea și încearcă din nou.');
    }
    setBusy(false);
  }

  /* ---- pasul 3: ton + mesaje ---- */
  async function submitAssistant(e: React.FormEvent) {
    e.preventDefault();
    setErr3(null);
    setBusy(true);
    const base = cfg ?? await fetchCfg();
    if (!base) {
      setErr3('Nu am putut încărca setările contului. Mai încearcă o dată.');
      setBusy(false);
      return;
    }
    const merged: Cfg = {
      ...base,
      tone,
      welcome: welcome.trim(),
      qualificationQuestions: questions.map(x => ({ key: x.key, q: x.q.trim() })),
      bookingSlots: [slots[0].trim(), slots[1].trim()],
    };
    if (await postCfg(merged)) {
      setCfg(merged);
      setStep(4);
    } else {
      setErr3('Nu am putut salva. Verifică conexiunea și încearcă din nou.');
    }
    setBusy(false);
  }

  /* ---- pasul 4: chat de test + activare ---- */
  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || chatBusy) return;
    const h = [...history, { sender: 'lead' as const, body: msg }];
    setHistory(h); setInput(''); setChatBusy(true); setErr4(null);
    try {
      const r = await fetch('/api/demo/message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ history: h }) });
      const d = await r.json();
      setHistory([...h, { sender: 'ai', body: d.reply }]);
      setMeta(d);
    } catch {
      setHistory([...h, { sender: 'ai', body: 'Eroare de conexiune. Mai încearcă o dată.' }]);
    }
    setChatBusy(false);
  }

  async function complete(skip: boolean) {
    if (busy) return;
    setErr4(null);
    setBusy(true);
    try {
      const r = await fetch('/api/onboarding/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          history: skip ? [] : history,
          status: (!skip && meta?.status) || 'new',
          score: (!skip && meta?.score) || 'cold',
          qualification: (!skip && meta?.qualification) || {},
        }),
      });
      if (!r.ok) throw new Error();
      try { sessionStorage.removeItem('leaply_lead'); } catch { }
      window.location.href = '/app';
      return;
    } catch {
      setErr4('Nu am putut activa asistentul. Mai încearcă o dată.');
      setBusy(false);
    }
  }

  const hasExchange = history.some(m => m.sender === 'ai');
  const chips = ['Cât costă serviciile voastre?', 'Vreau o programare'];
  const scoreRo: Record<string, string> = { hot: 'Hot', warm: 'Warm', cold: 'Cold' };

  return (
    <div className="wz">
      <header className="wz-top">
        <div className="wz-top-in">
          <Link href="/" aria-label="Leaply — acasă"><Logo light size={24} /></Link>
          <span className="wz-top-step">Pasul {step} din 4 · {STEP_NAMES[step - 1]}</span>
        </div>
      </header>

      <div className="wz-wrap">
        <div className="wz-progress" role="progressbar" aria-valuemin={1} aria-valuemax={4} aria-valuenow={step} aria-label={`Pasul ${step} din 4`}>
          <div className="wz-track"><div className="wz-fill" style={{ width: `${(step / 4) * 100}%` }} /></div>
          <div className="wz-dots">
            {[1, 2, 3, 4].map(i => (
              <span key={i} className={`wz-dot${i === step ? ' on' : i < step ? ' done' : ''}`} />
            ))}
          </div>
        </div>

        {/* ============ PASUL 1 — CONTUL TĂU ============ */}
        {step === 1 && (
          <div className="wz-card">
            <h1 className="wz-title">Contul tău</h1>
            <p className="wz-sub">Îți faci cont și îți testezi propriul asistent AI în sub 5 minute.</p>
            {hasPrefill && (
              <span className="wz-prefill"><IcBolt /> Ți-am prefill-uit datele din cererea de demo.</span>
            )}
            <form className="wz-form" onSubmit={submitAccount}>
              <label className="fld" htmlFor="wz-name">Numele tău</label>
              <input id="wz-name" className="txt" value={name} onChange={e => setName(e.target.value)} placeholder="ex. Andrei Popescu" autoComplete="name" />

              <label className="fld" htmlFor="wz-email">Email</label>
              <input id="wz-email" className="txt" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="andrei@firma.ro" autoComplete="email" required />

              <label className="fld" htmlFor="wz-pass">Parolă</label>
              <div className="wz-pw">
                <input id="wz-pass" className="txt" type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Minim 8 caractere" autoComplete="new-password" minLength={8} required />
                <button type="button" className="wz-pw-toggle" onClick={() => setShowPw(v => !v)} aria-label={showPw ? 'Ascunde parola' : 'Arată parola'}>
                  {showPw ? <IcEyeOff /> : <IcEye />}
                </button>
              </div>
              <div className="wz-hint">Minim 8 caractere.</div>

              {err1 && (
                <div className="wz-err" role="alert">
                  <IcAlert />
                  <span>
                    {err1.msg}
                    {err1.conflict && <> <Link href="/login">Intră în cont</Link></>}
                  </span>
                </div>
              )}

              <div className="wz-actions">
                <button className="btn btn-primary btn-lg" type="submit" disabled={busy}>
                  {busy ? 'Se creează contul…' : <>Creează contul gratuit <IcArrowR /></>}
                </button>
              </div>
              <div className="wz-note">Fără card. Contul e gratuit cât testezi.</div>
            </form>
          </div>
        )}

        {/* ============ PASUL 2 — AFACEREA TA ============ */}
        {step === 2 && (
          <div className="wz-card">
            <h1 className="wz-title">Afacerea ta</h1>
            <p className="wz-sub">Asistentul folosește aceste date ca să răspundă corect clienților tăi.</p>
            <form className="wz-form" onSubmit={submitBusiness}>
              <label className="fld" htmlFor="wz-biz">Numele firmei</label>
              <input id="wz-biz" className="txt" value={bizName} onChange={e => setBizName(e.target.value)} placeholder="ex. Termopane Bihor SRL" required />

              <label className="fld" htmlFor="wz-vert">Domeniul</label>
              <select id="wz-vert" className="txt" value={vertical} onChange={e => setVertical(e.target.value)}>
                {VERTICALS.map(v => <option key={v} value={v}>{v}</option>)}
              </select>

              <label className="fld">Servicii și prețuri <span className="muted" style={{ fontWeight: 400 }}>(opțional)</span></label>
              {services.map((s, i) => (
                <div className="wz-svc" key={i}>
                  <input className="txt" value={s.name} onChange={e => setServices(rows => rows.map((r, j) => j === i ? { ...r, name: e.target.value } : r))} placeholder="ex. Termopane tripan" aria-label={`Serviciul ${i + 1}`} />
                  <input className="txt" value={s.price} onChange={e => setServices(rows => rows.map((r, j) => j === i ? { ...r, price: e.target.value } : r))} placeholder="de la 900 lei" aria-label={`Prețul serviciului ${i + 1}`} />
                  <button type="button" className="wz-x" onClick={() => setServices(rows => rows.filter((_, j) => j !== i))} aria-label={`Șterge serviciul ${i + 1}`}><IcX /></button>
                </div>
              ))}
              <button type="button" className="wz-add" onClick={() => setServices(rows => [...rows, { name: '', price: '' }])}><IcPlus /> Adaugă serviciu</button>

              {err2 && <div className="wz-err" role="alert"><IcAlert /><span>{err2}</span></div>}

              <div className="wz-actions">
                <button className="btn btn-primary btn-lg" type="submit" disabled={busy}>
                  {busy ? 'Se salvează…' : <>Continuă <IcArrowR /></>}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ============ PASUL 3 — ASISTENTUL TĂU ============ */}
        {step === 3 && (
          <div className="wz-card">
            <h1 className="wz-title">Asistentul tău</h1>
            <p className="wz-sub">Cum vorbește cu clienții, ce îi întreabă și când poate programa vizite.</p>
            <form className="wz-form" onSubmit={submitAssistant}>
              <label className="fld" htmlFor="wz-tone">Tonul asistentului</label>
              <select id="wz-tone" className="txt" value={tone} onChange={e => setTone(e.target.value)}>
                {TONES.map(t => <option key={t.v} value={t.v}>{t.label}</option>)}
              </select>

              <label className="fld" htmlFor="wz-welcome">Mesajul de bun venit</label>
              <textarea id="wz-welcome" className="txt" rows={3} value={welcome} onChange={e => setWelcome(e.target.value)} placeholder="ex. Bună! Mulțumim că ne-ai scris. Cu ce te putem ajuta?" />

              <label className="fld">Întrebările de calificare</label>
              {questions.map((q, i) => (
                <input
                  key={i}
                  className="txt"
                  style={{ marginBottom: 8 }}
                  value={q.q}
                  onChange={e => setQuestions(rows => rows.map((r, j) => j === i ? { ...r, q: e.target.value } : r))}
                  placeholder={`Întrebarea ${i + 1}`}
                  aria-label={`Întrebarea de calificare ${i + 1}`}
                />
              ))}

              <label className="fld">Intervale de programare</label>
              <input className="txt" style={{ marginBottom: 8 }} value={slots[0]} onChange={e => setSlots(s => [e.target.value, s[1]])} placeholder="ex. mâine 10:00–12:00" aria-label="Intervalul 1" />
              <input className="txt" value={slots[1]} onChange={e => setSlots(s => [s[0], e.target.value])} placeholder="ex. joi 14:00–16:00" aria-label="Intervalul 2" />

              {err3 && <div className="wz-err" role="alert"><IcAlert /><span>{err3}</span></div>}

              <div className="wz-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setStep(2)} disabled={busy}><IcArrowL /> Înapoi</button>
                <button className="btn btn-primary btn-lg" type="submit" disabled={busy}>
                  {busy ? 'Se salvează…' : <>Continuă <IcArrowR /></>}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ============ PASUL 4 — TESTEAZĂ-L ============ */}
        {step === 4 && (
          <div className="wz-card">
            <h1 className="wz-title">Testează-l</h1>
            <p className="wz-sub">Scrie ca un client real. Asistentul răspunde cu datele tale, exact ca în producție.</p>

            <div className="wz-chat">
              <div className="wz-chat-head">
                <span className="wz-ava"><IcBot /></span>
                <span>
                  <b>{cfg?.businessName || bizName || 'Asistentul tău'}</b>
                  <small>asistent Leaply · răspunde instant</small>
                </span>
              </div>
              <div ref={boxRef} className="wz-chat-body">
                {history.length === 0 && (
                  <div className="wz-empty">Trimite un mesaj de test — de exemplu „Cât costă serviciile voastre?” — și vezi cum răspunde.</div>
                )}
                {history.map((m, i) => (
                  <div key={i} className={`bubble ${m.sender === 'lead' ? 'out' : 'in'}`}>{m.body}</div>
                ))}
                {chatBusy && <div className="wz-typing">Asistentul scrie…</div>}
              </div>
              <div className="wz-chat-foot">
                <input className="txt" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Scrie ca un client…" aria-label="Mesaj de test" />
                <button type="button" className="btn btn-dark btn-sm" onClick={() => send()} disabled={chatBusy}>Trimite</button>
              </div>
            </div>

            <div className="wz-chips">
              {chips.map(c => <button key={c} type="button" className="wz-chip" onClick={() => send(c)} disabled={chatBusy}>{c}</button>)}
            </div>

            {meta && (
              <div className="wz-meta">
                <IcCheck /> Răspuns în {(meta.latencyMs / 1000).toFixed(2)} sec · scor lead: <b style={{ color: 'var(--ink)' }}>{scoreRo[meta.score] || meta.score}</b>
              </div>
            )}

            {err4 && <div className="wz-err" role="alert"><IcAlert /><span>{err4}</span></div>}

            <div className="wz-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setStep(3)} disabled={busy}><IcArrowL /> Înapoi</button>
              <button
                type="button"
                className={`btn btn-lg ${hasExchange ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => complete(false)}
                disabled={busy || !hasExchange}
                title={hasExchange ? undefined : 'Trimite mai întâi un mesaj de test'}
              >
                {busy ? 'Se activează…' : <>Activează asistentul <IcArrowR /></>}
              </button>
            </div>
            <button type="button" className="wz-skip" onClick={() => complete(true)} disabled={busy}>Sar peste test și activez direct</button>
          </div>
        )}
      </div>
    </div>
  );
}
