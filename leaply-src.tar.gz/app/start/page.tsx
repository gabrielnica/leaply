'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';
import { presetFor, Preset } from '../../lib/vertical-presets';

/* ---- tipuri ---- */
type Msg = { sender: 'lead' | 'ai'; body: string };
type SvcRow = { name: string; price: string };
type Question = { key: string; q: string };
type Cfg = {
  businessName: string;
  rules?: string;
  company?: any;
  vertical: string;
  tone: string;
  welcome: string;
  services: { name: string; price: string }[];
  qualificationQuestions: Question[];
  bookingSlots: string[];
  redFlags: string[];
  knowledge?: string;
  description?: string;
  ownerPhone?: string;
};
type Lead = { name?: string; contact?: string; phone?: string; email?: string; website?: string; business?: string; vertical?: string; demoRequestId?: string };

const VERTICALS = ['Servicii pentru casă', 'Imobiliare', 'Clinică privată', 'Dealer auto', 'Altceva'];
const TONES = [
  { v: 'prietenos', label: 'Prietenos — cald, apropiat' },
  { v: 'profesional', label: 'Profesional — sobru, la obiect' },
  { v: 'energic', label: 'Energic — entuziast, rapid' },
];
const STEP_NAMES = ['Contul tău', 'Afacerea ta', 'Asistentul tău', 'Testează-l'];

function normVertical(v?: string): string {
  const s = (v || '').toLowerCase();
  const any = (...ks: string[]) => ks.some(k => s.includes(k));
  if (any('cas', 'termopan', 'mobil la comand', 'mobilă', 'mobila', 'amenaj', 'constr', 'renov', 'instala', 'acoperi', 'fotovolt', 'hvac', 'aer condi', 'curatenie', 'curățenie', 'dezinsec', 'mutari', 'mutări', 'ferestre', 'usi', 'uși')) return 'Servicii pentru casă';
  if (any('imobil')) return 'Imobiliare';
  if (any('clinic', 'stomato', 'dent', 'medic', 'dermato', 'estetic', 'oftalmo', 'kineto', 'veterinar', 'psiho', 'recuperare')) return 'Clinică privată';
  if (any('dealer', 'auto', 'vulcaniz', 'detailing', 'anvelope')) return 'Dealer auto';
  return 'Altceva';
}

/* ---- pictograme SVG minimaliste (stroke 1.75, currentColor) ---- */
const S = { fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round' } as const;
const IcArrowR = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></svg>
);
const IcArrowL = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M19 12H5" /><path d="m11 6-6 6 6 6" /></svg>
);
const IcEye = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></svg>
);
const IcEyeOff = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M9.9 4.9A9.8 9.8 0 0 1 12 4.7c6.5 0 10 7 10 7a17.8 17.8 0 0 1-2.2 3.1M6.4 6.4A17 17 0 0 0 2 11.7s3.5 7 10 7a9.7 9.7 0 0 0 5.6-1.7" /><path d="M10 10a3 3 0 0 0 4.2 4.2" /><path d="m3 3 18 18" /></svg>
);
const IcPlus = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M12 5v14" /><path d="M5 12h14" /></svg>
);
const IcX = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>
);
const IcAlert = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="12" cy="12" r="9" /><path d="M12 8v4.5" /><path d="M12 16h.01" /></svg>
);
const IcCheck = ({ size = 15 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M20 6 9 17l-5-5" /></svg>
);
const IcBot = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" {...S} aria-hidden="true"><rect x="4" y="8" width="16" height="12" rx="3" /><path d="M12 4v4M9 13v1.5M15 13v1.5" /><circle cx="12" cy="3.5" r="1" /></svg>
);
const IcBolt = ({ size = 15 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><path d="M13 2 4.8 13.2h6L10 22l8.2-11.2h-6L13 2z" /></svg>
);
const IcGlobe = ({ size = 17 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" {...S} aria-hidden="true"><circle cx="12" cy="12" r="9" /><path d="M3 12h18" /><path d="M12 3a13.5 13.5 0 0 1 0 18 13.5 13.5 0 0 1 0-18z" /></svg>
);

async function fetchCfg(): Promise<Cfg | null> {
  try {
    const r = await fetch('/api/account/config');
    if (!r.ok) return null;
    return await r.json();
  } catch { return null; }
}
async function postCfg(cfg: Cfg): Promise<boolean> {
  try {
    const r = await fetch('/api/account/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cfg) });
    if (!r.ok) return false;
    const d = await r.json().catch(() => ({} as any));
    return !!d.ok;
  } catch { return false; }
}

export default function Start() {
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);

  /* pasul 1 — cont */
  const [lead, setLead] = useState<Lead | null>(null);
  const [hasPrefill, setHasPrefill] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [err1, setErr1] = useState<{ msg: string; conflict?: boolean } | null>(null);

  /* pasul 2 — afacere */
  const [bizName, setBizName] = useState('');
  const [vertical, setVertical] = useState(VERTICALS[0]);
  const [services, setServices] = useState<SvcRow[]>([{ name: '', price: '' }]);
  const [err2, setErr2] = useState<string | null>(null);

  /* pasul 2 — import automat de pe site */
  const [scrapeUrl, setScrapeUrl] = useState('');
  const [scrapeBusy, setScrapeBusy] = useState(false);
  const [scrapeErr, setScrapeErr] = useState<string | null>(null);
  const [scrapedCount, setScrapedCount] = useState<number | null>(null);
  const [knowledge, setKnowledge] = useState('');
  const [description, setDescription] = useState('');

  /* pasul 2 — date firmă de la ANAF (după CUI) */
  const [cuiVal, setCuiVal] = useState('');
  const [anafBusy, setAnafBusy] = useState(false);
  const [anafErr, setAnafErr] = useState<string | null>(null);
  const [anafCompany, setAnafCompany] = useState<any>(null);

  /* pasul 3 — reguli și limite pentru asistent */
  const [rules, setRules] = useState('');

  /* pasul 3 — asistent */
  const [cfg, setCfg] = useState<Cfg | null>(null);
  const [tone, setTone] = useState('prietenos');
  const [welcome, setWelcome] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [slots, setSlots] = useState<[string, string]>(['', '']);
  const [err3, setErr3] = useState<string | null>(null);

  /* pasul 4 — test */
  const [history, setHistory] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [chatBusy, setChatBusy] = useState(false);
  const [meta, setMeta] = useState<any>(null);
  const [err4, setErr4] = useState<string | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      const ref = new URLSearchParams(window.location.search).get('ref');
      if (ref && /^acc_[A-Za-z0-9_-]{4,40}$/.test(ref)) sessionStorage.setItem('leaply_ref', ref);
    } catch {}
    try {
      const raw = sessionStorage.getItem('leaply_lead');
      if (!raw) return;
      const l: Lead = JSON.parse(raw);
      setLead(l);
      if (l.name) setName(l.name);
      const em = l.email && l.email.includes('@') ? l.email : l.contact && l.contact.includes('@') ? l.contact : '';
      if (em) setEmail(em.trim());
      if (l.business) setBizName(l.business);
      if (l.vertical) setVertical(normVertical(l.vertical));
      if (l.website) setScrapeUrl(l.website.trim());
      if (l.name || l.contact || l.email || l.phone || l.business) setHasPrefill(true);
    } catch { /* prefill opțional */ }
  }, []);

  useEffect(() => { boxRef.current?.scrollTo(0, boxRef.current.scrollHeight); }, [history, chatBusy]);

  /* onboarding rapid: dacă avem site-ul din cererea de demo, îl citim AUTOMAT la pasul 2 —
     serviciile + cunoștințele se completează singure, utilizatorul doar verifică */
  const autoScraped = useRef(false);
  /* preset per vertical: servicii/întrebări/reguli precompletate din 1 foc */
  const presetRef = useRef<Preset | null>(null);
  const [presetApplied, setPresetApplied] = useState(false);
  useEffect(() => {
    if (step === 2 && !autoScraped.current && scrapeUrl.trim()) {
      autoScraped.current = true;
      importSite();
    }
    if (step === 2 && !presetRef.current) {
      const p = presetFor(lead?.vertical);
      if (p) {
        presetRef.current = p;
        // serviciile din preset doar dacă utilizatorul n-a scris nimic încă
        setServices(rows => (rows.some(r => r.name.trim()) ? rows : p.services.map(s => ({ ...s }))));
        setPresetApplied(true);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  /* umple pasul 3 din config-ul contului */
  function seedStep3(c: Cfg) {
    setTone(TONES.some(t => t.v === c.tone) ? c.tone : 'prietenos');
    setWelcome(c.welcome || '');
    const qq = Array.isArray(c.qualificationQuestions) && c.qualificationQuestions.length > 0
      ? c.qualificationQuestions.map(x => ({ key: x.key, q: x.q || '' }))
      : [{ key: 'q1', q: '' }, { key: 'q2', q: '' }, { key: 'q3', q: '' }];
    setQuestions(qq);
    const bs = Array.isArray(c.bookingSlots) ? c.bookingSlots : [];
    setSlots([bs[0] || '', bs[1] || '']);
    if ((c as any).rules) setRules(String((c as any).rules));
  }

  /* umple pașii 2–3 din config (păstrând ce a scris deja utilizatorul) */
  function seedFromConfig(c: Cfg) {
    setCfg(c);
    setBizName(prev => prev || c.businessName || '');
    if (c.vertical && VERTICALS.includes(c.vertical)) setVertical(prev => (lead?.vertical ? prev : c.vertical));
    if (Array.isArray(c.services) && c.services.length > 0) {
      setServices(c.services.map(s => ({ name: String(s.name ?? ''), price: String(s.price ?? '') })));
    }
    seedStep3(c);
  }

  /* ---- pasul 1: signup ---- */
  async function submitAccount(e: React.FormEvent) {
    e.preventDefault();
    setErr1(null);
    if (!name.trim()) { setErr1({ msg: 'Spune-ne cum te cheamă.' }); return; }
    if (!email.includes('@')) { setErr1({ msg: 'Adresa de email nu pare validă.' }); return; }
    if (password.length < 8) { setErr1({ msg: 'Parola trebuie să aibă minim 8 caractere.' }); return; }
    setBusy(true);
    try {
      const r = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          password,
          business: bizName.trim() || undefined,
          vertical: vertical || undefined,
          demoRequestId: lead?.demoRequestId || undefined,
          ref: (() => { try { return sessionStorage.getItem('leaply_ref') || undefined; } catch { return undefined; } })(),
        }),
      });
      const d = await r.json().catch(() => ({} as any));
      if (r.ok && d.ok) {
        const c = await fetchCfg();
        if (c) seedFromConfig(c);
        setStep(2);
      } else if (r.status === 409) {
        setErr1({ msg: d.error || 'Există deja un cont cu acest email.', conflict: true });
      } else {
        setErr1({ msg: d.error || 'Nu am putut crea contul. Mai încearcă o dată.' });
      }
    } catch {
      setErr1({ msg: 'Eroare de conexiune. Verifică internetul și încearcă din nou.' });
    }
    setBusy(false);
  }

  /* ---- pasul 2: import automat de pe site ---- */
  async function importSite() {
    const url = scrapeUrl.trim();
    if (!url || scrapeBusy) return;
    setScrapeErr(null);
    setScrapedCount(null);
    setScrapeBusy(true);
    try {
      const r = await fetch('/api/onboarding/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const d = await r.json().catch(() => ({} as any));
      if (r.ok && d.ok) {
        const found: SvcRow[] = Array.isArray(d.services)
          ? d.services
            .map((s: any) => ({ name: String(s?.name ?? '').trim(), price: String(s?.price ?? '').trim() }))
            .filter((s: SvcRow) => s.name)
          : [];
        if (found.length > 0) {
          setServices(rows => {
            const existing = rows.filter(s => s.name.trim());
            const known = new Set(existing.map(s => s.name.trim().toLowerCase()));
            const merged = [...existing, ...found.filter(s => !known.has(s.name.toLowerCase()))];
            return merged.length > 0 ? merged : [{ name: '', price: '' }];
          });
        }
        if (typeof d.knowledge === 'string') setKnowledge(d.knowledge);
        if (typeof d.description === 'string') setDescription(d.description);
        setScrapedCount(found.length);
      } else {
        setScrapeErr(d.error || 'Nu am putut citi site-ul. Verifică adresa și mai încearcă o dată.');
      }
    } catch {
      setScrapeErr('Eroare de conexiune. Verifică internetul și încearcă din nou.');
    }
    setScrapeBusy(false);
  }

  /* ---- pasul 2: date firmă de la ANAF ---- */
  async function lookupAnaf() {
    const cui = cuiVal.trim();
    if (!cui || anafBusy) return;
    setAnafErr(null); setAnafBusy(true);
    try {
      const r = await fetch('/api/anaf?cui=' + encodeURIComponent(cui));
      const d = await r.json().catch(() => ({} as any));
      if (r.ok && d.ok && d.company) {
        setAnafCompany(d.company);
        if (d.company.name) setBizName(d.company.name);
      } else {
        setAnafErr(d.error || 'Nu am găsit firma. Verifică CUI-ul.');
      }
    } catch { setAnafErr('Eroare de conexiune. Mai încearcă o dată.'); }
    setAnafBusy(false);
  }

  /* ---- pasul 2: firmă + servicii ---- */
  async function submitBusiness(e: React.FormEvent) {
    e.preventDefault();
    setErr2(null);
    setBusy(true);
    const base = cfg ?? await fetchCfg();
    if (!base) {
      setErr2('Nu am putut încărca setările contului. Mai încearcă o dată.');
      setBusy(false);
      return;
    }
    if (!cfg) seedStep3(base);
    // presetul de vertical umple pasul 3 (peste default-urile generice, nu peste ce a scris omul)
    const p = presetRef.current;
    if (p) {
      setTone(p.tone);
      setWelcome(w => (w && w !== base.welcome ? w : p.welcome));
      setQuestions(qs => (qs.some(q => q.q.trim() && !(base.qualificationQuestions || []).some((bq: any) => bq.q === q.q)) ? qs : p.questions.map(q => ({ ...q }))));
      setRules(r => r || p.rules);
    }
    const merged: Cfg = {
      ...base,
      businessName: bizName.trim() || base.businessName,
      vertical,
      services: services
        .filter(s => s.name.trim())
        .map(s => ({ name: s.name.trim(), price: s.price.trim() })),
      ...(knowledge.trim() ? { knowledge: knowledge.trim() } : {}),
      ...(description.trim() ? { description: description.trim() } : {}),
      ...(lead?.phone?.trim() ? { ownerPhone: lead.phone.trim() } : {}),
      ...(anafCompany ? { company: anafCompany } : {}),
      ...(presetRef.current?.redFlags?.length ? { redFlags: presetRef.current.redFlags } : {}),
    };
    if (await postCfg(merged)) {
      if (anafCompany) {
        // datele de facturare se completează singure — clientul nu le mai tastează la plată
        fetch('/api/integrations', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'billing', company: anafCompany.name, cif: anafCompany.cui, address: anafCompany.address, city: [anafCompany.city, anafCompany.county].filter(Boolean).join(', '), email }),
        }).catch(() => {});
      }
      setCfg(merged);
      setStep(3);
    } else {
      setErr2('Nu am putut salva. Verifică conexiunea și încearcă din nou.');
    }
    setBusy(false);
  }

  /* ---- pasul 3: ton + mesaje ---- */
  async function submitAssistant(e: React.FormEvent) {
    e.preventDefault();
    setErr3(null);
    setBusy(true);
    const base = cfg ?? await fetchCfg();
    if (!base) {
      setErr3('Nu am putut încărca setările contului. Mai încearcă o dată.');
      setBusy(false);
      return;
    }
    const merged: Cfg = {
      ...base,
      tone,
      welcome: welcome.trim(),
      qualificationQuestions: questions.map(x => ({ key: x.key, q: x.q.trim() })),
      bookingSlots: [slots[0].trim(), slots[1].trim()],
      ...(rules.trim() ? { rules: rules.trim() } : {}),
    };
    if (await postCfg(merged)) {
      setCfg(merged);
      setStep(4);
    } else {
      setErr3('Nu am putut salva. Verifică conexiunea și încearcă din nou.');
    }
    setBusy(false);
  }

  /* ---- pasul 4: chat de test + activare ---- */
  async function send(text?: string) {
    const msg = (text ?? input).trim();
    if (!msg || chatBusy) return;
    const h = [...history, { sender: 'lead' as const, body: msg }];
    setHistory(h); setInput(''); setChatBusy(true); setErr4(null);
    try {
      const r = await fetch('/api/demo/message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ history: h }) });
      const d = await r.json();
      setHistory([...h, { sender: 'ai', body: d.reply }]);
      setMeta(d);
    } catch {
      setHistory([...h, { sender: 'ai', body: 'Eroare de conexiune. Mai încearcă o dată.' }]);
    }
    setChatBusy(false);
  }

  async function complete(skip: boolean) {
    if (busy) return;
    setErr4(null);
    setBusy(true);
    try {
      const r = await fetch('/api/onboarding/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          history: skip ? [] : history,
          status: (!skip && meta?.status) || 'new',
          score: (!skip && meta?.score) || 'cold',
          qualification: (!skip && meta?.qualification) || {},
        }),
      });
      if (!r.ok) throw new Error();
      try { sessionStorage.removeItem('leaply_lead'); } catch { }
      window.location.href = '/app';
      return;
    } catch {
      setErr4('Nu am putut activa asistentul. Mai încearcă o dată.');
      setBusy(false);
    }
  }

  const hasExchange = history.some(m => m.sender === 'ai');
  const chips = ['Cât costă serviciile voastre?', 'Vreau o programare'];
  const scoreRo: Record<string, string> = { hot: 'Hot', warm: 'Warm', cold: 'Cold' };

  return (
    <div className="wz">
      <header className="wz-top">
        <div className="wz-top-in">
          <Link href="/" aria-label="Leaply — acasă"><Logo light size={24} /></Link>
          <span className="wz-top-step">Pasul {step} din 4 · {STEP_NAMES[step - 1]}</span>
        </div>
      </header>

      <div className="wz-wrap">
        <div className="wz-progress" role="progressbar" aria-valuemin={1} aria-valuemax={4} aria-valuenow={step} aria-label={`Pasul ${step} din 4`}>
          <div className="wz-track"><div className="wz-fill" style={{ width: `${(step / 4) * 100}%` }} /></div>
          <div className="wz-dots">
            {[1, 2, 3, 4].map(i => (
              <span key={i} className={`wz-dot${i === step ? ' on' : i < step ? ' done' : ''}`} />
            ))}
          </div>
        </div>

        {/* ============ PASUL 1 — CONTUL TĂU ============ */}
        {step === 1 && (
          <div className="wz-card">
            <h1 className="wz-title">Contul tău</h1>
            <p className="wz-sub">Contul e gata în sub un minut. Restul pașilor sunt opționali — îi poți face și mai târziu, din aplicație.</p>
            {hasPrefill && (
              <span className="wz-prefill"><IcBolt /> Ți-am prefill-uit datele din cererea de demo.</span>
            )}
            <form className="wz-form" onSubmit={submitAccount}>
              <label className="fld" htmlFor="wz-name">Numele tău</label>
              <input id="wz-name" className="txt" value={name} onChange={e => setName(e.target.value)} placeholder="ex. Andrei Popescu" autoComplete="name" />

              <label className="fld" htmlFor="wz-email">Email</label>
              <input id="wz-email" className="txt" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="andrei@firma.ro" autoComplete="email" required />

              <label className="fld" htmlFor="wz-pass">Parolă</label>
              <div className="wz-pw">
                <input id="wz-pass" className="txt" type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Minim 8 caractere" autoComplete="new-password" minLength={8} required />
                <button type="button" className="wz-pw-toggle" onClick={() => setShowPw(v => !v)} aria-label={showPw ? 'Ascunde parola' : 'Arată parola'}>
                  {showPw ? <IcEyeOff /> : <IcEye />}
                </button>
              </div>
              <div className="wz-hint">Minim 8 caractere.</div>

              {err1 && (
                <div className="wz-err" role="alert">
                  <IcAlert />
                  <span>
                    {err1.msg}
                    {err1.conflict && <> <Link href="/login">Intră în cont</Link></>}
                  </span>
                </div>
              )}

              <div className="wz-actions">
                <button className="btn btn-primary btn-lg" type="submit" disabled={busy}>
                  {busy ? 'Se creează contul…' : <>Creează contul gratuit <IcArrowR /></>}
                </button>
              </div>
              <div className="wz-note">Fără card. Contul e gratuit cât testezi.</div>
            </form>
          </div>
        )}

        {/* ============ PASUL 2 — AFACEREA TA ============ */}
        {step === 2 && (
          <div className="wz-card">
            <h1 className="wz-title">Afacerea ta</h1>
            <p className="wz-sub">Asistentul folosește aceste date ca să răspundă corect clienților tăi.</p>
            {presetApplied && (
              <span className="wz-prefill"><IcBolt /> Am precompletat serviciile, întrebările și regulile pentru domeniul tău — ajustează doar prețurile.</span>
            )}

            <div className="wz-import">
              <div className="wz-import-head">
                <span className="wz-import-ic"><IcGlobe /></span>
                <div>
                  <b>Import automat de pe site</b>
                  <p>Îți citim site-ul și completăm automat serviciile și cunoștințele despre afacere.</p>
                </div>
              </div>
              <div className="wz-import-row">
                <input
                  className="txt"
                  value={scrapeUrl}
                  onChange={e => setScrapeUrl(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); importSite(); } }}
                  placeholder="firma.ro"
                  aria-label="Adresa site-ului firmei"
                  inputMode="url"
                  disabled={scrapeBusy}
                />
                <button type="button" className="btn btn-dark" onClick={importSite} disabled={scrapeBusy || !scrapeUrl.trim()}>
                  {scrapeBusy ? 'Se importă…' : 'Importă cu AI'}
                </button>
              </div>
              {scrapeBusy && <div className="wz-import-load">Îți citim site-ul și completăm automat serviciile… ~10s</div>}
              {!scrapeBusy && scrapeErr && <div className="wz-err" role="alert"><IcAlert /><span>{scrapeErr}</span></div>}
              {!scrapeBusy && scrapedCount !== null && (
                <span className="wz-import-ok"><IcCheck /> Am importat {scrapedCount} servicii + cunoștințe despre afacere</span>
              )}
            </div>

            <form className="wz-form" onSubmit={submitBusiness}>
              <label className="fld" htmlFor="wz-cui">CUI-ul firmei <span className="muted" style={{ fontWeight: 400 }}>(completăm restul de la ANAF)</span></label>
              <div className="wz-import-row">
                <input id="wz-cui" className="txt" value={cuiVal} onChange={e => setCuiVal(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); lookupAnaf(); } }}
                  placeholder="ex. RO12345678" inputMode="numeric" disabled={anafBusy} />
                <button type="button" className="btn btn-dark" onClick={lookupAnaf} disabled={anafBusy || !cuiVal.trim()}>
                  {anafBusy ? 'Căutăm…' : 'Preia de la ANAF'}
                </button>
              </div>
              {anafErr && <div className="wz-err" role="alert"><IcAlert /><span>{anafErr}</span></div>}
              {anafCompany && (
                <span className="wz-import-ok"><IcCheck /> {anafCompany.name} · {anafCompany.cui}{anafCompany.regCom ? ' · ' + anafCompany.regCom : ''} — datele de facturare se completează automat</span>
              )}

              <label className="fld" htmlFor="wz-biz">Numele firmei</label>
              <input id="wz-biz" className="txt" value={bizName} onChange={e => setBizName(e.target.value)} placeholder="ex. DentArt Studio SRL" required />

              <label className="fld" htmlFor="wz-vert">Domeniul</label>
              <select id="wz-vert" className="txt" value={vertical} onChange={e => setVertical(e.target.value)}>
                {VERTICALS.map(v => <option key={v} value={v}>{v}</option>)}
              </select>

              <label className="fld">Servicii și prețuri <span className="muted" style={{ fontWeight: 400 }}>(opțional)</span></label>
              {services.map((s, i) => (
                <div className="wz-svc" key={i}>
                  <input className="txt" value={s.name} onChange={e => setServices(rows => rows.map((r, j) => j === i ? { ...r, name: e.target.value } : r))} placeholder="ex. Termopane tripan" aria-label={`Serviciul ${i + 1}`} />
                  <input className="txt" value={s.price} onChange={e => setServices(rows => rows.map((r, j) => j === i ? { ...r, price: e.target.value } : r))} placeholder="de la 900 lei" aria-label={`Prețul serviciului ${i + 1}`} />
                  <button type="button" className="wz-x" onClick={() => setServices(rows => rows.filter((_, j) => j !== i))} aria-label={`Șterge serviciul ${i + 1}`}><IcX /></button>
                </div>
              ))}
              <button type="button" className="wz-add" onClick={() => setServices(rows => [...rows, { name: '', price: '' }])}><IcPlus /> Adaugă serviciu</button>

              {err2 && <div className="wz-err" role="alert"><IcAlert /><span>{err2}</span></div>}

              <div className="wz-actions">
                <button className="btn btn-primary btn-lg" type="submit" disabled={busy}>
                  {busy ? 'Se salvează…' : <>Continuă <IcArrowR /></>}
                </button>
              </div>
            </form>
            <button type="button" className="wz-skip" onClick={() => { window.location.href = '/app'; }} disabled={busy}>
              Contul e deja creat — sar peste configurare și intru în aplicație
            </button>
          </div>
        )}

        {/* ============ PASUL 3 — ASISTENTUL TĂU ============ */}
        {step === 3 && (
          <div className="wz-card">
            <h1 className="wz-title">Asistentul tău</h1>
            <p className="wz-sub">Cum vorbește cu clienții, ce îi întreabă și când poate programa vizite.</p>
            <form className="wz-form" onSubmit={submitAssistant}>
              <label className="fld" htmlFor="wz-tone">Tonul asistentului</label>
              <select id="wz-tone" className="txt" value={tone} onChange={e => setTone(e.target.value)}>
                {TONES.map(t => <option key={t.v} value={t.v}>{t.label}</option>)}
              </select>

              <label className="fld" htmlFor="wz-welcome">Mesajul de bun venit</label>
              <textarea id="wz-welcome" className="txt" rows={3} value={welcome} onChange={e => setWelcome(e.target.value)} placeholder="ex. Bună! Mulțumim că ne-ai scris. Cu ce te putem ajuta?" />

              <label className="fld">Întrebările de calificare</label>
              {questions.map((q, i) => (
                <input
                  key={i}
                  className="txt"
                  style={{ marginBottom: 8 }}
                  value={q.q}
                  onChange={e => setQuestions(rows => rows.map((r, j) => j === i ? { ...r, q: e.target.value } : r))}
                  placeholder={`Întrebarea ${i + 1}`}
                  aria-label={`Întrebarea de calificare ${i + 1}`}
                />
              ))}

              <label className="fld">Intervale de programare</label>
              <input className="txt" style={{ marginBottom: 8 }} value={slots[0]} onChange={e => setSlots(s => [e.target.value, s[1]])} placeholder="ex. mâine 10:00–12:00" aria-label="Intervalul 1" />
              <input className="txt" value={slots[1]} onChange={e => setSlots(s => [s[0], e.target.value])} placeholder="ex. joi 14:00–16:00" aria-label="Intervalul 2" />

              <label className="fld" htmlFor="wz-rules">Reguli și limite <span className="muted" style={{ fontWeight: 400 }}>(opțional — asistentul le respectă strict)</span></label>
              <textarea id="wz-rules" className="txt" rows={3} value={rules} onChange={e => setRules(e.target.value)}
                placeholder="ex. Nu promite termene de livrare. Nu oferi discounturi. Nu discuta despre concurență. Programările doar în timpul săptămânii." />

              {err3 && <div className="wz-err" role="alert"><IcAlert /><span>{err3}</span></div>}

              <div className="wz-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setStep(2)} disabled={busy}><IcArrowL /> Înapoi</button>
                <button className="btn btn-primary btn-lg" type="submit" disabled={busy}>
                  {busy ? 'Se salvează…' : <>Continuă <IcArrowR /></>}
                </button>
              </div>
            </form>
            <button type="button" className="wz-skip" onClick={() => { window.location.href = '/app'; }} disabled={busy}>
              Sar peste — configurez mai târziu din aplicație
            </button>
          </div>
        )}

        {/* ============ PASUL 4 — TESTEAZĂ-L ============ */}
        {step === 4 && (
          <div className="wz-card">
            <h1 className="wz-title">Testează-l</h1>
            <p className="wz-sub">Scrie ca un client real. Asistentul răspunde cu datele tale, exact ca în producție.</p>

            <div className="wz-chat">
              <div className="wz-chat-head">
                <span className="wz-ava"><IcBot /></span>
                <span>
                  <b>{cfg?.businessName || bizName || 'Asistentul tău'}</b>
                  <small>asistent Leaply · răspunde instant</small>
                </span>
              </div>
              <div ref={boxRef} className="wz-chat-body">
                {history.length === 0 && (
                  <div className="wz-empty">Trimite un mesaj de test — de exemplu „Cât costă serviciile voastre?” — și vezi cum răspunde.</div>
                )}
                {history.map((m, i) => (
                  <div key={i} className={`bubble ${m.sender === 'lead' ? 'out' : 'in'}`}>{m.body}</div>
                ))}
                {chatBusy && <div className="wz-typing">Asistentul scrie…</div>}
              </div>
              <div className="wz-chat-foot">
                <input className="txt" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Scrie ca un client…" aria-label="Mesaj de test" />
                <button type="button" className="btn btn-dark btn-sm" onClick={() => send()} disabled={chatBusy}>Trimite</button>
              </div>
            </div>

            <div className="wz-chips">
              {chips.map(c => <button key={c} type="button" className="wz-chip" onClick={() => send(c)} disabled={chatBusy}>{c}</button>)}
            </div>

            {meta && (
              <div className="wz-meta">
                <IcCheck /> Răspuns în {(meta.latencyMs / 1000).toFixed(2)} sec · scor lead: <b style={{ color: 'var(--ink)' }}>{scoreRo[meta.score] || meta.score}</b>
              </div>
            )}

            {err4 && <div className="wz-err" role="alert"><IcAlert /><span>{err4}</span></div>}

            <div className="wz-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setStep(3)} disabled={busy}><IcArrowL /> Înapoi</button>
              <button
                type="button"
                className={`btn btn-lg ${hasExchange ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => complete(false)}
                disabled={busy || !hasExchange}
                title={hasExchange ? undefined : 'Trimite mai întâi un mesaj de test'}
              >
                {busy ? 'Se activează…' : <>Activează asistentul <IcArrowR /></>}
              </button>
            </div>
            <button type="button" className="wz-skip" onClick={() => complete(true)} disabled={busy}>Sar peste test și activez direct</button>
          </div>
        )}
      </div>
    </div>
  );
}
