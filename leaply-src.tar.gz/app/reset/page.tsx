'use client';

import { useState, useEffect, FormEvent } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';

function IconLock() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="4.5" y="10.5" width="15" height="10" rx="2.5" />
      <path d="M8 10.5V7.75a4 4 0 0 1 8 0v2.75" />
    </svg>
  );
}

function IconAlert() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 8v4.5" />
      <path d="M12 15.8h.01" />
    </svg>
  );
}

function IconCheck({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m5 12.5 4.5 4.5L19 7.5" />
    </svg>
  );
}

export default function ResetPage() {
  const [token, setToken] = useState('');
  const [noToken, setNoToken] = useState(false);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const t = new URLSearchParams(window.location.search).get('token');
    if (t) setToken(t);
    else setNoToken(true);
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError('');
    if (password.length < 8) {
      setError('Parola trebuie să aibă cel puțin 8 caractere.');
      return;
    }
    if (password !== confirm) {
      setError('Parolele nu coincid. Scrie aceeași parolă în ambele câmpuri.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setDone(true);
        return;
      }
      setError(data.error || 'Linkul de resetare este invalid sau a expirat. Cere unul nou.');
      setLoading(false);
    } catch {
      setError('Nu am putut contacta serverul. Verifică conexiunea și încearcă din nou.');
      setLoading(false);
    }
  }

  return (
    <div className="au-wrap">
      <div className="au-box">
        <Link href="/" className="au-logo" aria-label="Leaply — înapoi la pagina principală">
          <Logo />
        </Link>

        <div className="au-card">
          {done ? (
            <div className="au-done">
              <div className="au-done-mark">
                <IconCheck size={24} />
              </div>
              <h1 className="au-head">Parolă schimbată</h1>
              <p className="au-sub">
                Gata, noua parolă e activă. Poți intra în cont chiar acum.
              </p>
              <Link href="/login" className="btn btn-primary">
                Intră în cont
              </Link>
            </div>
          ) : noToken ? (
            <>
              <div className="au-mark">
                <IconLock />
              </div>
              <h1 className="au-head">Link invalid</h1>
              <p className="au-sub">
                Linkul de resetare este incomplet sau a expirat. Cere unul nou și încearcă din nou
                din emailul primit.
              </p>
              <Link href="/forgot" className="btn btn-primary au-submit">
                Cere un link nou
              </Link>
            </>
          ) : (
            <>
              <div className="au-mark">
                <IconLock />
              </div>
              <h1 className="au-head">Setează o parolă nouă</h1>
              <p className="au-sub">
                Alege o parolă de cel puțin 8 caractere, pe care n-o folosești în altă parte.
              </p>

              <form className="au-form" onSubmit={onSubmit} noValidate>
                <label className="fld" htmlFor="au-pass">Parolă nouă</label>
                <div className="au-pw">
                  <input
                    id="au-pass"
                    className="txt"
                    type={show ? 'text' : 'password'}
                    autoComplete="new-password"
                    placeholder="Minim 8 caractere"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoFocus
                  />
                  <button
                    type="button"
                    className="au-toggle"
                    onClick={() => setShow((v) => !v)}
                    aria-label={show ? 'Ascunde parola' : 'Arată parola'}
                  >
                    {show ? 'ascunde' : 'arată'}
                  </button>
                </div>
                <p className="au-hint">Cel puțin 8 caractere.</p>

                <label className="fld" htmlFor="au-confirm">Repetă parola</label>
                <input
                  id="au-confirm"
                  className="txt"
                  type={show ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="Aceeași parolă, încă o dată"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />

                {error && (
                  <div className="au-error" role="alert">
                    <IconAlert />
                    <span>{error}</span>
                  </div>
                )}

                <button className="btn btn-primary au-submit" type="submit" disabled={loading}>
                  {loading ? (
                    <>
                      <span className="au-spin" aria-hidden="true" />
                      Se salvează…
                    </>
                  ) : (
                    'Salvează parola nouă'
                  )}
                </button>
              </form>
            </>
          )}
        </div>

        <div className="au-links">
          <span>
            Ți-ai amintit parola? <Link href="/login">Intră în cont</Link>
          </span>
        </div>
      </div>
    </div>
  );
}
