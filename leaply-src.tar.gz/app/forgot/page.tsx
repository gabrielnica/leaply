'use client';

import { useState, FormEvent } from 'react';
import Link from 'next/link';
import { Logo } from '../../lib/logo';

function IconMail() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="3.5" y="5.5" width="17" height="13" rx="2.5" />
      <path d="m4.5 7.5 7.5 5.5 7.5-5.5" />
    </svg>
  );
}

function IconArrow() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M4.5 12h15" />
      <path d="m13.5 6 6 6-6 6" />
    </svg>
  );
}

function IconAlert() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 8v4.5" />
      <path d="M12 15.8h.01" />
    </svg>
  );
}

function IconCheck() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="m5 12.5 4.5 4.5L19 7.5" />
    </svg>
  );
}

export default function ForgotPage() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (loading) return;
    setError('');
    if (!email.trim() || !email.includes('@')) {
      setError('Scrie adresa de email cu care ți-ai făcut contul.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() }),
      });
      if (res.ok) {
        setSent(true);
      } else {
        const data = await res.json().catch(() => ({}));
        setError(data.error || 'Ceva n-a mers. Încearcă din nou.');
      }
    } catch {
      setError('Nu am putut contacta serverul. Verifică conexiunea și încearcă din nou.');
    }
    setLoading(false);
  }

  return (
    <div className="au-wrap">
      <div className="au-box">
        <Link href="/" className="au-logo" aria-label="Leaply — înapoi la pagina principală">
          <Logo />
        </Link>

        <div className="au-card">
          <div className="au-mark">
            <IconMail />
          </div>
          <h1 className="au-head">Ai uitat parola?</h1>
          <p className="au-sub">
            Nicio problemă. Scrie emailul contului și îți trimitem un link de resetare.
          </p>

          {sent ? (
            <div className="au-ok" role="status">
              <IconCheck />
              <span>
                Dacă există un cont cu acest email, primești în câteva minute un link de resetare
                (valabil o oră).
              </span>
            </div>
          ) : (
            <form className="au-form" onSubmit={onSubmit} noValidate>
              <label className="fld" htmlFor="au-email">Email</label>
              <input
                id="au-email"
                className="txt"
                type="email"
                autoComplete="email"
                placeholder="nume@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoFocus
              />

              {error && (
                <div className="au-error" role="alert">
                  <IconAlert />
                  <span>{error}</span>
                </div>
              )}

              <button className="btn btn-primary au-submit" type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <span className="au-spin" aria-hidden="true" />
                    Se trimite…
                  </>
                ) : (
                  <>
                    Trimite linkul
                    <IconArrow />
                  </>
                )}
              </button>
            </form>
          )}
        </div>

        <div className="au-links">
          <span>
            Ți-ai amintit parola? <Link href="/login">Intră în cont</Link>
          </span>
        </div>
      </div>
    </div>
  );
}
