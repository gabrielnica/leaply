import { LegalShell } from '../legal-layout';
export const metadata = { title: 'Termeni și condiții — Leaply' };

export default function Termeni() {
  return (
    <LegalShell title="Termeni și condiții" updated="2 iulie 2026">
      <h2>1. Cine suntem</h2>
      <p>Platforma Leaply (leaply.ro) este operată de <b>ARHAI S.R.L.</b>, CUI RO35913161, J2016000743052, cu sediul în Oradea, jud. Bihor („Leaply", „noi"). Ne poți contacta la <a href="mailto:salut@leaply.ro">salut@leaply.ro</a>.</p>

      <h2>2. Serviciul</h2>
      <p>Leaply este un serviciu software (SaaS) care răspunde automat lead-urilor afacerii tale pe canale precum WhatsApp, Facebook Messenger, Instagram, formular web, SMS și telefon, îi califică prin întrebări configurabile și poate propune programări. Serviciul include un panou de administrare, integrări (ex. Google Calendar, CRM prin API/webhook) și rapoarte.</p>

      <h2>3. Contul și utilizarea</h2>
      <p>Ești responsabil pentru confidențialitatea datelor de autentificare și pentru activitatea din contul tău. Serviciul poate fi folosit doar în scopuri legale; este interzisă utilizarea pentru spam, mesaje nesolicitate în masă, conținut ilegal sau înșelător. Trebuie să ai temeiul legal de a comunica cu persoanele ale căror date le introduci sau le conectezi la Leaply.</p>

      <h2>4. Abonamente, plăți și facturare</h2>
      <p>Planurile și prețurile sunt afișate pe leaply.ro (Trial gratuit, apoi Start, Pro, Scale — abonamente lunare în EUR). Plata se procesează prin Stripe; facturile se emit automat. Fiecare plan include un număr lunar de conversații; la depășire te anunțăm și îți propunem un plan superior. Poți anula oricând — abonamentul rămâne activ până la finalul perioadei plătite. Sumele deja facturate nu se rambursează, cu excepția cazurilor prevăzute de lege.</p>

      <h2>5. Conținutul și datele tale</h2>
      <p>Rămâi proprietarul datelor introduse (configurări, cunoștințe despre afacere, date despre lead-uri). Ne acorzi o licență limitată de a le prelucra strict pentru furnizarea serviciului. Detalii despre prelucrarea datelor cu caracter personal găsești în <a href="/confidentialitate">Politica de confidențialitate</a>.</p>

      <h2>6. Răspunsuri generate de AI</h2>
      <p>Răspunsurile asistentului sunt generate automat pe baza configurării tale. Facem eforturi rezonabile ca acestea să respecte regulile setate de tine, dar nu garantăm acuratețea fiecărui răspuns. Ești responsabil de verificarea informațiilor comerciale critice (prețuri, termene, angajamente) comunicate clienților tăi.</p>

      <h2>7. Disponibilitate și limitarea răspunderii</h2>
      <p>Ne propunem o disponibilitate cât mai ridicată, fără a garanta funcționare neîntreruptă; serviciul depinde și de platforme terțe (Meta, Google, operatori SMS/telefonie, Stripe). În limita maximă permisă de lege, răspunderea noastră totală este limitată la sumele plătite de tine în ultimele 12 luni. Nu răspundem pentru pierderi indirecte (profit nerealizat, pierderi de date cauzate de terți etc.).</p>

      <h2>8. Suspendare și încetare</h2>
      <p>Putem suspenda sau închide conturi care încalcă acești termeni (cu notificare, când e rezonabil). Tu poți închide contul oricând; la cerere, îți exportăm sau ștergem datele conform legislației aplicabile.</p>

      <h2>9. Modificări</h2>
      <p>Putem actualiza acești termeni; modificările semnificative se anunță pe email cu minimum 15 zile înainte. Continuarea utilizării după intrarea în vigoare înseamnă acceptare.</p>

      <h2>10. Legea aplicabilă</h2>
      <p>Se aplică legea română. Litigiile se soluționează amiabil sau de instanțele competente din Oradea. Consumatorii pot apela la <a href="https://anpc.ro/ce-este-sal/" target="_blank" rel="noopener">SAL (ANPC)</a> sau la <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener">platforma europeană SOL</a>.</p>

      <h2>Anexa 1 — Acord de prelucrare a datelor (DPA)</h2>
      <p>Această anexă face parte integrantă din Termeni și se aplică în măsura în care, prin utilizarea serviciului, ne transmiți date cu caracter personal ale clienților și potențialilor tăi clienți („lead-uri"), în sensul Regulamentului (UE) 2016/679 (GDPR).</p>

      <h3>A1.1. Rolurile părților</h3>
      <p>Pentru datele lead-urilor tale, tu ești <b>operator</b> (stabilești scopurile și mijloacele), iar ARHAI S.R.L. acționează ca <b>persoană împuternicită</b> (procesor), prelucrând datele exclusiv conform instrucțiunilor tale documentate — adică configurarea contului și funcționarea serviciului. Pentru datele contului tău (email, facturare), Leaply e operator, conform <a href="/confidentialitate">Politicii de confidențialitate</a>.</p>

      <h3>A1.2. Obiectul, durata și natura prelucrării</h3>
      <p>Obiect: recepționarea, stocarea și procesarea mesajelor și datelor de contact ale lead-urilor (nume, telefon, conținutul conversațiilor, date de programare), generarea de răspunsuri automate și rapoarte. Durata: pe durata contractului; la încetare, datele se șterg sau se restituie conform A1.6. Categorii de persoane vizate: clienții și potențialii clienți ai afacerii tale. Nu prelucrăm intenționat categorii speciale de date; te obligi să nu soliciți lead-urilor astfel de date prin configurarea asistentului.</p>

      <h3>A1.3. Subprocesatori autorizați</h3>
      <p>Ne autorizezi în mod general să folosim următoarele categorii de subprocesatori, cu obligații contractuale cel puțin la fel de stricte: găzduire pe servere în Uniunea Europeană; furnizori de modele AI (ex. OpenAI) pentru generarea răspunsurilor; platforme de mesagerie prin care alegi să comunici (Meta — WhatsApp/Messenger/Instagram; Twilio; SMSLink); Google (Calendar, dacă îl conectezi); Stripe și SmartBill (plăți și facturare); Resend (emailuri tranzacționale). Lista actualizată e disponibilă la cerere la <a href="mailto:salut@leaply.ro">salut@leaply.ro</a>; te anunțăm cu 15 zile înainte de adăugarea unui subprocesator nou, cu drept de obiecție.</p>

      <h3>A1.4. Securitate</h3>
      <p>Aplicăm măsuri tehnice și organizatorice adecvate: criptarea comunicațiilor (TLS), criptarea token-urilor și cheilor, controlul accesului pe bază de rol și sesiuni, jurnal de audit pentru acțiunile sensibile, copii de rezervă zilnice cu păstrare limitată, acces la datele de producție restricționat la personal autorizat.</p>

      <h3>A1.5. Asistență și incidente</h3>
      <p>Te asistăm, în limite rezonabile, la îndeplinirea obligațiilor tale privind drepturile persoanelor vizate (acces, rectificare, ștergere, export) — prin funcțiile din aplicație (export CSV, ștergere conversații) sau la cerere. Te notificăm fără întârzieri nejustificate (cel târziu în 48 de ore de la constatare) despre orice încălcare a securității datelor care afectează datele prelucrate pentru tine.</p>

      <h3>A1.6. Ștergere și restituire</h3>
      <p>La încetarea contractului, îți putem exporta datele (format CSV/JSON) și le ștergem din sistemele active în cel mult 30 de zile, iar din copiile de rezervă prin rotația normală a acestora (max. 90 de zile), cu excepția datelor pe care legea ne obligă să le păstrăm (ex. documente contabile).</p>

      <h3>A1.7. Audit</h3>
      <p>La cerere scrisă, cel mult o dată pe an, îți punem la dispoziție informațiile rezonabil necesare pentru a demonstra conformitatea cu această anexă (descrierea măsurilor, certificări/atestări ale subprocesatorilor).</p>
    </LegalShell>
  );
}
