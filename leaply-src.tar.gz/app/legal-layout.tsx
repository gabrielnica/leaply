import Link from 'next/link';
import { Logo } from '../lib/logo';

export function LegalShell({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  return (
    <main style={{ maxWidth: 780, margin: '0 auto', padding: '40px 20px 80px', lineHeight: 1.65 }}>
      <p><Link href="/">← leaply.ro</Link></p>
      <div style={{ margin: '8px 0 4px' }}><Logo size={28} /></div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 34, margin: '10px 0 4px' }}>{title}</h1>
      <p style={{ color: 'var(--muted)', fontSize: 14 }}>Ultima actualizare: {updated}</p>
      <div className="legal-body">{children}</div>
      <hr style={{ margin: '40px 0 16px', border: 'none', borderTop: '1px solid rgba(16,18,20,.12)' }} />
      <p style={{ fontSize: 14, color: 'var(--muted)' }}>
        <Link href="/termeni">Termeni și condiții</Link> · <Link href="/confidentialitate">Politica de confidențialitate</Link> · <Link href="/cookies">Politica de cookies</Link><br />
        ARHAI S.R.L. · CUI RO35913161 · J2016000743052 · Oradea, jud. Bihor · salut@leaply.ro<br />
        <a href="https://anpc.ro/ce-este-sal/" target="_blank" rel="noopener">ANPC — SAL</a> · <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener">Platforma SOL (ODR)</a>
      </p>
    </main>
  );
}
