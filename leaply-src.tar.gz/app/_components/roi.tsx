'use client';
import { useState } from 'react';
export function RoiCalculator() {
  const [leads, setLeads] = useState(40);
  const [value, setValue] = useState(3000);
  const [rate, setRate] = useState(30);
  const missed = Math.round(leads * 0.4);              // ~40% nu primesc răspuns la timp
  const recovered = Math.round(missed * 0.6);          // Leaply recuperează ~60% din ele
  const extraDeals = Math.round(recovered * (rate / 100));
  const monthly = extraDeals * value;
  const fmt = (n: number) => n.toLocaleString('ro-RO');
  return (
    <div className="roi">
      <div className="roi-controls">
        <label>Lead-uri pe lună<b>{leads}</b></label>
        <input type="range" min={5} max={300} value={leads} onChange={e => setLeads(+e.target.value)} />
        <label>Valoarea unui client (lei)<b>{fmt(value)}</b></label>
        <input type="range" min={200} max={20000} step={100} value={value} onChange={e => setValue(+e.target.value)} />
        <label>Rata ta de închidere<b>{rate}%</b></label>
        <input type="range" min={5} max={60} value={rate} onChange={e => setRate(+e.target.value)} />
      </div>
      <div className="roi-result">
        <div className="roi-big">+{fmt(monthly)} lei<span>/lună</span></div>
        <p>venituri recuperate estimate, din lead-uri la care altfel nu ai fi răspuns la timp</p>
        <div className="roi-sub">
          <span><b>{missed}</b> lead-uri/lună pierdute acum</span>
          <span><b>{extraDeals}</b> clienți în plus cu Leaply</span>
        </div>
        <a href="#demo" className="btn btn-primary">Vreau rezultatul ăsta ▸</a>
      </div>
    </div>
  );
}
