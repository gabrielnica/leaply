'use client';
import { useState } from 'react';
export function LeadForm() {
  const [f, setF] = useState({ name: '', contact: '', business: '', vertical: 'Servicii casă (termopane, mobilă, amenajări)' });
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const upd = (k: string, v: string) => setF({ ...f, [k]: v });
  async function submit(e: any) {
    e.preventDefault();
    if (!f.contact || loading) return;
    setLoading(true);
    try { await fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) }); setSent(true); }
    catch { setSent(true); }
    setLoading(false);
  }
  if (sent) return (
    <div className="leadform sent">
      <div style={{ fontSize: 44 }}>🎉</div>
      <h3>Gata! Te contactăm în cel mult o oră.</h3>
      <p>Îți pregătim un asistent Leaply pe lead-urile afacerii tale. Vezi între timp cum răspunde:</p>
      <a href="/demo" className="btn btn-primary">Deschide demo live ▸</a>
    </div>
  );
  return (
    <form className="leadform" onSubmit={submit}>
      <h3>Vezi Leaply pe afacerea ta</h3>
      <p>Îți setăm un asistent pe lead-urile tale reale. Fără card, fără obligații.</p>
      <input placeholder="Numele tău" value={f.name} onChange={e => upd('name', e.target.value)} />
      <input placeholder="Telefon sau email *" value={f.contact} onChange={e => upd('contact', e.target.value)} required />
      <input placeholder="Numele firmei" value={f.business} onChange={e => upd('business', e.target.value)} />
      <select value={f.vertical} onChange={e => upd('vertical', e.target.value)}>
        <option>Servicii casă (termopane, mobilă, amenajări)</option>
        <option>Imobiliare</option>
        <option>Clinică privată</option>
        <option>Dealer auto</option>
        <option>Altceva</option>
      </select>
      <button className="btn btn-primary" type="submit">{loading ? 'Se trimite…' : 'Cere demo gratuit ▸'}</button>
      <span className="micro">🔒 Datele tale rămân în UE. Fără spam.</span>
    </form>
  );
}
