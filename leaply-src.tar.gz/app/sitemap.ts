import type { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = 'https://leaply.ro';
  const now = new Date();
  const fixed = ['', '/demo', '/start', '/developers', '/termeni', '/confidentialitate', '/cookies'];
  const verticals = ['termopane', 'stomatologie', 'service-auto', 'imobiliare', 'instalatii', 'saloane'];
  return [
    ...fixed.map(p => ({ url: base + p, lastModified: now, priority: p === '' ? 1 : 0.7 })),
    ...verticals.map(v => ({ url: `${base}/solutii/${v}`, lastModified: now, priority: 0.8 })),
  ];
}
