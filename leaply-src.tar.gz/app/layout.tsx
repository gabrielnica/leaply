import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Leaply — Răspunde fiecărui lead în sub 60 de secunde',
  description: 'Leaply răspunde automat, în română, fiecărui lead de pe Facebook, Instagram, WhatsApp sau site — îl califică și îți programează întâlnirea. 24/7.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ro">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  );
}
