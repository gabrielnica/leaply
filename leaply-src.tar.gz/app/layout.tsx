import './globals.css';
import './landing.css';
import './app-ui.css';
import './auth-ui.css';
import './wizard.css';
import type { Metadata } from 'next';
import { Bricolage_Grotesque, Inter } from 'next/font/google';

const display = Bricolage_Grotesque({ subsets: ['latin', 'latin-ext'], weight: ['500', '600', '700', '800'], variable: '--font-display' });
const text = Inter({ subsets: ['latin', 'latin-ext'], weight: ['400', '500', '600', '700'], variable: '--font-text' });

export const metadata: Metadata = {
  metadataBase: new URL('https://leaply.ro'),
  title: 'Leaply — Niciun lead pierdut. Răspuns în sub 60 de secunde, 24/7',
  description: 'Leaply răspunde automat, în română, fiecărui lead de pe Facebook, Instagram, WhatsApp sau site — îl califică și îți programează întâlnirea în calendar. Tu doar vinzi.',
  openGraph: {
    title: 'Leaply — Niciun lead pierdut',
    description: 'Asistent AI în română care răspunde lead-urilor tale în sub 60 de secunde, le califică și programează întâlniri. 24/7.',
    url: 'https://leaply.ro',
    siteName: 'Leaply',
    locale: 'ro_RO',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ro" className={`${display.variable} ${text.variable}`}>
      <body>{children}</body>
    </html>
  );
}
