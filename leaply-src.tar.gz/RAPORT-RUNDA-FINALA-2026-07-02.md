# Leaply — Raport rundă finală · 2 iulie 2026

Totul din plan e implementat, testat local (10/10 teste) și LIVE pe leaply.ro.

## Livrat în această rundă

1. **Funnel fără dublă tastare** — formularul „Cere demo" cere acum: nume, email (obligatoriu), telefon, site, firmă, tip servicii → totul se salvează la prima interacțiune (îl vezi în Admin chiar dacă abandonează) → utilizatorul aterizează în wizard cu TOATE datele precompletate.
2. **Knowledge AI de pe site-ul clientului** — în wizard, pasul „Afacerea ta" are „Importă cu AI": citim site-ul lui, extragem serviciile + prețurile + cunoștințe despre afacere (cu LLM când cheia OpenAI e setată; euristic altfel) și le injectăm în creierul asistentului (`config.knowledge`, folosit în system prompt).
3. **WhatsApp fără fricțiune** — în Canale, opțiunea recomandată: „Cere număr de la Leaply" — un click, clientul nu-și face niciun cont nicăieri; cererea îți vine pe email + apare în Admin, tu provisionezi numărul din contul tău Twilio master. Variantele Meta/Twilio proprii au rămas la „avansat".
4. **Dashboard captivant** — Overview are acum: card „Utilizare plan" cu bară de progres, grafic SVG „Activitate ultimele 14 zile", linia „Leaply a răspuns la X lead-uri — echivalentul a ~Y ore de muncă", pe lângă eroul „lei salvați".
5. **Follow-up-uri automate** — motor cron (`/api/cron/run?key=CRON_SECRET`): lead-urile care nu răspund după N ore primesc follow-up pe canalul original, cu fallback pe SMS; configurabil de client în Setări (on/off, ore, mesaj). Max 1 follow-up per conversație.
6. **SMS prin SMSLink.ro** — confirmare automată la programare către lead + canal de fallback pentru follow-up. Chei în Admin → Setări platformă.
7. **Facturare completă** — la plata Stripe (recurentă), factura SmartBill pleacă AUTOMAT pe firma clientului (datele de facturare le completează clientul în Setări → „Date de facturare"; seria/CIF-ul tău în Admin → Setări).
8. **Admin extins** — grupuri noi de chei: SMSLink, SmartBill, Twilio master, CRON_SECRET; cererile de numere WhatsApp apar în lista de cereri.

## Ce activezi tu (o singură dată, toate din Admin → Setări platformă)

| Serviciu | Ce faci | Deblochează |
|---|---|---|
| OpenAI | cheie API (~5 min) | LLM real + import site cu AI de calitate |
| Meta App | App ID + Secret (~15 min) | Conectare Facebook un-click |
| Resend | cheie + domeniu verificat | emailuri reale (resetări, notificări, follow-up email) |
| SMSLink.ro | connection ID + parolă | SMS confirmări + reamintiri |
| SmartBill | email + token + CIF + serie | facturi automate la plată |
| Stripe | chei + 3 price ID-uri | plăți recurente self-service |
| Twilio master | SID + token (contul tău) | numere WhatsApp „de la Leaply" pentru clienți |
| Google Cloud | Client ID + Secret | Calendar live |
| Coolify | Scheduled Task: `curl "https://leaply.ro/api/cron/run?key=<CRON_SECRET>"` la 15 min | follow-up-urile rulează singure |

## Verificat live după deploy

Formularul nou pe landing ✓ · scrape/cron/request-number protejate corect (401 fără auth/cheie) ✓ · health OK, datele păstrate ✓ · regresie demo/wizard/dashboard ✓

## Recomandarea următorului pas

Pune cheia OpenAI + creează aplicația Meta (împreună ~20 de minute) și fă un test cap-coadă cu firma ta: cere demo pe landing → wizard cu import de pe site-ul tău → conectează pagina ta de Facebook → scrie-ți pe Messenger. Din momentul ăla ai produsul întreg în mână, exact cum îl va trăi primul client.
