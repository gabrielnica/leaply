import { NextRequest, NextResponse } from 'next/server';

// Protecție opțională cu parolă (Basic Auth) pentru dashboard + API-uri sensibile.
// Se activează setând env ADMIN_PASSWORD în Coolify. Fără ADMIN_PASSWORD, totul rămâne
// deschis (mod demo MVP) — recomandat să setezi parola înainte de clienți reali.
export function middleware(req: NextRequest) {
  const pass = process.env.ADMIN_PASSWORD;
  if (!pass) return NextResponse.next();
  const auth = req.headers.get('authorization') || '';
  if (auth.startsWith('Basic ')) {
    try {
      const decoded = atob(auth.slice(6));
      const pw = decoded.slice(decoded.indexOf(':') + 1);
      if (pw === pass) return NextResponse.next();
    } catch {}
  }
  return new NextResponse('Autentificare necesară', {
    status: 401,
    headers: { 'WWW-Authenticate': 'Basic realm="Leaply"' },
  });
}

export const config = {
  matcher: ['/app/:path*', '/admin/:path*', '/api/account/:path*', '/api/conversation/:path*'],
};
