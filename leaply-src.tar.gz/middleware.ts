import { NextRequest, NextResponse } from 'next/server';

const SESSION_COOKIE = 'leaply_session';

// Gard ușor la margine: fără cookie de sesiune nu intri în /app sau /admin.
// Validarea reală a sesiunii (DB) se face în layout-uri/pagini/API-uri.
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (pathname === '/admin/login') return NextResponse.next();
  const hasSession = Boolean(req.cookies.get(SESSION_COOKIE)?.value);
  if (hasSession) return NextResponse.next();
  const url = req.nextUrl.clone();
  url.pathname = pathname.startsWith('/admin') ? '/admin/login' : '/login';
  url.search = `?next=${encodeURIComponent(pathname)}`;
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ['/app/:path*', '/admin/:path*'],
};
