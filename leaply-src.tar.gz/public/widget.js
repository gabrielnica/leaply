/* Leaply chat widget — instalare: <script src="https://leaply.ro/widget.js" data-leaply="ID_CONT" async></script>
   Opțional: data-color="#FF4D1F" data-position="left|right" data-avatar="https://…/logo.png" */
(function () {
  if (window.__leaply) return; window.__leaply = 1;
  var sc = document.currentScript || Array.prototype.slice.call(document.scripts).filter(function (s) { return s.src && s.src.indexOf('widget.js') > -1; }).pop();
  var ACC = sc && sc.getAttribute('data-leaply'); if (!ACC) return;
  var BASE = (sc.src.match(/^https?:\/\/[^\/]+/) || ['https://leaply.ro'])[0];
  var ACCENT = (sc.getAttribute('data-color') || '#FF4D1F');
  var SIDE = (sc.getAttribute('data-position') === 'left') ? 'left' : 'right';
  var AVATAR = sc.getAttribute('data-avatar') || '';
  var SID_KEY = 'leaply_sid';
  var sid; try { sid = localStorage.getItem(SID_KEY); if (!sid) { sid = 'w' + Math.random().toString(36).slice(2) + Date.now().toString(36); localStorage.setItem(SID_KEY, sid); } } catch (e) { sid = 'w' + Date.now(); }

  var css = document.createElement('style');
  css.textContent = '.lpw-btn{position:fixed;' + SIDE + ':20px;bottom:20px;z-index:2147483000;width:58px;height:58px;border-radius:50%;border:0;cursor:pointer;background:' + ACCENT + ';box-shadow:0 8px 28px rgba(0,0,0,.28);display:flex;align-items:center;justify-content:center;transition:transform .15s;overflow:hidden}.lpw-btn:hover{transform:scale(1.06)}.lpw-btn img{width:100%;height:100%;object-fit:cover;border-radius:50%}.lpw-panel{position:fixed;' + SIDE + ':20px;bottom:90px;z-index:2147483000;width:min(360px,calc(100vw - 32px));height:min(520px,calc(100vh - 120px));background:#fff;border-radius:16px;box-shadow:0 18px 60px rgba(0,0,0,.30);display:none;flex-direction:column;overflow:hidden;font-family:-apple-system,Segoe UI,Roboto,sans-serif}.lpw-panel.on{display:flex}.lpw-head{background:#101214;color:#fff;padding:14px 16px;font-weight:600;font-size:15px;display:flex;justify-content:space-between;align-items:center}.lpw-head small{display:block;font-weight:400;opacity:.7;font-size:12px}.lpw-x{background:none;border:0;color:#fff;font-size:20px;cursor:pointer;line-height:1}.lpw-msgs{flex:1;overflow-y:auto;padding:14px;background:#f7f5f1}.lpw-m{max-width:82%;margin:0 0 8px;padding:9px 12px;border-radius:12px;font-size:14px;line-height:1.45;white-space:pre-wrap;word-wrap:break-word}.lpw-ai{background:#fff;border:1px solid rgba(16,18,20,.10);border-bottom-left-radius:4px}.lpw-me{background:' + ACCENT + ';color:#fff;margin-left:auto;border-bottom-right-radius:4px}.lpw-in{display:flex;gap:8px;padding:10px;border-top:1px solid rgba(16,18,20,.08);background:#fff}.lpw-in input{flex:1;border:1px solid rgba(16,18,20,.16);border-radius:10px;padding:10px 12px;font-size:14px;outline:none}.lpw-in input:focus{border-color:' + ACCENT + '}.lpw-in button{border:0;border-radius:10px;background:#101214;color:#fff;padding:0 16px;font-size:14px;font-weight:600;cursor:pointer}.lpw-dots{opacity:.6;font-size:13px;padding:4px 2px}.lpw-pow{text-align:center;font-size:10.5px;color:#9a938a;padding:4px 0 7px;background:#fff}.lpw-pow a{color:#9a938a}.lpw-teaser{position:fixed;' + SIDE + ':88px;bottom:30px;z-index:2147483000;max-width:240px;background:#fff;border:1px solid rgba(16,18,20,.10);border-radius:14px;box-shadow:0 10px 34px rgba(0,0,0,.18);padding:11px 14px;font-family:-apple-system,Segoe UI,Roboto,sans-serif;font-size:13.5px;line-height:1.45;cursor:pointer;animation:lpwIn .3s ease}@keyframes lpwIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}.lpw-teaser b{display:block;margin-bottom:2px}';
  document.head.appendChild(css);

  var btn = document.createElement('button'); btn.className = 'lpw-btn'; btn.setAttribute('aria-label', 'Deschide chat');
  btn.innerHTML = AVATAR ? '<img src="' + AVATAR.replace(/"/g, '') + '" alt=""/>' : '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.38-4.1-1.05L3 20l1.05-5.4A8.5 8.5 0 1 1 21 11.5z"/></svg>';
  var panel = document.createElement('div'); panel.className = 'lpw-panel';
  panel.innerHTML = '<div class="lpw-head"><div><span class="lpw-name">Asistent</span><small>Răspundem în sub un minut</small></div><button class="lpw-x" aria-label="Închide">×</button></div><div class="lpw-msgs"></div><div class="lpw-in"><input type="text" placeholder="Scrie un mesaj…" aria-label="Mesajul tău"/><button>Trimite</button></div><div class="lpw-pow">⚡ powered by <a href="https://leaply.ro" target="_blank" rel="noopener">Leaply</a></div>';
  document.body.appendChild(btn); document.body.appendChild(panel);

  var msgs = panel.querySelector('.lpw-msgs'), input = panel.querySelector('input'), send = panel.querySelector('.lpw-in button');
  function add(cls, text) { var m = document.createElement('div'); m.className = 'lpw-m ' + cls; m.textContent = text; msgs.appendChild(m); msgs.scrollTop = msgs.scrollHeight; return m; }

  var CFG = null, booted = false;
  function loadCfg(cb) {
    if (CFG) return cb(CFG);
    fetch(BASE + '/api/widget/config?account=' + encodeURIComponent(ACC)).then(function (r) { return r.json(); }).then(function (c) {
      CFG = c || {};
      if (CFG.hideBranding) { var p = panel.querySelector('.lpw-pow'); if (p) p.remove(); }
      cb(CFG);
    }).catch(function () { cb({}); });
  }
  function boot() {
    if (booted) return; booted = true;
    loadCfg(function (c) {
      if (c.name) panel.querySelector('.lpw-name').textContent = c.name;
      add('lpw-ai', c.welcome || 'Bună! Cu ce vă putem ajuta?');
    });
  }
  function openPanel() { hideTeaser(); panel.classList.add('on'); boot(); input.focus(); startPoll(); }
  btn.addEventListener('click', function () {
    if (panel.classList.contains('on')) { panel.classList.remove('on'); stopPoll(); }
    else openPanel();
  });
  panel.querySelector('.lpw-x').addEventListener('click', function () { panel.classList.remove('on'); stopPoll(); });

  /* Teaser proactiv: după 30s pe pagină, o dată pe sesiune */
  var teaser = null;
  function hideTeaser() { if (teaser) { teaser.remove(); teaser = null; } }
  try {
    if (!sessionStorage.getItem('leaply_teased')) {
      setTimeout(function () {
        if (panel.classList.contains('on')) return;
        loadCfg(function (c) {
          sessionStorage.setItem('leaply_teased', '1');
          teaser = document.createElement('div'); teaser.className = 'lpw-teaser';
          teaser.innerHTML = '<b>' + (c.name || 'Asistent') + '</b>';
          teaser.appendChild(document.createTextNode(c.teaser || 'Aveți o întrebare? Vă răspundem în sub un minut. 👋'));
          teaser.addEventListener('click', openPanel);
          document.body.appendChild(teaser);
          setTimeout(hideTeaser, 20000);
        });
      }, 30000);
    }
  } catch (e) { /* sessionStorage blocat */ }

  /* Polling: răspunsurile scrise manual de owner ajung la vizitator (max 5s) */
  var pollT = null, lastAt = new Date().toISOString();
  function startPoll() {
    if (pollT) return;
    pollT = setInterval(function () {
      if (!panel.classList.contains('on')) return;
      fetch(BASE + '/api/widget/poll?account=' + encodeURIComponent(ACC) + '&session=' + encodeURIComponent(sid) + '&after=' + encodeURIComponent(lastAt))
        .then(function (r) { return r.json(); })
        .then(function (d) {
          (d.messages || []).forEach(function (m) { add('lpw-ai', m.body); if (m.at > lastAt) lastAt = m.at; });
        }).catch(function () { /* offline */ });
    }, 5000);
  }
  function stopPoll() { if (pollT) { clearInterval(pollT); pollT = null; } }

  var busy = false;
  function submit() {
    var text = input.value.trim(); if (!text || busy) return;
    input.value = ''; add('lpw-me', text); busy = true;
    var dots = document.createElement('div'); dots.className = 'lpw-dots'; dots.textContent = 'scrie…'; msgs.appendChild(dots); msgs.scrollTop = msgs.scrollHeight;
    fetch(BASE + '/api/widget/message', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ account: ACC, session: sid, message: text })
    }).then(function (r) { return r.json(); }).then(function (d) {
      dots.remove(); busy = false;
      if (d.reply) add('lpw-ai', d.reply);
      else if (d.human) add('lpw-ai', 'Un coleg a preluat conversația și vă răspunde în scurt timp.');
      else if (d.error) add('lpw-ai', 'A apărut o problemă tehnică. Reîncercați, vă rugăm.');
    }).catch(function () { dots.remove(); busy = false; add('lpw-ai', 'Nu am putut trimite mesajul. Verificați conexiunea.'); });
  }
  send.addEventListener('click', submit);
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
})();
