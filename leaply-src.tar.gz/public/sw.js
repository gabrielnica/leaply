/* Service Worker Leaply — Web Push (desktop/browser).
   Primește notificarea, o afișează și, la click, deschide conversația/inbox-ul. */

self.addEventListener('push', function (event) {
  let data = { title: 'Leaply', body: 'Ai un lead nou.', url: '/app' };
  try { if (event.data) data = Object.assign(data, event.data.json()); } catch (e) {}
  const title = data.title || 'Leaply';
  const options = {
    body: data.body || '',
    icon: '/logo-email.png',
    badge: '/logo-email.png',
    tag: data.tag || 'lead',
    renotify: true,
    data: { url: data.url || '/app' },
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/app';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
      for (const client of list) {
        // dacă avem deja o fereastră Leaply deschisă, o focusăm și navigăm
        if ('focus' in client) {
          client.focus();
          if ('navigate' in client && url) { try { client.navigate(url); } catch (e) {} }
          return;
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })
  );
});

self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (event) { event.waitUntil(self.clients.claim()); });
