import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

let _db: Database.Database | null = null;

export function db(): Database.Database {
  if (_db) return _db;
  const p = process.env.LEAPLY_DB_PATH || path.join(process.cwd(), 'data', 'leaply.db');
  fs.mkdirSync(path.dirname(p), { recursive: true });
  _db = new Database(p);
  _db.pragma('journal_mode = WAL');
  init(_db);
  return _db;
}

function init(d: Database.Database) {
  d.exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY, name TEXT, vertical TEXT, plan TEXT,
    avg_deal_value INTEGER, config TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS channels (
    id TEXT PRIMARY KEY, account_id TEXT, type TEXT, status TEXT, label TEXT
  );
  CREATE TABLE IF NOT EXISTS leads (
    id TEXT PRIMARY KEY, account_id TEXT, name TEXT, phone TEXT, source TEXT,
    score TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY, account_id TEXT, lead_id TEXT, channel TEXT, status TEXT,
    first_response_ms INTEGER, qualification TEXT, created_at TEXT, updated_at TEXT
  );
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, conversation_id TEXT, direction TEXT, sender TEXT,
    body TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, account_id TEXT, email TEXT UNIQUE, name TEXT,
    password_hash TEXT, role TEXT DEFAULT 'owner', created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS password_resets (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, used INTEGER DEFAULT 0, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS demo_requests (
    id TEXT PRIMARY KEY, name TEXT, contact TEXT, business TEXT, vertical TEXT,
    status TEXT DEFAULT 'nou', account_id TEXT, created_at TEXT
  );
  `);
  migrate(d);
  const n = (d.prepare('SELECT COUNT(*) c FROM accounts').get() as any).c;
  if (n === 0) seed(d);
  seedAdmin(d);
  syncLeaplyKb(d);
  migrateDemoBusiness(d);
}

// Migrare one-time (2026-07-07): demo-ul public trece de la „Termopane Bihor" la
// „DentArt Studio" (business mai reprezentativ). Rulează o singură dată — dacă
// numele din config nu mai e Termopane Bihor, nu atinge nimic (edițiile manuale rămân).
function migrateDemoBusiness(d: Database.Database) {
  try {
    const row: any = d.prepare("SELECT config FROM accounts WHERE id='acc_demo'").get();
    if (!row) return;
    const cur = JSON.parse(row.config || '{}');
    if (cur.businessName !== 'Termopane Bihor') return;
    d.prepare("UPDATE accounts SET name=?, vertical=?, config=? WHERE id='acc_demo'")
      .run('DentArt Studio SRL', DEMO_CONFIG.vertical, JSON.stringify(DEMO_CONFIG));
    d.prepare("UPDATE channels SET label=REPLACE(REPLACE(REPLACE(label,'Termopane Bihor','DentArt Studio'),'termopanebihor.ro','dentart-studio.ro'),'@termopane.bihor','@dentart.studio') WHERE account_id='acc_demo'").run();
    console.log('[leaply] Demo public migrat: Termopane Bihor → DentArt Studio.');
  } catch (e) { console.error('[leaply demo migrate]', String(e).slice(0, 150)); }
}

// Contul acc_leaply („client zero" — bot-ul de vânzări de pe leaply.ro) primește mereu
// la boot baza de cunoștințe la zi din lib/leaply-kb.ts. Idempotent, best-effort.
function syncLeaplyKb(d: Database.Database) {
  try {
    const row: any = d.prepare("SELECT config FROM accounts WHERE id='acc_leaply'").get();
    if (!row) return;
    const { LEAPLY_KNOWLEDGE, LEAPLY_SALES_RULES } = require('./leaply-kb');
    const config = { ...(JSON.parse(row.config || '{}')), knowledge: LEAPLY_KNOWLEDGE, rules: LEAPLY_SALES_RULES, salesMode: true };
    // contul platformei nu e client: plan Scale permanent (fără expirare de trial / limite mici)
    d.prepare("UPDATE accounts SET config=?, plan='Scale' WHERE id='acc_leaply'").run(JSON.stringify(config));
  } catch (e) { console.error('[leaply kb sync]', String(e).slice(0, 150)); }
}

// Migrații idempotente (ALTER TABLE eșuează silențios dacă există coloana)
function migrate(d: Database.Database) {
  const add = (sql: string) => { try { d.exec(sql); } catch {} };
  add('ALTER TABLE channels ADD COLUMN credentials TEXT');
  add('ALTER TABLE accounts ADD COLUMN integrations TEXT');
  add('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)');
  add('ALTER TABLE conversations ADD COLUMN summary TEXT');
  add('ALTER TABLE users ADD COLUMN email_verified INTEGER DEFAULT 0');
  add('CREATE TABLE IF NOT EXISTS email_verifications (token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, used INTEGER DEFAULT 0, created_at TEXT)');
  add('ALTER TABLE conversations ADD COLUMN booking_at TEXT');
  add('ALTER TABLE conversations ADD COLUMN confirm_sent INTEGER DEFAULT 0');
  add('ALTER TABLE conversations ADD COLUMN assigned_to TEXT');
  add('ALTER TABLE accounts ADD COLUMN referred_by TEXT');
  add('CREATE TABLE IF NOT EXISTS audit_log (id TEXT PRIMARY KEY, actor TEXT, action TEXT, target TEXT, meta TEXT, created_at TEXT)');
  add('CREATE TABLE IF NOT EXISTS usage_counters (account_id TEXT, month TEXT, kind TEXT, n INTEGER DEFAULT 0, PRIMARY KEY(account_id, month, kind))');
}

function seedAdmin(d: Database.Database) {
  const n = (d.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get() as any).c;
  if (n > 0) return;
  const pw = process.env.ADMIN_PASSWORD;
  if (!pw) { console.warn('[leaply] Niciun admin creat — setează ADMIN_PASSWORD și repornește.'); return; }
  // hash scrypt inline (evită dependență circulară cu lib/auth)
  const crypto = require('crypto');
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex');
  d.prepare('INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)')
    .run(uid('us_'), 'acc_demo', 'salut@gabrielnica.ro', 'Gabriel', `s1$${salt}$${hash}`, 'admin', new Date().toISOString());
  console.log('[leaply] Admin creat: salut@gabrielnica.ro (parola din ADMIN_PASSWORD).');
}

export function uid(p = ''): string {
  return p + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function seed(d: Database.Database) {
  const now = new Date().toISOString();
  const acc = {
    id: 'acc_demo',
    name: 'DentArt Studio SRL',
    vertical: 'clinica-privata',
    plan: 'Pro',
    avg_deal_value: 4200,
    config: JSON.stringify(DEMO_CONFIG),
    created_at: now,
  };
  d.prepare('INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at) VALUES (@id,@name,@vertical,@plan,@avg_deal_value,@config,@created_at)').run(acc);

  const chans = [
    { id: uid('ch_'), account_id: acc.id, type: 'whatsapp', status: 'connected', label: 'WhatsApp Business +40 741 000 000' },
    { id: uid('ch_'), account_id: acc.id, type: 'meta_lead_ads', status: 'connected', label: 'Facebook: DentArt Studio' },
    { id: uid('ch_'), account_id: acc.id, type: 'messenger', status: 'connected', label: 'Messenger: DentArt Studio' },
    { id: uid('ch_'), account_id: acc.id, type: 'instagram', status: 'pending', label: 'Instagram: @dentart.studio' },
    { id: uid('ch_'), account_id: acc.id, type: 'webform', status: 'connected', label: 'Formular site dentart-studio.ro' },
    { id: uid('ch_'), account_id: acc.id, type: 'calendar', status: 'connected', label: 'Google Calendar' },
  ];
  const insCh = d.prepare('INSERT INTO channels (id,account_id,type,status,label) VALUES (@id,@account_id,@type,@status,@label)');
  chans.forEach(c => insCh.run(c));

  // Sample conversations
  const samples = [
    { name: 'Maria Pop', phone: '+40 745 112 233', source: 'meta_lead_ads', channel: 'whatsapp', score: 'hot', ms: 38000,
      msgs: [
        ['in','lead','Bună ziua, mă interesează un implant dentar. Cât ar costa?'],
        ['out','ai','Bună ziua, Maria! Implantul dentar în pachet complet pornește de la 3.500 lei — prețul exact îl stabilim după consultație, unde radiografia 3D e inclusă. Aveți dureri în acest moment, sau e un tratament pe care îl planificați?'],
        ['in','lead','Nu am dureri, dar mi-a spus medicul că am nevoie de implant la o măsea.'],
        ['out','ai','Am înțeles. Ați mai fost pacienta clinicii noastre?'],
        ['in','lead','Nu, ar fi prima dată.'],
        ['out','ai','Bine ați venit atunci! Vă pot programa la o consultație cu plan de tratament. V-ar conveni marți la 14:00 sau joi la 11:00?'],
        ['in','lead','Marți la 14:00.'],
        ['out','ai','Perfect — v-am programat marți la 14:00. Primiți confirmarea pe SMS. Vă așteptăm cu drag!'],
      ], qual: { nevoie: 'implant dentar', urgenta: 'planificat', programare: 'Marți 14:00' } },
    { name: 'Andrei Ionescu', phone: '+40 722 908 100', source: 'webform', channel: 'whatsapp', score: 'warm', ms: 45000,
      msgs: [
        ['in','lead','Salut, cât costă o albire profesională?'],
        ['out','ai','Bună ziua, Andrei! Albirea profesională în cabinet costă 900 lei și durează o singură ședință. Vă gândiți la o dată anume?'],
        ['in','lead','Mă mai gândesc, poate luna viitoare.'],
        ['out','ai','Nicio problemă! Vă pot rezerva un loc orientativ și vă confirmăm cu o săptămână înainte — fără nicio obligație. Vreți?'],
      ], qual: { nevoie: 'albire', urgenta: 'luna viitoare', programare: 'în așteptare' } },
    { name: 'Elena Radu', phone: '+40 733 445 566', source: 'messenger', channel: 'messenger', score: 'hot', ms: 29000,
      msgs: [
        ['in','lead','Bună seara, mă doare o măsea de ieri. Mă puteți primi urgent?'],
        ['out','ai','Bună seara, Elena! Îmi pare rău — durerile acute au prioritate la noi. Mâine dimineață la 9:00 vă putem primi. Vă convine?'],
        ['in','lead','Da, vin mâine la 9.'],
        ['out','ai','Programat! Mâine la 9:00, cu consultație și radiografie 3D inclusă. Primiți confirmarea pe SMS. Însănătoșire grabnică!'],
      ], qual: { nevoie: 'durere acută', urgenta: 'urgent', programare: 'mâine 9:00' } },
    { name: 'Vasile M.', phone: '+40 744 221 009', source: 'meta_lead_ads', channel: 'whatsapp', score: 'cold', ms: 41000,
      msgs: [
        ['in','lead','Faceți și consultații de medicina muncii?'],
        ['out','ai','Bună ziua! Suntem o clinică exclusiv stomatologică, deci medicina muncii nu intră în serviciile noastre. Vă putem recomanda cu drag pe cineva, dacă doriți.'],
        ['in','lead','Nu, mulțumesc.'],
      ], qual: { nevoie: '-', urgenta: '-', programare: 'necalificat' } },
  ];

  const insLead = d.prepare('INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)');
  const insConv = d.prepare('INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)');
  const insMsg = d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)');

  samples.forEach((s, i) => {
    const t0 = new Date(Date.now() - (i + 1) * 3600_000 * 6).toISOString();
    const leadId = uid('ld_'); const convId = uid('cv_');
    const status = s.score === 'cold' ? 'lost' : (s.qual.programare && s.qual.programare.match(/\d/) ? 'booked' : 'qualified');
    insLead.run(leadId, acc.id, s.name, s.phone, s.source, s.score, t0);
    insConv.run(convId, acc.id, leadId, s.channel, status, s.ms, JSON.stringify(s.qual), t0, t0);
    s.msgs.forEach((m, j) => insMsg.run(uid('ms_'), convId, m[0], m[1], m[2], new Date(new Date(t0).getTime() + j * 60000).toISOString()));
  });
}

export const DEMO_CONFIG = {
  businessName: 'DentArt Studio',
  vertical: 'clinica-privata',
  tone: 'profesional',
  welcome: 'Bună ziua! Sunteți în legătură cu DentArt Studio 😊 Cu ce vă putem ajuta?',
  services: [
    { name: 'Consultație + plan de tratament (include radiografie 3D)', price: '250 lei' },
    { name: 'Igienizare profesională completă', price: '350 lei' },
    { name: 'Albire profesională în cabinet', price: '900 lei' },
    { name: 'Implant dentar (pachet complet)', price: 'de la 3.500 lei' },
    { name: 'Fațete ceramice', price: 'de la 1.800 lei/dinte' },
    { name: 'Ortodonție — aparat fix sau alignere', price: 'plan personalizat după consultație' },
  ],
  qualificationQuestions: [
    { key: 'nevoie', q: 'Ce vă supără sau ce tratament vă interesează?' },
    { key: 'urgenta', q: 'Aveți dureri în acest moment, sau e un tratament pe care îl planificați?' },
    { key: 'istoric', q: 'Ați mai fost pacientul clinicii noastre?' },
  ],
  bookingSlots: ['marți la 14:00', 'joi la 11:00'],
  redFlags: ['veterinar', 'medicina muncii'],
  knowledge: 'Clinică stomatologică premium în Oradea. Program: luni-vineri 9:00-19:00, sâmbătă 9:00-13:00. Radiografia 3D e inclusă în consultație. Plata în rate fără dobândă, până la 12 rate. Garanție 10 ani la implanturi. Sedare conștientă disponibilă pentru pacienții anxioși. Parcare gratuită pentru pacienți. Medici cu supraspecializare în implantologie și estetică dentară.',
  rules: 'Nu pune diagnostice și nu recomanda tratamente prin chat — invită politicos la consultație. Nu promite prețuri finale înainte de consultație; indică doar intervalele din lista de servicii.',
};
