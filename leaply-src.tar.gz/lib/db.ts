import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

let _db: Database.Database | null = null;

export function db(): Database.Database {
  if (_db) return _db;
  const p = process.env.LEAPLY_DB_PATH || path.join(process.cwd(), 'data', 'leaply.db');
  fs.mkdirSync(path.dirname(p), { recursive: true });
  _db = new Database(p);
  _db.pragma('journal_mode = WAL');
  init(_db);
  return _db;
}

function init(d: Database.Database) {
  d.exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY, name TEXT, vertical TEXT, plan TEXT,
    avg_deal_value INTEGER, config TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS channels (
    id TEXT PRIMARY KEY, account_id TEXT, type TEXT, status TEXT, label TEXT
  );
  CREATE TABLE IF NOT EXISTS leads (
    id TEXT PRIMARY KEY, account_id TEXT, name TEXT, phone TEXT, source TEXT,
    score TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY, account_id TEXT, lead_id TEXT, channel TEXT, status TEXT,
    first_response_ms INTEGER, qualification TEXT, created_at TEXT, updated_at TEXT
  );
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, conversation_id TEXT, direction TEXT, sender TEXT,
    body TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, account_id TEXT, email TEXT UNIQUE, name TEXT,
    password_hash TEXT, role TEXT DEFAULT 'owner', created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS password_resets (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, used INTEGER DEFAULT 0, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS demo_requests (
    id TEXT PRIMARY KEY, name TEXT, contact TEXT, business TEXT, vertical TEXT,
    status TEXT DEFAULT 'nou', account_id TEXT, created_at TEXT
  );
  `);
  migrate(d);
  const n = (d.prepare('SELECT COUNT(*) c FROM accounts').get() as any).c;
  if (n === 0) seed(d);
  seedAdmin(d);
}

// Migrații idempotente (ALTER TABLE eșuează silențios dacă există coloana)
function migrate(d: Database.Database) {
  const add = (sql: string) => { try { d.exec(sql); } catch {} };
  add('ALTER TABLE channels ADD COLUMN credentials TEXT');
  add('ALTER TABLE accounts ADD COLUMN integrations TEXT');
  add('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)');
}

function seedAdmin(d: Database.Database) {
  const n = (d.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get() as any).c;
  if (n > 0) return;
  const pw = process.env.ADMIN_PASSWORD;
  if (!pw) { console.warn('[leaply] Niciun admin creat — setează ADMIN_PASSWORD și repornește.'); return; }
  // hash scrypt inline (evită dependență circulară cu lib/auth)
  const crypto = require('crypto');
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex');
  d.prepare('INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)')
    .run(uid('us_'), 'acc_demo', 'salut@gabrielnica.ro', 'Gabriel', `s1$${salt}$${hash}`, 'admin', new Date().toISOString());
  console.log('[leaply] Admin creat: salut@gabrielnica.ro (parola din ADMIN_PASSWORD).');
}

export function uid(p = ''): string {
  return p + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function seed(d: Database.Database) {
  const now = new Date().toISOString();
  const acc = {
    id: 'acc_demo',
    name: 'Termopane Bihor SRL',
    vertical: 'servicii-casa',
    plan: 'Pro',
    avg_deal_value: 4200,
    config: JSON.stringify(DEMO_CONFIG),
    created_at: now,
  };
  d.prepare('INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at) VALUES (@id,@name,@vertical,@plan,@avg_deal_value,@config,@created_at)').run(acc);

  const chans = [
    { id: uid('ch_'), account_id: acc.id, type: 'whatsapp', status: 'connected', label: 'WhatsApp Business +40 741 000 000' },
    { id: uid('ch_'), account_id: acc.id, type: 'meta_lead_ads', status: 'connected', label: 'Facebook: Termopane Bihor' },
    { id: uid('ch_'), account_id: acc.id, type: 'messenger', status: 'connected', label: 'Messenger: Termopane Bihor' },
    { id: uid('ch_'), account_id: acc.id, type: 'instagram', status: 'pending', label: 'Instagram: @termopane.bihor' },
    { id: uid('ch_'), account_id: acc.id, type: 'webform', status: 'connected', label: 'Formular site termopanebihor.ro' },
    { id: uid('ch_'), account_id: acc.id, type: 'calendar', status: 'connected', label: 'Google Calendar' },
  ];
  const insCh = d.prepare('INSERT INTO channels (id,account_id,type,status,label) VALUES (@id,@account_id,@type,@status,@label)');
  chans.forEach(c => insCh.run(c));

  // Sample conversations
  const samples = [
    { name: 'Maria Pop', phone: '+40 745 112 233', source: 'meta_lead_ads', channel: 'whatsapp', score: 'hot', ms: 38000,
      msgs: [
        ['in','lead','Bună, aș dori o ofertă pentru termopane la un apartament cu 3 camere.'],
        ['out','ai','Bună ziua, Maria! Mulțumim pentru mesaj 😊 Vă ajut imediat. Apartamentul are 3 camere — câte ferestre și uși de balcon ar fi de înlocuit, aproximativ?'],
        ['in','lead','5 ferestre și 2 uși de balcon.'],
        ['out','ai','Perfect. Pentru ce interval vă doriți montajul — cât mai repede, în 1-2 luni, sau doar vă informați deocamdată?'],
        ['in','lead','Cât mai repede, avem nevoie până la iarnă.'],
        ['out','ai','Am înțeles, vă putem programa o măsurătoare gratuită. Aveți disponibilitate joi la 16:00 sau vineri la 10:00?'],
        ['in','lead','Joi la 16:00 e perfect.'],
        ['out','ai','Excelent! Am notat: măsurătoare joi, ora 16:00. Un coleg vă confirmă adresa. Vă mulțumim, Maria! 🙌'],
      ], qual: { buget: '5 ferestre + 2 uși', urgenta: 'până la iarnă', programare: 'Joi 16:00' } },
    { name: 'Andrei Ionescu', phone: '+40 722 908 100', source: 'webform', channel: 'whatsapp', score: 'warm', ms: 45000,
      msgs: [
        ['in','lead','Salut, cât ar costa niște geamuri pentru o casă?'],
        ['out','ai','Salut, Andrei! Depinde de dimensiuni și număr. Câte ferestre are casa și știi aproximativ dimensiunile?'],
        ['in','lead','Nu sunt sigur, vreo 8 ferestre. Mă mai gândesc.'],
        ['out','ai','Nicio problemă! Îți putem face o ofertă exactă după o măsurătoare gratuită, fără obligații. Vrei să-ți propun o dată orientativă?'],
      ], qual: { buget: '~8 ferestre', urgenta: 'se informează', programare: 'în așteptare' } },
    { name: 'Elena Radu', phone: '+40 733 445 566', source: 'messenger', channel: 'messenger', score: 'hot', ms: 29000,
      msgs: [
        ['in','lead','Bună seara, vreau să schimb toate geamurile la o casă nouă. Puteți veni la măsurat?'],
        ['out','ai','Bună seara, Elena! Sigur că da. Casa este finalizată și gata de montaj, sau încă în construcție?'],
        ['in','lead','Gata, ne mutăm luna viitoare.'],
        ['out','ai','Minunat! Vă propun o măsurătoare gratuită. Luni la 11:00 sau marți la 17:00 v-ar conveni?'],
        ['in','lead','Marți la 17:00.'],
        ['out','ai','Am rezervat marți, 17:00. Vă confirmăm în scurt timp. Mulțumim, Elena! 🏡'],
      ], qual: { buget: 'casă întreagă', urgenta: 'mutare luna viitoare', programare: 'Marți 17:00' } },
    { name: 'Vasile M.', phone: '+40 744 221 009', source: 'meta_lead_ads', channel: 'whatsapp', score: 'cold', ms: 41000,
      msgs: [
        ['in','lead','Aveți și uși de interior?'],
        ['out','ai','Bună ziua! Momentan lucrăm cu ferestre și uși de exterior din PVC și aluminiu. Pentru uși de interior nu avem ofertă, dar vă pot pune în legătură cu un coleg dacă doriți.'],
        ['in','lead','Nu, mulțumesc.'],
      ], qual: { buget: '-', urgenta: '-', programare: 'necalificat' } },
  ];

  const insLead = d.prepare('INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)');
  const insConv = d.prepare('INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)');
  const insMsg = d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)');

  samples.forEach((s, i) => {
    const t0 = new Date(Date.now() - (i + 1) * 3600_000 * 6).toISOString();
    const leadId = uid('ld_'); const convId = uid('cv_');
    const status = s.score === 'cold' ? 'lost' : (s.qual.programare && s.qual.programare.match(/\d/) ? 'booked' : 'qualified');
    insLead.run(leadId, acc.id, s.name, s.phone, s.source, s.score, t0);
    insConv.run(convId, acc.id, leadId, s.channel, status, s.ms, JSON.stringify(s.qual), t0, t0);
    s.msgs.forEach((m, j) => insMsg.run(uid('ms_'), convId, m[0], m[1], m[2], new Date(new Date(t0).getTime() + j * 60000).toISOString()));
  });
}

export const DEMO_CONFIG = {
  businessName: 'Termopane Bihor',
  vertical: 'servicii-casa',
  tone: 'prietenos',
  welcome: 'Bună ziua! Mulțumim pentru mesaj 😊 Sunt asistentul Termopane Bihor și vă ajut imediat.',
  services: [
    { name: 'Ferestre PVC', price: 'de la 750 lei/buc' },
    { name: 'Ferestre aluminiu', price: 'ofertă la măsurătoare' },
    { name: 'Uși de exterior', price: 'de la 2.500 lei' },
  ],
  qualificationQuestions: [
    { key: 'buget', q: 'Aproximativ câte ferestre / uși ar fi de înlocuit?' },
    { key: 'urgenta', q: 'Pentru ce interval vă doriți montajul — cât mai repede, în 1-2 luni, sau doar vă informați?' },
    { key: 'zona', q: 'În ce localitate/zonă este imobilul?' },
  ],
  bookingSlots: ['joi la 16:00', 'vineri la 10:00'],
  redFlags: ['uși de interior', 'mobilă', 'reparații'],
};
