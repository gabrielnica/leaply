import { cfg, appUrl } from './settings';
import { setChannelCreds } from './channels';
import { setIntegration, getIntegrations } from './integrations';

// Conectare Meta „cu un click" (Facebook Login): utilizatorul alege pagina,
// noi primim page access token și abonăm webhook-urile automat.
// Necesită META_APP_ID + META_APP_SECRET (Admin → Setări platformă).
// În Development Mode funcționează pentru admini/testeri ai aplicației Meta;
// pentru public e nevoie de App Review (pages_messaging etc.).

const G = 'https://graph.facebook.com/v19.0';
export const metaConfigured = () => Boolean(cfg('META_APP_ID') && cfg('META_APP_SECRET'));
export const metaRedirect = () => `${appUrl()}/api/integrations/meta/callback`;

export function metaAuthUrl(state: string): string {
  const p = new URLSearchParams({
    client_id: cfg('META_APP_ID'),
    redirect_uri: metaRedirect(),
    state,
    response_type: 'code',
    // business_management e OBLIGATORIU ca /me/accounts să întoarcă paginile deținute
    // printr-un Business Manager (acces task-based) — fără el, lista vine goală.
    scope: 'pages_show_list,pages_messaging,pages_manage_metadata,instagram_basic,instagram_manage_messages,business_management',
  });
  return `https://www.facebook.com/v19.0/dialog/oauth?${p}`;
}

export async function metaExchangeCode(code: string): Promise<string | null> {
  const r = await fetch(`${G}/oauth/access_token?` + new URLSearchParams({
    client_id: cfg('META_APP_ID'), client_secret: cfg('META_APP_SECRET'),
    redirect_uri: metaRedirect(), code,
  }), { signal: AbortSignal.timeout(10000) });
  if (!r.ok) { console.error('[meta] exchange:', (await r.text()).slice(0, 200)); return null; }
  const short = (await r.json()).access_token;
  if (!short) return null;
  // token long-lived (60 zile; page tokens derivate nu expiră)
  const r2 = await fetch(`${G}/oauth/access_token?` + new URLSearchParams({
    grant_type: 'fb_exchange_token', client_id: cfg('META_APP_ID'),
    client_secret: cfg('META_APP_SECRET'), fb_exchange_token: short,
  }), { signal: AbortSignal.timeout(10000) });
  if (!r2.ok) return short;
  return (await r2.json()).access_token || short;
}

export type MetaPage = { id: string; name: string; access_token: string; ig?: { id: string; username?: string } };

export async function listPages(userToken: string): Promise<MetaPage[]> {
  const r = await fetch(`${G}/me/accounts?fields=id,name,access_token,instagram_business_account{id,username}&limit=100&access_token=${encodeURIComponent(userToken)}`,
    { signal: AbortSignal.timeout(10000) });
  if (!r.ok) { console.error('[meta] pages:', (await r.text()).slice(0, 300)); return []; }
  const data = (await r.json()).data || [];
  if (data.length === 0) {
    // diagnostic în log: ce permisiuni a acordat efectiv utilizatorul în dialogul OAuth
    try {
      const p = await fetch(`${G}/me/permissions?access_token=${encodeURIComponent(userToken)}`, { signal: AbortSignal.timeout(8000) });
      console.error('[meta] 0 pagini pentru user; permisiuni acordate:', (await p.text()).slice(0, 400));
    } catch { /* best-effort */ }
  }
  return data.map((p: any) => ({
    id: String(p.id), name: p.name || 'Pagina mea', access_token: p.access_token,
    ig: p.instagram_business_account ? { id: String(p.instagram_business_account.id), username: p.instagram_business_account.username } : undefined,
  }));
}

async function subscribePage(pageId: string, pageToken: string) {
  try {
    await fetch(`${G}/${pageId}/subscribed_apps?subscribed_fields=messages,messaging_postbacks&access_token=${encodeURIComponent(pageToken)}`,
      { method: 'POST', signal: AbortSignal.timeout(10000) });
  } catch (e) { console.error('[meta] subscribe:', String(e).slice(0, 150)); }
}

/** Conectează Messenger (+Instagram dacă pagina are cont IG business) și abonează webhook-urile. */
export async function connectPage(accId: string, page: MetaPage): Promise<{ messenger: boolean; instagram: boolean }> {
  setChannelCreds(accId, 'messenger', { provider: 'meta', page_id: page.id, page_access_token: page.access_token }, `Messenger — ${page.name}`);
  await subscribePage(page.id, page.access_token);
  let instagram = false;
  if (page.ig?.id) {
    setChannelCreds(accId, 'instagram', { provider: 'meta', page_id: page.ig.id, page_access_token: page.access_token }, `Instagram — @${page.ig.username || page.name}`);
    instagram = true;
  }
  setIntegration(accId, 'meta_pending', null);
  return { messenger: true, instagram };
}

export function getPendingPages(accId: string): MetaPage[] | null {
  const p = getIntegrations(accId).meta_pending;
  return Array.isArray(p?.pages) ? p.pages : null;
}
export function setPendingPages(accId: string, pages: MetaPage[]) {
  setIntegration(accId, 'meta_pending', { pages, ts: Date.now() });
}
