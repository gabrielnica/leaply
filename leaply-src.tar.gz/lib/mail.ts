// Trimitere email prin Resend (https://resend.com) — opțional.
// Fără RESEND_API_KEY, mesajul e doar logat (vizibil în Coolify → Logs).
export async function sendMail(to: string, subject: string, html: string): Promise<boolean> {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.MAIL_FROM || 'Leaply <salut@leaply.ro>';
  if (!key) {
    console.log(`[leaply mail — netrimis, lipsește RESEND_API_KEY] către: ${to} | subiect: ${subject}\n${html.replace(/<[^>]+>/g, ' ')}`);
    return false;
  }
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to, subject, html }),
    });
    return r.ok;
  } catch (e) {
    console.error('[leaply mail] eroare trimitere:', e);
    return false;
  }
}
