import { cfg } from './settings';
// Trimitere email prin Resend (https://resend.com) — opțional.
// Fără RESEND_API_KEY, mesajul e doar logat (vizibil în Coolify → Logs).
export async function sendMail(to: string, subject: string, html: string): Promise<boolean> {
  const key = cfg('RESEND_API_KEY');
  const from = cfg('MAIL_FROM') || 'Leaply <salut@leaply.ro>';
  if (!key) {
    console.log(`[leaply mail — netrimis, lipsește RESEND_API_KEY] către: ${to} | subiect: ${subject}\n${html.replace(/<[^>]+>/g, ' ')}`);
    return false;
  }
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to, subject, html }),
    });
    return r.ok;
  } catch (e) {
    console.error('[leaply mail] eroare trimitere:', e);
    return false;
  }
}

/** Email cu atașament (ex. backup DB săptămânal, off-site). Best-effort. */
export async function sendMailWithAttachment(to: string, subject: string, html: string, filename: string, content: Buffer): Promise<boolean> {
  const key = cfg('RESEND_API_KEY');
  const from = cfg('MAIL_FROM') || 'Leaply <salut@leaply.ro>';
  if (!key || content.length > 8_000_000) return false;
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ from, to, subject, html, attachments: [{ filename, content: content.toString('base64') }] }),
      signal: AbortSignal.timeout(20000),
    });
    return r.ok;
  } catch (e) { console.error('[mail attach]', String(e).slice(0, 150)); return false; }
}
