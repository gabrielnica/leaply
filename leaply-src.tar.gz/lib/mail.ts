import { cfg } from './settings';

// Șablonul de brand pentru TOATE emailurile Leaply — aceeași identitate ca site-ul
// (paper #F7F5F1, ink #101214, accent #FF4D1F). Orice html trimis prin sendMail
// e împachetat automat aici.
export function brandedEmail(inner: string): string {
  return `<!doctype html><html lang="ro"><body style="margin:0;padding:0;background:#F7F5F1">
<div style="background:#F7F5F1;padding:32px 16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Inter,Arial,sans-serif">
  <div style="max-width:560px;margin:0 auto">
    <div style="padding:0 4px 16px">
      <a href="https://leaply.ro" style="text-decoration:none;font-size:21px;font-weight:800;color:#101214;letter-spacing:-.02em">⚡&nbsp;leaply</a>
    </div>
    <div style="background:#ffffff;border:1px solid #E8E4DC;border-radius:16px;padding:28px 26px;color:#101214;font-size:15px;line-height:1.6">
      ${inner}
    </div>
    <div style="padding:18px 6px 0;color:#8A867E;font-size:12.5px;line-height:1.7">
      Leaply — asistentul AI care răspunde lead-urilor tale în sub 60 de secunde, 24/7.<br/>
      <a href="https://leaply.ro" style="color:#8A867E">leaply.ro</a> · <a href="mailto:salut@leaply.ro" style="color:#8A867E">salut@leaply.ro</a> · <a href="tel:+40373818737" style="color:#8A867E">0373 818 737</a><br/>
      ARHAI S.R.L. · CUI RO35913161 · Oradea, România
    </div>
  </div>
</div>
</body></html>`;
}

// Trimitere email prin Resend (https://resend.com) — opțional.
// Fără RESEND_API_KEY, mesajul e doar logat (vizibil în Coolify → Logs).
export async function sendMail(to: string, subject: string, html: string): Promise<boolean> {
  const key = cfg('RESEND_API_KEY');
  const from = cfg('MAIL_FROM') || 'Leaply <salut@leaply.ro>';
  if (!key) {
    console.log(`[leaply mail — netrimis, lipsește RESEND_API_KEY] către: ${to} | subiect: ${subject}\n${html.replace(/<[^>]+>/g, ' ')}`);
    return false;
  }
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to, subject, html: brandedEmail(html) }),
    });
    return r.ok;
  } catch (e) {
    console.error('[leaply mail] eroare trimitere:', e);
    return false;
  }
}

/** Email cu atașament (ex. backup DB săptămânal, off-site). Best-effort. */
export async function sendMailWithAttachment(to: string, subject: string, html: string, filename: string, content: Buffer): Promise<boolean> {
  const key = cfg('RESEND_API_KEY');
  const from = cfg('MAIL_FROM') || 'Leaply <salut@leaply.ro>';
  if (!key || content.length > 8_000_000) return false;
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({ from, to, subject, html: brandedEmail(html), attachments: [{ filename, content: content.toString('base64') }] }),
      signal: AbortSignal.timeout(20000),
    });
    return r.ok;
  } catch (e) { console.error('[mail attach]', String(e).slice(0, 150)); return false; }
}
