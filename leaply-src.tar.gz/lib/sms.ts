import { cfg } from './settings';

// SMS prin SMSLink.ro (Setări platformă: SMSLINK_CONNECTION_ID + SMSLINK_PASSWORD).
export const smsConfigured = () => Boolean(cfg('SMSLINK_CONNECTION_ID') && cfg('SMSLINK_PASSWORD'));

export async function sendSms(to: string, message: string): Promise<boolean> {
  const num = to.replace(/[^\d+]/g, '');
  if (!num) return false;
  if (!smsConfigured()) {
    console.log(`[leaply sms — netrimis, lipsesc cheile SMSLink] către ${num}: ${message.slice(0, 80)}`);
    return false;
  }
  try {
    const p = new URLSearchParams({
      connection_id: cfg('SMSLINK_CONNECTION_ID'),
      password: cfg('SMSLINK_PASSWORD'),
      to: num.replace(/^\+/, ''),
      message: message.slice(0, 320),
    });
    const r = await fetch(`https://secure.smslink.ro/sms/gateway/communicate/index.php?${p}`, { signal: AbortSignal.timeout(10000) });
    const body = await r.text();
    const ok = r.ok && /^MESSAGE/.test(body.trim());
    if (!ok) console.error('[leaply sms] răspuns:', body.slice(0, 120));
    return ok;
  } catch (e) { console.error('[leaply sms]', String(e).slice(0, 150)); return false; }
}
