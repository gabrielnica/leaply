// Leaply — logo 2026. Marcă: pătrat rotunjit accent cu fulger alb + wordmark display.
export function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true" style={{ flexShrink: 0 }}>
      <rect x="1" y="1" width="46" height="46" rx="13" fill="#FF4D1F" />
      <path d="M26.5 9 L15 27.5 h7.5 L21.5 39 L33 20.5 h-7.5 Z" fill="#FFFFFF" stroke="#FFFFFF" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo({ light = false, size = 28 }: { light?: boolean; size?: number }) {
  return (
    <span className="logo" style={{ color: light ? '#F2F0EA' : 'var(--ink)' }}>
      <LogoMark size={size} />
      <span className="brandfont">leaply</span>
    </span>
  );
}
