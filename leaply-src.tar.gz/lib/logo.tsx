export function Logo({ light = false, size = 30 }: { light?: boolean; size?: number }) {
  const bubble = light ? '#12385F' : '#0B2A4A';
  const text = light ? '#ffffff' : '#0B2A4A';
  return (
    <span className="logo" style={{ color: text }}>
      <svg width={size} height={size} viewBox="0 0 120 120" aria-label="Leaply">
        <path d="M18 8 h84 a18 18 0 0 1 18 18 v56 a18 18 0 0 1 -18 18 h-50 l-22 22 v-22 h-12 a18 18 0 0 1 -18 -18 v-56 a18 18 0 0 1 18 -18 z" fill={bubble}/>
        <path d="M40 78 L64 54 L80 70 M64 54 L64 86 M64 54 L36 54" fill="none" stroke="#C6F24E" strokeWidth="11" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      <span className="brandfont">leaply</span>
    </span>
  );
}
