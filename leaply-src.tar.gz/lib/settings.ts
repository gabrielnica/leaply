import { db } from './db';

// Setări de platformă (chei API, model LLM etc.) — editabile din Admin → Setări platformă.
// Prioritate: valoarea din DB > variabila de mediu > gol. Niciodată expuse nemascate în UI.

export const SETTING_GROUPS: { group: string; keys: { key: string; label: string; hint?: string; secret?: boolean }[] }[] = [
  {
    group: 'AI / LLM',
    keys: [
      { key: 'OPENAI_API_KEY', label: 'OpenAI API key', secret: true, hint: 'Activează răspunsuri GPT. Fără cheie: creier pe reguli.' },
      { key: 'ANTHROPIC_API_KEY', label: 'Anthropic API key', secret: true, hint: 'Alternativă la OpenAI (Claude). Se folosește dacă OpenAI lipsește.' },
      { key: 'LLM_MODEL', label: 'Model', hint: 'ex. gpt-4o-mini sau claude-3-5-haiku-20241022' },
    ],
  },
  {
    group: 'Email (Resend)',
    keys: [
      { key: 'RESEND_API_KEY', label: 'Resend API key', secret: true, hint: 'Pentru resetări de parolă și notificări owner.' },
      { key: 'MAIL_FROM', label: 'Expeditor', hint: 'ex. Leaply <salut@leaply.ro> — domeniu verificat în Resend.' },
    ],
  },
  {
    group: 'Google Calendar (OAuth)',
    keys: [
      { key: 'GOOGLE_CLIENT_ID', label: 'Client ID', hint: 'Google Cloud Console → OAuth 2.0. Redirect URI: https://leaply.ro/api/integrations/google/callback' },
      { key: 'GOOGLE_CLIENT_SECRET', label: 'Client secret', secret: true },
    ],
  },
  {
    group: 'Stripe (plăți)',
    keys: [
      { key: 'STRIPE_SECRET_KEY', label: 'Secret key', secret: true },
      { key: 'STRIPE_WEBHOOK_SECRET', label: 'Webhook signing secret', secret: true, hint: 'Endpoint: https://leaply.ro/api/webhooks/stripe' },
      { key: 'STRIPE_PRICE_START', label: 'Price ID — Start (59€)' },
      { key: 'STRIPE_PRICE_PRO', label: 'Price ID — Pro (129€)' },
      { key: 'STRIPE_PRICE_SCALE', label: 'Price ID — Scale (299€)' },
    ],
  },
  {
    group: 'Meta / WhatsApp',
    keys: [
      { key: 'META_APP_ID', label: 'Meta App ID', hint: 'Meta for Developers → aplicația ta. Necesar pentru conectarea cu un click (Facebook Login).' },
      { key: 'META_APP_SECRET', label: 'Meta app secret', secret: true, hint: 'Din aceeași aplicație. Folosit și la validarea semnăturii webhook-urilor.' },
      { key: 'META_VERIFY_TOKEN', label: 'Verify token', hint: 'Folosit la abonarea webhook-urilor în Meta for Developers.' },
      { key: 'WHATSAPP_APP_SECRET', label: 'WhatsApp app secret', secret: true },
    ],
  },
  {
    group: 'General',
    keys: [{ key: 'APP_URL', label: 'URL aplicație', hint: 'implicit https://leaply.ro' }],
  },
];

const KNOWN = new Set(SETTING_GROUPS.flatMap(g => g.keys.map(k => k.key)));

export function cfg(key: string): string {
  try {
    const row: any = db().prepare('SELECT value FROM settings WHERE key=?').get(key);
    if (row?.value) return row.value;
  } catch {}
  return process.env[key] || '';
}

export function setSetting(key: string, value: string) {
  if (!KNOWN.has(key)) throw new Error('cheie necunoscută');
  const d = db();
  if (!value) d.prepare('DELETE FROM settings WHERE key=?').run(key);
  else d.prepare('INSERT INTO settings (key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at')
    .run(key, value, new Date().toISOString());
}

export function listSettings() {
  const mask = (v: string) => v.length > 8 ? `${v.slice(0, 4)}…${v.slice(-4)}` : (v ? '••••' : '');
  return SETTING_GROUPS.map(g => ({
    group: g.group,
    keys: g.keys.map(k => {
      let dbVal = '';
      try { dbVal = (db().prepare('SELECT value FROM settings WHERE key=?').get(k.key) as any)?.value || ''; } catch {}
      const envVal = process.env[k.key] || '';
      const effective = dbVal || envVal;
      return {
        ...k,
        source: dbVal ? 'db' : envVal ? 'env' : 'unset',
        preview: k.secret ? mask(effective) : effective,
      };
    }),
  }));
}

export const appUrl = () => cfg('APP_URL') || 'https://leaply.ro';
