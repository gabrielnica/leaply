import { llmReply, llmActive } from './llm';

// Import automat de cunoștințe de pe site-ul clientului.
// v2: crawl multi-pagină — pe lângă homepage citește și paginile cu adevărat utile
// (/servicii, /preturi, /contact, /despre, /program), unde stau prețurile și programul.

const strip = (html: string) =>
  html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').replace(/\s+/g, ' ').trim();

const UA = { 'User-Agent': 'Mozilla/5.0 (LeaplyBot; +https://leaply.ro)' };
const USEFUL = /servic|pret|tarif|price|contact|despre|about|program|orar|echipa|oferta|meniu|menu/i;
const SKIP = /\.(jpg|png|pdf|zip|mp4|css|js)$|#|mailto:|tel:|\/(blog|wp-|category|tag|en\/|login)/i;

async function fetchPage(url: string): Promise<{ text: string; html: string } | null> {
  try {
    const r = await fetch(url, { headers: UA, redirect: 'follow', signal: AbortSignal.timeout(10000) });
    if (!r.ok) return null;
    const html = await r.text();
    return { text: strip(html), html };
  } catch { return null; }
}

/** Homepage + până la 4 pagini interne relevante → un singur text (max ~24k). */
export async function crawlSite(rawUrl: string): Promise<{ ok: boolean; text?: string; pages?: string[]; error?: string }> {
  let url = rawUrl.trim();
  if (!/^https?:\/\//.test(url)) url = 'https://' + url;
  let origin: string;
  try { origin = new URL(url).origin; } catch { return { ok: false, error: 'Adresă de site invalidă.' }; }

  const home = await fetchPage(url);
  if (!home) return { ok: false, error: 'Nu am putut accesa site-ul (timeout sau blocat).' };
  if (home.text.length < 100) return { ok: false, error: 'Site-ul nu are conținut lizibil.' };

  // linkuri interne relevante din homepage
  const links = new Set<string>();
  for (const m of home.html.matchAll(/href=["']([^"'#?]+)["']/gi)) {
    const href = m[1];
    if (SKIP.test(href) || !USEFUL.test(href)) continue;
    try {
      const u = new URL(href, origin);
      if (u.origin === origin && u.pathname.length > 1) links.add(u.href);
    } catch { /* href invalid */ }
    if (links.size >= 4) break;
  }
  const pages = [url];
  let text = `[pagina principală] ${home.text.slice(0, 9000)}\n`;
  for (const l of links) {
    const p = await fetchPage(l);
    if (p && p.text.length > 80) {
      text += `\n[${new URL(l).pathname}] ${p.text.slice(0, 4500)}\n`;
      pages.push(l);
    }
    if (text.length > 24000) break;
  }
  return { ok: true, text, pages };
}

export async function scrapeSite(rawUrl: string): Promise<{ ok: boolean; knowledge?: string; services?: { name: string; price: string }[]; description?: string; pages?: string[]; siteText?: string; error?: string }> {
  const crawled = await crawlSite(rawUrl);
  if (!crawled.ok) return { ok: false, error: crawled.error };
  const text = crawled.text!.slice(0, 20000);

  if (llmActive()) {
    const out = await llmReply(
      `Ești un extractor de date pentru un asistent AI de vânzări. Primești textul mai multor pagini ale unui site românesc de afaceri (marcate cu [cale]). Răspunde STRICT cu JSON valid: {"description":"1-2 fraze despre afacere","services":[{"name":"...","price":"... sau «la cerere»"}],"knowledge":"5-10 fraze cu informații utile pentru a răspunde clienților (program, zonă de acoperire, garanții, diferențiatori, întrebări frecvente)"} — totul în română, fără alte cuvinte în afara JSON-ului.`,
      [{ role: 'user', content: text }]);
    if (out) {
      try {
        const j = JSON.parse(out.replace(/^```json?|```$/g, '').trim());
        return { ok: true, description: j.description || '', services: Array.isArray(j.services) ? j.services.slice(0, 12) : [], knowledge: String(j.knowledge || '').slice(0, 2000), pages: crawled.pages, siteText: text };
      } catch { /* JSON invalid — cădem pe fallback */ }
    }
  }
  return { ok: true, description: '', services: [], knowledge: text.slice(0, 1500), pages: crawled.pages, siteText: text };
}

/** Ține conținutul site-ului ca „Document firmă" (RAG) — actualizat la reimport și lunar din cron.
 *  Un singur doc per cont, numit „Site: <domeniu>". */
export async function syncSiteDoc(accId: string, website: string): Promise<boolean> {
  const crawled = await crawlSite(website);
  if (!crawled.ok || !crawled.text) return false;
  try {
    const { db } = await import('./db');
    let host = website; try { host = new URL(/^https?:/.test(website) ? website : 'https://' + website).host; } catch {}
    const name = `Site: ${host}`;
    const d = db();
    const existing: any = d.prepare("SELECT id FROM knowledge_docs WHERE account_id=? AND name LIKE 'Site: %' LIMIT 1").get(accId);
    if (existing) d.prepare('UPDATE knowledge_docs SET name=?, content=?, created_at=? WHERE id=?').run(name, crawled.text.slice(0, 100000), new Date().toISOString(), existing.id);
    else d.prepare('INSERT INTO knowledge_docs (id, account_id, name, content, created_at) VALUES (?,?,?,?,?)')
      .run('kd_' + Math.random().toString(36).slice(2, 10), accId, name, crawled.text.slice(0, 100000), new Date().toISOString());
    return true;
  } catch { return false; }
}
