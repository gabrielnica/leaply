import { llmReply, llmActive } from './llm';

// Import automat de cunoștințe de pe site-ul clientului (wizard, pas „Afacerea ta").
const strip = (html: string) =>
  html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').replace(/\s+/g, ' ').trim();

export async function scrapeSite(rawUrl: string): Promise<{ ok: boolean; knowledge?: string; services?: { name: string; price: string }[]; description?: string; error?: string }> {
  let url = rawUrl.trim();
  if (!/^https?:\/\//.test(url)) url = 'https://' + url;
  try { new URL(url); } catch { return { ok: false, error: 'Adresă de site invalidă.' }; }
  let text = '';
  try {
    const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (LeaplyBot; +https://leaply.ro)' }, redirect: 'follow', signal: AbortSignal.timeout(12000) });
    if (!r.ok) return { ok: false, error: `Site-ul a răspuns cu ${r.status}.` };
    text = strip(await r.text()).slice(0, 12000);
  } catch { return { ok: false, error: 'Nu am putut accesa site-ul (timeout sau blocat).' }; }
  if (text.length < 100) return { ok: false, error: 'Site-ul nu are conținut lizibil.' };

  if (llmActive()) {
    const out = await llmReply(
      `Ești un extractor de date pentru un asistent AI de vânzări. Primești textul unui site românesc de afaceri. Răspunde STRICT cu JSON valid: {"description":"1-2 fraze despre afacere","services":[{"name":"...","price":"... sau «la cerere»"}],"knowledge":"5-10 fraze cu informații utile pentru a răspunde clienților (program, zonă de acoperire, garanții, diferențiatori, întrebări frecvente)"} — totul în română, fără alte cuvinte în afara JSON-ului.`,
      [{ role: 'user', content: text }]);
    if (out) {
      try {
        const j = JSON.parse(out.replace(/^```json?|```$/g, '').trim());
        return { ok: true, description: j.description || '', services: Array.isArray(j.services) ? j.services.slice(0, 8) : [], knowledge: String(j.knowledge || '').slice(0, 2000) };
      } catch {}
    }
  }
  // fallback fără LLM: primele fraze relevante
  return { ok: true, description: '', services: [], knowledge: text.slice(0, 1500) };
}
