import { db } from './db';
import { TRIAL_DAYS } from './plan';

// Statistici de business pentru zona de admin (KPI, marje, funnel, numere).
// Toate interogările sunt read-only și ieftine (SQLite local).

export const PLAN_PRICE: Record<string, number> = { Start: 59, Pro: 129, Scale: 299 };
const PAID = ['Start', 'Pro', 'Scale'];
// costuri unitare estimate (EUR) — aliniate cu analiza de marje
export const UNIT_COST = { conv: 0.002, sms: 0.05, voiceMin: 0.15, numberMonthly: 5 };

const monthKey = () => new Date().toISOString().slice(0, 7);
const PLATFORM = ['acc_demo', 'acc_leaply']; // conturile interne nu intră în cifrele de business

const notPlatform = `id NOT IN ('acc_demo','acc_leaply') AND parent_id IS NULL`;

export function adminKpis() {
  const d = db();
  const accs: any[] = d.prepare(`SELECT id, plan, created_at, trial_extra, suspended FROM accounts WHERE ${notPlatform}`).all();
  const paid = accs.filter(a => PAID.includes(a.plan));
  const trials = accs.filter(a => !PAID.includes(a.plan));
  const mrr = paid.reduce((s, a) => s + (PLAN_PRICE[a.plan] || 0), 0);
  const now = Date.now();
  const daysLeft = (a: any) => Math.ceil(TRIAL_DAYS + (a.trial_extra || 0) - (now - new Date(a.created_at).getTime()) / 86400_000);
  const expiringSoon = trials.filter(a => { const l = daysLeft(a); return l > 0 && l <= 3; }).length;
  const expired = trials.filter(a => daysLeft(a) <= 0).length;
  const new7d = accs.filter(a => now - new Date(a.created_at).getTime() < 7 * 86400_000).length;
  const m = monthKey();
  const cnt = (kind: string) => (d.prepare(`SELECT COALESCE(SUM(n),0) s FROM usage_counters WHERE month=? AND kind=? AND account_id NOT IN ('acc_demo','acc_leaply')`).get(m, kind) as any).s;
  const convMonth = (d.prepare(`SELECT COUNT(*) c FROM conversations WHERE created_at >= ? AND account_id NOT IN ('acc_demo','acc_leaply')`).get(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString()) as any).c;
  return {
    total: accs.length, paidCount: paid.length, trialCount: trials.length,
    mrr, expiringSoon, expired, new7d,
    convMonth, smsMonth: cnt('sms'), voiceMinMonth: cnt('voice_min'),
    numbers: numbersAllocated().length,
    suspended: accs.filter(a => a.suspended).length,
  };
}

/** Numere Twilio alocate (voce sau WhatsApp) — registrul parcului de numere. */
export function numbersAllocated(): { number: string; account_id: string; account: string; type: string; status: string }[] {
  const rows: any[] = db().prepare(`
    SELECT ch.type, ch.status, ch.credentials, ch.account_id, a.name AS account
    FROM channels ch JOIN accounts a ON a.id = ch.account_id
    WHERE ch.credentials IS NOT NULL`).all();
  const out: any[] = [];
  for (const r of rows) {
    try {
      const c = JSON.parse(r.credentials);
      if (c.from_number) out.push({ number: c.from_number, account_id: r.account_id, account: r.account, type: r.type, status: r.status });
    } catch { /* ignore */ }
  }
  return out;
}

/** Economia per cont: consum, cost estimat, venit, marjă. Sortat după cost. */
export function accountEconomics() {
  const d = db();
  const m = monthKey();
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();
  const accs: any[] = d.prepare(`SELECT id, name, plan FROM accounts WHERE ${notPlatform}`).all();
  const numbers = numbersAllocated();
  const { limitFor } = require('./usage');
  return accs.map(a => {
    const conv = (d.prepare('SELECT COUNT(*) c FROM conversations WHERE account_id=? AND created_at >= ?').get(a.id, monthStart) as any).c;
    const g = (kind: string) => (d.prepare('SELECT n FROM usage_counters WHERE account_id=? AND month=? AND kind=?').get(a.id, m, kind) as any)?.n || 0;
    const sms = g('sms'), voiceMin = g('voice_min');
    const numCount = numbers.filter(n => n.account_id === a.id).length;
    const cost = conv * UNIT_COST.conv + sms * UNIT_COST.sms + voiceMin * UNIT_COST.voiceMin + numCount * UNIT_COST.numberMonthly;
    const revenue = PLAN_PRICE[a.plan] || 0;
    const limit = limitFor(a.plan || 'Trial');
    return {
      id: a.id, name: a.name, plan: a.plan || 'Trial',
      conv, sms, voiceMin, numbers: numCount, limit,
      pct: limit ? Math.round((conv / limit) * 100) : 0,
      cost: Math.round(cost * 100) / 100, revenue,
      margin: Math.round((revenue - cost) * 100) / 100,
    };
  }).sort((x, y) => y.cost - x.cost);
}

/** Funnel: cereri demo → conturi → activate (canal real conectat) → plătitori. */
export function funnelStats() {
  const d = db();
  const demoReqs = (d.prepare("SELECT COUNT(*) c FROM demo_requests WHERE vertical NOT LIKE '%_number'").get() as any).c;
  const accounts = (d.prepare(`SELECT COUNT(*) c FROM accounts WHERE ${notPlatform}`).get() as any).c;
  const activated = (d.prepare(`
    SELECT COUNT(DISTINCT a.id) c FROM accounts a
    JOIN channels ch ON ch.account_id = a.id AND ch.status='connected' AND ch.type != 'webform'
    WHERE a.${notPlatform}`).get() as any).c;
  const paid = (d.prepare(`SELECT COUNT(*) c FROM accounts WHERE plan IN ('Start','Pro','Scale') AND ${notPlatform}`).get() as any).c;
  const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 100) : 0);
  return { demoReqs, accounts, activated, paid, pctAcc: pct(accounts, demoReqs), pctAct: pct(activated, accounts), pctPaid: pct(paid, accounts) };
}

/** Schimbări de plan / evenimente de billing recente (din audit). */
export function recentBillingEvents(limit = 25) {
  return db().prepare(`
    SELECT actor, action, target, meta, created_at FROM audit_log
    WHERE action IN ('plan.change','billing.upgraded','billing.churn','account.suspend','trial.extend')
    ORDER BY created_at DESC LIMIT ?`).all(limit) as any[];
}

/** Conturile plătitoare, cu detalii pentru pagina de billing. */
export function paidAccounts() {
  return db().prepare(`
    SELECT a.id, a.name, a.plan, a.created_at,
      (SELECT email FROM users u WHERE u.account_id=a.id AND u.role='owner' ORDER BY u.created_at LIMIT 1) AS owner_email
    FROM accounts a WHERE a.plan IN ('Start','Pro','Scale') AND a.${notPlatform}
    ORDER BY a.created_at DESC`).all() as any[];
}
