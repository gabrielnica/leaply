import { cfg } from './settings';
import { getIntegrations } from './integrations';

// Factură SmartBill Cloud la plată (Setări platformă: SMARTBILL_EMAIL, SMARTBILL_TOKEN,
// SMARTBILL_CIF — CIF-ul firmei tale, SMARTBILL_SERIES — seria facturii).
// Datele clientului vin din Setări & Plan → Facturare (integrations.billing).
export const smartbillConfigured = () =>
  Boolean(cfg('SMARTBILL_EMAIL') && cfg('SMARTBILL_TOKEN') && cfg('SMARTBILL_CIF') && cfg('SMARTBILL_SERIES'));

const PLAN_PRICE: Record<string, number> = { Start: 59, Pro: 129, Scale: 299 };

export async function issueInvoice(accId: string, plan: string, accountName: string, ownerEmail: string | null): Promise<boolean> {
  return issueInvoiceAmount(accId, PLAN_PRICE[plan] || 0, `Abonament Leaply ${plan} (lunar)`, `LEAPLY-${plan.toUpperCase()}`, accountName, ownerEmail);
}

/** Factură pe o SUMĂ exactă (prorate la upgrade, add-on-uri, plăți anuale) — din Stripe invoice.paid. */
export async function issueInvoiceAmount(accId: string, price: number, description: string, code: string, accountName: string, ownerEmail: string | null): Promise<boolean> {
  if (!smartbillConfigured()) {
    console.log(`[leaply smartbill — factură neemisă, lipsesc cheile] cont ${accId}: ${description} ${price}€`);
    return false;
  }
  if (!(price > 0)) return false;
  const b = getIntegrations(accId).billing || {};
  try {
    const auth = Buffer.from(`${cfg('SMARTBILL_EMAIL')}:${cfg('SMARTBILL_TOKEN')}`).toString('base64');
    const r = await fetch('https://ws.smartbill.ro/SBORO/api/invoice', {
      method: 'POST',
      headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        companyVatCode: cfg('SMARTBILL_CIF'),
        seriesName: cfg('SMARTBILL_SERIES'),
        client: {
          name: b.company || accountName,
          vatCode: b.cif || '',
          address: b.address || '',
          city: b.city || '',
          country: 'Romania',
          email: b.email || ownerEmail || '',
          isTaxPayer: Boolean(b.cif),
          saveToDb: true,
        },
        issueDate: new Date().toISOString().slice(0, 10),
        currency: 'EUR',
        isDraft: false,
        sendEmail: true,
        products: [{
          name: description,
          code,
          isService: true,
          measuringUnitName: 'buc',
          currency: 'EUR',
          quantity: 1,
          price,
          isTaxIncluded: true,
          taxName: 'Normala',
          taxPercentage: 21,
        }],
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!r.ok) { console.error('[leaply smartbill]', r.status, (await r.text()).slice(0, 250)); return false; }
    console.log(`[leaply smartbill] factură emisă pentru ${accId}: ${description} ${price}€`);
    return true;
  } catch (e) { console.error('[leaply smartbill]', String(e).slice(0, 200)); return false; }
}
