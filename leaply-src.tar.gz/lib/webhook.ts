import crypto from 'crypto';
import { cfg, appUrl } from './settings';
import { db, uid } from './db';
import { getAccount, addMessage, updateConversation } from './store';
import { nextReply, Turn } from './brain';
import { resolveAccount, sendReply } from './channels';
import { gcalConnected, getFreeSlots, bookSlot } from './gcal';
import { getOwnerEmail, getIntegrations, emitWebhookOut } from './integrations';
import { overLimit, limitFor, shouldNotifyLimit } from './usage';
import { sendMail } from './mail';
import { sendSms } from './sms';

export function verifyMeta(url: URL): string | null {
  const mode = url.searchParams.get('hub.mode');
  const token = url.searchParams.get('hub.verify_token');
  const challenge = url.searchParams.get('hub.challenge');
  const expected = cfg('META_VERIFY_TOKEN') || 'leaply_verify_token';
  if (mode === 'subscribe' && token === expected) return challenge || '';
  return null;
}

export function checkSignature(raw: string, header: string | null, secret?: string): boolean {
  if (!secret) return process.env.NODE_ENV !== 'production'; // fără secret: permis doar în dev; în producție respinge (fail closed)
  if (!header) return false;
  const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(raw).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(header)); } catch { return false; }
}

export type InboundLead = { name: string; phone: string; text: string; replyTo: string };

// Extracție best-effort: Meta Lead Ads / WhatsApp (Meta & Twilio) / Messenger / IG / payload de test
export function extractLead(channel: string, payload: any): InboundLead | null {
  if (payload && payload.name && payload.text) {
    return { name: payload.name, phone: payload.phone || '', text: payload.text, replyTo: payload.phone || '' };
  }
  try {
    if (channel === 'whatsapp') {
      const m = payload?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
      const c = payload?.entry?.[0]?.changes?.[0]?.value?.contacts?.[0];
      if (m) return { name: c?.profile?.name || 'Lead WhatsApp', phone: m.from || '', text: m.text?.body || '(mesaj)', replyTo: m.from || '' };
    }
    if (channel === 'whatsapp_twilio') {
      const from = String(payload?.From || '').replace('whatsapp:', '');
      if (from && payload?.Body) return { name: payload?.ProfileName || 'Lead WhatsApp', phone: from, text: String(payload.Body), replyTo: from };
    }
    if (channel === 'meta_lead_ads') {
      const fd = payload?.entry?.[0]?.changes?.[0]?.value?.field_data || [];
      if (!fd.length) return null; // ping fără formular -> nu crea lead gol
      const get = (k: string) => fd.find((f: any) => f.name === k)?.values?.[0] || '';
      return { name: get('full_name') || 'Lead Facebook', phone: get('phone_number'), text: 'Am completat formularul de pe Facebook și aș dori o ofertă.', replyTo: get('phone_number') };
    }
    if (channel === 'messenger' || channel === 'instagram') {
      const msg = payload?.entry?.[0]?.messaging?.[0];
      if (msg?.message?.text !== undefined || msg?.message) {
        const psid = msg?.sender?.id || '';
        return { name: `Lead ${channel}`, phone: '', text: msg.message?.text || '(mesaj)', replyTo: psid };
      }
    }
  } catch {}
  return null;
}

/** Găsește conversația deschisă a lead-ului (același cont+canal+contact, activă în ultimele 24h) sau creează una nouă. */
function findOrCreateConversation(accId: string, channel: string, lead: InboundLead): { convId: string; isNew: boolean; status: string } {
  const d = db();
  const key = lead.replyTo || lead.phone;
  if (key) {
    const row: any = d.prepare(`
      SELECT c.id, c.status FROM conversations c JOIN leads l ON l.id = c.lead_id
      WHERE c.account_id=? AND c.channel=? AND l.phone=? AND c.status IN ('active','human','qualified')
        AND c.updated_at > ? ORDER BY c.updated_at DESC LIMIT 1`)
      .get(accId, channel === 'whatsapp_twilio' ? 'whatsapp' : channel, key, new Date(Date.now() - 24 * 3600_000).toISOString());
    if (row) return { convId: row.id, isNew: false, status: row.status };
  }
  const now = new Date().toISOString();
  const leadId = uid('ld_'); const convId = uid('cv_');
  d.transaction(() => {
    d.prepare('INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(leadId, accId, lead.name, key, channel, 'warm', now);
    d.prepare('INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(convId, accId, leadId, channel === 'whatsapp_twilio' ? 'whatsapp' : channel, 'active', 0, '{}', now, now);
  })();
  return { convId, isNew: true, status: 'active' };
}

function historyOf(convId: string): Turn[] {
  const msgs: any[] = db().prepare("SELECT direction, sender, body FROM messages WHERE conversation_id=? AND direction IN ('in','out') ORDER BY created_at").all(convId);
  return msgs.map(m => ({ sender: m.direction === 'in' ? 'lead' as const : 'ai' as const, body: m.body }));
}

async function notifyOwner(accId: string, subject: string, html: string) {
  try {
    if (getIntegrations(accId).notify?.email === false) return;
    const email = getOwnerEmail(accId);
    if (email) await sendMail(email, subject, html);
  } catch {}
}

export async function processInbound(channel: string, payload: any) {
  const accId = resolveAccount(channel, payload);
  const acc = getAccount(accId);
  if (!acc) return { ok: false, reason: 'cont negăsit' };
  const lead = extractLead(channel, payload);
  if (!lead) return { ok: false, reason: 'no lead extracted' };
  const t0 = Date.now();
  const canonChannel = channel === 'whatsapp_twilio' ? 'whatsapp' : channel;

  const { convId, isNew, status } = findOrCreateConversation(accId, channel, lead);
  addMessage(convId, 'in', 'lead', lead.text);

  // Owner-ul a preluat conversația — AI-ul tace, doar anunțăm owner-ul.
  if (status === 'human') {
    await notifyOwner(accId, `Mesaj nou de la ${lead.name} (conversație preluată de tine)`,
      `<p><b>${lead.name}</b> a scris:</p><blockquote>${lead.text}</blockquote><p>Conversația e preluată de tine — Leaply nu răspunde. <a href="${appUrl()}/app/conversation/${convId}">Deschide conversația</a></p>`);
    return { ok: true, convId, human: true };
  }

  // Limita planului: peste limită, lead-ul rămâne în inbox dar AI-ul nu răspunde.
  if (overLimit(accId, acc.plan)) {
    addMessage(convId, 'note', 'system', `Limita planului ${acc.plan} (${limitFor(acc.plan)} conversații/lună) a fost atinsă — asistentul nu a răspuns automat.`);
    if (shouldNotifyLimit(accId)) {
      await notifyOwner(accId, 'Ai atins limita planului — lead-urile nu mai primesc răspuns automat',
        `<p>Contul tău a atins limita de <b>${limitFor(acc.plan)} conversații/lună</b> (plan ${acc.plan}). Lead-urile noi intră în inbox, dar asistentul nu le mai răspunde automat.</p><p><a href="${appUrl()}/app/settings">Treci pe un plan mai mare</a> ca să reactivezi răspunsurile instant.</p>`);
    }
    emitWebhookOut(accId, isNew ? 'lead.created' : 'lead.updated', {
      conversation_id: convId, name: lead.name, phone: lead.phone, channel: canonChannel,
      score: 'warm', status: 'active', limited: true, last_message: lead.text,
    });
    return { ok: true, convId, limited: true };
  }

  // Sloturi reale din Google Calendar, dacă e conectat
  let config = acc.config;
  let liveSlots: { label: string; iso: string }[] | null = null;
  if (gcalConnected(accId)) {
    liveSlots = await getFreeSlots(accId);
    if (liveSlots && liveSlots.length >= 2) config = { ...config, bookingSlots: liveSlots.map(s => s.label) };
  }

  const history = historyOf(convId);
  const res = await nextReply(config, history);
  addMessage(convId, 'out', 'ai', res.reply);
  updateConversation(convId, {
    ...(isNew ? { first_response_ms: Date.now() - t0 } : {}),
    score: res.score, status: res.status, qualification: res.qualification,
  });

  // Booking real în calendar
  let eventLink: string | null = null;
  if (res.status === 'booked' && liveSlots?.length) {
    const chosen = liveSlots.find(s => res.reply.toLowerCase().includes(s.label.split(' ')[0])) || liveSlots[0];
    eventLink = await bookSlot(accId, chosen.iso, `Măsurătoare — ${lead.name}`,
      `Programat automat de Leaply.\nLead: ${lead.name} ${lead.phone}\nCanal: ${canonChannel}\nConversație: ${appUrl()}/app/conversation/${convId}`);
    if (eventLink) addMessage(convId, 'note', 'system', 'Eveniment creat în Google Calendar.');
  }
  // SMS de confirmare către lead la programare (dacă SMSLink e configurat și avem telefon)
  if (res.status === 'booked' && lead.phone && lead.phone.replace(/[^\d]/g, '').length >= 9) {
    const when = liveSlots?.length ? (liveSlots.find(s => res.reply.toLowerCase().includes(s.label.split(' ')[0])) || liveSlots[0]).label : '';
    const okSms = await sendSms(lead.phone, `Confirmare programare${when ? ' ' + when : ''} — ${acc.name}. Vă mulțumim! Dacă nu mai puteți ajunge, răspundeți la acest mesaj.`);
    if (okSms) addMessage(convId, 'note', 'system', 'SMS de confirmare trimis lead-ului.');
  }

  // Răspunsul pleacă înapoi pe canal (WhatsApp Meta/Twilio, Messenger, Instagram)
  let delivery: any = { sent: false, error: 'canal fără trimitere (lead ads/webform)' };
  if (['whatsapp', 'whatsapp_twilio', 'messenger', 'instagram'].includes(channel)) {
    delivery = await sendReply(accId, canonChannel, lead.replyTo, res.reply);
    if (!delivery.sent && delivery.error) addMessage(convId, 'note', 'system', `Răspuns negenerat pe canal: ${delivery.error}`);
  }

  // Notificări owner + webhook-out spre CRM
  const appUrl = appUrl();
  if (isNew && res.score === 'hot') {
    await notifyOwner(accId, `Lead fierbinte: ${lead.name}`,
      `<p>Leaply a calificat un lead <b>fierbinte</b> pe ${canonChannel}: <b>${lead.name}</b> ${lead.phone}</p><p><a href="${appUrl}/app/conversation/${convId}">Vezi conversația</a></p>`);
  }
  if (res.status === 'booked') {
    await notifyOwner(accId, `Programare nouă: ${lead.name}`,
      `<p>Leaply a programat o întâlnire cu <b>${lead.name}</b> ${lead.phone}.</p>${eventLink ? `<p><a href="${eventLink}">Vezi în Google Calendar</a></p>` : ''}<p><a href="${appUrl}/app/conversation/${convId}">Vezi conversația</a></p>`);
  }
  emitWebhookOut(accId, isNew ? 'lead.created' : 'lead.updated', {
    conversation_id: convId, name: lead.name, phone: lead.phone, channel: canonChannel,
    score: res.score, status: res.status, qualification: res.qualification, last_message: lead.text,
  });

  return { ok: true, convId, reply: res.reply, respondedInMs: Date.now() - t0, delivered: delivery.sent, eventLink };
}
