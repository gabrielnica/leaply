import crypto from 'crypto';
import { getAccount, createInboundConversation, addMessage, updateConversation } from './store';
import { nextReply } from './brain';

export function verifyMeta(url: URL): string | null {
  const mode = url.searchParams.get('hub.mode');
  const token = url.searchParams.get('hub.verify_token');
  const challenge = url.searchParams.get('hub.challenge');
  const expected = process.env.META_VERIFY_TOKEN || 'leaply_verify_token';
  if (mode === 'subscribe' && token === expected) return challenge || '';
  return null;
}

export function checkSignature(raw: string, header: string | null, secret?: string): boolean {
  if (!secret) return true; // dev mode: no secret configured
  if (!header) return false;
  const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(raw).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(header)); } catch { return false; }
}

// Best-effort extraction across Meta Lead Ads / WhatsApp / Messenger / IG / test payloads
export function extractLead(channel: string, payload: any): { name: string; phone: string; text: string } | null {
  if (payload && payload.name && payload.text) return { name: payload.name, phone: payload.phone || '', text: payload.text };
  try {
    if (channel === 'whatsapp') {
      const m = payload?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
      const c = payload?.entry?.[0]?.changes?.[0]?.value?.contacts?.[0];
      if (m) return { name: c?.profile?.name || 'Lead WhatsApp', phone: m.from || '', text: m.text?.body || '(mesaj)' };
    }
    if (channel === 'meta_lead_ads') {
      const fd = payload?.entry?.[0]?.changes?.[0]?.value?.field_data || [];
      const get = (k: string) => fd.find((f: any) => f.name === k)?.values?.[0] || '';
      return { name: get('full_name') || 'Lead Facebook', phone: get('phone_number'), text: 'Am completat formularul de pe Facebook și aș dori o ofertă.' };
    }
    if (channel === 'messenger' || channel === 'instagram') {
      const msg = payload?.entry?.[0]?.messaging?.[0];
      if (msg) return { name: `Lead ${channel}`, phone: '', text: msg.message?.text || '(mesaj)' };
    }
  } catch {}
  return null;
}

export async function processInbound(channel: string, payload: any) {
  const acc = getAccount();
  const lead = extractLead(channel, payload);
  if (!lead) return { ok: false, reason: 'no lead extracted' };
  const t0 = Date.now();
  const { convId } = createInboundConversation(acc.id, channel, lead.name, lead.phone, channel, lead.text);
  const res = await nextReply(acc.config, [{ sender: 'lead', body: lead.text }]);
  addMessage(convId, 'out', 'ai', res.reply);
  updateConversation(convId, { first_response_ms: Date.now() - t0, score: res.score, status: res.status, qualification: res.qualification });
  // In producție: aici s-ar trimite răspunsul înapoi prin API-ul canalului (WhatsApp/Messenger).
  return { ok: true, convId, reply: res.reply, respondedInMs: Date.now() - t0 };
}
