import { cfg } from './settings';

// Strat LLM opțional. Cu cheie setată (Admin → Setări platformă sau env), reformulează
// răspunsul cu un model real; altfel rămâne creierul determinist (brain.ts). Nu aruncă niciodată.
// Dacă OpenAI eșuează (ex. 429 quota) și există cheie Anthropic, trece automat pe Anthropic.

// Ultima eroare LLM — pentru diagnostic (/api/health?llm=1). Nu conține chei.
export let lastLLMError: string | null = null;

type Opts = { maxTokens: number; temperature: number };

async function openaiReply(key: string, system: string, history: { role: string, content: string }[], o: Opts): Promise<string | null> {
  const model = cfg('LLM_MODEL') || 'gpt-4o-mini';
  const r = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, temperature: o.temperature, max_tokens: o.maxTokens,
      messages: [{ role: 'system', content: system }, ...history] }),
    signal: AbortSignal.timeout(15000),
  });
  const j = await r.json();
  if (!r.ok) {
    lastLLMError = `openai ${r.status} (model ${model}): ${String(j?.error?.message || JSON.stringify(j)).slice(0, 300)}`;
    console.error('[llm]', lastLLMError);
    return null;
  }
  return j?.choices?.[0]?.message?.content?.trim() || null;
}

async function anthropicReply(key: string, system: string, history: { role: string, content: string }[], o: Opts): Promise<string | null> {
  const configured = cfg('LLM_MODEL') || '';
  const model = configured.startsWith('claude') ? configured : 'claude-3-5-haiku-20241022';
  // Anthropic cere alternanță strictă user/asistent și primul mesaj = user
  const msgs: { role: 'user' | 'assistant'; content: string }[] = [];
  for (const m of history) {
    const role = m.role === 'assistant' ? 'assistant' as const : 'user' as const;
    if (msgs.length === 0 && role === 'assistant') msgs.push({ role: 'user', content: '(început de conversație)' });
    if (msgs.length > 0 && msgs[msgs.length - 1].role === role) msgs[msgs.length - 1].content += '\n' + m.content;
    else msgs.push({ role, content: m.content });
  }
  if (msgs.length === 0) msgs.push({ role: 'user', content: '(început de conversație)' });
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model, max_tokens: o.maxTokens, system, messages: msgs }),
    signal: AbortSignal.timeout(15000),
  });
  const j = await r.json();
  if (!r.ok) {
    lastLLMError = `anthropic ${r.status} (model ${model}): ${String(j?.error?.message || JSON.stringify(j)).slice(0, 300)}`;
    console.error('[llm]', lastLLMError);
    return null;
  }
  return j?.content?.[0]?.text?.trim() || null;
}

export async function llmReply(system: string, history: { role: string, content: string }[], opts?: { maxTokens?: number; temperature?: number }): Promise<string | null> {
  const o: Opts = { maxTokens: opts?.maxTokens ?? 220, temperature: opts?.temperature ?? 0.4 };
  try {
    const openai = cfg('OPENAI_API_KEY');
    const anthropic = cfg('ANTHROPIC_API_KEY');
    if (openai) {
      const out = await openaiReply(openai, system, history, o).catch((e: any) => {
        lastLLMError = `openai exception: ${String(e?.message || e).slice(0, 200)}`;
        console.error('[llm]', lastLLMError);
        return null;
      });
      if (out) { lastLLMError = null; return out; }
      // fallback: OpenAI a picat (ex. quota) → încearcă Anthropic dacă există cheie
      if (anthropic) {
        const alt = await anthropicReply(anthropic, system, history, o);
        if (alt) { lastLLMError = null; return alt; }
      }
      return null;
    }
    if (anthropic) {
      const out = await anthropicReply(anthropic, system, history, o);
      if (out) { lastLLMError = null; return out; }
      return null;
    }
    return null;
  } catch (e: any) {
    lastLLMError = `exception: ${String(e?.message || e).slice(0, 200)}`;
    console.error('[llm]', lastLLMError);
    return null;
  }
}

export function llmActive(): boolean {
  return !!(cfg('OPENAI_API_KEY') || cfg('ANTHROPIC_API_KEY'));
}

/** Probă de diagnostic: un apel minimal, întoarce ok/eroare (fără chei). */
export async function llmProbe(): Promise<{ ok: boolean; error: string | null }> {
  if (!llmActive()) return { ok: false, error: 'nicio cheie API setată' };
  const out = await llmReply('Răspunde cu un singur cuvânt: pong', [{ role: 'user', content: 'ping' }], { maxTokens: 8, temperature: 0 });
  return { ok: !!out, error: out ? null : lastLLMError };
}
