// Optional LLM layer. If a key is present, phrase the reply with a real model.
// Otherwise the deterministic brain (brain.ts) is used. Never throws.
export async function llmReply(system: string, history: {role:string, content:string}[]): Promise<string | null> {
  try {
    const model = process.env.LLM_MODEL || 'gpt-4o-mini';
    if (process.env.OPENAI_API_KEY) {
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
        body: JSON.stringify({ model, temperature: 0.4, max_tokens: 220,
          messages: [{ role: 'system', content: system }, ...history] }),
      });
      const j = await r.json();
      return j?.choices?.[0]?.message?.content?.trim() || null;
    }
    if (process.env.ANTHROPIC_API_KEY) {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: process.env.LLM_MODEL || 'claude-3-5-haiku-20241022', max_tokens: 220,
          system, messages: history.map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })) }),
      });
      const j = await r.json();
      return j?.content?.[0]?.text?.trim() || null;
    }
    return null;
  } catch { return null; }
}

export function llmActive(): boolean {
  return !!(process.env.OPENAI_API_KEY || process.env.ANTHROPIC_API_KEY);
}
