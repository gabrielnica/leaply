import { cfg } from './settings';

// Strat LLM opțional. Cu cheie setată (Admin → Setări platformă sau env), reformulează
// răspunsul cu un model real; altfel rămâne creierul determinist (brain.ts). Nu aruncă niciodată.

// Ultima eroare LLM — pentru diagnostic (/api/health?llm=1). Nu conține chei.
export let lastLLMError: string | null = null;

export async function llmReply(system: string, history: { role: string, content: string }[], opts?: { maxTokens?: number; temperature?: number }): Promise<string | null> {
  const maxTokens = opts?.maxTokens ?? 220;
  const temperature = opts?.temperature ?? 0.4;
  try {
    const openai = cfg('OPENAI_API_KEY');
    const anthropic = cfg('ANTHROPIC_API_KEY');
    if (openai) {
      const model = cfg('LLM_MODEL') || 'gpt-4o-mini';
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${openai}` },
        body: JSON.stringify({ model, temperature, max_tokens: maxTokens,
          messages: [{ role: 'system', content: system }, ...history] }),
        signal: AbortSignal.timeout(15000),
      });
      const j = await r.json();
      if (!r.ok) {
        lastLLMError = `openai ${r.status} (model ${model}): ${String(j?.error?.message || JSON.stringify(j)).slice(0, 300)}`;
        console.error('[llm]', lastLLMError);
        return null;
      }
      lastLLMError = null;
      return j?.choices?.[0]?.message?.content?.trim() || null;
    }
    if (anthropic) {
      const model = cfg('LLM_MODEL') || 'claude-3-5-haiku-20241022';
      // Anthropic cere alternanță strictă user/asistent și primul mesaj = user
      const msgs: { role: 'user' | 'assistant'; content: string }[] = [];
      for (const m of history) {
        const role = m.role === 'assistant' ? 'assistant' as const : 'user' as const;
        if (msgs.length === 0 && role === 'assistant') msgs.push({ role: 'user', content: '(început de conversație)' });
        if (msgs.length > 0 && msgs[msgs.length - 1].role === role) msgs[msgs.length - 1].content += '\n' + m.content;
        else msgs.push({ role, content: m.content });
      }
      if (msgs.length === 0) msgs.push({ role: 'user', content: '(început de conversație)' });
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': anthropic, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model, max_tokens: maxTokens, system, messages: msgs }),
        signal: AbortSignal.timeout(15000),
      });
      const j = await r.json();
      if (!r.ok) {
        lastLLMError = `anthropic ${r.status} (model ${model}): ${String(j?.error?.message || JSON.stringify(j)).slice(0, 300)}`;
        console.error('[llm]', lastLLMError);
        return null;
      }
      lastLLMError = null;
      return j?.content?.[0]?.text?.trim() || null;
    }
    return null;
  } catch (e: any) {
    lastLLMError = `exception: ${String(e?.message || e).slice(0, 200)}`;
    console.error('[llm]', lastLLMError);
    return null;
  }
}

export function llmActive(): boolean {
  return !!(cfg('OPENAI_API_KEY') || cfg('ANTHROPIC_API_KEY'));
}

/** Probă de diagnostic: un apel minimal, întoarce ok/eroare (fără chei). */
export async function llmProbe(): Promise<{ ok: boolean; error: string | null }> {
  if (!llmActive()) return { ok: false, error: 'nicio cheie API setată' };
  const out = await llmReply('Răspunde cu un singur cuvânt: pong', [{ role: 'user', content: 'ping' }], { maxTokens: 8, temperature: 0 });
  return { ok: !!out, error: out ? null : lastLLMError };
}
