import { cfg } from './settings';

// Strat LLM opțional. Cu cheie setată (Admin → Setări platformă sau env), reformulează
// răspunsul cu un model real; altfel rămâne creierul determinist (brain.ts). Nu aruncă niciodată.
export async function llmReply(system: string, history: { role: string, content: string }[], opts?: { maxTokens?: number; temperature?: number }): Promise<string | null> {
  const maxTokens = opts?.maxTokens ?? 220;
  const temperature = opts?.temperature ?? 0.4;
  try {
    const openai = cfg('OPENAI_API_KEY');
    const anthropic = cfg('ANTHROPIC_API_KEY');
    if (openai) {
      const model = cfg('LLM_MODEL') || 'gpt-4o-mini';
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${openai}` },
        body: JSON.stringify({ model, temperature, max_tokens: maxTokens,
          messages: [{ role: 'system', content: system }, ...history] }),
        signal: AbortSignal.timeout(15000),
      });
      const j = await r.json();
      return j?.choices?.[0]?.message?.content?.trim() || null;
    }
    if (anthropic) {
      const model = cfg('LLM_MODEL') || 'claude-3-5-haiku-20241022';
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': anthropic, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model, max_tokens: maxTokens,
          system, messages: history.map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })) }),
        signal: AbortSignal.timeout(15000),
      });
      const j = await r.json();
      return j?.content?.[0]?.text?.trim() || null;
    }
    return null;
  } catch { return null; }
}

export function llmActive(): boolean {
  return !!(cfg('OPENAI_API_KEY') || cfg('ANTHROPIC_API_KEY'));
}
