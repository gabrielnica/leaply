// Magistrala de evenimente in-memory pentru inboxul real-time (SSE).
// Un singur proces Node (server.js) => un EventEmitter e suficient; fără Redis.
import { EventEmitter } from 'events';

export type LeaplyEvent = { type: 'message' | 'conversation'; convId: string; at: string };

const g = globalThis as any;
const bus: EventEmitter = g.__leaplyBus || (g.__leaplyBus = new EventEmitter());
bus.setMaxListeners(500);

export function emitAccountEvent(accId: string, ev: LeaplyEvent) {
  try { bus.emit(`acc:${accId}`, ev); } catch { /* best-effort */ }
}

export function onAccountEvent(accId: string, fn: (ev: LeaplyEvent) => void): () => void {
  const key = `acc:${accId}`;
  bus.on(key, fn);
  return () => bus.off(key, fn);
}
