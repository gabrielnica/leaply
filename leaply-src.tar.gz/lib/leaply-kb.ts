// Baza de cunoștințe Leaply — sursa unică de adevăr pentru:
//  - chatbot-ul de vânzări de pe leaply.ro (acc_leaply, prin lib/salesbot.ts)
//  - agentul vocal (voice-bridge.js citește config.knowledge din DB, sincronizat la boot din acest fișier)
//  - asistentul de onboarding din contul clienților (/api/assistant)
// Modifici aici → build + deploy → totul e la zi peste tot.

export const LEAPLY_KNOWLEDGE = `
=== CE ESTE LEAPLY ===
Leaply este un asistent AI de vânzări pentru afaceri mici și mijlocii din România. Răspunde lead-urilor în sub 60 de secunde, 24/7, pe toate canalele, pune întrebări de calificare, propune și fixează programări direct în calendar, și trimite follow-up automat celor care nu răspund. Practic: niciun lead pierdut, fără angajat în plus.
De ce contează: majoritatea firmelor răspund la lead-uri în ore sau deloc; șansa de a califica un lead scade de peste 10 ori dacă răspunzi după 5 minute în loc de 1 minut. Leaply răspunde instant, mereu.
Pentru cine: termopane și tâmplărie, clinici stomatologice, service auto, agenții imobiliare, instalatori, saloane de înfrumusețare — și orice afacere de servicii care primește cereri pe WhatsApp, Facebook, Instagram, site sau telefon.

=== CANALE SUPORTATE ===
- WhatsApp Business — pe numărul clientului (Meta Cloud API sau Twilio) SAU pe un număr oferit de Leaply (zero bătăi de cap, îl configurăm noi).
- Facebook Messenger și Instagram DM — conectare cu un singur click („Conectează cu Facebook").
- Facebook Lead Ads — lead-urile din campanii intră automat și primesc mesaj în secunde.
- Chat pe site (widget) — se instalează cu O SINGURĂ linie de cod, fără programator.
- Telefon — agent vocal AI care răspunde la apeluri în română, natural, califică apelantul și trimite SMS automat; apelantul devine lead în inbox cu transcriptul convorbirii. Număr de telefon oferit de Leaply.
- Google Calendar — AI-ul vede disponibilitatea reală și fixează programările direct în calendar.

=== CUM FUNCȚIONEAZĂ ===
1. Lead-ul scrie sau sună pe orice canal conectat.
2. AI-ul răspunde instant, în limba clientului (română, maghiară, engleză), cu tonul și datele afacerii tale.
3. Pune 2-3 întrebări de calificare setate de tine (nevoie, urgență, zonă etc.).
4. Propune o programare (sloturi reale din Google Calendar dacă e conectat) și o confirmă.
5. Totul apare în inbox-ul Leaply: conversații, scor lead (hot/warm/cold), rezumat AI, transcript apeluri.
6. Poți prelua oricând conversația manual (takeover) — AI-ul se oprește instant.
7. Follow-up automat multi-touch (implicit la 4h / 24h / 72h) pentru lead-urile care nu răspund; SMS de confirmare cu 24h înainte de programare (anti-neprezentare).

=== FUNCȚII INCLUSE ===
Inbox mini-CRM (căutare, filtre, export CSV, asignare pe colegi, echipă cu rol agent), rezumat AI per conversație, notificări pe email și WhatsApp către proprietar la lead-uri fierbinți, import lead-uri din CSV, integrare CRM prin webhook (Zapier/Make), API public REST (documentație pe leaply.ro/developers), configurare AI din date reale: preia datele firmei de la ANAF după CUI și poate citi site-ul firmei ca să învețe serviciile.

=== PREȚURI (EUR/lună, plată cu cardul, anulezi oricând) ===
- Trial GRATUIT 14 zile: la crearea contului, fără card — acces la TOATE funcțiile + 30 de conversații, ca să testezi tot.
- Start — 59 €/lună: 300 de conversații/lună, WhatsApp + chat pe site + Google Calendar, calificare + programare, follow-up automat, 50 SMS/lună.
- Pro — 129 €/lună: 1.000 de conversații/lună, tot ce e în Start + Messenger, Instagram DM, Facebook Lead Ads, agent vocal (telefon, 200 min/lună), echipă (până la 3 colegi), acces API, 200 SMS/lună.
- Scale — 299 €/lună: 3.000 de conversații/lună, toate canalele, echipă extinsă (10 colegi), 600 minute agent vocal, 1.000 SMS/lună — pentru volume mari și mai multe locații.
O „conversație" = un schimb de mesaje cu un lead într-o lună (nu per mesaj). Fără contract pe termen lung, fără taxe de instalare. Plata prin Stripe (card), factura fiscală se emite automat (SmartBill). Un client tipic recuperează abonamentul dintr-un singur lead salvat.

=== ACTIVARE — CÂT DE REPEDE PORNEȘTI ===
1. Cont în ~2 minute pe leaply.ro/start (sau îl creăm noi pentru tine, prin chat sau telefon, și primești email cu linkul de activare).
2. Wizard-ul de configurare: datele firmei (se pot prelua de la ANAF după CUI), serviciile și prețurile, întrebările de calificare, tonul asistentului — plus un test de chat pe loc.
3. Chat-ul de site e activ imediat (copiezi o linie de cod). Facebook/Instagram se conectează cu un click. Pentru WhatsApp sau număr de telefon, ceri un număr de la Leaply din pagina Canale — de obicei activ în aceeași zi.
Nu ai nevoie de programator sau cunoștințe tehnice pentru nimic din toate astea.

=== SECURITATE & GDPR ===
Datele sunt stocate pe servere în Uniunea Europeană; token-urile și cheile sunt criptate; backup automat zilnic. Conform GDPR — pagini legale pe leaply.ro/termeni, /confidentialitate, /cookies. Operator: ARHAI SRL, CUI RO35913161, România.

=== CONTACT & LINKURI ===
Email: salut@leaply.ro · Telefon (agent AI demo — chiar produsul nostru): 0373 818 737 · Site: leaply.ro · Creare cont: leaply.ro/start · Login: leaply.ro/login · Documentație API: leaply.ro/developers

=== ÎNTREBĂRI FRECVENTE & OBIECȚII ===
„Sună robotic?" — Nu. Răspunde natural, în limba și tonul afacerii tale, cu diacritice; clienții de obicei nu-și dau seama. Și poți prelua conversația oricând.
„Cât durează implementarea?" — Contul: 2 minute. Chat pe site: imediat. Facebook/Instagram: 1 click. WhatsApp/telefon: de obicei în aceeași zi.
„Pot folosi numărul meu de WhatsApp?" — Da, prin Meta Cloud API sau Twilio. Sau primești un număr de la Leaply și nu configurezi nimic.
„Ce limbi vorbește?" — Română (implicit), maghiară și engleză — detectează automat limba clientului.
„Dacă AI-ul greșește?" — Îi setezi reguli obligatorii pe care nu le încalcă (ex: nu promite discounturi), nu inventează prețuri (folosește doar lista ta), iar tu poți prelua oricând.
„Pot anula?" — Oricând, din cont, fără penalități. Rămâi cu datele (export CSV).
„Ce se întâmplă după trial?" — Alegi un plan din cont (Setări & Plan). Dacă nu alegi, contul rămâne, dar AI-ul nu mai răspunde automat peste limita de trial.
„Aveți discount?" — Prețurile sunt cele publicate; nu oferim discounturi neanunțate. Pentru volume peste Scale, scrie-ne la salut@leaply.ro.
„E greu de configurat?" — Nu: wizard pas cu pas, date preluate de la ANAF, iar în cont ai un asistent AI care te ghidează la fiecare pas.
`.trim();

// Ghid pas-cu-pas pentru asistentul de onboarding din contul clienților (/api/assistant).
export const LEAPLY_ONBOARDING_GUIDE = `
GHID DE CONFIGURARE LEAPLY (pentru utilizatori logați în aplicație):

PAGINILE APLICAȚIEI:
- /app — Overview: KPI-uri, grafic 14 zile, checklist de activare (dispare când totul e configurat).
- /app/inbox — toate conversațiile: căutare, filtre pe status/canal, export CSV, import lead-uri CSV, asignare pe colegi.
- /app/config — Configurare AI: numele afacerii, ton, mesaj de bun venit, servicii + prețuri, întrebări de calificare, cunoștințe despre afacere (knowledge), REGULI obligatorii pentru AI, sloturi de programare.
- /app/channels — Canale & Integrări: conectare WhatsApp, Messenger, Instagram, Lead Ads, widget site, telefon, Google Calendar.
- /app/settings — Setări & Plan: planul curent + upgrade (plată card), notificări, webhook CRM, cheie API, echipă, follow-up (cadență), referral.

PAȘII RECOMANDAȚI DUPĂ CREAREA CONTULUI (în ordine):
1. Configurare AI (/app/config): completează serviciile cu prețuri reale (AI-ul NU inventează prețuri — folosește doar ce scrii aici), 2-3 întrebări de calificare, cunoștințe despre afacere (program, zonă de lucru, garanții etc.) și eventuale reguli (ex: „nu promite discounturi").
2. Instalează chat-ul pe site (/app/channels → Formular web → Detalii): copiezi o linie de cod <script src="https://leaply.ro/widget.js" data-leaply="ID_CONT" async></script> înainte de </body> sau în Google Tag Manager. Opțional data-color="#culoare".
3. Conectează Facebook/Instagram (/app/channels → Messenger → „Conectează cu Facebook — un click"): alegi pagina, Messenger și Instagram DM se activează automat.
4. WhatsApp (/app/channels → WhatsApp): recomandat „Cere număr de la Leaply" (noi configurăm tot, de obicei în aceeași zi). Avansat: Meta Cloud API (Phone Number ID + Access token) sau Twilio (Account SID + Auth token + număr).
5. Telefon / agent vocal (/app/channels → Telefon): „Cere număr de telefon de la Leaply" — primești un număr care răspunde cu agentul vocal AI; îl pui pe site/anunțuri sau redirecționezi numărul firmei către el.
6. Google Calendar (/app/channels → Google Calendar → Conectează): AI-ul propune doar sloturi libere reale și creează evenimente la programare.
7. Setări (/app/settings): verifică notificările, setează cadența de follow-up, invită colegi (echipă), și când ești gata alege planul potrivit.

PROBLEME FRECVENTE:
- „AI-ul nu răspunde pe site" — verifică dacă scriptul widget e instalat cu ID-ul corect (îl vezi în Canale → Formular web → Detalii) și dacă nu ai depășit limita planului (bara de usage din Setări).
- „Conectarea Facebook dă eroare" — reîncearcă din /app/channels; dacă persistă, scrie la salut@leaply.ro.
- „Nu primesc email-uri" — verifică spam; adresa expeditoare e salut@leaply.ro.
- „Vreau să schimb răspunsurile AI-ului" — totul se controlează din /app/config (servicii, cunoștințe, reguli, ton).
- „Cum preiau eu conversația?" — deschide conversația din inbox și apasă preluare (takeover); AI-ul se oprește pentru acea conversație.
- Resetare parolă: leaply.ro/forgot. Suport: salut@leaply.ro.
`.trim();

// Reguli pentru bot-ul de vânzări Leaply (chat + voce).
export const LEAPLY_SALES_RULES = `
Nu inventa prețuri, funcții sau termene — folosește DOAR informațiile din baza de cunoștințe; dacă nu știi, spune sincer și oferă salut@leaply.ro.
Nu oferi discounturi sau condiții speciale. Nu vorbi urât despre concurenți.
Scopul tău în fiecare conversație: (1) răspunzi clar și scurt la întrebări, (2) afli tipul afacerii și problema cu lead-urile, (3) obții numele, firma și emailul, (4) îi propui să-i creezi contul PE LOC — gratuit, fără card — ca să primească linkul de activare pe email.
Nu fi insistent: maxim o propunere de cont per 2-3 schimburi de mesaje; dacă omul refuză clar, rămâi util și politicos.
Dacă persoana are deja cont: îndrum-o spre leaply.ro/login sau leaply.ro/forgot pentru parolă, iar pentru probleme spre salut@leaply.ro.
`.trim();
