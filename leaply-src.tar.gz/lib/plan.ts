import { db } from './db';

// Matricea de funcții per plan — SINGURUL loc unde se decide cine are voie la ce.
// Trial = acces la tot (ca să testeze produsul complet), dar limitat în timp (14 zile)
// și la 30 conversații/lună (lib/usage.ts). Numerele gestionate de Leaply (WhatsApp/voce)
// cer plan plătit — costă bani reali.

export type PlanName = 'Trial' | 'Start' | 'Pro' | 'Scale';
export const PLAN_ORDER: PlanName[] = ['Trial', 'Start', 'Pro', 'Scale'];
export const TRIAL_DAYS = 14;

type PlanSpec = {
  channels: string[];        // tipuri de canale conectabile
  api: boolean;              // cheie API v1
  teamAgents: number;        // colegi (rol agent), pe lângă owner
  smsMonthly: number;        // SMS-uri trimise de platformă / lună
  voiceMinutesMonthly: number; // minute agent vocal / lună
  requestNumber: ('whatsapp' | 'voice')[]; // numere gestionate de Leaply
};

const ALL_CHANNELS = ['webform', 'whatsapp', 'calendar', 'messenger', 'instagram', 'meta_lead_ads', 'voice'];

export const PLANS: Record<PlanName, PlanSpec> = {
  Trial: { channels: ALL_CHANNELS, api: true, teamAgents: 1, smsMonthly: 10, voiceMinutesMonthly: 15, requestNumber: [] },
  Start: { channels: ['webform', 'whatsapp', 'calendar'], api: false, teamAgents: 0, smsMonthly: 50, voiceMinutesMonthly: 0, requestNumber: ['whatsapp'] },
  Pro: { channels: ALL_CHANNELS, api: true, teamAgents: 3, smsMonthly: 200, voiceMinutesMonthly: 200, requestNumber: ['whatsapp', 'voice'] },
  Scale: { channels: ALL_CHANNELS, api: true, teamAgents: 10, smsMonthly: 1000, voiceMinutesMonthly: 600, requestNumber: ['whatsapp', 'voice'] },
};

export const planSpec = (plan: string): PlanSpec => PLANS[(plan as PlanName)] ?? PLANS.Trial;

export function channelAllowed(plan: string, type: string): boolean {
  return planSpec(plan).channels.includes(type);
}

/** Cel mai mic plan PLĂTIT care include canalul/funcția — pentru mesajele de upgrade. */
export function requiredPlanForChannel(type: string): PlanName {
  for (const p of ['Start', 'Pro', 'Scale'] as PlanName[]) if (PLANS[p].channels.includes(type)) return p;
  return 'Pro';
}
export function requiredPlanFor(check: (s: PlanSpec) => boolean): PlanName {
  for (const p of ['Start', 'Pro', 'Scale'] as PlanName[]) if (check(PLANS[p])) return p;
  return 'Scale';
}

export const upgradeMsg = (what: string, plan: PlanName) =>
  `${what} e disponibil de la planul ${plan}. Treci pe ${plan} din Setări & Plan (/app/settings) și se activează instant.`;

/* ---------- Trial: limită de timp ---------- */
export function trialDaysLeft(accId: string): number | null {
  const row: any = db().prepare('SELECT plan, created_at FROM accounts WHERE id=?').get(accId);
  if (!row || row.plan !== 'Trial') return null;
  const age = (Date.now() - new Date(row.created_at).getTime()) / 86400_000;
  return Math.max(0, Math.ceil(TRIAL_DAYS - age));
}
export function trialExpired(accId: string): boolean {
  const left = trialDaysLeft(accId);
  return left !== null && left <= 0;
}

/* ---------- Contoare lunare (SMS, minute voce) ---------- */
const monthKey = () => new Date().toISOString().slice(0, 7);

export function counterThisMonth(accId: string, kind: string): number {
  try {
    const row: any = db().prepare('SELECT n FROM usage_counters WHERE account_id=? AND month=? AND kind=?').get(accId, monthKey(), kind);
    return row?.n || 0;
  } catch { return 0; }
}
export function bumpCounter(accId: string, kind: string, n = 1) {
  try {
    db().prepare(`INSERT INTO usage_counters (account_id, month, kind, n) VALUES (?,?,?,?)
      ON CONFLICT(account_id, month, kind) DO UPDATE SET n = n + excluded.n`).run(accId, monthKey(), kind, n);
  } catch { /* best-effort */ }
}

/** SMS cu respectarea plafonului lunar: true = are voie (și contorizează). */
export function allowSms(accId: string, plan: string): boolean {
  const cap = planSpec(plan).smsMonthly;
  if (counterThisMonth(accId, 'sms') >= cap) return false;
  bumpCounter(accId, 'sms', 1);
  return true;
}

/** Agent vocal: are voie să preia apelul? (verificare la începutul apelului) */
export function voiceAllowed(accId: string, plan: string): boolean {
  const spec = planSpec(plan);
  if (!spec.channels.includes('voice')) return false;
  return counterThisMonth(accId, 'voice_min') < spec.voiceMinutesMonthly;
}
