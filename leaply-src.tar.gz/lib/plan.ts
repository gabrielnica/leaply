import { db } from './db';

// Matricea de funcții per plan — SINGURUL loc unde se decide cine are voie la ce.
// Trial = acces la tot (ca să testeze produsul complet), dar limitat în timp (14 zile)
// și la 30 conversații/lună (lib/usage.ts). Numerele gestionate de Leaply (WhatsApp/voce)
// cer plan plătit — costă bani reali.

export type PlanName = 'Trial' | 'Start' | 'Pro' | 'Scale';
export const PLAN_ORDER: PlanName[] = ['Trial', 'Start', 'Pro', 'Scale'];
export const TRIAL_DAYS = 14;

// Identificatorii interni rămân Start/Pro/Scale (DB, Stripe, admin) — pentru clienți
// pachetele se numesc SOCIAL / COMPLET / TOTAL (repachetare 2026-07-08):
//   Social (59€):  Facebook Messenger + Instagram + Lead Ads + chat pe site + Calendar
//   Complet (129€): tot din Social + WhatsApp (nr. propriu sau de la Leaply) + API + echipă
//   Total (299€):  tot din Complet + agent vocal AI cu număr dedicat + echipă extinsă
export const PLAN_LABELS: Record<PlanName, string> = { Trial: 'Trial', Start: 'Social', Pro: 'Complet', Scale: 'Total' };
export const planLabel = (plan: string) => PLAN_LABELS[(plan as PlanName)] ?? plan;

type PlanSpec = {
  channels: string[];        // tipuri de canale conectabile
  api: boolean;              // cheie API v1
  teamAgents: number;        // colegi (rol agent), pe lângă owner
  smsMonthly: number;        // SMS-uri trimise de platformă / lună
  voiceMinutesMonthly: number; // minute agent vocal / lună
  requestNumber: ('whatsapp' | 'voice')[]; // numere gestionate de Leaply
};

const ALL_CHANNELS = ['webform', 'whatsapp', 'calendar', 'messenger', 'instagram', 'meta_lead_ads', 'voice'];
const SOCIAL_CHANNELS = ['webform', 'messenger', 'instagram', 'meta_lead_ads', 'calendar'];

export const PLANS: Record<PlanName, PlanSpec> = {
  Trial: { channels: ALL_CHANNELS, api: true, teamAgents: 1, smsMonthly: 10, voiceMinutesMonthly: 15, requestNumber: [] },
  // Social — canalele Meta gratuite + chat web: cost ~0 pt noi, activare ușoară
  Start: { channels: SOCIAL_CHANNELS, api: false, teamAgents: 0, smsMonthly: 25, voiceMinutesMonthly: 0, requestNumber: [] },
  // Complet — + WhatsApp + API/CRM + echipă
  Pro: { channels: [...SOCIAL_CHANNELS, 'whatsapp'], api: true, teamAgents: 3, smsMonthly: 100, voiceMinutesMonthly: 0, requestNumber: ['whatsapp'] },
  // Total — + agent vocal cu număr dedicat
  Scale: { channels: ALL_CHANNELS, api: true, teamAgents: 10, smsMonthly: 400, voiceMinutesMonthly: 500, requestNumber: ['whatsapp', 'voice'] },
};

/* ---------- Add-on-uri per cont (setate din admin; stocate în integrations.addons) ----------
   { conv?: n, sms?: n, voice_min?: n, numbers?: n } — se ADUNĂ la limitele planului. */
export function accountAddons(accId: string): { conv: number; sms: number; voice_min: number; numbers: number } {
  try {
    const row: any = db().prepare('SELECT integrations FROM accounts WHERE id=?').get(accId);
    const a = JSON.parse(row?.integrations || '{}')?.addons || {};
    return { conv: Number(a.conv) || 0, sms: Number(a.sms) || 0, voice_min: Number(a.voice_min) || 0, numbers: Number(a.numbers) || 0 };
  } catch { return { conv: 0, sms: 0, voice_min: 0, numbers: 0 }; }
}

export const planSpec = (plan: string): PlanSpec => PLANS[(plan as PlanName)] ?? PLANS.Trial;

/** Limite EFECTIVE = plan + add-on-uri. Folosește astea la enforcement. */
export function effectiveLimits(accId: string, plan: string) {
  const s = planSpec(plan);
  const a = accountAddons(accId);
  return { sms: s.smsMonthly + a.sms, voiceMin: s.voiceMinutesMonthly + a.voice_min, convExtra: a.conv };
}

export function channelAllowed(plan: string, type: string): boolean {
  return planSpec(plan).channels.includes(type);
}

/** Cel mai mic plan PLĂTIT care include canalul/funcția — pentru mesajele de upgrade. */
export function requiredPlanForChannel(type: string): PlanName {
  for (const p of ['Start', 'Pro', 'Scale'] as PlanName[]) if (PLANS[p].channels.includes(type)) return p;
  return 'Pro';
}
export function requiredPlanFor(check: (s: PlanSpec) => boolean): PlanName {
  for (const p of ['Start', 'Pro', 'Scale'] as PlanName[]) if (check(PLANS[p])) return p;
  return 'Scale';
}

export const upgradeMsg = (what: string, plan: PlanName) =>
  `${what} e disponibil de la pachetul ${planLabel(plan)}. Treci pe ${planLabel(plan)} din Setări & Plan (/app/settings) și se activează instant.`;

/* ---------- Trial: limită de timp ---------- */
export function trialDaysLeft(accId: string): number | null {
  const row: any = db().prepare('SELECT plan, created_at, trial_extra FROM accounts WHERE id=?').get(accId);
  if (!row || row.plan !== 'Trial') return null;
  const age = (Date.now() - new Date(row.created_at).getTime()) / 86400_000;
  return Math.max(0, Math.ceil(TRIAL_DAYS + (row.trial_extra || 0) - age));
}
export function trialExpired(accId: string): boolean {
  const left = trialDaysLeft(accId);
  return left !== null && left <= 0;
}

/** Data (ISO) la care expiră trialul, sau null dacă nu e cont pe trial. */
export function trialEndsAt(accId: string): string | null {
  const row: any = db().prepare('SELECT plan, created_at, trial_extra FROM accounts WHERE id=?').get(accId);
  if (!row || row.plan !== 'Trial') return null;
  return new Date(new Date(row.created_at).getTime() + (TRIAL_DAYS + (row.trial_extra || 0)) * 86400_000).toISOString();
}

/* ---------- Contoare lunare (SMS, minute voce) ---------- */
const monthKey = () => new Date().toISOString().slice(0, 7);

export function counterThisMonth(accId: string, kind: string): number {
  try {
    const row: any = db().prepare('SELECT n FROM usage_counters WHERE account_id=? AND month=? AND kind=?').get(accId, monthKey(), kind);
    return row?.n || 0;
  } catch { return 0; }
}
export function bumpCounter(accId: string, kind: string, n = 1) {
  try {
    db().prepare(`INSERT INTO usage_counters (account_id, month, kind, n) VALUES (?,?,?,?)
      ON CONFLICT(account_id, month, kind) DO UPDATE SET n = n + excluded.n`).run(accId, monthKey(), kind, n);
  } catch { /* best-effort */ }
}

/** SMS cu respectarea plafonului lunar EFECTIV (plan + add-on-uri): true = are voie (și contorizează). */
export function allowSms(accId: string, plan: string): boolean {
  const cap = effectiveLimits(accId, plan).sms;
  if (counterThisMonth(accId, 'sms') >= cap) return false;
  bumpCounter(accId, 'sms', 1);
  return true;
}

/** Agent vocal: are voie să preia apelul? (limita efectivă = plan + add-on-uri) */
export function voiceAllowed(accId: string, plan: string): boolean {
  const spec = planSpec(plan);
  if (!spec.channels.includes('voice')) return false;
  return counterThisMonth(accId, 'voice_min') < effectiveLimits(accId, plan).voiceMin;
}
