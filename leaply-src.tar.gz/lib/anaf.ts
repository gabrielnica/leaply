// Preluare date firmă de la ANAF după CUI (serviciul public de TVA).
// Fără cheie API — endpoint public, rate-limitat; tratăm elegant erorile.
export type AnafCompany = {
  cui: string; name: string; regCom: string; address: string;
  city: string; county: string; vatPayer: boolean; active: boolean;
};

export async function lookupCui(rawCui: string): Promise<{ ok: boolean; company?: AnafCompany; error?: string }> {
  const cui = String(rawCui || '').toUpperCase().replace(/^RO/, '').replace(/\D/g, '');
  if (!cui || cui.length < 2 || cui.length > 10) return { ok: false, error: 'CUI invalid.' };
  const today = new Date().toISOString().slice(0, 10);
  try {
    const r = await fetch('https://webservicesp.anaf.ro/api/PlatitorTvaRest/v9/tva', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify([{ cui: Number(cui), data: today }]),
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) return { ok: false, error: `ANAF a răspuns cu ${r.status}. Încearcă din nou.` };
    const j: any = await r.json();
    const f = j?.found?.[0];
    if (!f) return { ok: false, error: 'CUI-ul nu a fost găsit la ANAF.' };
    const g = f.date_generale || {};
    const vat = f.inregistrare_scop_Tva?.scpTVA === true;
    const addr = f.adresa_sediu_social || {};
    const city = addr.sdenumire_Localitate || '';
    const county = addr.sdenumire_Judet || '';
    return {
      ok: true,
      company: {
        cui: (vat ? 'RO' : '') + cui,
        name: g.denumire || '',
        regCom: g.nrRegCom || '',
        address: g.adresa || [addr.sdenumire_Strada, addr.snumar_Strada].filter(Boolean).join(' '),
        city, county,
        vatPayer: vat,
        active: !(f.stare_inactiv?.statusInactivi === true),
      },
    };
  } catch (e) {
    console.error('[anaf]', String(e).slice(0, 150));
    return { ok: false, error: 'ANAF nu a răspuns (serviciul e uneori lent). Reîncearcă.' };
  }
}
