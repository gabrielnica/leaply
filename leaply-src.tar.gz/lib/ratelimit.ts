// Rate limiting simplu în memorie, per cheie (IP / API key / sesiune).
const buckets = new Map<string, { n: number; t: number }>();
export function rateLimited(key: string, max = 120, windowMs = 60_000): boolean {
  const b = buckets.get(key) || { n: 0, t: Date.now() };
  if (Date.now() - b.t > windowMs) { b.n = 0; b.t = Date.now(); }
  b.n++;
  buckets.set(key, b);
  if (buckets.size > 20_000) buckets.clear(); // protecție memorie
  return b.n > max;
}
