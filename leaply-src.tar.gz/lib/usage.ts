import { db } from './db';
import { getIntegrations, setIntegration } from './integrations';

// Limite de conversații pe lună, per plan. Enforcement soft: peste limită,
// lead-ul se salvează în inbox dar asistentul nu mai răspunde automat.
export const PLAN_LIMITS: Record<string, number> = { Trial: 30, Start: 300, Pro: 1000, Scale: 3000 };

export const limitFor = (plan: string) => PLAN_LIMITS[plan] ?? PLAN_LIMITS.Trial;

const monthStart = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1).toISOString(); };
export const monthKey = () => new Date().toISOString().slice(0, 7);

export function usageThisMonth(accId: string): number {
  const row: any = db().prepare('SELECT COUNT(*) c FROM conversations WHERE account_id=? AND created_at >= ?').get(accId, monthStart());
  return row?.c || 0;
}

export function overLimit(accId: string, plan: string): boolean {
  return usageThisMonth(accId) >= limitFor(plan);
}

/** true doar prima dată pe lună (ca să nu spamăm owner-ul cu notificări de limită). */
export function shouldNotifyLimit(accId: string): boolean {
  const i = getIntegrations(accId);
  if (i.limitNotified === monthKey()) return false;
  setIntegration(accId, 'limitNotified', monthKey());
  return true;
}
