import { cfg } from './settings';

// Transcriere audio (mesaje vocale Twilio) cu OpenAI Whisper. Best-effort — nu aruncă.
export async function transcribeRecording(url: string): Promise<string | null> {
  try {
    const key = cfg('OPENAI_API_KEY');
    if (!key) return null;
    // Înregistrările Twilio cer basic auth cu contul master
    const sid = cfg('TWILIO_MASTER_SID'), tok = cfg('TWILIO_MASTER_TOKEN');
    const headers: Record<string, string> = {};
    if (sid && tok) headers.Authorization = 'Basic ' + Buffer.from(`${sid}:${tok}`).toString('base64');
    const audio = await fetch(url + '.mp3', { headers, signal: AbortSignal.timeout(15000) });
    if (!audio.ok) { console.error('[transcribe] download', audio.status); return null; }
    const buf = Buffer.from(await audio.arrayBuffer());
    if (buf.length < 1000 || buf.length > 15_000_000) return null;

    const form = new FormData();
    form.append('file', new Blob([buf], { type: 'audio/mpeg' }), 'voicemail.mp3');
    form.append('model', 'whisper-1');
    form.append('language', 'ro');
    const r = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST', headers: { Authorization: `Bearer ${key}` }, body: form,
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok) { console.error('[transcribe] whisper', r.status, (await r.text()).slice(0, 150)); return null; }
    const j: any = await r.json();
    return (j.text || '').trim() || null;
  } catch (e) { console.error('[transcribe]', String(e).slice(0, 150)); return null; }
}
