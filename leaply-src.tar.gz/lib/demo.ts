import crypto from 'crypto';
import { DEMO_CONFIG } from './db';
import { getAccount, updateAccountConfig } from './store';
import { getSessionUser, SessionUser } from './auth';
import { llmReply, llmActive } from './llm';

export type DemoMode = 'public' | 'account';

/** Configul „efectiv" pentru demo.
 *  - mode 'public'  → mereu contul demo public (DentArt), indiferent de sesiune.
 *  - mode 'account' → contul utilizatorului logat, cu fallback-uri sigure pe câmpurile esențiale. */
export function effectiveDemoConfig(mode: DemoMode = 'account'): { config: any; personalized: boolean; accountId: string | null } {
  if (mode === 'account') {
    let user: SessionUser | null = null;
    try { user = getSessionUser(); } catch {}
    if (user) {
      try {
        const acc = getAccount(user.account_id);
        if (acc?.config && typeof acc.config === 'object') {
          const config: any = { ...acc.config };
          if (!config.businessName) config.businessName = acc.name || 'firma ta';
          if (!config.tone) config.tone = 'profesional';
          if (!config.welcome) config.welcome = `Bună ziua! Ați contactat ${config.businessName} 😊 Cu ce vă putem ajuta?`;
          if (!Array.isArray(config.services)) config.services = [];
          if (!Array.isArray(config.qualificationQuestions)) config.qualificationQuestions = [];
          return { config, personalized: true, accountId: user.account_id };
        }
      } catch {}
    }
  }
  return { config: DEMO_CONFIG, personalized: false, accountId: null };
}

/* ---------- întrebări de start ---------- */

export const PUBLIC_STARTERS = [
  'Bună, cât costă un implant dentar?',
  'Aș vrea o programare la igienizare.',
  'Mă doare o măsea — mă puteți primi urgent?',
];

function shortService(name: string): string {
  const base = String(name).split('(')[0].trim();
  const cut = base.length > 45 ? base.slice(0, 45).replace(/\s+\S*$/, '') + '…' : base;
  return cut.charAt(0).toLowerCase() + cut.slice(1);
}

/** Fallback determinist: întrebări derivate din lista de servicii. */
export function heuristicStarters(config: any): string[] {
  const out: string[] = [];
  const svcs = (config.services || []).filter((s: any) => s?.name);
  if (svcs[0]) out.push(`Bună ziua! Cât costă ${shortService(svcs[0].name)}?`);
  if (svcs[1]) out.push(`Mă interesează ${shortService(svcs[1].name)} — îmi puteți da detalii?`);
  out.push('Aș vrea o programare cât mai repede. Când aveți liber?');
  if (out.length < 3) out.push('Care este programul dumneavoastră?');
  return out.slice(0, 3);
}

function startersHash(config: any, docsSample: string): string {
  const src = JSON.stringify({ s: config.services || [], k: (config.knowledge || '').slice(0, 2000), v: config.vertical || '', d: docsSample.slice(0, 500) });
  return crypto.createHash('sha1').update(src).digest('hex').slice(0, 12);
}

/** Întrebări de start realiste, generate de LLM din datele reale ale contului
 *  (servicii + cunoștințe + documente). Cache în config (_demoStarters) pe hash-ul datelor. */
export async function accountStarters(accountId: string, config: any, docsSample: string): Promise<string[]> {
  const hash = startersHash(config, docsSample);
  const cached = config._demoStarters;
  if (cached && cached.hash === hash && Array.isArray(cached.list) && cached.list.length >= 2) return cached.list;

  let list: string[] | null = null;
  if (llmActive()) {
    const svc = (config.services || []).slice(0, 10).map((s: any) => `- ${s.name}: ${s.price}`).join('\n');
    const sys = `Generezi întrebări pe care un CLIENT REAL le-ar trimite pe WhatsApp firmei "${config.businessName}"${config.vertical ? ` (domeniu: ${config.vertical})` : ''}. Date reale despre firmă:\n${svc ? 'Servicii:\n' + svc + '\n' : ''}${config.knowledge ? 'Despre firmă: ' + String(config.knowledge).slice(0, 900) + '\n' : ''}${docsSample ? 'Din documentele firmei: ' + docsSample.slice(0, 600) + '\n' : ''}\nScrie EXACT 3 întrebări scurte (max 12 cuvinte), naturale, în română cu diacritice, fiecare pe un rând, fără numerotare, fără ghilimele. Prima despre prețul unui serviciu concret al firmei, a doua despre alt serviciu sau un detaliu specific firmei, a treia despre programare/disponibilitate.`;
    const raw = await llmReply(sys, [{ role: 'user', content: 'Generează cele 3 întrebări.' }], { maxTokens: 160, temperature: 0.6 });
    if (raw) {
      list = raw.split('\n').map(l => l.replace(/^[\s\d\.\-•"„”]+|["„”]+$/g, '').trim()).filter(l => l.length > 8 && l.length < 120).slice(0, 3);
      if (list.length < 2) list = null;
    }
  }
  if (!list) list = heuristicStarters(config);

  // cache — nu regenerăm la fiecare deschidere
  try {
    const acc = getAccount(accountId);
    if (acc?.config) updateAccountConfig(accountId, { ...acc.config, _demoStarters: { hash, list } });
  } catch {}
  return list;
}
