import { DEMO_CONFIG } from './db';
import { getAccount } from './store';
import { getSessionUser, SessionUser } from './auth';

// Configul „efectiv" pentru demo: contul utilizatorului logat (cu fallback-uri
// sigure pe câmpurile esențiale), altfel contul demo public (DentArt).
export function effectiveDemoConfig(): { config: any; personalized: boolean } {
  let user: SessionUser | null = null;
  try { user = getSessionUser(); } catch {}
  if (user) {
    try {
      const acc = getAccount(user.account_id);
      if (acc?.config && typeof acc.config === 'object') {
        const config: any = { ...acc.config };
        if (!config.businessName) config.businessName = acc.name || 'firma ta';
        if (!config.tone) config.tone = 'profesional';
        if (!config.welcome) config.welcome = `Bună ziua! Ați contactat ${config.businessName} 😊 Cu ce vă putem ajuta?`;
        if (!Array.isArray(config.services)) config.services = [];
        if (!Array.isArray(config.qualificationQuestions)) config.qualificationQuestions = [];
        return { config, personalized: true };
      }
    } catch {}
  }
  return { config: DEMO_CONFIG, personalized: false };
}

// Nume de serviciu scurt și natural pentru o întrebare de client.
function shortService(name: string): string {
  const base = String(name).split('(')[0].trim();
  const cut = base.length > 45 ? base.slice(0, 45).replace(/\s+\S*$/, '') + '…' : base;
  return cut.charAt(0).toLowerCase() + cut.slice(1);
}

// Întrebări de start pentru pagina de demo, derivate din serviciile contului.
export function demoStarters(config: any, personalized: boolean): string[] {
  if (!personalized) {
    return ['Bună, cât costă un implant dentar?', 'Aș vrea o programare la igienizare.', 'Mă doare o măsea — mă puteți primi urgent?'];
  }
  const out: string[] = [];
  const svcs = (config.services || []).filter((s: any) => s?.name);
  if (svcs[0]) out.push(`Bună ziua! Cât costă ${shortService(svcs[0].name)}?`);
  if (svcs[1]) out.push(`Mă interesează ${shortService(svcs[1].name)} — îmi puteți da detalii?`);
  out.push('Aș vrea o programare cât mai repede. Când aveți liber?');
  if (out.length < 3) out.push('Care este programul dumneavoastră?');
  return out.slice(0, 3);
}
