import { db } from './db';

// Bucla de calitate: răspunsurile apreciate de owner (👍) devin exemple few-shot
// în promptul asistentului — stilul se aliniază la ce vrea patronul, fără reguli scrise.

export function fewShotExamples(accId: string, max = 3): string | null {
  try {
    const rows: any[] = db().prepare(`
      SELECT m.body FROM messages m
      JOIN conversations c ON c.id = m.conversation_id
      WHERE c.account_id = ? AND m.sender = 'ai' AND m.rating = 1
      ORDER BY m.created_at DESC LIMIT ?`).all(accId, max);
    if (!rows.length) return null;
    return rows.map((r, i) => `${i + 1}) „${String(r.body).slice(0, 220)}"`).join(' ');
  } catch { return null; }
}
