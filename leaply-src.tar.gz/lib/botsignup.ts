import crypto from 'crypto';
import { db, uid } from './db';
import { createAccountWithOwner, createResetToken, emailOk } from './auth';
import { sendMail } from './mail';
import { sendSms } from './sms';
import { appUrl } from './settings';
import { audit } from './audit';

// Creare cont inițiată de bot (chatbot-ul de vânzări sau agentul vocal).
// Creează contul cu parolă aleatorie + trimite email cu link de setare parolă (72h).
export type BotSignupResult =
  | { ok: true; created: true; email: string }
  | { ok: true; exists: true; email: string }
  | { ok: false; error: string };

export async function createAccountFromBot(p: { name?: string; email: string; company?: string; phone?: string; source: string }): Promise<BotSignupResult> {
  const email = String(p.email || '').trim().toLowerCase();
  if (!emailOk(email)) return { ok: false, error: 'email invalid' };
  const d = db();

  const existing: any = d.prepare('SELECT id FROM users WHERE email=?').get(email);
  if (existing) return { ok: true, exists: true, email };

  const name = String(p.name || '').slice(0, 120).trim() || email.split('@')[0];
  const company = String(p.company || '').slice(0, 120).trim();
  const phone = String(p.phone || '').replace(/[^\d+]/g, '').slice(0, 20);

  const res = createAccountWithOwner({ name, email, password: crypto.randomBytes(24).toString('hex'), business: company || undefined });
  if ('error' in res) return { ok: false, error: res.error };

  // telefonul proprietarului intră în config (notificări WhatsApp + context)
  if (phone) {
    try {
      const row: any = d.prepare('SELECT config FROM accounts WHERE id=?').get(res.accountId);
      const config = { ...(JSON.parse(row?.config || '{}')), ownerPhone: phone };
      d.prepare('UPDATE accounts SET config=? WHERE id=?').run(JSON.stringify(config), res.accountId);
    } catch { /* best-effort */ }
  }

  // vizibil în admin, ca orice cerere de demo
  try {
    d.prepare('INSERT INTO demo_requests (id,name,contact,business,vertical,status,account_id,created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(uid('dr_'), name, phone ? `${email} / ${phone}` : email, company, p.source, 'cont creat de bot', res.accountId, new Date().toISOString());
  } catch { /* best-effort */ }

  const token = createResetToken(res.userId, 72);
  const url = `${appUrl()}/reset?token=${token}`;
  await sendMail(email, 'Contul tău Leaply e gata — setează-ți parola',
    `<p>Salut, ${name}!</p>
     <p>Contul tău Leaply${company ? ` pentru <b>${company}</b>` : ''} a fost creat și te așteaptă. Mai ai un singur pas:</p>
     <p style="margin:18px 0"><a href="${url}" style="background:#FF4D1F;color:#fff;padding:12px 22px;border-radius:8px;text-decoration:none;font-weight:600">Setează-ți parola și intră în cont</a></p>
     <p>Linkul e valabil 72 de ore. Te loghezi apoi oricând pe <a href="${appUrl()}/login">${appUrl().replace('https://', '')}/login</a> cu emailul <b>${email}</b>.</p>
     <p>Ce urmează în cont (5 minute, fără cunoștințe tehnice):</p>
     <ol><li>Completezi serviciile și prețurile tale (Configurare AI)</li>
     <li>Instalezi chat-ul pe site cu o singură linie de cod (Canale)</li>
     <li>Conectezi Facebook/Instagram cu un click sau ceri un număr WhatsApp/telefon de la Leaply</li></ol>
     <p>Trialul e gratuit, fără card. Dacă te blochezi oriunde, răspunde la acest email sau scrie-ne la salut@leaply.ro.</p>
     <p>— Echipa Leaply</p>`);

  if (phone) {
    sendSms(phone, `Leaply: contul tău e creat! Ți-am trimis pe ${email} linkul de activare (valabil 72h). Setează parola și ești gata de start.`).catch(() => {});
  }

  try { audit(`bot:${p.source}`, 'account.create', res.accountId, { email, company, phone: phone || undefined }); } catch { /* best-effort */ }
  return { ok: true, created: true, email };
}
