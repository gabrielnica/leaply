import { db, uid } from './db';

// Credentiale per canal (channels.credentials, JSON):
//  whatsapp (provider 'meta'):   { provider:'meta', phone_number_id, access_token, app_secret? }
//  whatsapp (provider 'twilio'): { provider:'twilio', account_sid, auth_token, from_number }  // from_number: '+40...'
//  messenger/instagram:          { provider:'meta', page_id, page_access_token }

export function getChannel(accId: string, type: string): any | null {
  const c: any = db().prepare('SELECT * FROM channels WHERE account_id=? AND type=?').get(accId, type);
  if (!c) return null;
  try { c.creds = JSON.parse(c.credentials || 'null'); } catch { c.creds = null; }
  return c;
}

export function setChannelCreds(accId: string, type: string, creds: any | null, label?: string) {
  const d = db();
  const existing: any = d.prepare('SELECT id FROM channels WHERE account_id=? AND type=?').get(accId, type);
  const status = creds ? 'connected' : 'pending';
  if (existing) {
    d.prepare('UPDATE channels SET credentials=?, status=?, label=COALESCE(?,label) WHERE id=?')
      .run(creds ? JSON.stringify(creds) : null, status, label || null, existing.id);
  } else {
    d.prepare('INSERT INTO channels (id,account_id,type,status,label,credentials) VALUES (?,?,?,?,?,?)')
      .run(uid('ch_'), accId, type, status, label || type, creds ? JSON.stringify(creds) : null);
  }
}

/** Rutare multi-tenant: găsește contul după identificatorii din payload-ul inbound. */
export function resolveAccount(channel: string, payload: any): string {
  try {
    const rows: any[] = db().prepare("SELECT account_id, credentials FROM channels WHERE credentials IS NOT NULL").all();
    let needle = '';
    if (channel === 'whatsapp') needle = payload?.entry?.[0]?.changes?.[0]?.value?.metadata?.phone_number_id || '';
    if (channel === 'whatsapp_twilio') needle = String(payload?.To || '').replace('whatsapp:', '');
    if (channel === 'messenger' || channel === 'instagram') needle = String(payload?.entry?.[0]?.id || '');
    if (needle) {
      for (const r of rows) {
        try {
          const c = JSON.parse(r.credentials);
          if (c.phone_number_id === needle || c.page_id === needle || c.from_number === needle) return r.account_id;
        } catch {}
      }
    }
  } catch {}
  return 'acc_demo';
}

type SendResult = { sent: boolean; provider?: string; error?: string };

async function sendWhatsAppMeta(creds: any, to: string, text: string): Promise<SendResult> {
  const r = await fetch(`https://graph.facebook.com/v19.0/${creds.phone_number_id}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${creds.access_token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', to: to.replace(/[^\d+]/g, ''), type: 'text', text: { body: text } }),
    signal: AbortSignal.timeout(10000),
  });
  if (!r.ok) return { sent: false, provider: 'meta', error: `${r.status} ${(await r.text()).slice(0, 200)}` };
  return { sent: true, provider: 'meta' };
}

async function sendWhatsAppTwilio(creds: any, to: string, text: string): Promise<SendResult> {
  const auth = Buffer.from(`${creds.account_sid}:${creds.auth_token}`).toString('base64');
  const form = new URLSearchParams({
    From: `whatsapp:${creds.from_number}`,
    To: `whatsapp:${to.replace(/[^\d+]/g, '')}`,
    Body: text,
  });
  const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${creds.account_sid}/Messages.json`, {
    method: 'POST',
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
    signal: AbortSignal.timeout(10000),
  });
  if (!r.ok) return { sent: false, provider: 'twilio', error: `${r.status} ${(await r.text()).slice(0, 200)}` };
  return { sent: true, provider: 'twilio' };
}

async function sendMessengerLike(creds: any, psid: string, text: string): Promise<SendResult> {
  const r = await fetch(`https://graph.facebook.com/v19.0/me/messages?access_token=${encodeURIComponent(creds.page_access_token)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ recipient: { id: psid }, messaging_type: 'RESPONSE', message: { text } }),
    signal: AbortSignal.timeout(10000),
  });
  if (!r.ok) return { sent: false, provider: 'meta', error: `${r.status} ${(await r.text()).slice(0, 200)}` };
  return { sent: true, provider: 'meta' };
}

/** Trimite răspunsul pe canalul de proveniență. Nu aruncă niciodată — loghează și întoarce statusul. */
export async function sendReply(accId: string, channelType: string, replyTo: string, text: string): Promise<SendResult> {
  try {
    if (!replyTo) return { sent: false, error: 'fără destinatar' };
    const ch = getChannel(accId, channelType === 'instagram' ? 'instagram' : channelType === 'messenger' ? 'messenger' : 'whatsapp');
    if (!ch?.creds) return { sent: false, error: `canal ${channelType} neconectat (fără credențiale)` };
    let res: SendResult;
    if (channelType === 'whatsapp') {
      res = ch.creds.provider === 'twilio'
        ? await sendWhatsAppTwilio(ch.creds, replyTo, text)
        : await sendWhatsAppMeta(ch.creds, replyTo, text);
    } else {
      res = await sendMessengerLike(ch.creds, replyTo, text);
    }
    if (!res.sent) console.error(`[leaply send ${channelType}]`, accId, res.error);
    return res;
  } catch (e) {
    console.error(`[leaply send ${channelType}]`, accId, String(e).slice(0, 200));
    return { sent: false, error: String(e).slice(0, 200) };
  }
}
