import { getIntegrations, setIntegration } from './integrations';
import { cfg, appUrl } from './settings';

// Google Calendar per cont. Necesită env: GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, APP_URL.
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
export const gcalConfigured = () => Boolean(cfg('GOOGLE_CLIENT_ID') && cfg('GOOGLE_CLIENT_SECRET'));
export const redirectUri = () => `${appUrl()}/api/integrations/google/callback`;

export function authUrl(state: string): string {
  const p = new URLSearchParams({
    client_id: cfg('GOOGLE_CLIENT_ID'),
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: 'https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.freebusy openid email',
    access_type: 'offline',
    prompt: 'consent',
    state,
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${p}`;
}

export async function exchangeCode(code: string): Promise<{ refresh_token?: string; access_token?: string; email?: string } | null> {
  const r = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code, client_id: cfg('GOOGLE_CLIENT_ID'), client_secret: cfg('GOOGLE_CLIENT_SECRET'),
      redirect_uri: redirectUri(), grant_type: 'authorization_code',
    }),
  });
  if (!r.ok) { console.error('[gcal] exchange:', (await r.text()).slice(0, 200)); return null; }
  const tok = await r.json();
  let email = '';
  try {
    const ui = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', { headers: { Authorization: `Bearer ${tok.access_token}` } });
    if (ui.ok) email = (await ui.json()).email || '';
  } catch {}
  return { refresh_token: tok.refresh_token, access_token: tok.access_token, email };
}

async function accessToken(accId: string): Promise<string | null> {
  const g = getIntegrations(accId).google;
  if (!g?.refresh_token) return null;
  const r = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      refresh_token: g.refresh_token, client_id: cfg('GOOGLE_CLIENT_ID'),
      client_secret: cfg('GOOGLE_CLIENT_SECRET'), grant_type: 'refresh_token',
    }),
  });
  if (!r.ok) {
    console.error('[gcal] refresh esuat pentru', accId);
    if (r.status === 400) setIntegration(accId, 'google', null); // token revocat
    return null;
  }
  return (await r.json()).access_token || null;
}

export const gcalConnected = (accId: string) => Boolean(getIntegrations(accId).google?.refresh_token);

const RO_DAYS = ['duminică', 'luni', 'marți', 'miercuri', 'joi', 'vineri', 'sâmbătă'];
const fmtSlot = (d: Date) => `${RO_DAYS[d.getDay()]} la ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

/** Următoarele 2 sloturi libere din calendarul contului.
 *  Orele vin din config.bookingSlots („10:00", „16:30"…) — cele setate de client în wizard/config;
 *  zilele din config.workDays (ex. [1,2,3,4,5,6] = luni-sâmbătă). Fallback: 10:00 & 16:00, luni-vineri. */
export async function getFreeSlots(accId: string): Promise<{ label: string; iso: string }[] | null> {
  const tok = await accessToken(accId);
  if (!tok) return null;
  const calId = getIntegrations(accId).google?.calendar_id || 'primary';
  let slotTimes: { h: number; m: number }[] = [{ h: 10, m: 0 }, { h: 16, m: 0 }];
  let workDays: number[] = [1, 2, 3, 4, 5];
  try {
    const { getAccount } = require('./store');
    const cfgA = getAccount(accId)?.config || {};
    const parsed = (Array.isArray(cfgA.bookingSlots) ? cfgA.bookingSlots : [])
      .map((s: any) => { const m = String(s).match(/(\d{1,2})[:.](\d{2})/); return m ? { h: Math.min(23, +m[1]), m: Math.min(59, +m[2]) } : null; })
      .filter(Boolean) as { h: number; m: number }[];
    if (parsed.length) slotTimes = parsed.slice(0, 4);
    if (Array.isArray(cfgA.workDays) && cfgA.workDays.length) workDays = cfgA.workDays.map(Number).filter((x: number) => x >= 0 && x <= 6);
  } catch { /* fallback pe default */ }
  const candidates: Date[] = [];
  const now = new Date();
  for (let day = 1; day <= 7 && candidates.length < 10; day++) {
    const d = new Date(now); d.setDate(d.getDate() + day);
    if (!workDays.includes(d.getDay())) continue;
    for (const t of slotTimes) { const s = new Date(d); s.setHours(t.h, t.m, 0, 0); candidates.push(s); }
  }
  try {
    const r = await fetch('https://www.googleapis.com/calendar/v3/freeBusy', {
      method: 'POST',
      headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        timeMin: candidates[0].toISOString(),
        timeMax: new Date(candidates[candidates.length - 1].getTime() + 3600_000).toISOString(),
        timeZone: 'Europe/Bucharest',
        items: [{ id: calId }],
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) return null;
    const busy: { start: string; end: string }[] = (await r.json()).calendars?.[calId]?.busy || [];
    const free = candidates.filter(c => {
      const s = c.getTime(), e = s + 3600_000;
      return !busy.some(b => new Date(b.start).getTime() < e && new Date(b.end).getTime() > s);
    });
    return free.slice(0, 2).map(d => ({ label: fmtSlot(d), iso: d.toISOString() }));
  } catch (e) { console.error('[gcal] freebusy:', String(e).slice(0, 150)); return null; }
}

/** Creează evenimentul de programare. Întoarce link-ul evenimentului sau null. */
export async function bookSlot(accId: string, iso: string, summary: string, description: string): Promise<string | null> {
  const tok = await accessToken(accId);
  if (!tok) return null;
  const calId = getIntegrations(accId).google?.calendar_id || 'primary';
  try {
    const start = new Date(iso);
    const r = await fetch(`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calId)}/events`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        summary, description,
        start: { dateTime: start.toISOString(), timeZone: 'Europe/Bucharest' },
        end: { dateTime: new Date(start.getTime() + 3600_000).toISOString(), timeZone: 'Europe/Bucharest' },
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) { console.error('[gcal] insert:', (await r.text()).slice(0, 200)); return null; }
    return (await r.json()).htmlLink || null;
  } catch (e) { console.error('[gcal] book:', String(e).slice(0, 150)); return null; }
}
