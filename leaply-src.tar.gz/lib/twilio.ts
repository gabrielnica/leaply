import { cfg, appUrl } from './settings';
import { setChannelCreds } from './channels';
import { getOwnerEmail } from './integrations';
import { sendMail } from './mail';
import { audit } from './audit';

// Provisionare automată de numere din contul Twilio master (Setări platformă:
// TWILIO_MASTER_SID + TWILIO_MASTER_TOKEN). Voce = cap-coadă automat.
// WhatsApp = cumpără numărul + pas manual rămas (înregistrarea sender-ului pe WABA).

export const twilioMasterConfigured = () =>
  Boolean(cfg('TWILIO_MASTER_SID') && cfg('TWILIO_MASTER_TOKEN'));

const authHeader = () =>
  'Basic ' + Buffer.from(`${cfg('TWILIO_MASTER_SID')}:${cfg('TWILIO_MASTER_TOKEN')}`).toString('base64');

export type ProvisionResult = { ok: true; number: string; kind: 'voice' | 'whatsapp' } | { ok: false; error: string };

export async function provisionNumber(accId: string, kind: 'voice' | 'whatsapp'): Promise<ProvisionResult> {
  if (!twilioMasterConfigured()) {
    return { ok: false, error: 'Lipsesc TWILIO_MASTER_SID / TWILIO_MASTER_TOKEN în Admin → Setări platformă.' };
  }
  const sid = cfg('TWILIO_MASTER_SID');
  try {
    // 1. caută un număr RO național cu voce
    const q = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/AvailablePhoneNumbers/RO/Local.json?VoiceEnabled=true&PageSize=5`, {
      headers: { Authorization: authHeader() }, signal: AbortSignal.timeout(15000),
    });
    const found: any = await q.json().catch(() => ({}));
    const num = found?.available_phone_numbers?.[0]?.phone_number;
    if (!q.ok) return { ok: false, error: `Twilio ${q.status}: ${(found?.message || '').slice(0, 200)}` };
    if (!num) return { ok: false, error: 'Twilio nu are momentan numere RO disponibile (poate lipsi regulatory bundle-ul aprobat pe cont).' };

    // 2. cumpără numărul + setează webhook-ul de voce către Leaply
    const form = new URLSearchParams({
      PhoneNumber: num,
      VoiceUrl: `${appUrl()}/api/webhooks/voice`,
      VoiceMethod: 'POST',
      FriendlyName: `Leaply ${kind} ${accId}`,
    });
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/IncomingPhoneNumbers.json`, {
      method: 'POST',
      headers: { Authorization: authHeader(), 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form.toString(),
      signal: AbortSignal.timeout(20000),
    });
    const data: any = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: `Twilio ${r.status}: ${(data?.message || '').slice(0, 200)}` };
    const bought = data.phone_number || num;

    // 3. leagă numărul de cont
    if (kind === 'voice') {
      // rutarea inbound se face după from_number (resolveAccount('voice') caută To în credentials)
      setChannelCreds(accId, 'voice', { provider: 'twilio', from_number: bought }, `Telefon Leaply ${bought} — agent vocal activ`);
    } else {
      // WhatsApp: numărul e cumpărat; înregistrarea ca sender pe WABA (Senders API + OTP voce) e pasul următor, manual deocamdată
      setChannelCreds(accId, 'whatsapp', null, `Număr ${bought} rezervat — activare WhatsApp în curs (1 zi lucrătoare)`);
    }

    // 4. anunță ownerul
    const email = getOwnerEmail(accId);
    if (email) {
      sendMail(email,
        kind === 'voice' ? `Numărul tău de telefon Leaply e activ: ${bought}` : `Numărul tău WhatsApp e rezervat: ${bought}`,
        kind === 'voice'
          ? `<p>Numărul tău dedicat <b>${bought}</b> e activ! Apelurile primite sunt preluate de agentul vocal AI, apelanții devin lead-uri în inbox, iar tu primești notificări.</p><p>Pune-l pe site și în anunțuri, sau redirecționează numărul firmei către el.</p>`
          : `<p>Am rezervat pentru tine numărul <b>${bought}</b>. Îl activăm pe WhatsApp în cel mult o zi lucrătoare și te anunțăm când e gata de folosit.</p>`
      ).catch(() => {});
    }
    audit('admin', 'number.provision', accId, { number: bought, kind });
    return { ok: true, number: bought, kind };
  } catch (e) {
    return { ok: false, error: String(e).slice(0, 200) };
  }
}
