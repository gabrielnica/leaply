import { db } from './db';

// Setări de integrare per cont, stocate ca JSON în accounts.integrations:
// { google?: { refresh_token, calendar_id?, email? },
//   webhookOut?: { url, secret? },
//   notify?: { email?: boolean } }
export function getIntegrations(accId: string): any {
  const row: any = db().prepare('SELECT integrations FROM accounts WHERE id=?').get(accId);
  try { return JSON.parse(row?.integrations || '{}') || {}; } catch { return {}; }
}

export function setIntegration(accId: string, key: string, value: any) {
  const cur = getIntegrations(accId);
  if (value === null) delete cur[key]; else cur[key] = value;
  db().prepare('UPDATE accounts SET integrations=? WHERE id=?').run(JSON.stringify(cur), accId);
}

export function getOwnerEmail(accId: string): string | null {
  const u: any = db().prepare("SELECT email FROM users WHERE account_id=? ORDER BY created_at LIMIT 1").get(accId);
  return u?.email || null;
}

/** Trimite evenimentul spre webhook-ul CRM al contului (Zapier/Make/etc), fire-and-forget. */
export async function emitWebhookOut(accId: string, event: string, data: any) {
  const cfg = getIntegrations(accId).webhookOut;
  if (!cfg?.url || !/^https:\/\//.test(cfg.url)) return;
  try {
    const body = JSON.stringify({ event, account_id: accId, ts: new Date().toISOString(), data });
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (cfg.secret) {
      const crypto = require('crypto');
      headers['X-Leaply-Signature'] = 'sha256=' + crypto.createHmac('sha256', cfg.secret).update(body).digest('hex');
    }
    await fetch(cfg.url, { method: 'POST', headers, body, signal: AbortSignal.timeout(5000) });
  } catch (e) { console.error('[leaply webhook-out]', accId, event, String(e).slice(0, 200)); }
}
