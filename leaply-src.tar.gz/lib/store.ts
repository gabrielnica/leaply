import { db, uid } from './db';

export function getAccount(id = 'acc_demo') {
  const a: any = db().prepare('SELECT * FROM accounts WHERE id = ?').get(id);
  if (a) a.config = JSON.parse(a.config || '{}');
  return a;
}
export function listChannels(accId = 'acc_demo') {
  return db().prepare('SELECT * FROM channels WHERE account_id = ?').all(accId) as any[];
}
export function listConversations(accId = 'acc_demo') {
  return db().prepare(`SELECT c.*, l.name lead_name, l.phone, l.source FROM conversations c
    JOIN leads l ON l.id = c.lead_id WHERE c.account_id = ? ORDER BY c.updated_at DESC`).all(accId) as any[];
}
export function getConversation(id: string) {
  const c: any = db().prepare(`SELECT c.*, l.name lead_name, l.phone, l.source FROM conversations c
    JOIN leads l ON l.id = c.lead_id WHERE c.id = ?`).get(id);
  if (!c) return null;
  c.qualification = JSON.parse(c.qualification || '{}');
  c.messages = db().prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at').all(id);
  return c;
}
export function stats(accId = 'acc_demo') {
  const d = db();
  const acc: any = d.prepare('SELECT avg_deal_value FROM accounts WHERE id = ?').get(accId);
  const convs = d.prepare('SELECT * FROM conversations WHERE account_id = ?').all(accId) as any[];
  const leads = convs.length;
  const booked = convs.filter(c => c.status === 'booked').length;
  const qualified = convs.filter(c => c.status === 'qualified' || c.status === 'booked').length;
  const avgMs = convs.length ? Math.round(convs.reduce((s, c) => s + (c.first_response_ms || 0), 0) / convs.length) : 0;
  const dv = acc?.avg_deal_value || 0;
  const savedLei = Math.round(qualified * 0.35 * dv); // qualified * conv rate * deal value
  return { leads, booked, qualified, avgSec: Math.round(avgMs / 1000), savedLei };
}
export function createInboundConversation(accId: string, channel: string, leadName: string, phone: string, source: string, firstMsg: string) {
  const d = db(); const now = new Date().toISOString();
  const leadId = uid('ld_'); const convId = uid('cv_');
  d.transaction(() => {
    d.prepare('INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(leadId, accId, leadName, phone, source, 'warm', now);
    d.prepare('INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(convId, accId, leadId, channel, 'active', 0, '{}', now, now);
    addMessage(convId, 'in', 'lead', firstMsg);
  })();
  return { convId, leadId };
}
export function addMessage(convId: string, direction: string, sender: string, body: string) {
  db().prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)')
    .run(uid('ms_'), convId, direction, sender, body, new Date().toISOString());
  db().prepare('UPDATE conversations SET updated_at = ? WHERE id = ?').run(new Date().toISOString(), convId);
}
export function updateConversation(convId: string, patch: { status?: string; score?: string; first_response_ms?: number; qualification?: any }) {
  const d = db();
  if (patch.status) d.prepare('UPDATE conversations SET status=? WHERE id=?').run(patch.status, convId);
  if (patch.first_response_ms != null) d.prepare('UPDATE conversations SET first_response_ms=? WHERE id=?').run(patch.first_response_ms, convId);
  if (patch.qualification) d.prepare('UPDATE conversations SET qualification=? WHERE id=?').run(JSON.stringify(patch.qualification), convId);
  if (patch.score) { const c: any = d.prepare('SELECT lead_id FROM conversations WHERE id=?').get(convId); if (c) d.prepare('UPDATE leads SET score=? WHERE id=?').run(patch.score, c.lead_id); }
}

export function updateAccountConfig(accId: string, config: any) {
  db().prepare('UPDATE accounts SET config=? WHERE id=?').run(JSON.stringify(config), accId);
}

export function listAccountsWithStats() {
  const accs = db().prepare('SELECT * FROM accounts').all() as any[];
  return accs.map(a => {
    const convs = db().prepare('SELECT * FROM conversations WHERE account_id=?').all(a.id) as any[];
    const booked = convs.filter(c => c.status === 'booked').length;
    const avgMs = convs.length ? Math.round(convs.reduce((s, c) => s + (c.first_response_ms || 0), 0) / convs.length) : 0;
    const health = Math.min(100, 40 + convs.length * 8 + booked * 6);
    return { ...a, leads: convs.length, booked, avgSec: Math.round(avgMs / 1000), health };
  });
}
