import crypto from 'crypto';
import { db } from './db';
import { getIntegrations, setIntegration } from './integrations';

// Chei API per cont: lp_<random>. Stocăm doar hash-ul (sha256) + prefixul pentru afișare.
export function generateApiKey(accId: string): string {
  const raw = 'lp_' + crypto.randomBytes(24).toString('base64url');
  setIntegration(accId, 'api', { hash: crypto.createHash('sha256').update(raw).digest('hex'), prefix: raw.slice(0, 8), created_at: new Date().toISOString() });
  return raw; // afișat O SINGURĂ dată
}
export function revokeApiKey(accId: string) { setIntegration(accId, 'api', null); }
export function apiKeyInfo(accId: string) {
  const a = getIntegrations(accId).api;
  return a ? { prefix: a.prefix, created_at: a.created_at } : null;
}

/** Autentifică un request de API public. Întoarce account_id sau null. */
export function resolveApiKey(header: string | null): string | null {
  const m = /^Bearer\s+(lp_[A-Za-z0-9_-]+)$/.exec(header || '');
  if (!m) return null;
  const hash = crypto.createHash('sha256').update(m[1]).digest('hex');
  const rows: any[] = db().prepare('SELECT id, integrations FROM accounts WHERE integrations IS NOT NULL').all();
  for (const r of rows) {
    try { if (JSON.parse(r.integrations || '{}').api?.hash === hash) return r.id; } catch {}
  }
  return null;
}
