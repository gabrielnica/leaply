import crypto from 'crypto';
import { cookies } from 'next/headers';
import { db, uid } from './db';

export const SESSION_COOKIE = 'leaply_session';
const SESSION_DAYS = 30;

/* ---------- parole (scrypt, fără dependențe externe) ---------- */
export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex');
  return `s1$${salt}$${hash}`;
}
export function verifyPassword(pw: string, stored: string): boolean {
  try {
    const [v, salt, hash] = stored.split('$');
    if (v !== 's1' || !salt || !hash) return false;
    const calc = crypto.scryptSync(pw, salt, 64);
    return crypto.timingSafeEqual(calc, Buffer.from(hash, 'hex'));
  } catch { return false; }
}

const sha256 = (s: string) => crypto.createHash('sha256').update(s).digest('hex');

/* ---------- sesiuni ---------- */
export function createSession(userId: string): { token: string; expires: Date } {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_DAYS * 86400_000);
  db().prepare('INSERT INTO sessions (token_hash,user_id,expires_at,created_at) VALUES (?,?,?,?)')
    .run(sha256(token), userId, expires.toISOString(), new Date().toISOString());
  return { token, expires };
}

export function destroySession(token: string) {
  db().prepare('DELETE FROM sessions WHERE token_hash=?').run(sha256(token));
}

export function destroyAllSessions(userId: string) {
  db().prepare('DELETE FROM sessions WHERE user_id=?').run(userId);
}

export type SessionUser = { id: string; account_id: string; email: string; name: string; role: string };

export function getUserByToken(token: string | undefined | null): SessionUser | null {
  if (!token) return null;
  const row: any = db().prepare(`
    SELECT u.id, u.account_id, u.email, u.name, u.role, s.expires_at
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ?`).get(sha256(token));
  if (!row) return null;
  if (new Date(row.expires_at) < new Date()) {
    db().prepare('DELETE FROM sessions WHERE token_hash=?').run(sha256(token));
    return null;
  }
  return { id: row.id, account_id: row.account_id, email: row.email, name: row.name, role: row.role };
}

/** Pentru server components / route handlers (citește cookie-ul cererii curente). */
export function getSessionUser(): SessionUser | null {
  try { return getUserByToken(cookies().get(SESSION_COOKIE)?.value); } catch { return null; }
}

/* ---------- resetare parolă ---------- */
export function createResetToken(userId: string, hours = 1): string {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + hours * 3600_000); // implicit 1h; bot-signup folosește 72h
  db().prepare('INSERT INTO password_resets (token_hash,user_id,expires_at,used,created_at) VALUES (?,?,?,0,?)')
    .run(sha256(token), userId, expires.toISOString(), new Date().toISOString());
  return token;
}
export function createVerifyToken(userId: string): string {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + 7 * 86400_000); // 7 zile
  db().prepare('INSERT INTO email_verifications (token_hash,user_id,expires_at,used,created_at) VALUES (?,?,?,0,?)')
    .run(sha256(token), userId, expires.toISOString(), new Date().toISOString());
  return token;
}
export function consumeVerifyToken(token: string): string | null {
  const row: any = db().prepare('SELECT user_id, expires_at, used FROM email_verifications WHERE token_hash=?').get(sha256(token));
  if (!row || row.used || new Date(row.expires_at) < new Date()) return null;
  db().prepare('UPDATE email_verifications SET used=1 WHERE token_hash=?').run(sha256(token));
  db().prepare('UPDATE users SET email_verified=1 WHERE id=?').run(row.user_id);
  return row.user_id;
}

export function consumeResetToken(token: string): string | null {
  const row: any = db().prepare('SELECT user_id, expires_at, used FROM password_resets WHERE token_hash=?').get(sha256(token));
  if (!row || row.used || new Date(row.expires_at) < new Date()) return null;
  db().prepare('UPDATE password_resets SET used=1 WHERE token_hash=?').run(sha256(token));
  return row.user_id;
}

/* ---------- creare cont (signup) ---------- */
export const emailOk = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);

export function createAccountWithOwner(p: { name: string; email: string; password: string; business?: string; vertical?: string }) {
  const d = db();
  const email = p.email.trim().toLowerCase();
  const exists = d.prepare('SELECT id FROM users WHERE email=?').get(email);
  if (exists) return { error: 'există deja un cont cu acest email' };
  const now = new Date().toISOString();
  const accId = uid('acc_');
  const userId = uid('us_');
  const businessName = (p.business || p.name || 'Afacerea mea').slice(0, 120);
  const config = {
    businessName,
    vertical: p.vertical || 'servicii',
    tone: 'prietenos',
    welcome: `Bună ziua! Mulțumim pentru mesaj 😊 Sunt asistentul ${businessName} și vă ajut imediat.`,
    services: [],
    qualificationQuestions: [
      { key: 'nevoie', q: 'Cu ce vă putem ajuta, mai exact?' },
      { key: 'urgenta', q: 'Pentru ce interval aveți nevoie — cât mai repede, în 1-2 luni, sau doar vă informați?' },
      { key: 'zona', q: 'În ce localitate/zonă sunteți?' },
    ],
    bookingSlots: ['joi la 16:00', 'vineri la 10:00'],
    redFlags: [],
  };
  d.transaction(() => {
    d.prepare('INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(accId, businessName, p.vertical || 'servicii', 'Trial', 3000, JSON.stringify(config), now);
    d.prepare('INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)')
      .run(userId, accId, email, p.name.slice(0, 120), hashPassword(p.password), 'owner', now);
    const chans = [
      { type: 'webform', status: 'connected', label: 'Formular / chat web' },
      { type: 'whatsapp', status: 'pending', label: 'WhatsApp Business' },
      { type: 'meta_lead_ads', status: 'pending', label: 'Facebook Lead Ads' },
      { type: 'messenger', status: 'pending', label: 'Messenger' },
      { type: 'instagram', status: 'pending', label: 'Instagram DM' },
      { type: 'voice', status: 'pending', label: 'Apeluri telefonice (număr de la Leaply)' },
      { type: 'calendar', status: 'pending', label: 'Google Calendar' },
    ];
    const ins = d.prepare('INSERT INTO channels (id,account_id,type,status,label) VALUES (?,?,?,?,?)');
    chans.forEach(c => ins.run(uid('ch_'), accId, c.type, c.status, c.label));
  })();
  return { accountId: accId, userId };
}
