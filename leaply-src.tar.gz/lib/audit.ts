import { db, uid } from './db';

/** Jurnal de audit — cine a făcut ce (acțiuni sensibile: planuri, echipă, chei, canale). */
export function audit(actor: string, action: string, target = '', meta: any = null) {
  try {
    db().prepare('INSERT INTO audit_log (id,actor,action,target,meta,created_at) VALUES (?,?,?,?,?,?)')
      .run(uid('au_'), actor.slice(0, 160), action.slice(0, 80), String(target).slice(0, 160), meta ? JSON.stringify(meta).slice(0, 500) : null, new Date().toISOString());
  } catch (e) { console.error('[audit]', String(e).slice(0, 100)); }
}
export function recentAudit(limit = 30) {
  return db().prepare('SELECT * FROM audit_log ORDER BY created_at DESC LIMIT ?').all(Math.min(limit, 100)) as any[];
}
