// Helper de browser pentru Web Push (desktop/browser). Rulează DOAR pe client.

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

export function pushSupported(): boolean {
  return typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
}

export function pushPermission(): NotificationPermission | 'unsupported' {
  if (!pushSupported()) return 'unsupported';
  return Notification.permission;
}

/** Cere permisiunea, se abonează la Web Push și trimite abonamentul la server. */
export async function enableWebPush(): Promise<{ ok: boolean; error?: string }> {
  try {
    if (!pushSupported()) return { ok: false, error: 'Browserul acesta nu suportă notificări push.' };
    const reg = await navigator.serviceWorker.register('/sw.js');
    await navigator.serviceWorker.ready;
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') return { ok: false, error: 'Permisiunea pentru notificări a fost refuzată.' };
    const vr = await fetch('/api/push/vapid').then(r => r.json());
    if (!vr?.configured || !vr?.key) return { ok: false, error: 'Notificările push nu sunt încă activate pe server.' };
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vr.key) as BufferSource,
      });
    }
    const r = await fetch('/api/push/web-subscribe', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subscription: sub.toJSON() }),
    });
    if (!r.ok) return { ok: false, error: 'Nu am putut salva abonamentul.' };
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Eroare la activarea notificărilor.' };
  }
}

export async function disableWebPush(): Promise<void> {
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = await reg?.pushManager.getSubscription();
    if (sub) {
      await fetch('/api/push/web-subscribe', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'unsubscribe', endpoint: sub.endpoint }),
      }).catch(() => {});
      await sub.unsubscribe().catch(() => {});
    }
  } catch {}
}
