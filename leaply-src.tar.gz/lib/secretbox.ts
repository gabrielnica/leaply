import crypto from 'crypto';
import { cfg } from './settings';

// Criptare la rest pentru credențialele de canale (AES-256-GCM).
// Cheia: setarea CREDS_KEY (Admin → Setări → Infrastructură) sau env CREDS_KEY.
// - fără cheie setată → scriem plaintext (compatibil cu ce există; nimic nu se strică)
// - cu cheie → scrierile noi sunt criptate ("enc:v1:iv:tag:ct"), citirile acceptă AMBELE
//   formate (migrare leneșă: fiecare re-salvare criptează rândul).
// ATENȚIE: dacă schimbi cheia după ce există rânduri criptate, acelea devin ilizibile —
// reconectează canalele sau păstrează cheia veche.

const keyOf = (): Buffer | null => {
  const s = cfg('CREDS_KEY') || '';
  if (!s) return null;
  return crypto.createHash('sha256').update(s).digest();
};

export function sealJson(obj: any): string {
  const plain = JSON.stringify(obj);
  const key = keyOf();
  if (!key) return plain;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
  return `enc:v1:${iv.toString('base64')}:${c.getAuthTag().toString('base64')}:${ct.toString('base64')}`;
}

export function openJson(raw: string | null | undefined): any | null {
  if (!raw) return null;
  if (!raw.startsWith('enc:v1:')) {
    try { return JSON.parse(raw); } catch { return null; }
  }
  const key = keyOf();
  if (!key) return null; // criptat dar cheia lipsește — tratăm canalul ca neconfigurat
  try {
    const [, , ivB, tagB, ctB] = raw.split(':');
    const de = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivB, 'base64'));
    de.setAuthTag(Buffer.from(tagB, 'base64'));
    const pt = Buffer.concat([de.update(Buffer.from(ctB, 'base64')), de.final()]).toString('utf8');
    return JSON.parse(pt);
  } catch { return null; }
}
