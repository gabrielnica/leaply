import fs from 'fs';
import path from 'path';
import { db } from './db';

// Backup SQLite pe volumul persistent: /data/backups/leaply-YYYYMMDD-HHmm.db
// Rotativ — păstrăm ultimele 14. Se rulează zilnic din cron.
const dir = () => {
  const base = path.dirname(process.env.LEAPLY_DB_PATH || path.join(process.cwd(), 'data', 'leaply.db'));
  const d = path.join(base, 'backups');
  fs.mkdirSync(d, { recursive: true });
  return d;
};

export async function backupDb(): Promise<{ file: string; size: number }> {
  const stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '').replace(/(\d{8})(\d{4})/, '$1-$2');
  const file = path.join(dir(), `leaply-${stamp}.db`);
  await db().backup(file); // API-ul nativ better-sqlite3 — consistent chiar sub scrieri
  // rotație
  const all = fs.readdirSync(dir()).filter(f => f.startsWith('leaply-') && f.endsWith('.db')).sort();
  for (const old of all.slice(0, Math.max(0, all.length - 14))) fs.unlinkSync(path.join(dir(), old));
  return { file, size: fs.statSync(file).size };
}

export function latestBackup(): { file: string; size: number; mtime: string } | null {
  try {
    const all = fs.readdirSync(dir()).filter(f => f.startsWith('leaply-') && f.endsWith('.db')).sort();
    if (!all.length) return null;
    const f = path.join(dir(), all[all.length - 1]);
    const st = fs.statSync(f);
    return { file: f, size: st.size, mtime: st.mtime.toISOString() };
  } catch { return null; }
}

export function listBackups(): { name: string; size: number; mtime: string }[] {
  try {
    return fs.readdirSync(dir()).filter(f => f.startsWith('leaply-') && f.endsWith('.db')).sort().reverse()
      .map(name => { const st = fs.statSync(path.join(dir(), name)); return { name, size: st.size, mtime: st.mtime.toISOString() }; });
  } catch { return []; }
}
