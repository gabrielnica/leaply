import crypto from 'crypto';
import { db, uid } from './db';
import { cfg } from './settings';
import { getIntegrations } from './integrations';

// Motor de notificări push — două canale, o singură funcție de trimitere:
//  • Web Push (VAPID) pentru desktop/browser (biblioteca `web-push`).
//  • Firebase Cloud Messaging HTTP v1 pentru mobil (iOS via APNs relay + Android),
//    fără SDK — semnăm un JWT din service account și obținem un OAuth token.
// Toate cheile se pun în Admin → Setări platformă (grupul „Notificări push").
// Best-effort peste tot: dacă lipsesc cheile, funcțiile tac și întorc 0.

export type PushPayload = { title: string; body: string; url?: string; tag?: string };

/* ---------------- config helpers ---------------- */
export const webPushConfigured = () => Boolean(cfg('VAPID_PUBLIC_KEY') && cfg('VAPID_PRIVATE_KEY'));
export const fcmConfigured = () => Boolean(cfg('FCM_SERVICE_ACCOUNT') && cfg('FCM_PROJECT_ID'));
export const pushConfigured = () => webPushConfigured() || fcmConfigured();
export const getVapidPublicKey = () => cfg('VAPID_PUBLIC_KEY');

/* ---------------- stocare token-uri ---------------- */
const MAX_PER_ACCOUNT = 60; // plafon anti-abuz per cont (dispozitive / browsere)

export function saveWebSub(accId: string, userId: string, sub: { endpoint: string; keys?: { p256dh?: string; auth?: string } }) {
  const now = new Date().toISOString();
  const ep = String(sub?.endpoint || ''); const p = String(sub?.keys?.p256dh || ''); const a = String(sub?.keys?.auth || '');
  // validare mărime — endpoint-urile reale au ~sub 1KB, cheile ~200 caractere
  if (!ep || !p || !a || ep.length > 1024 || p.length > 300 || a.length > 300) return;
  db().prepare(`INSERT INTO web_push_subs (id, account_id, user_id, endpoint, p256dh, auth, created_at, last_seen)
    VALUES (?,?,?,?,?,?,?,?)
    ON CONFLICT(endpoint) DO UPDATE SET account_id=excluded.account_id, user_id=excluded.user_id, p256dh=excluded.p256dh, auth=excluded.auth, last_seen=excluded.last_seen`)
    .run(uid('wps'), accId, userId, ep, p, a, now, now);
  capRows('web_push_subs', accId);
}
/** Șterge un abonament — scopat pe cont (API). Fără accId: prune intern (token mort). */
export function removeWebSub(endpoint: string, accId?: string) {
  try {
    if (accId) db().prepare('DELETE FROM web_push_subs WHERE endpoint=? AND account_id=?').run(endpoint, accId);
    else db().prepare('DELETE FROM web_push_subs WHERE endpoint=?').run(endpoint);
  } catch {}
}
export function saveDeviceToken(accId: string, userId: string, platform: string, token: string) {
  const now = new Date().toISOString();
  if (!token || token.length > 4096) return;
  db().prepare(`INSERT INTO device_tokens (id, account_id, user_id, platform, token, created_at, last_seen)
    VALUES (?,?,?,?,?,?,?)
    ON CONFLICT(token) DO UPDATE SET account_id=excluded.account_id, user_id=excluded.user_id, platform=excluded.platform, last_seen=excluded.last_seen`)
    .run(uid('dev'), accId, userId, platform || 'unknown', token, now, now);
  capRows('device_tokens', accId);
}
/** Șterge un token — scopat pe cont (API). Fără accId: prune intern (token mort). */
export function removeDeviceToken(token: string, accId?: string) {
  try {
    if (accId) db().prepare('DELETE FROM device_tokens WHERE token=? AND account_id=?').run(token, accId);
    else db().prepare('DELETE FROM device_tokens WHERE token=?').run(token);
  } catch {}
}
/** Păstrează cel mult MAX_PER_ACCOUNT rânduri per cont (le șterge pe cele mai vechi). */
function capRows(table: 'web_push_subs' | 'device_tokens', accId: string) {
  try {
    const n = (db().prepare(`SELECT COUNT(*) c FROM ${table} WHERE account_id=?`).get(accId) as any).c;
    if (n > MAX_PER_ACCOUNT) {
      db().prepare(`DELETE FROM ${table} WHERE id IN (
        SELECT id FROM ${table} WHERE account_id=? ORDER BY last_seen ASC LIMIT ?)`).run(accId, n - MAX_PER_ACCOUNT);
    }
  } catch {}
}

/* ---------------- FCM: OAuth token din service account ---------------- */
let fcmToken: { value: string; exp: number } | null = null;
async function fcmAccessToken(): Promise<string | null> {
  if (fcmToken && fcmToken.exp > Date.now() + 60_000) return fcmToken.value;
  let sa: any;
  try { sa = JSON.parse(cfg('FCM_SERVICE_ACCOUNT')); } catch { return null; }
  if (!sa?.client_email || !sa?.private_key) return null;
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const claim = {
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now, exp: now + 3600,
  };
  const b64 = (o: any) => Buffer.from(JSON.stringify(o)).toString('base64url');
  const signingInput = `${b64(header)}.${b64(claim)}`;
  const sig = crypto.createSign('RSA-SHA256').update(signingInput).end().sign(sa.private_key).toString('base64url');
  const jwt = `${signingInput}.${sig}`;
  try {
    const r = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: jwt }).toString(),
      signal: AbortSignal.timeout(10000),
    });
    const j: any = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) return null;
    fcmToken = { value: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
    return fcmToken.value;
  } catch { return null; }
}

async function sendFcm(token: string, payload: PushPayload): Promise<'ok' | 'gone' | 'error'> {
  const access = await fcmAccessToken();
  const projectId = cfg('FCM_PROJECT_ID');
  if (!access || !projectId) return 'error';
  const message = {
    message: {
      token,
      notification: { title: payload.title, body: payload.body },
      data: { url: payload.url || '/app', tag: payload.tag || 'lead' },
      apns: { payload: { aps: { sound: 'default', 'mutable-content': 1 } } },
      android: { priority: 'HIGH', notification: { sound: 'default', default_vibrate_timings: true } },
    },
  };
  try {
    const r = await fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${access}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(message),
      signal: AbortSignal.timeout(10000),
    });
    if (r.ok) return 'ok';
    // token invalid/expirat → îl curățăm
    if (r.status === 404 || r.status === 400) {
      const t = await r.text().catch(() => '');
      if (/UNREGISTERED|INVALID_ARGUMENT|NOT_FOUND/i.test(t)) return 'gone';
    }
    return 'error';
  } catch { return 'error'; }
}

/* ---------------- Web Push (VAPID) ---------------- */
function webpushLib(): any | null {
  if (!webPushConfigured()) return null;
  try {
    // require ca să nu forțăm încărcarea când nu e configurat
    const wp = require('web-push');
    wp.setVapidDetails(cfg('VAPID_SUBJECT') || 'mailto:salut@leaply.ro', cfg('VAPID_PUBLIC_KEY'), cfg('VAPID_PRIVATE_KEY'));
    return wp;
  } catch { return null; }
}

async function sendWeb(wp: any, row: any, payload: PushPayload): Promise<'ok' | 'gone' | 'error'> {
  try {
    await wp.sendNotification(
      { endpoint: row.endpoint, keys: { p256dh: row.p256dh, auth: row.auth } },
      JSON.stringify(payload),
      { TTL: 3600 },
    );
    return 'ok';
  } catch (e: any) {
    const code = e?.statusCode;
    if (code === 404 || code === 410) return 'gone';
    return 'error';
  }
}

/* ---------------- API principal ---------------- */
/** Trimite o notificare push la toate dispozitivele contului (mobil + desktop).
 *  Respectă preferința integrations.notify.push (implicit pornit). Best-effort. */
export async function pushToAccount(accId: string, payload: PushPayload): Promise<{ sent: number; pruned: number }> {
  let sent = 0, pruned = 0;
  try {
    if (getIntegrations(accId).notify?.push === false) return { sent, pruned };
  } catch {}
  // --- Web Push (desktop) ---
  const wp = webpushLib();
  if (wp) {
    const subs: any[] = db().prepare('SELECT * FROM web_push_subs WHERE account_id=?').all(accId);
    for (const s of subs) {
      const res = await sendWeb(wp, s, payload);
      if (res === 'ok') sent++;
      else if (res === 'gone') { removeWebSub(s.endpoint); pruned++; }
    }
  }
  // --- FCM (mobil) ---
  if (fcmConfigured()) {
    const devs: any[] = db().prepare('SELECT * FROM device_tokens WHERE account_id=?').all(accId);
    for (const d of devs) {
      const res = await sendFcm(d.token, payload);
      if (res === 'ok') sent++;
      else if (res === 'gone') { removeDeviceToken(d.token); pruned++; }
    }
  }
  return { sent, pruned };
}

/** Trimite doar către dispozitivele unui user (pt. test din Setări). */
export async function pushToUser(accId: string, userId: string, payload: PushPayload): Promise<{ sent: number }> {
  let sent = 0;
  const wp = webpushLib();
  if (wp) {
    const subs: any[] = db().prepare('SELECT * FROM web_push_subs WHERE account_id=? AND user_id=?').all(accId, userId);
    for (const s of subs) { const r = await sendWeb(wp, s, payload); if (r === 'ok') sent++; else if (r === 'gone') removeWebSub(s.endpoint); }
  }
  if (fcmConfigured()) {
    const devs: any[] = db().prepare('SELECT * FROM device_tokens WHERE account_id=? AND user_id=?').all(accId, userId);
    for (const d of devs) { const r = await sendFcm(d.token, payload); if (r === 'ok') sent++; else if (r === 'gone') removeDeviceToken(d.token); }
  }
  return { sent };
}
