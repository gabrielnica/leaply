import { db } from './db';

// Memorie per client: istoricul lead-ului (după telefon) injectat în promptul AI.
// Efect: „Bună ziua, doamna Maria, mă bucur să vă reaud" în loc de tratament de străin.

export function leadContext(accId: string, phone: string | null | undefined, excludeConvId?: string): string | null {
  const p = String(phone || '').trim();
  if (!p || p.length < 6 || p.startsWith('widget:')) return null;
  try {
    const d = db();
    const rows: any[] = d.prepare(`
      SELECT c.id, c.status, c.qualification, c.won_value, c.updated_at, l.name
      FROM conversations c JOIN leads l ON l.id = c.lead_id
      WHERE c.account_id = ? AND l.phone = ? ${excludeConvId ? 'AND c.id != ?' : ''}
      ORDER BY c.updated_at DESC LIMIT 5`).all(...(excludeConvId ? [accId, p, excludeConvId] : [accId, p]));
    if (!rows.length) return null;
    const last = rows[0];
    const name = (last.name || '').trim();
    const cleanName = name && !/^(vizitator|lead|apel)/i.test(name) ? name : '';
    const when = new Date(last.updated_at).toLocaleDateString('ro-RO');
    let lastTopic = '';
    try {
      const q = JSON.parse(last.qualification || '{}');
      lastTopic = q.nevoie || q.serviciu || q.problema || q.interes || q.buget || '';
    } catch { /* ignore */ }
    const statusRo: Record<string, string> = { booked: 'a avut o programare', qualified: 'a fost calificat', lost: 'nu s-a concretizat', human: 'a vorbit cu un coleg', active: 'a rămas deschisă' };
    const bits = [
      `CLIENT RECURENT${cleanName ? ` — numele lui: ${cleanName}` : ''}: a mai scris/sunat de ${rows.length} ${rows.length === 1 ? 'dată' : 'ori'}, ultima pe ${when} (${statusRo[last.status] || last.status}${lastTopic ? `, subiect: „${String(lastTopic).slice(0, 80)}"` : ''}).`,
      rows.some(r => r.won_value) ? 'A mai cumpărat de la noi — client fidel, tratează-l ca atare.' : '',
      `Salută-l ca pe un cunoscut${cleanName ? `, folosindu-i numele (${cleanName.split(' ')[0]})` : ''}, și NU-i repune întrebările la care a răspuns deja în trecut dacă subiectul e același.`,
    ].filter(Boolean);
    return bits.join(' ');
  } catch { return null; }
}
