// Preseturi de configurare per vertical — wizard-ul completează totul din 1 click.
// Prețurile sunt ORIENTATIVE și marcate ca atare; utilizatorul le ajustează.

export type Preset = {
  match: string[]; // fragmente care identifică verticalul din textul liber
  services: { name: string; price: string }[];
  questions: { key: string; q: string }[];
  welcome: string;
  rules: string;
  redFlags: string[];
  tone: string;
};

export const VERTICAL_PRESETS: Record<string, Preset> = {
  stomatologie: {
    match: ['stomato', 'dent', 'implant', 'ortodon'],
    services: [
      { name: 'Consultație + plan de tratament', price: 'de la 200 lei' },
      { name: 'Igienizare profesională', price: 'de la 300 lei' },
      { name: 'Implant dentar (pachet complet)', price: 'de la 3.500 lei' },
      { name: 'Albire profesională', price: 'de la 800 lei' },
    ],
    questions: [
      { key: 'nevoie', q: 'Ce vă supără sau ce tratament vă interesează?' },
      { key: 'urgenta', q: 'Aveți dureri în acest moment, sau e un tratament planificat?' },
      { key: 'istoric', q: 'Ați mai fost pacientul clinicii noastre?' },
    ],
    welcome: 'Bună ziua! Mulțumim că ne-ați scris 😊 Cu ce vă putem ajuta?',
    rules: 'Nu pune diagnostice și nu recomanda tratamente prin chat — invită politicos la consultație. Nu promite prețuri finale înainte de consultație.',
    redFlags: ['medicina muncii', 'veterinar'],
    tone: 'profesional',
  },
  termopane: {
    match: ['termopan', 'tamplarie', 'tâmplărie', 'ferestre', 'pvc'],
    services: [
      { name: 'Ferestre PVC', price: 'de la 750 lei/buc' },
      { name: 'Ferestre aluminiu', price: 'ofertă la măsurătoare' },
      { name: 'Uși de exterior', price: 'de la 2.500 lei' },
      { name: 'Măsurătoare', price: 'gratuită' },
    ],
    questions: [
      { key: 'buget', q: 'Aproximativ câte ferestre / uși ar fi de înlocuit?' },
      { key: 'urgenta', q: 'Pentru ce interval vă doriți montajul — cât mai repede, în 1-2 luni, sau doar vă informați?' },
      { key: 'zona', q: 'În ce localitate/zonă este imobilul?' },
    ],
    welcome: 'Bună ziua! Mulțumim pentru mesaj 😊 Vă ajut imediat cu oferta.',
    rules: 'Nu promite termene de montaj exacte fără măsurătoare. Prețul final se dă doar după măsurătoare.',
    redFlags: ['uși de interior', 'mobilă'],
    tone: 'prietenos',
  },
  auto: {
    match: ['auto', 'service', 'dealer', 'vulcaniz', 'detailing', 'anvelope', 'masini', 'mașini'],
    services: [
      { name: 'Diagnoză computerizată', price: 'de la 150 lei' },
      { name: 'Revizie completă', price: 'de la 450 lei + piese' },
      { name: 'Schimb anvelope + echilibrare', price: 'de la 120 lei' },
      { name: 'ITP', price: 'conform tarifelor RAR' },
    ],
    questions: [
      { key: 'masina', q: 'Ce marcă și model e mașina, și din ce an?' },
      { key: 'problema', q: 'Ce problemă are sau ce lucrare vă interesează?' },
      { key: 'urgenta', q: 'E urgent (mașina nu merge) sau putem programa în zilele următoare?' },
    ],
    welcome: 'Salut! Mulțumim de mesaj — spune-ne cu ce te putem ajuta la mașină.',
    rules: 'Nu da diagnostic ferm fără să vedem mașina. Prețul pieselor se confirmă după identificarea exactă.',
    redFlags: ['dezmembrari', 'dezmembrări'],
    tone: 'prietenos',
  },
  imobiliare: {
    match: ['imobil', 'apartament', 'agentie', 'agenție', 'dezvoltator'],
    services: [
      { name: 'Vizionare proprietate', price: 'gratuită' },
      { name: 'Evaluare proprietate', price: 'gratuită la exclusivitate' },
      { name: 'Consultanță achiziție / credit', price: 'gratuită' },
    ],
    questions: [
      { key: 'interes', q: 'Căutați să cumpărați, să închiriați sau să vindeți?' },
      { key: 'detalii', q: 'Ce zonă și ce buget aveți în vedere?' },
      { key: 'urgenta', q: 'În cât timp ați vrea să vă mutați / finalizați?' },
    ],
    welcome: 'Bună ziua! Mulțumim pentru interes 😊 Vă ajut imediat.',
    rules: 'Nu negocia prețuri în chat — programează vizionare sau discuție cu agentul. Nu da adresa exactă a proprietăților fără programare.',
    redFlags: [],
    tone: 'profesional',
  },
  instalatii: {
    match: ['instala', 'sanitar', 'termic', 'centrale', 'climatizare', 'aer condi', 'hvac'],
    services: [
      { name: 'Intervenție / constatare', price: 'de la 150 lei' },
      { name: 'Montaj centrală termică', price: 'de la 1.200 lei + materiale' },
      { name: 'Montaj aer condiționat', price: 'de la 500 lei' },
      { name: 'Revizie centrală', price: 'de la 250 lei' },
    ],
    questions: [
      { key: 'problema', q: 'Ce problemă aveți sau ce lucrare vă interesează?' },
      { key: 'urgenta', q: 'E o urgență (avarie) sau o lucrare planificată?' },
      { key: 'zona', q: 'În ce localitate/zonă sunteți?' },
    ],
    welcome: 'Bună ziua! Spuneți-ne ce problemă aveți și revenim imediat cu o soluție.',
    rules: 'La urgențe (scurgeri, miros de gaz) recomandă ÎNTÂI oprirea alimentării și abia apoi programarea. Nu da prețuri finale fără constatare.',
    redFlags: [],
    tone: 'prietenos',
  },
  saloane: {
    match: ['salon', 'coafor', 'frizerie', 'barber', 'unghii', 'cosmetic', 'infrumusetare', 'înfrumusețare'],
    services: [
      { name: 'Tuns + styling', price: 'de la 80 lei' },
      { name: 'Vopsit / balayage', price: 'de la 250 lei' },
      { name: 'Manichiură semipermanentă', price: 'de la 120 lei' },
      { name: 'Tratamente faciale', price: 'de la 150 lei' },
    ],
    questions: [
      { key: 'serviciu', q: 'Ce serviciu vă interesează?' },
      { key: 'stilist', q: 'Aveți o preferință pentru un anumit stilist/tehnician?' },
      { key: 'interval', q: 'Ce zi și interval orar v-ar conveni?' },
    ],
    welcome: 'Bună! 💇 Mulțumim de mesaj — te programăm imediat.',
    rules: 'Confirmă întotdeauna durata aproximativă a serviciului la programare. Nu promite același stilist fără să verifici disponibilitatea.',
    redFlags: [],
    tone: 'energic',
  },
  avocatura: {
    match: ['avocat', 'notariat', 'notar', 'juridic'],
    services: [
      { name: 'Consultanță juridică inițială', price: 'de la 300 lei' },
      { name: 'Redactare contracte', price: 'de la 500 lei' },
      { name: 'Reprezentare în instanță', price: 'ofertă după analiza dosarului' },
    ],
    questions: [
      { key: 'domeniu', q: 'În ce domeniu aveți nevoie de ajutor (civil, penal, comercial, familie)?' },
      { key: 'stadiu', q: 'E o situație nouă sau există deja un dosar/litigiu în curs?' },
      { key: 'urgenta', q: 'Există termene sau scadențe apropiate?' },
    ],
    welcome: 'Bună ziua. Vă mulțumim pentru mesaj — descrieți pe scurt situația și vă programăm la o consultație.',
    rules: 'NU da sfaturi juridice în chat — doar programează consultația. Confidențialitate totală; nu cere detalii sensibile în chat.',
    redFlags: [],
    tone: 'profesional',
  },
  fitness: {
    match: ['fitness', 'sala', 'sală', 'sport', 'antrenor', 'gym'],
    services: [
      { name: 'Abonament lunar', price: 'de la 150 lei' },
      { name: 'Ședință cu antrenor personal', price: 'de la 100 lei' },
      { name: 'Ședință de probă', price: 'gratuită' },
    ],
    questions: [
      { key: 'obiectiv', q: 'Ce obiectiv aveți — slăbire, masă musculară, tonifiere, sănătate?' },
      { key: 'experienta', q: 'Ați mai mers la sală / lucrat cu antrenor?' },
      { key: 'program', q: 'În ce intervale ați putea veni de obicei?' },
    ],
    welcome: 'Salut! 💪 Super că vrei să începi — te ajutăm imediat.',
    rules: 'Nu da sfaturi medicale sau de nutriție specifice — recomandă evaluarea la prima ședință.',
    redFlags: [],
    tone: 'energic',
  },
};

/** Găsește presetul potrivit după textul liber al verticalului (diacritics-insensitive). */
export function presetFor(vertical?: string): Preset | null {
  const v = (vertical || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  if (!v) return null;
  for (const p of Object.values(VERTICAL_PRESETS)) {
    if (p.match.some(m => v.includes(m.normalize('NFD').replace(/[̀-ͯ]/g, '')))) return p;
  }
  return null;
}
