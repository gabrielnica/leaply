import { db } from './db';

// Documente firmă (RAG-lite): ownerul urcă PDF/TXT/CSV/MD cu oferte, liste de prețuri,
// regulamente — asistentul primește în prompt DOAR fragmentele relevante pentru întrebare.
// Fără vector DB: scoring pe suprapunere de cuvinte, suficient la volumele unui SMB.

const norm = (s: string) =>
  s.toLowerCase()
    .replace(/[ăâ]/g, 'a').replace(/[îí]/g, 'i').replace(/ș/g, 's').replace(/ț/g, 't')
    .replace(/[^a-z0-9 ]+/g, ' ');

const STOP = new Set(['si', 'sau', 'de', 'la', 'cu', 'in', 'pe', 'un', 'o', 'ce', 'ca', 'e', 'este', 'sunt', 'as', 'vrea', 'pentru', 'mai', 'the', 'a', 'to']);

function tokens(s: string): string[] {
  return norm(s).split(/\s+/).filter(w => w.length > 2 && !STOP.has(w));
}

/** Sparge un document în fragmente de ~600 caractere, pe granițe de paragraf/rând. */
function chunks(content: string): string[] {
  const out: string[] = [];
  let cur = '';
  for (const line of content.split(/\n+/)) {
    if (cur.length + line.length > 600 && cur) { out.push(cur.trim()); cur = ''; }
    cur += line + '\n';
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

export function listDocs(accId: string) {
  return db().prepare('SELECT id, name, length(content) size, created_at FROM knowledge_docs WHERE account_id=? ORDER BY created_at DESC').all(accId) as any[];
}

export function addDoc(accId: string, name: string, content: string): string {
  const id = 'kd_' + Math.random().toString(36).slice(2, 10);
  db().prepare('INSERT INTO knowledge_docs (id, account_id, name, content, created_at) VALUES (?,?,?,?,?)')
    .run(id, accId, name.slice(0, 120), content.slice(0, 200_000), new Date().toISOString());
  return id;
}

export function deleteDoc(accId: string, id: string): boolean {
  return db().prepare('DELETE FROM knowledge_docs WHERE id=? AND account_id=?').run(id, accId).changes > 0;
}

/** Fragmentele cele mai relevante din documentele firmei pentru întrebarea lead-ului.
 *  Maxim ~1500 caractere — promptul rămâne mic și ieftin. */
export function docsContext(accId: string, query: string): string | null {
  try {
    const docs: any[] = db().prepare('SELECT name, content FROM knowledge_docs WHERE account_id=? LIMIT 20').all(accId);
    if (!docs.length) return null;
    const q = new Set(tokens(query || ''));
    if (!q.size) return null;
    const scored: { score: number; name: string; text: string }[] = [];
    for (const d of docs) {
      for (const ch of chunks(String(d.content || ''))) {
        let score = 0;
        for (const w of tokens(ch)) if (q.has(w)) score++;
        if (score > 0) scored.push({ score, name: d.name, text: ch });
      }
    }
    if (!scored.length) return null;
    scored.sort((a, b) => b.score - a.score);
    let out = ''; const used = new Set<string>();
    for (const s of scored) {
      if (out.length + s.text.length > 1500) break;
      out += `[din „${s.name}"] ${s.text}\n`;
      used.add(s.name); if (used.size >= 3 && out.length > 900) break;
    }
    return out.trim() || null;
  } catch { return null; }
}
