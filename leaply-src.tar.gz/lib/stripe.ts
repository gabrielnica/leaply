import crypto from 'crypto';
import { cfg, appUrl } from './settings';
import { db } from './db';
import { getIntegrations, setIntegration } from './integrations';

// Stripe fără SDK. Env: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
// STRIPE_PRICE_START, STRIPE_PRICE_PRO, STRIPE_PRICE_SCALE, APP_URL.
export const stripeConfigured = () => Boolean(cfg('STRIPE_SECRET_KEY'));

export async function createCheckout(accId: string, plan: 'Start' | 'Pro' | 'Scale'): Promise<{ url?: string; error?: string }> {
  if (!stripeConfigured()) return { error: 'Plățile nu sunt încă activate. Scrie-ne la salut@leaply.ro și îți activăm planul manual.' };
  const price = cfg('STRIPE_PRICE_' + plan.toUpperCase());
  if (!price) return { error: `Planul ${plan} nu are preț configurat.` };
  const base = appUrl();
  const form = new URLSearchParams({
    mode: 'subscription',
    'line_items[0][price]': price,
    'line_items[0][quantity]': '1',
    success_url: `${base}/app/settings?billing=success`,
    cancel_url: `${base}/app/settings?billing=cancel`,
    client_reference_id: accId,
    'metadata[account_id]': accId,
    'metadata[plan]': plan,
    // metadata și PE SUBSCRIPȚIE — altfel evenimentele customer.subscription.* vin fără account_id
    'subscription_data[metadata][account_id]': accId,
    'subscription_data[metadata][plan]': plan,
  });
  const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${cfg('STRIPE_SECRET_KEY')}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
    signal: AbortSignal.timeout(10000),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) return { error: data?.error?.message || `Stripe ${r.status}` };
  return { url: data.url };
}

/** Verifică semnătura Stripe (schema t=...,v1=...) și întoarce evenimentul sau null. */
export function verifyStripeEvent(rawBody: string, sigHeader: string | null): any | null {
  const secret = cfg('STRIPE_WEBHOOK_SECRET');
  if (!secret || !sigHeader) return null;
  try {
    const parts = Object.fromEntries(sigHeader.split(',').map(kv => kv.split('=') as [string, string]));
    const expected = crypto.createHmac('sha256', secret).update(`${parts.t}.${rawBody}`).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(parts.v1 || ''))) return null;
    if (Math.abs(Date.now() / 1000 - Number(parts.t)) > 600) return null;
    return JSON.parse(rawBody);
  } catch { return null; }
}

export function applyPlan(accId: string, plan: string) {
  db().prepare('UPDATE accounts SET plan=? WHERE id=?').run(plan, accId);
}

/**
 * Schimbarea planului, corect și la MIJLOCUL LUNII:
 * - dacă contul are deja un abonament Stripe activ → actualizăm abonamentul existent
 *   (proration_behavior=always_invoice: Stripe facturează/creditează automat diferența
 *   pe zilele rămase — clientul NU plătește două abonamente);
 * - altfel (trial sau abonament anulat) → checkout nou.
 */
export async function changePlan(accId: string, plan: 'Start' | 'Pro' | 'Scale'): Promise<{ url?: string; updated?: boolean; error?: string }> {
  if (!stripeConfigured()) return { error: 'Plățile nu sunt încă activate. Scrie-ne la salut@leaply.ro și îți activăm planul manual.' };
  const price = cfg('STRIPE_PRICE_' + plan.toUpperCase());
  if (!price) return { error: `Planul ${plan} nu are preț configurat.` };

  const subId = getIntegrations(accId).stripe?.subscription_id;
  if (subId) {
    const key = cfg('STRIPE_SECRET_KEY');
    try {
      const g = await fetch(`https://api.stripe.com/v1/subscriptions/${subId}`, {
        headers: { Authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(10000),
      });
      const s: any = await g.json().catch(() => ({}));
      const item = s?.items?.data?.[0];
      if (g.ok && item && !['canceled', 'incomplete_expired'].includes(s.status)) {
        if (item.price?.id === price) { applyPlan(accId, plan); return { updated: true }; }
        const form = new URLSearchParams({
          'items[0][id]': item.id,
          'items[0][price]': price,
          proration_behavior: 'always_invoice', // diferența se facturează imediat, prorata
          'metadata[account_id]': accId,
          'metadata[plan]': plan,
        });
        const r = await fetch(`https://api.stripe.com/v1/subscriptions/${subId}`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/x-www-form-urlencoded' },
          body: form.toString(),
          signal: AbortSignal.timeout(10000),
        });
        const data: any = await r.json().catch(() => ({}));
        if (!r.ok) return { error: data?.error?.message || `Stripe ${r.status}` };
        applyPlan(accId, plan);
        setIntegration(accId, 'stripe', { ...getIntegrations(accId).stripe, plan });
        return { updated: true };
      }
      // abonament dispărut/anulat → curățăm referința și facem checkout nou
      setIntegration(accId, 'stripe', null);
    } catch { /* la orice eroare de rețea cădem pe checkout nou */ }
  }
  return createCheckout(accId, plan);
}
