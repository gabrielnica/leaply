import crypto from 'crypto';
import { cfg, appUrl } from './settings';
import { db } from './db';
import { getIntegrations, setIntegration } from './integrations';

// Stripe fără SDK. Env: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
// STRIPE_PRICE_START, STRIPE_PRICE_PRO, STRIPE_PRICE_SCALE, APP_URL.
export const stripeConfigured = () => Boolean(cfg('STRIPE_SECRET_KEY'));

export async function createCheckout(accId: string, plan: 'Start' | 'Pro' | 'Scale'): Promise<{ url?: string; error?: string }> {
  if (!stripeConfigured()) return { error: 'Plățile nu sunt încă activate. Scrie-ne la salut@leaply.ro și îți activăm planul manual.' };
  const price = cfg('STRIPE_PRICE_' + plan.toUpperCase());
  if (!price) return { error: `Planul ${plan} nu are preț configurat.` };
  const base = appUrl();
  const form = new URLSearchParams({
    mode: 'subscription',
    'line_items[0][price]': price,
    'line_items[0][quantity]': '1',
    success_url: `${base}/app/settings?billing=success`,
    cancel_url: `${base}/app/settings?billing=cancel`,
    client_reference_id: accId,
    'metadata[account_id]': accId,
    'metadata[plan]': plan,
    // metadata și PE SUBSCRIPȚIE — altfel evenimentele customer.subscription.* vin fără account_id
    'subscription_data[metadata][account_id]': accId,
    'subscription_data[metadata][plan]': plan,
  });
  const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${cfg('STRIPE_SECRET_KEY')}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
    signal: AbortSignal.timeout(10000),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) return { error: data?.error?.message || `Stripe ${r.status}` };
  return { url: data.url };
}

/** Verifică semnătura Stripe (schema t=...,v1=...) și întoarce evenimentul sau null. */
export function verifyStripeEvent(rawBody: string, sigHeader: string | null): any | null {
  const secret = cfg('STRIPE_WEBHOOK_SECRET');
  if (!secret || !sigHeader) return null;
  try {
    const parts = Object.fromEntries(sigHeader.split(',').map(kv => kv.split('=') as [string, string]));
    const expected = crypto.createHmac('sha256', secret).update(`${parts.t}.${rawBody}`).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(parts.v1 || ''))) return null;
    if (Math.abs(Date.now() / 1000 - Number(parts.t)) > 600) return null;
    return JSON.parse(rawBody);
  } catch { return null; }
}

export function applyPlan(accId: string, plan: string) {
  db().prepare('UPDATE accounts SET plan=? WHERE id=?').run(plan, accId);
  // multi-locație: locațiile moștenesc planul contului-părinte (un singur abonament)
  try { db().prepare('UPDATE accounts SET plan=? WHERE parent_id=?').run(plan, accId); } catch { /* best-effort */ }
}

/** Citește data următoarei reînnoiri (current_period_end) a unui abonament. Best-effort. */
export async function fetchSubscriptionMeta(subId: string): Promise<{ renews_at: string | null; status?: string }> {
  if (!subId || !stripeConfigured()) return { renews_at: null };
  try {
    const r = await fetch(`https://api.stripe.com/v1/subscriptions/${subId}`, {
      headers: { Authorization: `Bearer ${cfg('STRIPE_SECRET_KEY')}` }, signal: AbortSignal.timeout(10000),
    });
    const s: any = await r.json().catch(() => ({}));
    if (!r.ok) return { renews_at: null };
    return { renews_at: s.current_period_end ? new Date(s.current_period_end * 1000).toISOString() : null, status: s.status };
  } catch { return { renews_at: null }; }
}

/**
 * Schimbarea planului, corect și la MIJLOCUL LUNII:
 * - dacă contul are deja un abonament Stripe activ → actualizăm abonamentul existent
 *   (proration_behavior=always_invoice: Stripe facturează/creditează automat diferența
 *   pe zilele rămase — clientul NU plătește două abonamente);
 * - altfel (trial sau abonament anulat) → checkout nou.
 */
export async function changePlan(accId: string, plan: 'Start' | 'Pro' | 'Scale'): Promise<{ url?: string; updated?: boolean; error?: string }> {
  if (!stripeConfigured()) return { error: 'Plățile nu sunt încă activate. Scrie-ne la salut@leaply.ro și îți activăm planul manual.' };
  const price = cfg('STRIPE_PRICE_' + plan.toUpperCase());
  if (!price) return { error: `Planul ${plan} nu are preț configurat.` };

  const subId = getIntegrations(accId).stripe?.subscription_id;
  if (subId) {
    const key = cfg('STRIPE_SECRET_KEY');
    try {
      const g = await fetch(`https://api.stripe.com/v1/subscriptions/${subId}`, {
        headers: { Authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(10000),
      });
      const s: any = await g.json().catch(() => ({}));
      const item = s?.items?.data?.[0];
      if (g.ok && item && !['canceled', 'incomplete_expired'].includes(s.status)) {
        if (item.price?.id === price) { applyPlan(accId, plan); return { updated: true }; }
        const form = new URLSearchParams({
          'items[0][id]': item.id,
          'items[0][price]': price,
          proration_behavior: 'always_invoice', // diferența se facturează imediat, prorata
          'metadata[account_id]': accId,
          'metadata[plan]': plan,
        });
        const r = await fetch(`https://api.stripe.com/v1/subscriptions/${subId}`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/x-www-form-urlencoded' },
          body: form.toString(),
          signal: AbortSignal.timeout(10000),
        });
        const data: any = await r.json().catch(() => ({}));
        if (!r.ok) return { error: data?.error?.message || `Stripe ${r.status}` };
        applyPlan(accId, plan);
        setIntegration(accId, 'stripe', { ...getIntegrations(accId).stripe, plan });
        return { updated: true };
      }
      // abonament dispărut/anulat → curățăm referința și facem checkout nou
      setIntegration(accId, 'stripe', null);
    } catch { /* la orice eroare de rețea cădem pe checkout nou */ }
  }
  return createCheckout(accId, plan);
}

/* ================= Add-on-uri (Extra resurse) — subscription items pe abonamentul existent =================
   Prețurile Stripe se creează AUTOMAT la prima folosire (din cheia stocată) și se salvează în settings. */

const ADDON_DEFS: Record<string, { unit: number; settingsKey: string; name: string; amountCents: number }> = {
  conv: { unit: 200, settingsKey: 'STRIPE_PRICE_ADDON_CONV', name: 'Leaply Extra — +200 conversații/lună', amountCents: 1900 },
  voice_min: { unit: 100, settingsKey: 'STRIPE_PRICE_ADDON_VOICE', name: 'Leaply Extra — +100 minute agent vocal/lună', amountCents: 2900 },
  sms: { unit: 500, settingsKey: 'STRIPE_PRICE_ADDON_SMS', name: 'Leaply Extra — +500 SMS/lună', amountCents: 2900 },
  numbers: { unit: 1, settingsKey: 'STRIPE_PRICE_ADDON_NUMBER', name: 'Leaply Extra — număr suplimentar (locație/brand)', amountCents: 1200 },
};

const saveSettingRaw = (key: string, value: string) =>
  db().prepare('INSERT INTO settings (key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at')
    .run(key, value, new Date().toISOString());

async function stripePost(path: string, form: URLSearchParams): Promise<any> {
  const r = await fetch(`https://api.stripe.com/v1/${path}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${cfg('STRIPE_SECRET_KEY')}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
    signal: AbortSignal.timeout(12000),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data?.error?.message || `Stripe ${r.status}`);
  return data;
}
async function stripeGet(path: string): Promise<any> {
  const r = await fetch(`https://api.stripe.com/v1/${path}`, {
    headers: { Authorization: `Bearer ${cfg('STRIPE_SECRET_KEY')}` }, signal: AbortSignal.timeout(12000),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data?.error?.message || `Stripe ${r.status}`);
  return data;
}
async function stripeDelete(path: string): Promise<any> {
  const r = await fetch(`https://api.stripe.com/v1/${path}`, {
    method: 'DELETE', headers: { Authorization: `Bearer ${cfg('STRIPE_SECRET_KEY')}` }, signal: AbortSignal.timeout(12000),
  });
  return r.json().catch(() => ({}));
}

/** Creează (o singură dată) produsele/prețurile de add-on în Stripe și le ține minte în settings. */
export async function ensureAddonPrices(): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  for (const [kind, def] of Object.entries(ADDON_DEFS)) {
    let priceId = cfg(def.settingsKey);
    if (!priceId) {
      const product = await stripePost('products', new URLSearchParams({ name: def.name }));
      const price = await stripePost('prices', new URLSearchParams({
        product: product.id, currency: 'eur', unit_amount: String(def.amountCents), 'recurring[interval]': 'month',
      }));
      priceId = price.id;
      saveSettingRaw(def.settingsKey, priceId);
      console.log(`[stripe addons] creat ${def.settingsKey}=${priceId}`);
    }
    out[kind] = priceId;
  }
  return out;
}

/** Sincronizează subscription items cu add-on-urile setate (cantități = pachete). Prorare automată. */
export async function syncAddonItems(accId: string, addons: { conv: number; sms: number; voice_min: number; numbers: number }): Promise<{ ok: boolean; billed?: string[]; error?: string }> {
  try {
    if (!stripeConfigured()) return { ok: false, error: 'Stripe neconfigurat' };
    const subId = getIntegrations(accId).stripe?.subscription_id;
    if (!subId) return { ok: false, error: 'Contul nu are abonament Stripe activ — add-on-urile rămân doar ca limite (facturare manuală).' };
    const prices = await ensureAddonPrices();
    const sub = await stripeGet(`subscriptions/${subId}`);
    if (!sub?.items?.data || ['canceled', 'incomplete_expired'].includes(sub.status)) return { ok: false, error: 'Abonamentul nu e activ.' };
    const billed: string[] = [];
    for (const [kind, def] of Object.entries(ADDON_DEFS)) {
      const qty = Math.ceil(((addons as any)[kind] || 0) / def.unit);
      const item = sub.items.data.find((it: any) => it.price?.id === prices[kind]);
      if (item && qty === 0) {
        await stripeDelete(`subscription_items/${item.id}?proration_behavior=always_invoice`);
        billed.push(`${kind}: scos`);
      } else if (item && item.quantity !== qty) {
        await stripePost(`subscription_items/${item.id}`, new URLSearchParams({ quantity: String(qty), proration_behavior: 'always_invoice' }));
        billed.push(`${kind}: ${qty}×`);
      } else if (!item && qty > 0) {
        await stripePost('subscription_items', new URLSearchParams({
          subscription: subId, price: prices[kind], quantity: String(qty), proration_behavior: 'always_invoice',
        }));
        billed.push(`${kind}: ${qty}×`);
      }
    }
    return { ok: true, billed };
  } catch (e) {
    return { ok: false, error: String(e).slice(0, 200) };
  }
}
