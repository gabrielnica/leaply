// Puntea Twilio Media Streams <-> OpenAI Realtime.
// Audio g711_ulaw 8kHz în AMBELE direcții (fără transcodare = latență minimă).
// Barge-in: când apelantul vorbește peste agent, tăiem redarea instant.
const WebSocket = require('ws');
const path = require('path');
const Database = require('better-sqlite3');

let _db = null;
function db() {
  if (_db) return _db;
  _db = new Database(process.env.LEAPLY_DB_PATH || path.join(process.cwd(), 'data', 'leaply.db'));
  return _db;
}
function cfg(key) {
  try {
    const row = db().prepare('SELECT value FROM settings WHERE key=?').get(key);
    if (row && row.value) return row.value;
  } catch {}
  return process.env[key] || '';
}
const uid = p => p + Math.random().toString(36).slice(2, 10);

function accountConfig(accId) {
  try {
    const a = db().prepare('SELECT name, config FROM accounts WHERE id=?').get(accId);
    return a ? { name: a.name, ...(JSON.parse(a.config || '{}')) } : null;
  } catch { return null; }
}

function instructionsFor(c) {
  const svc = (c.services || []).map(s => `- ${s.name}: ${s.price}`).join('\n');
  const slots = (c.bookingSlots || []).slice(0, 2).join(' sau ');
  return `Ești recepționerul vocal al firmei "${c.businessName || c.name}". Vorbești LA TELEFON, în ROMÂNĂ, natural și cald, ca un angajat uman prietenos (nu spune că ești robot decât dacă ești întrebat direct — atunci recunoști sincer că ești asistent digital).
REGULI DE CONVERSAȚIE TELEFONICĂ: propoziții SCURTE (max 2 pe replică), fără liste, fără emoji. O singură întrebare o dată. Confirmă ce ai auzit când notezi date. Dacă apelantul vorbește maghiară sau engleză, treci imediat pe limba lui.
${svc ? 'SERVICII ȘI PREȚURI (doar astea, nu inventa):\n' + svc : ''}
${c.knowledge ? 'DESPRE AFACERE: ' + String(c.knowledge).slice(0, 1200) : ''}
${c.rules ? 'REGULI OBLIGATORII DE LA PATRON (nu le încălca niciodată): ' + c.rules : ''}
SCOPUL TĂU: 1) afli ce dorește, 2) pui 2-3 întrebări de calificare (${(c.qualificationQuestions || []).map(q => q.q).slice(0, 3).join(' / ') || 'nevoie, urgență, zonă'}), 3) propui o programare${slots ? ' (' + slots + ')' : ''}, 4) ceri numele. Numărul de telefon îl avem deja de la apel.
Dacă cere ceva ce nu oferim: refuză politicos și oferă să transmiți un mesaj echipei. La final mulțumește și spune că primește confirmarea pe SMS.`;
}

function attachVoiceBridge(twilioWs) {
  let streamSid = null, accId = null, convId = null, callerLine = [], agentLine = [];
  let openaiWs = null, closed = false;

  const toTwilio = obj => { try { twilioWs.send(JSON.stringify(obj)); } catch {} };
  const toOpenAI = obj => { try { if (openaiWs && openaiWs.readyState === 1) openaiWs.send(JSON.stringify(obj)); } catch {} };

  function startOpenAI(config) {
    const key = cfg('OPENAI_API_KEY');
    if (!key) { console.error('[voice] fără OPENAI_API_KEY — închid'); twilioWs.close(); return; }
    const model = cfg('VOICE_MODEL') || 'gpt-realtime';
    openaiWs = new WebSocket(`wss://api.openai.com/v1/realtime?model=${encodeURIComponent(model)}`, {
      headers: { Authorization: `Bearer ${key}` },
    });
    openaiWs.on('open', () => {
      toOpenAI({
        type: 'session.update',
        session: {
          type: 'realtime',
          output_modalities: ['audio'],
          instructions: instructionsFor(config),
          audio: {
            input: {
              format: { type: 'audio/pcmu' },
              turn_detection: { type: 'server_vad', threshold: 0.5, prefix_padding_ms: 200, silence_duration_ms: 450 },
              transcription: { model: 'whisper-1' },
            },
            output: {
              format: { type: 'audio/pcmu' },
              voice: cfg('VOICE_VOICE') || 'marin',
            },
          },
        },
      });
      // salutul inițial — agentul vorbește primul, imediat
      toOpenAI({ type: 'response.create', response: { instructions: 'Salută scurt și natural: bună ziua, numele firmei, întreabă cu ce poți ajuta. O singură propoziție.' } });
    });
    openaiWs.on('message', raw => {
      let ev; try { ev = JSON.parse(raw.toString()); } catch { return; }
      switch (ev.type) {
        case 'response.audio.delta':
        case 'response.output_audio.delta':
          if (streamSid && ev.delta) toTwilio({ event: 'media', streamSid, media: { payload: ev.delta } });
          break;
        case 'input_audio_buffer.speech_started': // barge-in: apelantul vorbește peste agent
          if (streamSid) toTwilio({ event: 'clear', streamSid });
          toOpenAI({ type: 'response.cancel' });
          break;
        case 'conversation.item.input_audio_transcription.completed':
          if (ev.transcript) callerLine.push(ev.transcript.trim());
          break;
        case 'response.audio_transcript.done':
        case 'response.output_audio_transcript.done':
          if (ev.transcript) agentLine.push(ev.transcript.trim());
          break;
        case 'error':
          console.error('[voice openai]', JSON.stringify(ev.error || ev).slice(0, 300));
          break;
      }
    });
    openaiWs.on('close', () => { if (!closed) twilioWs.close(); });
    openaiWs.on('error', e => console.error('[voice openai ws]', String(e).slice(0, 150)));
  }

  twilioWs.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.event === 'start') {
      streamSid = msg.start.streamSid;
      const params = msg.start.customParameters || {};
      accId = params.account || 'acc_demo';
      convId = params.conv || null;
      const config = accountConfig(accId) || { businessName: 'firma noastră' };
      console.log(`[voice] apel pornit — cont ${accId}, conv ${convId}`);
      startOpenAI(config);
    } else if (msg.event === 'media') {
      toOpenAI({ type: 'input_audio_buffer.append', audio: msg.media.payload });
    } else if (msg.event === 'stop') {
      twilioWs.close();
    }
  });

  twilioWs.on('close', () => {
    closed = true;
    try { if (openaiWs) openaiWs.close(); } catch {}
    // transcriptul intră în conversația din inbox
    try {
      if (convId && (callerLine.length || agentLine.length)) {
        const d = db(); const now = () => new Date().toISOString();
        const ins = d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)');
        const n = Math.max(callerLine.length, agentLine.length);
        for (let i = 0; i < n; i++) {
          if (agentLine[i]) ins.run(uid('ms_'), convId, 'out', 'ai', `🗣️ ${agentLine[i]}`, now());
          if (callerLine[i]) ins.run(uid('ms_'), convId, 'in', 'lead', `🗣️ ${callerLine[i]}`, now());
        }
        ins.run(uid('ms_'), convId, 'note', 'system', `Convorbire vocală încheiată (${callerLine.length + agentLine.length} replici, transcrise automat).`, now());
        d.prepare('UPDATE conversations SET updated_at=? WHERE id=?').run(now(), convId);
      }
    } catch (e) { console.error('[voice save]', String(e).slice(0, 150)); }
  });
  twilioWs.on('error', e => console.error('[voice twilio ws]', String(e).slice(0, 150)));
}

module.exports = { attachVoiceBridge };
