// Puntea Twilio Media Streams <-> OpenAI Realtime.
// Audio g711_ulaw 8kHz în AMBELE direcții (fără transcodare = latență minimă).
// Barge-in: când apelantul vorbește peste agent, tăiem redarea instant.
const WebSocket = require('ws');
const path = require('path');
const Database = require('better-sqlite3');

let _db = null;
function db() {
  if (_db) return _db;
  _db = new Database(process.env.LEAPLY_DB_PATH || path.join(process.cwd(), 'data', 'leaply.db'));
  return _db;
}
function cfg(key) {
  try {
    const row = db().prepare('SELECT value FROM settings WHERE key=?').get(key);
    if (row && row.value) return row.value;
  } catch {}
  return process.env[key] || '';
}
const uid = p => p + Math.random().toString(36).slice(2, 10);

function accountConfig(accId) {
  try {
    const a = db().prepare('SELECT name, config FROM accounts WHERE id=?').get(accId);
    return a ? { name: a.name, ...(JSON.parse(a.config || '{}')) } : null;
  } catch { return null; }
}

const isSalesAccount = (accId, c) => accId === 'acc_leaply' || Boolean(c && c.salesMode);

// Memorie per client: dacă numărul a mai sunat/scris, agentul îl salută ca pe un cunoscut.
function callerMemory(accId, phone) {
  if (!phone || phone.length < 6) return '';
  try {
    const rows = db().prepare(`
      SELECT c.status, c.updated_at, l.name FROM conversations c JOIN leads l ON l.id=c.lead_id
      WHERE c.account_id=? AND l.phone=? ORDER BY c.updated_at DESC LIMIT 4`).all(accId, phone);
    if (rows.length <= 1) return ''; // doar conversația curentă
    const n = rows[1] && rows[1].name && !/^(apel|lead|vizitator)/i.test(rows[1].name) ? rows[1].name : '';
    return `\nCLIENT RECURENT${n ? ' — numele: ' + n : ''}: a mai contactat firma de ${rows.length - 1} ${rows.length - 1 === 1 ? 'dată' : 'ori'}, ultima pe ${new Date(rows[1].updated_at).toLocaleDateString('ro-RO')}. Salută-l călduros, ca pe un cunoscut${n ? ', folosindu-i numele' : ''} — nu ca pe un străin.`;
  } catch { return ''; }
}

function instructionsFor(c, sales) {
  const svc = (c.services || []).map(s => `- ${s.name}: ${s.price}`).join('\n');
  const slots = (c.bookingSlots || []).slice(0, 2).join(' sau ');
  const goal = sales
    ? `PRONUNȚIE: numele „Leaply" se pronunță „LIPLI" (nu „leapli", nu „lepli"). Site-ul leaply.ro îl spui mereu „lipli punct ro".
SCOPUL TĂU (ești consultantul prietenos Leaply — apelantul e un potențial CLIENT LEAPLY): 1) răspunzi clar și cu entuziasm calm la întrebările despre produs, DOAR din cunoștințele de mai sus (nu inventa prețuri sau funcții; ce nu știi → salut@leaply.ro), 2) afli cu interes sincer ce afacere are și ce problemă are cu lead-urile — arată-i pe scurt cum l-ar ajuta Leaply concret, pe cazul LUI, 3) DEVREME în conversație (după ce i-ai răspuns la prima întrebare), oferă-te cald să-i creezi contul PE LOC, gratuit, fără card: „dacă vreți, vă fac eu contul acum, în timp ce vorbim — durează un minut și primiți totul pe email". Scopul e să plece din apel cu contul făcut și cu chef să înceapă.
CREAREA CONTULUI LA TELEFON: cere numele, firma și adresa de email. Emailul îl confirmi OBLIGATORIU repetându-l literă cu literă (ex: „g-a-b-i arond firma punct ro — corect?"). Abia după confirmare apelezi funcția create_account. După rezultat: dacă s-a creat → bucură-te cu el: spune-i că emailul de activare e deja trimis (valabil 72 de ore; dacă avem numărul lui, și un SMS), că setează parola dintr-un click și că în cont îl așteaptă un asistent care îl ghidează pas cu pas; dacă emailul are deja cont → îndrumă-l cald spre lipli punct ro slash login sau resetare parolă; dacă a eșuat → cere emailul din nou, fără să-l faci să se simtă vinovat. NU spune că ai creat contul înainte să primești rezultatul funcției. Dacă refuză, nu insista — rămâi util, invită-l să testeze pe lipli punct ro și încheie călduros.`
    : `SCOPUL TĂU: 1) afli ce dorește, 2) pui 2-3 întrebări de calificare (${(c.qualificationQuestions || []).map(q => q.q).slice(0, 3).join(' / ') || 'nevoie, urgență, zonă'}), 3) propui o programare${slots ? ' (' + slots + ')' : ''}, 4) ceri numele. Numărul de telefon îl avem deja de la apel.
Dacă cere ceva ce nu oferim: refuză politicos și oferă să transmiți un mesaj echipei. La final mulțumește și spune că primește confirmarea pe SMS.`;
  return `Ești recepționerul vocal al firmei "${c.businessName || c.name}". Vorbești LA TELEFON, în ROMÂNĂ, natural, cald și zâmbind (se aude în voce), ca un coleg prietenos căruia îi face plăcere să ajute (nu spune că ești robot decât dacă ești întrebat direct — atunci recunoști sincer, cu umor blând, că ești asistent digital${sales ? ' — chiar produsul Leaply în acțiune, cea mai bună demonstrație' : ''}).
REGULI DE CONVERSAȚIE TELEFONICĂ: propoziții SCURTE (max 2 pe replică), ritm alert dar calm, ton pozitiv, fără liste, fără emoji. Mici confirmări umane („sigur", „desigur", „super", „am înțeles") sunt binevenite, cu măsură. Dacă ești întrerupt, oprește-te și ascultă — nu relua ce spuneai. O singură întrebare o dată. Confirmă ce ai auzit când notezi date. Dacă apelantul vorbește maghiară sau engleză, treci imediat pe limba lui.
${svc ? 'SERVICII ȘI PREȚURI (doar astea, nu inventa):\n' + svc : ''}
${c.knowledge ? 'DESPRE AFACERE: ' + String(c.knowledge).slice(0, sales ? 6000 : 1200) : ''}
${c.rules ? 'REGULI OBLIGATORII DE LA PATRON (nu le încălca niciodată): ' + c.rules : ''}
${goal}`;
}

const SIGNUP_TOOL = {
  type: 'function',
  name: 'create_account',
  description: 'Creează contul Leaply al apelantului și îi trimite emailul de activare (link de setare parolă, valabil 72h). Apeleaz-o DOAR după ce apelantul și-a confirmat emailul literă cu literă.',
  parameters: {
    type: 'object',
    properties: {
      email: { type: 'string', description: 'Adresa de email confirmată de apelant' },
      name: { type: 'string', description: 'Numele apelantului' },
      company: { type: 'string', description: 'Numele firmei' },
    },
    required: ['email'],
  },
};

// Transfer la om: agentul face legătura cu patronul în timpul apelului (Twilio <Dial>).
const TRANSFER_TOOL = {
  type: 'function',
  name: 'transfer_to_human',
  description: 'Transferă apelul către un coleg uman. Folosește DOAR când apelantul cere explicit să vorbească cu o persoană, e nemulțumit sau are o problemă pe care nu o poți rezolva. Anunță-l întâi că îl transferi.',
  parameters: { type: 'object', properties: { reason: { type: 'string', description: 'motivul transferului, pe scurt' } }, required: [] },
};

async function transferCall(callSid, toPhone) {
  const sid = cfg('TWILIO_MASTER_SID'), token = cfg('TWILIO_MASTER_TOKEN');
  if (!sid || !token || !callSid || !toPhone) return { ok: false, error: 'transfer indisponibil (lipsesc credențialele sau numărul)' };
  const esc = s => String(s).replace(/[<>&"]/g, '');
  const twiml = `<Response><Say language="ro-RO">Vă fac legătura cu un coleg. Un moment, vă rog.</Say><Dial timeout="25">${esc(toPhone)}</Dial><Say language="ro-RO">Colegul nostru nu a putut prelua apelul. Vă contactăm noi în cel mai scurt timp. O zi bună!</Say></Response>`;
  try {
    const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Calls/${callSid}.json`, {
      method: 'POST',
      headers: {
        Authorization: 'Basic ' + Buffer.from(`${sid}:${token}`).toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({ Twiml: twiml }).toString(),
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) return { ok: false, error: `Twilio ${r.status}` };
    return { ok: true };
  } catch (e) { return { ok: false, error: String(e).slice(0, 120) }; }
}

async function botSignup(args, callerPhone) {
  const port = process.env.PORT || 3000;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api/internal/bot-signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-leaply-key': cfg('CRON_SECRET') },
      body: JSON.stringify({ ...args, phone: callerPhone || '', source: 'voicebot' }),
      signal: AbortSignal.timeout(15000),
    });
    return await r.json();
  } catch (e) {
    console.error('[voice signup]', String(e).slice(0, 150));
    return { ok: false, error: 'eroare tehnică — cere-i să încerce pe leaply.ro/start sau salut@leaply.ro' };
  }
}

function attachVoiceBridge(twilioWs) {
  let streamSid = null, accId = null, convId = null, callerLine = [], agentLine = [], notes = [];
  let openaiWs = null, closed = false, sales = false, callerPhone = '', callStartedAt = 0;
  let callSid = '', transferPhone = ''; // transfer la om în timpul apelului
  // pentru barge-in precis: ce item redăm și de când (timestamp-urile media Twilio, în ms)
  let lastAssistantItem = null, responseStartTs = null, latestMediaTs = 0, responseActive = false;

  const toTwilio = obj => { try { twilioWs.send(JSON.stringify(obj)); } catch {} };
  const toOpenAI = obj => { try { if (openaiWs && openaiWs.readyState === 1) openaiWs.send(JSON.stringify(obj)); } catch {} };

  function startOpenAI(config) {
    const key = cfg('OPENAI_API_KEY');
    if (!key) { console.error('[voice] fără OPENAI_API_KEY — închid'); twilioWs.close(); return; }
    const model = cfg('VOICE_MODEL') || 'gpt-realtime';
    openaiWs = new WebSocket(`wss://api.openai.com/v1/realtime?model=${encodeURIComponent(model)}`, {
      headers: { Authorization: `Bearer ${key}` },
    });
    openaiWs.on('open', () => {
      toOpenAI({
        type: 'session.update',
        session: {
          type: 'realtime',
          output_modalities: ['audio'],
          instructions: instructionsFor(config, sales) + callerMemory(accId, callerPhone)
            + (transferPhone ? ' Dacă apelantul cere să vorbească cu o persoană/un coleg/patronul, folosește uneltele ca să îl transferi.' : ''),
          ...((sales || transferPhone) ? {
            tools: [...(sales ? [SIGNUP_TOOL] : []), ...(transferPhone ? [TRANSFER_TOOL] : [])],
            tool_choice: 'auto',
          } : {}),
          audio: {
            input: {
              format: { type: 'audio/pcmu' },
              turn_detection: { type: 'server_vad', threshold: 0.5, prefix_padding_ms: 200, silence_duration_ms: 300, create_response: true, interrupt_response: true },
              transcription: { model: 'whisper-1' },
            },
            output: {
              format: { type: 'audio/pcmu' },
              voice: cfg('VOICE_VOICE') || 'marin',
            },
          },
        },
      });
      // salutul inițial — agentul vorbește primul, imediat
      toOpenAI({
        type: 'response.create',
        response: {
          instructions: sales
            ? 'Salută cald și cu energie bună, ca un om căruia îi face plăcere apelul: „Bună ziua, ați sunat la Leaply — mă bucur să vă aud!" (Leaply se pronunță LIPLI). Apoi întreabă prietenos cu ce poți ajuta. Maxim două propoziții scurte.'
            : 'Salută cald și natural, ca un coleg prietenos: bună ziua + numele firmei + „cu ce vă pot ajuta?". Ton zâmbitor, maxim două propoziții scurte.',
        },
      });
    });
    openaiWs.on('message', raw => {
      let ev; try { ev = JSON.parse(raw.toString()); } catch { return; }
      switch (ev.type) {
        case 'response.audio.delta':
        case 'response.output_audio.delta':
          if (streamSid && ev.delta) {
            if (responseStartTs === null) responseStartTs = latestMediaTs; // începe redarea acestui răspuns
            if (ev.item_id) lastAssistantItem = ev.item_id;
            responseActive = true;
            toTwilio({ event: 'media', streamSid, media: { payload: ev.delta } });
          }
          break;
        case 'input_audio_buffer.speech_started': { // barge-in: apelantul vorbește peste agent
          if (streamSid) toTwilio({ event: 'clear', streamSid }); // golim instant bufferul Twilio
          if (responseActive) toOpenAI({ type: 'response.cancel' });
          // spunem modelului exact cât s-a auzit din replica lui — conversația rămâne coerentă
          if (lastAssistantItem && responseStartTs !== null) {
            const heardMs = Math.max(0, latestMediaTs - responseStartTs);
            toOpenAI({ type: 'conversation.item.truncate', item_id: lastAssistantItem, content_index: 0, audio_end_ms: heardMs });
          }
          lastAssistantItem = null; responseStartTs = null; responseActive = false;
          break;
        }
        case 'response.done':
          responseActive = false; responseStartTs = null;
          break;
        case 'response.output_item.done': { // tool call: creare cont / transfer la om
          const item = ev.item;
          if (item && item.type === 'function_call' && item.name === 'transfer_to_human') {
            let targs = {}; try { targs = JSON.parse(item.arguments || '{}'); } catch {}
            console.log(`[voice] transfer_to_human (apel ${accId}, motiv: ${targs.reason || '-'})`);
            transferCall(callSid, transferPhone).then(result => {
              notes.push(result.ok
                ? `📞 Apel transferat către ${transferPhone}${targs.reason ? ` (motiv: ${targs.reason})` : ''}.`
                : `⚠️ Transfer eșuat: ${result.error}`);
              if (!result.ok) { // spunem modelului că nu a mers — continuă conversația elegant
                toOpenAI({ type: 'conversation.item.create', item: { type: 'function_call_output', call_id: item.call_id, output: JSON.stringify({ ok: false, spune: 'Transferul nu e disponibil acum. Cere-i numărul și promite că un coleg îl sună înapoi în câteva minute.' }) } });
                toOpenAI({ type: 'response.create' });
              }
              // dacă a mers, Twilio preia apelul cu <Dial> — stream-ul se închide singur
            });
            break;
          }
          if (sales && item && item.type === 'function_call' && item.name === 'create_account') {
            let args = {}; try { args = JSON.parse(item.arguments || '{}'); } catch {}
            console.log(`[voice] create_account pentru ${args.email || '?'} (apel ${accId})`);
            botSignup(args, callerPhone).then(result => {
              notes.push(result && result.created
                ? `✅ Cont creat în timpul apelului pentru ${result.email} — email de activare trimis.`
                : result && result.exists
                  ? `ℹ️ Apelantul are deja cont (${result.email}).`
                  : `⚠️ Creare cont eșuată: ${(result && result.error) || 'necunoscut'}`);
              toOpenAI({ type: 'conversation.item.create', item: { type: 'function_call_output', call_id: item.call_id, output: JSON.stringify(result) } });
              toOpenAI({ type: 'response.create' });
            });
          }
          break;
        }
        case 'conversation.item.input_audio_transcription.completed':
          if (ev.transcript) callerLine.push(ev.transcript.trim());
          break;
        case 'response.audio_transcript.done':
        case 'response.output_audio_transcript.done':
          if (ev.transcript) agentLine.push(ev.transcript.trim());
          break;
        case 'error': {
          const msgt = JSON.stringify(ev.error || ev);
          if (!/cancellation failed|no active response|already shorter/i.test(msgt)) console.error('[voice openai]', msgt.slice(0, 300));
          break;
        }
      }
    });
    openaiWs.on('close', () => { if (!closed) twilioWs.close(); });
    openaiWs.on('error', e => console.error('[voice openai ws]', String(e).slice(0, 150)));
  }

  twilioWs.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.event === 'start') {
      streamSid = msg.start.streamSid;
      const params = msg.start.customParameters || {};
      accId = params.account || 'acc_demo';
      convId = params.conv || null;
      callerPhone = params.from || '';
      callSid = params.callSid || '';
      callStartedAt = Date.now();
      const config = accountConfig(accId) || { businessName: 'firma noastră' };
      transferPhone = (callSid && cfg('TWILIO_MASTER_SID') && cfg('TWILIO_MASTER_TOKEN'))
        ? String(config.transferPhone || config.ownerPhone || '').replace(/[^\d+]/g, '') : '';
      if (transferPhone && !/^\+?\d{8,}$/.test(transferPhone)) transferPhone = '';
      sales = isSalesAccount(accId, config);
      console.log(`[voice] apel pornit — cont ${accId}, conv ${convId}`);
      startOpenAI(config);
    } else if (msg.event === 'media') {
      if (msg.media.timestamp) latestMediaTs = Number(msg.media.timestamp) || latestMediaTs;
      toOpenAI({ type: 'input_audio_buffer.append', audio: msg.media.payload });
    } else if (msg.event === 'stop') {
      twilioWs.close();
    }
  });

  twilioWs.on('close', () => {
    closed = true;
    try { if (openaiWs) openaiWs.close(); } catch {}
    // contorizăm minutele de agent vocal (plafon lunar per plan, verificat la începutul apelului)
    try {
      if (accId && callStartedAt) {
        const mins = Math.max(1, Math.ceil((Date.now() - callStartedAt) / 60000));
        const month = new Date().toISOString().slice(0, 7);
        db().prepare(`INSERT INTO usage_counters (account_id, month, kind, n) VALUES (?,?, 'voice_min', ?)
          ON CONFLICT(account_id, month, kind) DO UPDATE SET n = n + excluded.n`).run(accId, month, mins);
      }
    } catch (e) { console.error('[voice minutes]', String(e).slice(0, 120)); }
    // transcriptul intră în conversația din inbox
    try {
      if (convId && (callerLine.length || agentLine.length)) {
        const d = db(); const now = () => new Date().toISOString();
        const ins = d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)');
        const n = Math.max(callerLine.length, agentLine.length);
        for (let i = 0; i < n; i++) {
          if (agentLine[i]) ins.run(uid('ms_'), convId, 'out', 'ai', `🗣️ ${agentLine[i]}`, now());
          if (callerLine[i]) ins.run(uid('ms_'), convId, 'in', 'lead', `🗣️ ${callerLine[i]}`, now());
        }
        notes.forEach(t => ins.run(uid('ms_'), convId, 'note', 'system', t, now()));
        ins.run(uid('ms_'), convId, 'note', 'system', `Convorbire vocală încheiată (${callerLine.length + agentLine.length} replici, transcrise automat).`, now());
        d.prepare('UPDATE conversations SET updated_at=? WHERE id=?').run(now(), convId);
      }
    } catch (e) { console.error('[voice save]', String(e).slice(0, 150)); }
  });
  twilioWs.on('error', e => console.error('[voice twilio ws]', String(e).slice(0, 150)));
}

module.exports = { attachVoiceBridge };
