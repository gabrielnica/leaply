// Puntea Twilio Media Streams <-> OpenAI Realtime.
// Audio g711_ulaw 8kHz în AMBELE direcții (fără transcodare = latență minimă).
// Barge-in: când apelantul vorbește peste agent, tăiem redarea instant.
const WebSocket = require('ws');
const path = require('path');
const Database = require('better-sqlite3');

let _db = null;
function db() {
  if (_db) return _db;
  _db = new Database(process.env.LEAPLY_DB_PATH || path.join(process.cwd(), 'data', 'leaply.db'));
  return _db;
}
function cfg(key) {
  try {
    const row = db().prepare('SELECT value FROM settings WHERE key=?').get(key);
    if (row && row.value) return row.value;
  } catch {}
  return process.env[key] || '';
}
const uid = p => p + Math.random().toString(36).slice(2, 10);

function accountConfig(accId) {
  try {
    const a = db().prepare('SELECT name, config FROM accounts WHERE id=?').get(accId);
    return a ? { name: a.name, ...(JSON.parse(a.config || '{}')) } : null;
  } catch { return null; }
}

const isSalesAccount = (accId, c) => accId === 'acc_leaply' || Boolean(c && c.salesMode);

function instructionsFor(c, sales) {
  const svc = (c.services || []).map(s => `- ${s.name}: ${s.price}`).join('\n');
  const slots = (c.bookingSlots || []).slice(0, 2).join(' sau ');
  const goal = sales
    ? `SCOPUL TĂU (ești consultantul de vânzări Leaply — apelantul e un potențial CLIENT LEAPLY): 1) răspunzi clar la întrebările despre produs, DOAR din cunoștințele de mai sus (nu inventa prețuri sau funcții; ce nu știi → salut@leaply.ro), 2) afli ce afacere are și ce problemă are cu lead-urile, 3) îi propui să-i creezi contul PE LOC, gratuit, fără card — primește imediat emailul de activare.
CREAREA CONTULUI LA TELEFON: cere numele, firma și adresa de email. Emailul îl confirmi OBLIGATORIU repetându-l literă cu literă (ex: „g-a-b-i arond firma punct ro — corect?"). Abia după confirmare apelezi funcția create_account. După rezultat: dacă s-a creat → spune-i că are emailul de activare (valabil 72 de ore) și, dacă avem numărul lui, și un SMS; dacă emailul are deja cont → îndrumă-l spre leaply punct ro slash login sau resetare parolă; dacă a eșuat → cere emailul din nou. NU spune că ai creat contul înainte să primești rezultatul funcției. Nu insista dacă refuză — rămâi util și încheie politicos, cu invitația de a testa pe leaply.ro.`
    : `SCOPUL TĂU: 1) afli ce dorește, 2) pui 2-3 întrebări de calificare (${(c.qualificationQuestions || []).map(q => q.q).slice(0, 3).join(' / ') || 'nevoie, urgență, zonă'}), 3) propui o programare${slots ? ' (' + slots + ')' : ''}, 4) ceri numele. Numărul de telefon îl avem deja de la apel.
Dacă cere ceva ce nu oferim: refuză politicos și oferă să transmiți un mesaj echipei. La final mulțumește și spune că primește confirmarea pe SMS.`;
  return `Ești recepționerul vocal al firmei "${c.businessName || c.name}". Vorbești LA TELEFON, în ROMÂNĂ, natural și cald, ca un angajat uman prietenos (nu spune că ești robot decât dacă ești întrebat direct — atunci recunoști sincer că ești asistent digital${sales ? ' — chiar produsul Leaply în acțiune' : ''}).
REGULI DE CONVERSAȚIE TELEFONICĂ: propoziții SCURTE (max 2 pe replică), ritm alert dar calm, fără liste, fără emoji. Dacă ești întrerupt, oprește-te și ascultă — nu relua ce spuneai. O singură întrebare o dată. Confirmă ce ai auzit când notezi date. Dacă apelantul vorbește maghiară sau engleză, treci imediat pe limba lui.
${svc ? 'SERVICII ȘI PREȚURI (doar astea, nu inventa):\n' + svc : ''}
${c.knowledge ? 'DESPRE AFACERE: ' + String(c.knowledge).slice(0, sales ? 6000 : 1200) : ''}
${c.rules ? 'REGULI OBLIGATORII DE LA PATRON (nu le încălca niciodată): ' + c.rules : ''}
${goal}`;
}

const SIGNUP_TOOL = {
  type: 'function',
  name: 'create_account',
  description: 'Creează contul Leaply al apelantului și îi trimite emailul de activare (link de setare parolă, valabil 72h). Apeleaz-o DOAR după ce apelantul și-a confirmat emailul literă cu literă.',
  parameters: {
    type: 'object',
    properties: {
      email: { type: 'string', description: 'Adresa de email confirmată de apelant' },
      name: { type: 'string', description: 'Numele apelantului' },
      company: { type: 'string', description: 'Numele firmei' },
    },
    required: ['email'],
  },
};

async function botSignup(args, callerPhone) {
  const port = process.env.PORT || 3000;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api/internal/bot-signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-leaply-key': cfg('CRON_SECRET') },
      body: JSON.stringify({ ...args, phone: callerPhone || '', source: 'voicebot' }),
      signal: AbortSignal.timeout(15000),
    });
    return await r.json();
  } catch (e) {
    console.error('[voice signup]', String(e).slice(0, 150));
    return { ok: false, error: 'eroare tehnică — cere-i să încerce pe leaply.ro/start sau salut@leaply.ro' };
  }
}

function attachVoiceBridge(twilioWs) {
  let streamSid = null, accId = null, convId = null, callerLine = [], agentLine = [], notes = [];
  let openaiWs = null, closed = false, sales = false, callerPhone = '';
  // pentru barge-in precis: ce item redăm și de când (timestamp-urile media Twilio, în ms)
  let lastAssistantItem = null, responseStartTs = null, latestMediaTs = 0, responseActive = false;

  const toTwilio = obj => { try { twilioWs.send(JSON.stringify(obj)); } catch {} };
  const toOpenAI = obj => { try { if (openaiWs && openaiWs.readyState === 1) openaiWs.send(JSON.stringify(obj)); } catch {} };

  function startOpenAI(config) {
    const key = cfg('OPENAI_API_KEY');
    if (!key) { console.error('[voice] fără OPENAI_API_KEY — închid'); twilioWs.close(); return; }
    const model = cfg('VOICE_MODEL') || 'gpt-realtime';
    openaiWs = new WebSocket(`wss://api.openai.com/v1/realtime?model=${encodeURIComponent(model)}`, {
      headers: { Authorization: `Bearer ${key}` },
    });
    openaiWs.on('open', () => {
      toOpenAI({
        type: 'session.update',
        session: {
          type: 'realtime',
          output_modalities: ['audio'],
          instructions: instructionsFor(config, sales),
          ...(sales ? { tools: [SIGNUP_TOOL], tool_choice: 'auto' } : {}),
          audio: {
            input: {
              format: { type: 'audio/pcmu' },
              turn_detection: { type: 'server_vad', threshold: 0.5, prefix_padding_ms: 200, silence_duration_ms: 300, create_response: true, interrupt_response: true },
              transcription: { model: 'whisper-1' },
            },
            output: {
              format: { type: 'audio/pcmu' },
              voice: cfg('VOICE_VOICE') || 'marin',
            },
          },
        },
      });
      // salutul inițial — agentul vorbește primul, imediat
      toOpenAI({ type: 'response.create', response: { instructions: 'Salută scurt și natural: bună ziua, numele firmei, întreabă cu ce poți ajuta. O singură propoziție.' } });
    });
    openaiWs.on('message', raw => {
      let ev; try { ev = JSON.parse(raw.toString()); } catch { return; }
      switch (ev.type) {
        case 'response.audio.delta':
        case 'response.output_audio.delta':
          if (streamSid && ev.delta) {
            if (responseStartTs === null) responseStartTs = latestMediaTs; // începe redarea acestui răspuns
            if (ev.item_id) lastAssistantItem = ev.item_id;
            responseActive = true;
            toTwilio({ event: 'media', streamSid, media: { payload: ev.delta } });
          }
          break;
        case 'input_audio_buffer.speech_started': { // barge-in: apelantul vorbește peste agent
          if (streamSid) toTwilio({ event: 'clear', streamSid }); // golim instant bufferul Twilio
          if (responseActive) toOpenAI({ type: 'response.cancel' });
          // spunem modelului exact cât s-a auzit din replica lui — conversația rămâne coerentă
          if (lastAssistantItem && responseStartTs !== null) {
            const heardMs = Math.max(0, latestMediaTs - responseStartTs);
            toOpenAI({ type: 'conversation.item.truncate', item_id: lastAssistantItem, content_index: 0, audio_end_ms: heardMs });
          }
          lastAssistantItem = null; responseStartTs = null; responseActive = false;
          break;
        }
        case 'response.done':
          responseActive = false; responseStartTs = null;
          break;
        case 'response.output_item.done': { // tool call: creare cont în timpul apelului
          const item = ev.item;
          if (sales && item && item.type === 'function_call' && item.name === 'create_account') {
            let args = {}; try { args = JSON.parse(item.arguments || '{}'); } catch {}
            console.log(`[voice] create_account pentru ${args.email || '?'} (apel ${accId})`);
            botSignup(args, callerPhone).then(result => {
              notes.push(result && result.created
                ? `✅ Cont creat în timpul apelului pentru ${result.email} — email de activare trimis.`
                : result && result.exists
                  ? `ℹ️ Apelantul are deja cont (${result.email}).`
                  : `⚠️ Creare cont eșuată: ${(result && result.error) || 'necunoscut'}`);
              toOpenAI({ type: 'conversation.item.create', item: { type: 'function_call_output', call_id: item.call_id, output: JSON.stringify(result) } });
              toOpenAI({ type: 'response.create' });
            });
          }
          break;
        }
        case 'conversation.item.input_audio_transcription.completed':
          if (ev.transcript) callerLine.push(ev.transcript.trim());
          break;
        case 'response.audio_transcript.done':
        case 'response.output_audio_transcript.done':
          if (ev.transcript) agentLine.push(ev.transcript.trim());
          break;
        case 'error': {
          const msgt = JSON.stringify(ev.error || ev);
          if (!/cancellation failed|no active response|already shorter/i.test(msgt)) console.error('[voice openai]', msgt.slice(0, 300));
          break;
        }
      }
    });
    openaiWs.on('close', () => { if (!closed) twilioWs.close(); });
    openaiWs.on('error', e => console.error('[voice openai ws]', String(e).slice(0, 150)));
  }

  twilioWs.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.event === 'start') {
      streamSid = msg.start.streamSid;
      const params = msg.start.customParameters || {};
      accId = params.account || 'acc_demo';
      convId = params.conv || null;
      callerPhone = params.from || '';
      const config = accountConfig(accId) || { businessName: 'firma noastră' };
      sales = isSalesAccount(accId, config);
      console.log(`[voice] apel pornit — cont ${accId}, conv ${convId}`);
      startOpenAI(config);
    } else if (msg.event === 'media') {
      if (msg.media.timestamp) latestMediaTs = Number(msg.media.timestamp) || latestMediaTs;
      toOpenAI({ type: 'input_audio_buffer.append', audio: msg.media.payload });
    } else if (msg.event === 'stop') {
      twilioWs.close();
    }
  });

  twilioWs.on('close', () => {
    closed = true;
    try { if (openaiWs) openaiWs.close(); } catch {}
    // transcriptul intră în conversația din inbox
    try {
      if (convId && (callerLine.length || agentLine.length)) {
        const d = db(); const now = () => new Date().toISOString();
        const ins = d.prepare('INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)');
        const n = Math.max(callerLine.length, agentLine.length);
        for (let i = 0; i < n; i++) {
          if (agentLine[i]) ins.run(uid('ms_'), convId, 'out', 'ai', `🗣️ ${agentLine[i]}`, now());
          if (callerLine[i]) ins.run(uid('ms_'), convId, 'in', 'lead', `🗣️ ${callerLine[i]}`, now());
        }
        notes.forEach(t => ins.run(uid('ms_'), convId, 'note', 'system', t, now()));
        ins.run(uid('ms_'), convId, 'note', 'system', `Convorbire vocală încheiată (${callerLine.length + agentLine.length} replici, transcrise automat).`, now());
        d.prepare('UPDATE conversations SET updated_at=? WHERE id=?').run(now(), convId);
      }
    } catch (e) { console.error('[voice save]', String(e).slice(0, 150)); }
  });
  twilioWs.on('error', e => console.error('[voice twilio ws]', String(e).slice(0, 150)));
}

module.exports = { attachVoiceBridge };
