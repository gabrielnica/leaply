"use strict";exports.id=1035,exports.ids=[1035],exports.modules={1035:(e,a,i)=>{i.d(a,{O:()=>p,db:()=>s,uid:()=>d});var r=i(5890),t=i.n(r),n=i(2048),o=i.n(n),l=i(5315),u=i.n(l);let c=null;function s(){var e;if(c)return c;let a=process.env.LEAPLY_DB_PATH||u().join(process.cwd(),"data","leaply.db");return o().mkdirSync(u().dirname(a),{recursive:!0}),(c=new(t())(a)).pragma("journal_mode = WAL"),(e=c).exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY, name TEXT, vertical TEXT, plan TEXT,
    avg_deal_value INTEGER, config TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS channels (
    id TEXT PRIMARY KEY, account_id TEXT, type TEXT, status TEXT, label TEXT
  );
  CREATE TABLE IF NOT EXISTS leads (
    id TEXT PRIMARY KEY, account_id TEXT, name TEXT, phone TEXT, source TEXT,
    score TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY, account_id TEXT, lead_id TEXT, channel TEXT, status TEXT,
    first_response_ms INTEGER, qualification TEXT, created_at TEXT, updated_at TEXT
  );
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, conversation_id TEXT, direction TEXT, sender TEXT,
    body TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, account_id TEXT, email TEXT UNIQUE, name TEXT,
    password_hash TEXT, role TEXT DEFAULT 'owner', created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS password_resets (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, used INTEGER DEFAULT 0, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS demo_requests (
    id TEXT PRIMARY KEY, name TEXT, contact TEXT, business TEXT, vertical TEXT,
    status TEXT DEFAULT 'nou', account_id TEXT, created_at TEXT
  );
  `),function(e){let a=a=>{try{e.exec(a)}catch{}};a("ALTER TABLE channels ADD COLUMN credentials TEXT"),a("ALTER TABLE accounts ADD COLUMN integrations TEXT"),a("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)"),a("ALTER TABLE conversations ADD COLUMN summary TEXT"),a("ALTER TABLE users ADD COLUMN email_verified INTEGER DEFAULT 0"),a("CREATE TABLE IF NOT EXISTS email_verifications (token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, used INTEGER DEFAULT 0, created_at TEXT)"),a("ALTER TABLE conversations ADD COLUMN booking_at TEXT"),a("ALTER TABLE conversations ADD COLUMN confirm_sent INTEGER DEFAULT 0"),a("ALTER TABLE conversations ADD COLUMN assigned_to TEXT"),a("ALTER TABLE accounts ADD COLUMN referred_by TEXT"),a("CREATE TABLE IF NOT EXISTS audit_log (id TEXT PRIMARY KEY, actor TEXT, action TEXT, target TEXT, meta TEXT, created_at TEXT)")}(e),0===e.prepare("SELECT COUNT(*) c FROM accounts").get().c&&function(e){let a=new Date().toISOString(),i={id:"acc_demo",name:"Termopane Bihor SRL",vertical:"servicii-casa",plan:"Pro",avg_deal_value:4200,config:JSON.stringify(p),created_at:a};e.prepare("INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at) VALUES (@id,@name,@vertical,@plan,@avg_deal_value,@config,@created_at)").run(i);let r=[{id:d("ch_"),account_id:i.id,type:"whatsapp",status:"connected",label:"WhatsApp Business +40 741 000 000"},{id:d("ch_"),account_id:i.id,type:"meta_lead_ads",status:"connected",label:"Facebook: Termopane Bihor"},{id:d("ch_"),account_id:i.id,type:"messenger",status:"connected",label:"Messenger: Termopane Bihor"},{id:d("ch_"),account_id:i.id,type:"instagram",status:"pending",label:"Instagram: @termopane.bihor"},{id:d("ch_"),account_id:i.id,type:"webform",status:"connected",label:"Formular site termopanebihor.ro"},{id:d("ch_"),account_id:i.id,type:"calendar",status:"connected",label:"Google Calendar"}],t=e.prepare("INSERT INTO channels (id,account_id,type,status,label) VALUES (@id,@account_id,@type,@status,@label)");r.forEach(e=>t.run(e));let n=e.prepare("INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)"),o=e.prepare("INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)"),l=e.prepare("INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)");[{name:"Maria Pop",phone:"+40 745 112 233",source:"meta_lead_ads",channel:"whatsapp",score:"hot",ms:38e3,msgs:[["in","lead","Bună, aș dori o ofertă pentru termopane la un apartament cu 3 camere."],["out","ai","Bună ziua, Maria! Mulțumim pentru mesaj \uD83D\uDE0A Vă ajut imediat. Apartamentul are 3 camere — c\xe2te ferestre și uși de balcon ar fi de \xeenlocuit, aproximativ?"],["in","lead","5 ferestre și 2 uși de balcon."],["out","ai","Perfect. Pentru ce interval vă doriți montajul — c\xe2t mai repede, \xeen 1-2 luni, sau doar vă informați deocamdată?"],["in","lead","C\xe2t mai repede, avem nevoie p\xe2nă la iarnă."],["out","ai","Am \xeențeles, vă putem programa o măsurătoare gratuită. Aveți disponibilitate joi la 16:00 sau vineri la 10:00?"],["in","lead","Joi la 16:00 e perfect."],["out","ai","Excelent! Am notat: măsurătoare joi, ora 16:00. Un coleg vă confirmă adresa. Vă mulțumim, Maria! \uD83D\uDE4C"]],qual:{buget:"5 ferestre + 2 uși",urgenta:"p\xe2nă la iarnă",programare:"Joi 16:00"}},{name:"Andrei Ionescu",phone:"+40 722 908 100",source:"webform",channel:"whatsapp",score:"warm",ms:45e3,msgs:[["in","lead","Salut, c\xe2t ar costa niște geamuri pentru o casă?"],["out","ai","Salut, Andrei! Depinde de dimensiuni și număr. C\xe2te ferestre are casa și știi aproximativ dimensiunile?"],["in","lead","Nu sunt sigur, vreo 8 ferestre. Mă mai g\xe2ndesc."],["out","ai","Nicio problemă! \xceți putem face o ofertă exactă după o măsurătoare gratuită, fără obligații. Vrei să-ți propun o dată orientativă?"]],qual:{buget:"~8 ferestre",urgenta:"se informează",programare:"\xeen așteptare"}},{name:"Elena Radu",phone:"+40 733 445 566",source:"messenger",channel:"messenger",score:"hot",ms:29e3,msgs:[["in","lead","Bună seara, vreau să schimb toate geamurile la o casă nouă. Puteți veni la măsurat?"],["out","ai","Bună seara, Elena! Sigur că da. Casa este finalizată și gata de montaj, sau \xeencă \xeen construcție?"],["in","lead","Gata, ne mutăm luna viitoare."],["out","ai","Minunat! Vă propun o măsurătoare gratuită. Luni la 11:00 sau marți la 17:00 v-ar conveni?"],["in","lead","Marți la 17:00."],["out","ai","Am rezervat marți, 17:00. Vă confirmăm \xeen scurt timp. Mulțumim, Elena! \uD83C\uDFE1"]],qual:{buget:"casă \xeentreagă",urgenta:"mutare luna viitoare",programare:"Marți 17:00"}},{name:"Vasile M.",phone:"+40 744 221 009",source:"meta_lead_ads",channel:"whatsapp",score:"cold",ms:41e3,msgs:[["in","lead","Aveți și uși de interior?"],["out","ai","Bună ziua! Momentan lucrăm cu ferestre și uși de exterior din PVC și aluminiu. Pentru uși de interior nu avem ofertă, dar vă pot pune \xeen legătură cu un coleg dacă doriți."],["in","lead","Nu, mulțumesc."]],qual:{buget:"-",urgenta:"-",programare:"necalificat"}}].forEach((e,a)=>{let r=new Date(Date.now()-(a+1)*216e5).toISOString(),t=d("ld_"),u=d("cv_"),c="cold"===e.score?"lost":e.qual.programare&&e.qual.programare.match(/\d/)?"booked":"qualified";n.run(t,i.id,e.name,e.phone,e.source,e.score,r),o.run(u,i.id,t,e.channel,c,e.ms,JSON.stringify(e.qual),r,r),e.msgs.forEach((e,a)=>l.run(d("ms_"),u,e[0],e[1],e[2],new Date(new Date(r).getTime()+6e4*a).toISOString()))})}(e),function(e){if(e.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get().c>0)return;let a=process.env.ADMIN_PASSWORD;if(!a){console.warn("[leaply] Niciun admin creat — setează ADMIN_PASSWORD și repornește.");return}let r=i(4770),t=r.randomBytes(16).toString("hex"),n=r.scryptSync(a,t,64).toString("hex");e.prepare("INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)").run(d("us_"),"acc_demo","salut@gabrielnica.ro","Gabriel",`s1$${t}$${n}`,"admin",new Date().toISOString()),console.log("[leaply] Admin creat: salut@gabrielnica.ro (parola din ADMIN_PASSWORD).")}(e),function(e){try{let a=e.prepare("SELECT config FROM accounts WHERE id='acc_leaply'").get();if(!a)return;let{LEAPLY_KNOWLEDGE:r,LEAPLY_SALES_RULES:t}=i(2388),n={...JSON.parse(a.config||"{}"),knowledge:r,rules:t,salesMode:!0};e.prepare("UPDATE accounts SET config=? WHERE id='acc_leaply'").run(JSON.stringify(n))}catch(e){console.error("[leaply kb sync]",String(e).slice(0,150))}}(e),c}function d(e=""){return e+Math.random().toString(36).slice(2,10)+Date.now().toString(36).slice(-4)}let p={businessName:"Termopane Bihor",vertical:"servicii-casa",tone:"prietenos",welcome:"Bună ziua! Mulțumim pentru mesaj \uD83D\uDE0A Sunt asistentul Termopane Bihor și vă ajut imediat.",services:[{name:"Ferestre PVC",price:"de la 750 lei/buc"},{name:"Ferestre aluminiu",price:"ofertă la măsurătoare"},{name:"Uși de exterior",price:"de la 2.500 lei"}],qualificationQuestions:[{key:"buget",q:"Aproximativ c\xe2te ferestre / uși ar fi de \xeenlocuit?"},{key:"urgenta",q:"Pentru ce interval vă doriți montajul — c\xe2t mai repede, \xeen 1-2 luni, sau doar vă informați?"},{key:"zona",q:"\xcen ce localitate/zonă este imobilul?"}],bookingSlots:["joi la 16:00","vineri la 10:00"],redFlags:["uși de interior","mobilă","reparații"]}},2388:(e,a,i)=>{i.r(a),i.d(a,{LEAPLY_KNOWLEDGE:()=>r,LEAPLY_ONBOARDING_GUIDE:()=>t,LEAPLY_SALES_RULES:()=>n});let r=`
=== CE ESTE LEAPLY ===
Leaply este un asistent AI de v\xe2nzări pentru afaceri mici și mijlocii din Rom\xe2nia. Răspunde lead-urilor \xeen sub 60 de secunde, 24/7, pe toate canalele, pune \xeentrebări de calificare, propune și fixează programări direct \xeen calendar, și trimite follow-up automat celor care nu răspund. Practic: niciun lead pierdut, fără angajat \xeen plus.
De ce contează: majoritatea firmelor răspund la lead-uri \xeen ore sau deloc; șansa de a califica un lead scade de peste 10 ori dacă răspunzi după 5 minute \xeen loc de 1 minut. Leaply răspunde instant, mereu.
Pentru cine: termopane și t\xe2mplărie, clinici stomatologice, service auto, agenții imobiliare, instalatori, saloane de \xeenfrumusețare — și orice afacere de servicii care primește cereri pe WhatsApp, Facebook, Instagram, site sau telefon.

=== CANALE SUPORTATE ===
- WhatsApp Business — pe numărul clientului (Meta Cloud API sau Twilio) SAU pe un număr oferit de Leaply (zero bătăi de cap, \xeel configurăm noi).
- Facebook Messenger și Instagram DM — conectare cu un singur click („Conectează cu Facebook").
- Facebook Lead Ads — lead-urile din campanii intră automat și primesc mesaj \xeen secunde.
- Chat pe site (widget) — se instalează cu O SINGURĂ linie de cod, fără programator.
- Telefon — agent vocal AI care răspunde la apeluri \xeen rom\xe2nă, natural, califică apelantul și trimite SMS automat; apelantul devine lead \xeen inbox cu transcriptul convorbirii. Număr de telefon oferit de Leaply.
- Google Calendar — AI-ul vede disponibilitatea reală și fixează programările direct \xeen calendar.

=== CUM FUNCȚIONEAZĂ ===
1. Lead-ul scrie sau sună pe orice canal conectat.
2. AI-ul răspunde instant, \xeen limba clientului (rom\xe2nă, maghiară, engleză), cu tonul și datele afacerii tale.
3. Pune 2-3 \xeentrebări de calificare setate de tine (nevoie, urgență, zonă etc.).
4. Propune o programare (sloturi reale din Google Calendar dacă e conectat) și o confirmă.
5. Totul apare \xeen inbox-ul Leaply: conversații, scor lead (hot/warm/cold), rezumat AI, transcript apeluri.
6. Poți prelua oric\xe2nd conversația manual (takeover) — AI-ul se oprește instant.
7. Follow-up automat multi-touch (implicit la 4h / 24h / 72h) pentru lead-urile care nu răspund; SMS de confirmare cu 24h \xeenainte de programare (anti-neprezentare).

=== FUNCȚII INCLUSE ===
Inbox mini-CRM (căutare, filtre, export CSV, asignare pe colegi, echipă cu rol agent), rezumat AI per conversație, notificări pe email și WhatsApp către proprietar la lead-uri fierbinți, import lead-uri din CSV, integrare CRM prin webhook (Zapier/Make), API public REST (documentație pe leaply.ro/developers), configurare AI din date reale: preia datele firmei de la ANAF după CUI și poate citi site-ul firmei ca să \xeenvețe serviciile.

=== PREȚURI (EUR/lună, plată cu cardul, anulezi oric\xe2nd) ===
- Trial GRATUIT: la crearea contului, fără card — include 30 de conversații/lună ca să testezi tot.
- Start — 59 €/lună: 300 de conversații/lună, toate canalele, calificare + programare, follow-up automat.
- Pro — 129 €/lună: 1.000 de conversații/lună, tot ce e \xeen Start + echipă, API, prioritate la suport.
- Scale — 299 €/lună: 3.000 de conversații/lună, pentru volume mari și mai multe locații.
O „conversație" = un schimb de mesaje cu un lead \xeentr-o lună (nu per mesaj). Fără contract pe termen lung, fără taxe de instalare. Plata prin Stripe (card), factura fiscală se emite automat (SmartBill). Un client tipic recuperează abonamentul dintr-un singur lead salvat.

=== ACTIVARE — C\xc2T DE REPEDE PORNEȘTI ===
1. Cont \xeen ~2 minute pe leaply.ro/start (sau \xeel creăm noi pentru tine, prin chat sau telefon, și primești email cu linkul de activare).
2. Wizard-ul de configurare: datele firmei (se pot prelua de la ANAF după CUI), serviciile și prețurile, \xeentrebările de calificare, tonul asistentului — plus un test de chat pe loc.
3. Chat-ul de site e activ imediat (copiezi o linie de cod). Facebook/Instagram se conectează cu un click. Pentru WhatsApp sau număr de telefon, ceri un număr de la Leaply din pagina Canale — de obicei activ \xeen aceeași zi.
Nu ai nevoie de programator sau cunoștințe tehnice pentru nimic din toate astea.

=== SECURITATE & GDPR ===
Datele sunt stocate pe servere \xeen Uniunea Europeană; token-urile și cheile sunt criptate; backup automat zilnic. Conform GDPR — pagini legale pe leaply.ro/termeni, /confidentialitate, /cookies. Operator: ARHAI SRL, CUI RO35913161, Rom\xe2nia.

=== CONTACT & LINKURI ===
Email: salut@leaply.ro \xb7 Telefon (agent AI demo — chiar produsul nostru): 0373 818 737 \xb7 Site: leaply.ro \xb7 Creare cont: leaply.ro/start \xb7 Login: leaply.ro/login \xb7 Documentație API: leaply.ro/developers

=== \xceNTREBĂRI FRECVENTE & OBIECȚII ===
„Sună robotic?" — Nu. Răspunde natural, \xeen limba și tonul afacerii tale, cu diacritice; clienții de obicei nu-și dau seama. Și poți prelua conversația oric\xe2nd.
„C\xe2t durează implementarea?" — Contul: 2 minute. Chat pe site: imediat. Facebook/Instagram: 1 click. WhatsApp/telefon: de obicei \xeen aceeași zi.
„Pot folosi numărul meu de WhatsApp?" — Da, prin Meta Cloud API sau Twilio. Sau primești un număr de la Leaply și nu configurezi nimic.
„Ce limbi vorbește?" — Rom\xe2nă (implicit), maghiară și engleză — detectează automat limba clientului.
„Dacă AI-ul greșește?" — \xcei setezi reguli obligatorii pe care nu le \xeencalcă (ex: nu promite discounturi), nu inventează prețuri (folosește doar lista ta), iar tu poți prelua oric\xe2nd.
„Pot anula?" — Oric\xe2nd, din cont, fără penalități. Răm\xe2i cu datele (export CSV).
„Ce se \xeent\xe2mplă după trial?" — Alegi un plan din cont (Setări & Plan). Dacă nu alegi, contul răm\xe2ne, dar AI-ul nu mai răspunde automat peste limita de trial.
„Aveți discount?" — Prețurile sunt cele publicate; nu oferim discounturi neanunțate. Pentru volume peste Scale, scrie-ne la salut@leaply.ro.
„E greu de configurat?" — Nu: wizard pas cu pas, date preluate de la ANAF, iar \xeen cont ai un asistent AI care te ghidează la fiecare pas.
`.trim(),t=`
GHID DE CONFIGURARE LEAPLY (pentru utilizatori logați \xeen aplicație):

PAGINILE APLICAȚIEI:
- /app — Overview: KPI-uri, grafic 14 zile, checklist de activare (dispare c\xe2nd totul e configurat).
- /app/inbox — toate conversațiile: căutare, filtre pe status/canal, export CSV, import lead-uri CSV, asignare pe colegi.
- /app/config — Configurare AI: numele afacerii, ton, mesaj de bun venit, servicii + prețuri, \xeentrebări de calificare, cunoștințe despre afacere (knowledge), REGULI obligatorii pentru AI, sloturi de programare.
- /app/channels — Canale & Integrări: conectare WhatsApp, Messenger, Instagram, Lead Ads, widget site, telefon, Google Calendar.
- /app/settings — Setări & Plan: planul curent + upgrade (plată card), notificări, webhook CRM, cheie API, echipă, follow-up (cadență), referral.

PAȘII RECOMANDAȚI DUPĂ CREAREA CONTULUI (\xeen ordine):
1. Configurare AI (/app/config): completează serviciile cu prețuri reale (AI-ul NU inventează prețuri — folosește doar ce scrii aici), 2-3 \xeentrebări de calificare, cunoștințe despre afacere (program, zonă de lucru, garanții etc.) și eventuale reguli (ex: „nu promite discounturi").
2. Instalează chat-ul pe site (/app/channels → Formular web → Detalii): copiezi o linie de cod <script src="https://leaply.ro/widget.js" data-leaply="ID_CONT" async></script> \xeenainte de </body> sau \xeen Google Tag Manager. Opțional data-color="#culoare".
3. Conectează Facebook/Instagram (/app/channels → Messenger → „Conectează cu Facebook — un click"): alegi pagina, Messenger și Instagram DM se activează automat.
4. WhatsApp (/app/channels → WhatsApp): recomandat „Cere număr de la Leaply" (noi configurăm tot, de obicei \xeen aceeași zi). Avansat: Meta Cloud API (Phone Number ID + Access token) sau Twilio (Account SID + Auth token + număr).
5. Telefon / agent vocal (/app/channels → Telefon): „Cere număr de telefon de la Leaply" — primești un număr care răspunde cu agentul vocal AI; \xeel pui pe site/anunțuri sau redirecționezi numărul firmei către el.
6. Google Calendar (/app/channels → Google Calendar → Conectează): AI-ul propune doar sloturi libere reale și creează evenimente la programare.
7. Setări (/app/settings): verifică notificările, setează cadența de follow-up, invită colegi (echipă), și c\xe2nd ești gata alege planul potrivit.

PROBLEME FRECVENTE:
- „AI-ul nu răspunde pe site" — verifică dacă scriptul widget e instalat cu ID-ul corect (\xeel vezi \xeen Canale → Formular web → Detalii) și dacă nu ai depășit limita planului (bara de usage din Setări).
- „Conectarea Facebook dă eroare" — re\xeencearcă din /app/channels; dacă persistă, scrie la salut@leaply.ro.
- „Nu primesc email-uri" — verifică spam; adresa expeditoare e salut@leaply.ro.
- „Vreau să schimb răspunsurile AI-ului" — totul se controlează din /app/config (servicii, cunoștințe, reguli, ton).
- „Cum preiau eu conversația?" — deschide conversația din inbox și apasă preluare (takeover); AI-ul se oprește pentru acea conversație.
- Resetare parolă: leaply.ro/forgot. Suport: salut@leaply.ro.
`.trim(),n=`
Nu inventa prețuri, funcții sau termene — folosește DOAR informațiile din baza de cunoștințe; dacă nu știi, spune sincer și oferă salut@leaply.ro.
Nu oferi discounturi sau condiții speciale. Nu vorbi ur\xe2t despre concurenți.
Scopul tău \xeen fiecare conversație: (1) răspunzi clar și scurt la \xeentrebări, (2) afli tipul afacerii și problema cu lead-urile, (3) obții numele, firma și emailul, (4) \xeei propui să-i creezi contul PE LOC — gratuit, fără card — ca să primească linkul de activare pe email.
Nu fi insistent: maxim o propunere de cont per 2-3 schimburi de mesaje; dacă omul refuză clar, răm\xe2i util și politicos.
Dacă persoana are deja cont: \xeendrum-o spre leaply.ro/login sau leaply.ro/forgot pentru parolă, iar pentru probleme spre salut@leaply.ro.
`.trim()}};