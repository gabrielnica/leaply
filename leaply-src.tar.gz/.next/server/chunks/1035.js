"use strict";exports.id=1035,exports.ids=[1035],exports.modules={1035:(e,a,i)=>{i.d(a,{O:()=>p,db:()=>s,uid:()=>d});var n=i(85890),r=i.n(n),t=i(92048),o=i.n(t),c=i(55315),l=i.n(c);let u=null;function s(){var e;if(u)return u;let a=process.env.LEAPLY_DB_PATH||l().join(process.cwd(),"data","leaply.db");return o().mkdirSync(l().dirname(a),{recursive:!0}),(u=new(r())(a)).pragma("journal_mode = WAL"),(e=u).exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY, name TEXT, vertical TEXT, plan TEXT,
    avg_deal_value INTEGER, config TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS channels (
    id TEXT PRIMARY KEY, account_id TEXT, type TEXT, status TEXT, label TEXT
  );
  CREATE TABLE IF NOT EXISTS leads (
    id TEXT PRIMARY KEY, account_id TEXT, name TEXT, phone TEXT, source TEXT,
    score TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY, account_id TEXT, lead_id TEXT, channel TEXT, status TEXT,
    first_response_ms INTEGER, qualification TEXT, created_at TEXT, updated_at TEXT
  );
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, conversation_id TEXT, direction TEXT, sender TEXT,
    body TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, account_id TEXT, email TEXT UNIQUE, name TEXT,
    password_hash TEXT, role TEXT DEFAULT 'owner', created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS password_resets (
    token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, used INTEGER DEFAULT 0, created_at TEXT
  );
  CREATE TABLE IF NOT EXISTS demo_requests (
    id TEXT PRIMARY KEY, name TEXT, contact TEXT, business TEXT, vertical TEXT,
    status TEXT DEFAULT 'nou', account_id TEXT, created_at TEXT
  );
  `),function(e){let a=a=>{try{e.exec(a)}catch{}};a("ALTER TABLE channels ADD COLUMN credentials TEXT"),a("ALTER TABLE accounts ADD COLUMN integrations TEXT"),a("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT)"),a("ALTER TABLE conversations ADD COLUMN summary TEXT"),a("ALTER TABLE users ADD COLUMN email_verified INTEGER DEFAULT 0"),a("CREATE TABLE IF NOT EXISTS email_verifications (token_hash TEXT PRIMARY KEY, user_id TEXT, expires_at TEXT, used INTEGER DEFAULT 0, created_at TEXT)"),a("ALTER TABLE conversations ADD COLUMN booking_at TEXT"),a("ALTER TABLE conversations ADD COLUMN confirm_sent INTEGER DEFAULT 0"),a("ALTER TABLE conversations ADD COLUMN assigned_to TEXT"),a("ALTER TABLE accounts ADD COLUMN referred_by TEXT"),a("CREATE TABLE IF NOT EXISTS audit_log (id TEXT PRIMARY KEY, actor TEXT, action TEXT, target TEXT, meta TEXT, created_at TEXT)"),a("CREATE TABLE IF NOT EXISTS usage_counters (account_id TEXT, month TEXT, kind TEXT, n INTEGER DEFAULT 0, PRIMARY KEY(account_id, month, kind))"),a("ALTER TABLE accounts ADD COLUMN trial_extra INTEGER DEFAULT 0"),a("ALTER TABLE accounts ADD COLUMN suspended INTEGER DEFAULT 0"),a("ALTER TABLE accounts ADD COLUMN parent_id TEXT"),a("ALTER TABLE users ADD COLUMN active_account_id TEXT"),a("ALTER TABLE conversations ADD COLUMN won_value INTEGER"),a("ALTER TABLE messages ADD COLUMN rating INTEGER"),a("CREATE TABLE IF NOT EXISTS knowledge_docs (id TEXT PRIMARY KEY, account_id TEXT, name TEXT, content TEXT, created_at TEXT)"),a("ALTER TABLE users ADD COLUMN last_login TEXT"),a(`CREATE TABLE IF NOT EXISTS device_tokens (
    id TEXT PRIMARY KEY, account_id TEXT, user_id TEXT, platform TEXT,
    token TEXT UNIQUE, created_at TEXT, last_seen TEXT)`),a(`CREATE TABLE IF NOT EXISTS web_push_subs (
    id TEXT PRIMARY KEY, account_id TEXT, user_id TEXT,
    endpoint TEXT UNIQUE, p256dh TEXT, auth TEXT, created_at TEXT, last_seen TEXT)`)}(e),0===e.prepare("SELECT COUNT(*) c FROM accounts").get().c&&function(e){let a=new Date().toISOString(),i={id:"acc_demo",name:"DentArt Studio SRL",vertical:"clinica-privata",plan:"Pro",avg_deal_value:4200,config:JSON.stringify(p),created_at:a};e.prepare("INSERT INTO accounts (id,name,vertical,plan,avg_deal_value,config,created_at) VALUES (@id,@name,@vertical,@plan,@avg_deal_value,@config,@created_at)").run(i);let n=[{id:d("ch_"),account_id:i.id,type:"whatsapp",status:"connected",label:"WhatsApp Business +40 741 000 000"},{id:d("ch_"),account_id:i.id,type:"meta_lead_ads",status:"connected",label:"Facebook: DentArt Studio"},{id:d("ch_"),account_id:i.id,type:"messenger",status:"connected",label:"Messenger: DentArt Studio"},{id:d("ch_"),account_id:i.id,type:"instagram",status:"pending",label:"Instagram: @dentart.studio"},{id:d("ch_"),account_id:i.id,type:"webform",status:"connected",label:"Formular site dentart-studio.ro"},{id:d("ch_"),account_id:i.id,type:"calendar",status:"connected",label:"Google Calendar"}],r=e.prepare("INSERT INTO channels (id,account_id,type,status,label) VALUES (@id,@account_id,@type,@status,@label)");n.forEach(e=>r.run(e));let t=e.prepare("INSERT INTO leads (id,account_id,name,phone,source,score,created_at) VALUES (?,?,?,?,?,?,?)"),o=e.prepare("INSERT INTO conversations (id,account_id,lead_id,channel,status,first_response_ms,qualification,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)"),c=e.prepare("INSERT INTO messages (id,conversation_id,direction,sender,body,created_at) VALUES (?,?,?,?,?,?)");[{name:"Maria Pop",phone:"+40 745 112 233",source:"meta_lead_ads",channel:"whatsapp",score:"hot",ms:38e3,msgs:[["in","lead","Bună ziua, mă interesează un implant dentar. C\xe2t ar costa?"],["out","ai","Bună ziua, Maria! Implantul dentar \xeen pachet complet pornește de la 3.500 lei — prețul exact \xeel stabilim după consultație, unde radiografia 3D e inclusă. Aveți dureri \xeen acest moment, sau e un tratament pe care \xeel planificați?"],["in","lead","Nu am dureri, dar mi-a spus medicul că am nevoie de implant la o măsea."],["out","ai","Am \xeențeles. Ați mai fost pacienta clinicii noastre?"],["in","lead","Nu, ar fi prima dată."],["out","ai","Bine ați venit atunci! Vă pot programa la o consultație cu plan de tratament. V-ar conveni marți la 14:00 sau joi la 11:00?"],["in","lead","Marți la 14:00."],["out","ai","Perfect — v-am programat marți la 14:00. Primiți confirmarea pe SMS. Vă așteptăm cu drag!"]],qual:{nevoie:"implant dentar",urgenta:"planificat",programare:"Marți 14:00"}},{name:"Andrei Ionescu",phone:"+40 722 908 100",source:"webform",channel:"whatsapp",score:"warm",ms:45e3,msgs:[["in","lead","Salut, c\xe2t costă o albire profesională?"],["out","ai","Bună ziua, Andrei! Albirea profesională \xeen cabinet costă 900 lei și durează o singură ședință. Vă g\xe2ndiți la o dată anume?"],["in","lead","Mă mai g\xe2ndesc, poate luna viitoare."],["out","ai","Nicio problemă! Vă pot rezerva un loc orientativ și vă confirmăm cu o săptăm\xe2nă \xeenainte — fără nicio obligație. Vreți?"]],qual:{nevoie:"albire",urgenta:"luna viitoare",programare:"\xeen așteptare"}},{name:"Elena Radu",phone:"+40 733 445 566",source:"messenger",channel:"messenger",score:"hot",ms:29e3,msgs:[["in","lead","Bună seara, mă doare o măsea de ieri. Mă puteți primi urgent?"],["out","ai","Bună seara, Elena! \xcemi pare rău — durerile acute au prioritate la noi. M\xe2ine dimineață la 9:00 vă putem primi. Vă convine?"],["in","lead","Da, vin m\xe2ine la 9."],["out","ai","Programat! M\xe2ine la 9:00, cu consultație și radiografie 3D inclusă. Primiți confirmarea pe SMS. \xcensănătoșire grabnică!"]],qual:{nevoie:"durere acută",urgenta:"urgent",programare:"m\xe2ine 9:00"}},{name:"Vasile M.",phone:"+40 744 221 009",source:"meta_lead_ads",channel:"whatsapp",score:"cold",ms:41e3,msgs:[["in","lead","Faceți și consultații de medicina muncii?"],["out","ai","Bună ziua! Suntem o clinică exclusiv stomatologică, deci medicina muncii nu intră \xeen serviciile noastre. Vă putem recomanda cu drag pe cineva, dacă doriți."],["in","lead","Nu, mulțumesc."]],qual:{nevoie:"-",urgenta:"-",programare:"necalificat"}}].forEach((e,a)=>{let n=new Date(Date.now()-(a+1)*216e5).toISOString(),r=d("ld_"),l=d("cv_"),u="cold"===e.score?"lost":e.qual.programare&&e.qual.programare.match(/\d/)?"booked":"qualified";t.run(r,i.id,e.name,e.phone,e.source,e.score,n),o.run(l,i.id,r,e.channel,u,e.ms,JSON.stringify(e.qual),n,n),e.msgs.forEach((e,a)=>c.run(d("ms_"),l,e[0],e[1],e[2],new Date(new Date(n).getTime()+6e4*a).toISOString()))})}(e),function(e){if(e.prepare("SELECT COUNT(*) c FROM users WHERE role='admin'").get().c>0)return;let a=process.env.ADMIN_PASSWORD;if(!a){console.warn("[leaply] Niciun admin creat — setează ADMIN_PASSWORD și repornește.");return}let n=i(84770),r=n.randomBytes(16).toString("hex"),t=n.scryptSync(a,r,64).toString("hex");e.prepare("INSERT INTO users (id,account_id,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?,?)").run(d("us_"),"acc_demo","salut@gabrielnica.ro","Gabriel",`s1$${r}$${t}`,"admin",new Date().toISOString()),console.log("[leaply] Admin creat: salut@gabrielnica.ro (parola din ADMIN_PASSWORD).")}(e),function(e){try{let a=e.prepare("SELECT config FROM accounts WHERE id='acc_leaply'").get();if(!a)return;let{LEAPLY_KNOWLEDGE:n,LEAPLY_SALES_RULES:r}=i(12388),t={...JSON.parse(a.config||"{}"),knowledge:n,rules:r,salesMode:!0};e.prepare("UPDATE accounts SET config=?, plan='Scale' WHERE id='acc_leaply'").run(JSON.stringify(t))}catch(e){console.error("[leaply kb sync]",String(e).slice(0,150))}}(e),function(e){try{let a=e.prepare("SELECT config FROM accounts WHERE id='acc_demo'").get();if(!a)return;let i=JSON.parse(a.config||"{}");if("Termopane Bihor"!==i.businessName)return;e.prepare("UPDATE accounts SET name=?, vertical=?, config=? WHERE id='acc_demo'").run("DentArt Studio SRL",p.vertical,JSON.stringify(p)),e.prepare("UPDATE channels SET label=REPLACE(REPLACE(REPLACE(label,'Termopane Bihor','DentArt Studio'),'termopanebihor.ro','dentart-studio.ro'),'@termopane.bihor','@dentart.studio') WHERE account_id='acc_demo'").run(),console.log("[leaply] Demo public migrat: Termopane Bihor → DentArt Studio.")}catch(e){console.error("[leaply demo migrate]",String(e).slice(0,150))}}(e),u}function d(e=""){return e+Math.random().toString(36).slice(2,10)+Date.now().toString(36).slice(-4)}let p={businessName:"DentArt Studio",vertical:"clinica-privata",tone:"profesional",welcome:"Bună ziua! Sunteți \xeen legătură cu DentArt Studio \uD83D\uDE0A Cu ce vă putem ajuta?",services:[{name:"Consultație + plan de tratament (include radiografie 3D)",price:"250 lei"},{name:"Igienizare profesională completă",price:"350 lei"},{name:"Albire profesională \xeen cabinet",price:"900 lei"},{name:"Implant dentar (pachet complet)",price:"de la 3.500 lei"},{name:"Fațete ceramice",price:"de la 1.800 lei/dinte"},{name:"Ortodonție — aparat fix sau alignere",price:"plan personalizat după consultație"}],qualificationQuestions:[{key:"nevoie",q:"Ce vă supără sau ce tratament vă interesează?"},{key:"urgenta",q:"Aveți dureri \xeen acest moment, sau e un tratament pe care \xeel planificați?"},{key:"istoric",q:"Ați mai fost pacientul clinicii noastre?"}],bookingSlots:["marți la 14:00","joi la 11:00"],redFlags:["veterinar","medicina muncii"],knowledge:"Clinică stomatologică premium \xeen Oradea. Program: luni-vineri 9:00-19:00, s\xe2mbătă 9:00-13:00. Radiografia 3D e inclusă \xeen consultație. Plata \xeen rate fără dob\xe2ndă, p\xe2nă la 12 rate. Garanție 10 ani la implanturi. Sedare conștientă disponibilă pentru pacienții anxioși. Parcare gratuită pentru pacienți. Medici cu supraspecializare \xeen implantologie și estetică dentară.",rules:"Nu pune diagnostice și nu recomanda tratamente prin chat — invită politicos la consultație. Nu promite prețuri finale \xeenainte de consultație; indică doar intervalele din lista de servicii."}},12388:(e,a,i)=>{i.r(a),i.d(a,{LEAPLY_KNOWLEDGE:()=>n,LEAPLY_ONBOARDING_GUIDE:()=>r,LEAPLY_SALES_RULES:()=>t});let n=`
=== CE ESTE LEAPLY ===
Leaply este un asistent AI de v\xe2nzări pentru afaceri mici și mijlocii din Rom\xe2nia. Răspunde lead-urilor \xeen sub 60 de secunde, 24/7, pe toate canalele, pune \xeentrebări de calificare, propune și fixează programări direct \xeen calendar, și trimite follow-up automat celor care nu răspund. Practic: niciun lead pierdut, fără angajat \xeen plus.
De ce contează: majoritatea firmelor răspund la lead-uri \xeen ore sau deloc; șansa de a califica un lead scade de peste 10 ori dacă răspunzi după 5 minute \xeen loc de 1 minut. Leaply răspunde instant, mereu.
Pentru cine: termopane și t\xe2mplărie, clinici stomatologice, service auto, agenții imobiliare, instalatori, saloane de \xeenfrumusețare — și orice afacere de servicii care primește cereri pe WhatsApp, Facebook, Instagram, site sau telefon.

=== CANALE SUPORTATE ===
- WhatsApp Business — pe numărul clientului (Meta Cloud API sau Twilio) SAU pe un număr oferit de Leaply (zero bătăi de cap, \xeel configurăm noi).
- Facebook Messenger și Instagram DM — conectare cu un singur click („Conectează cu Facebook").
- Facebook Lead Ads — lead-urile din campanii intră automat și primesc mesaj \xeen secunde.
- Chat pe site (widget) — se instalează cu O SINGURĂ linie de cod, fără programator.
- Telefon — agent vocal AI care răspunde la apeluri \xeen rom\xe2nă, natural, califică apelantul și trimite SMS automat; apelantul devine lead \xeen inbox cu transcriptul convorbirii. Număr de telefon oferit de Leaply.
- Google Calendar — AI-ul vede disponibilitatea reală și fixează programările direct \xeen calendar.

=== CUM FUNCȚIONEAZĂ ===
1. Lead-ul scrie sau sună pe orice canal conectat.
2. AI-ul răspunde instant, \xeen limba clientului (rom\xe2nă, maghiară, engleză), cu tonul și datele afacerii tale.
3. Pune 2-3 \xeentrebări de calificare setate de tine (nevoie, urgență, zonă etc.).
4. Propune o programare (sloturi reale din Google Calendar dacă e conectat) și o confirmă.
5. Totul apare \xeen inbox-ul Leaply: conversații, scor lead (hot/warm/cold), rezumat AI, transcript apeluri.
6. Poți prelua oric\xe2nd conversația manual (takeover) — AI-ul se oprește instant.
7. Follow-up automat multi-touch (implicit la 4h / 24h / 72h) pentru lead-urile care nu răspund; SMS de confirmare cu 24h \xeenainte de programare (anti-neprezentare).

=== FUNCȚII INCLUSE ===
Inbox mini-CRM (căutare, filtre, export CSV, asignare pe colegi, echipă cu rol agent), rezumat AI per conversație, notificări pe email și WhatsApp către proprietar la lead-uri fierbinți, import lead-uri din CSV, integrare CRM prin webhook (Zapier/Make), API public REST (documentație pe leaply.ro/developers), configurare AI din date reale: preia datele firmei de la ANAF după CUI și poate citi site-ul firmei ca să \xeenvețe serviciile.

=== PREȚURI (EUR/lună, plată cu cardul, anulezi oric\xe2nd; fiecare pachet include tot ce e \xeen cel dinaintea lui) ===
- Trial GRATUIT 14 zile: la crearea contului, fără card — acces la TOATE funcțiile + 30 de conversații, ca să testezi tot.
- SOCIAL — 59 €/lună: Facebook Messenger + Instagram DM + Facebook Lead Ads + chat pe site, 300 de conversații/lună, Google Calendar, calificare + programare, follow-up automat, 25 SMS/lună.
- COMPLET — 129 €/lună: tot din Social + WhatsApp (numărul tău sau un număr de la Leaply, inclus), 800 de conversații/lună, echipă (p\xe2nă la 3 colegi), acces API + integrare CRM, 100 SMS/lună.
- TOTAL — 299 €/lună: tot din Complet + AGENT VOCAL AI cu număr de telefon dedicat (500 de minute/lună), 2.500 de conversații/lună, echipă extinsă (10 colegi), multi-locație, onboarding făcut de echipa Leaply, 400 SMS/lună.
- EXTRA RESURSE (se adaugă la orice pachet, oric\xe2nd): +200 conversații — 19 €/lună \xb7 +100 minute agent vocal — 29 €/lună \xb7 +500 SMS — 29 €/lună \xb7 număr suplimentar (altă locație/brand) — 12 €/lună.
O „conversație" = un schimb de mesaje cu un lead \xeentr-o lună (nu per mesaj). Fără contract pe termen lung, fără taxe de instalare. Plata prin Stripe (card), factura fiscală se emite automat (SmartBill). Un client tipic recuperează abonamentul dintr-un singur lead salvat.

=== ACTIVARE — C\xc2T DE REPEDE PORNEȘTI ===
1. Cont \xeen ~2 minute pe leaply.ro/start (sau \xeel creăm noi pentru tine, prin chat sau telefon, și primești email cu linkul de activare).
2. Wizard-ul de configurare: datele firmei (se pot prelua de la ANAF după CUI), serviciile și prețurile, \xeentrebările de calificare, tonul asistentului — plus un test de chat pe loc.
3. Chat-ul de site e activ imediat (copiezi o linie de cod). Facebook/Instagram se conectează cu un click. Pentru WhatsApp sau număr de telefon, ceri un număr de la Leaply din pagina Canale — de obicei activ \xeen aceeași zi.
Nu ai nevoie de programator sau cunoștințe tehnice pentru nimic din toate astea.

=== SECURITATE & GDPR ===
Datele sunt stocate pe servere \xeen Uniunea Europeană; token-urile și cheile sunt criptate; backup automat zilnic. Conform GDPR — pagini legale pe leaply.ro/termeni, /confidentialitate, /cookies. Operator: ARHAI SRL, CUI RO35913161, Rom\xe2nia.

=== CONTACT & LINKURI ===
Email: salut@leaply.ro \xb7 Telefon (agent AI demo — chiar produsul nostru): 0373 818 737 \xb7 Site: leaply.ro \xb7 Creare cont: leaply.ro/start \xb7 Login: leaply.ro/login \xb7 Documentație API: leaply.ro/developers

=== \xceNTREBĂRI FRECVENTE & OBIECȚII ===
„Sună robotic?" — Nu. Răspunde natural, \xeen limba și tonul afacerii tale, cu diacritice; clienții de obicei nu-și dau seama. Și poți prelua conversația oric\xe2nd.
„C\xe2t durează implementarea?" — Contul: 2 minute. Chat pe site: imediat. Facebook/Instagram: 1 click. WhatsApp/telefon: de obicei \xeen aceeași zi.
„Pot folosi numărul meu de WhatsApp?" — Da, prin Meta Cloud API sau Twilio. Sau primești un număr de la Leaply și nu configurezi nimic.
„Ce limbi vorbește?" — Rom\xe2nă (implicit), maghiară și engleză — detectează automat limba clientului.
„Dacă AI-ul greșește?" — \xcei setezi reguli obligatorii pe care nu le \xeencalcă (ex: nu promite discounturi), nu inventează prețuri (folosește doar lista ta), iar tu poți prelua oric\xe2nd.
„Pot anula?" — Oric\xe2nd, din cont, fără penalități. Răm\xe2i cu datele (export CSV).
„Ce se \xeent\xe2mplă după trial?" — Alegi un plan din cont (Setări & Plan). Dacă nu alegi, contul răm\xe2ne, dar AI-ul nu mai răspunde automat peste limita de trial.
„Aveți discount?" — Prețurile sunt cele publicate; nu oferim discounturi neanunțate. Pentru volume peste Scale, scrie-ne la salut@leaply.ro.
„E greu de configurat?" — Nu: wizard pas cu pas, date preluate de la ANAF, iar \xeen cont ai un asistent AI care te ghidează la fiecare pas.
`.trim(),r=`
GHID DE CONFIGURARE LEAPLY (pentru utilizatori logați \xeen aplicație):

PAGINILE APLICAȚIEI:
- /app — Overview: KPI-uri, grafic 14 zile, checklist de activare (dispare c\xe2nd totul e configurat).
- /app/inbox — toate conversațiile: căutare, filtre pe status/canal, export CSV, import lead-uri CSV, asignare pe colegi.
- /app/config — Configurare AI: numele afacerii, ton, mesaj de bun venit, servicii + prețuri, \xeentrebări de calificare, cunoștințe despre afacere (knowledge), REGULI obligatorii pentru AI, sloturi de programare.
- /app/channels — Canale & Integrări: conectare WhatsApp, Messenger, Instagram, Lead Ads, widget site, telefon, Google Calendar.
- /app/settings — Setări & Plan: planul curent + upgrade (plată card), notificări, webhook CRM, cheie API, echipă, follow-up (cadență), referral.

PAȘII RECOMANDAȚI DUPĂ CREAREA CONTULUI (\xeen ordine):
1. Configurare AI (/app/config): completează serviciile cu prețuri reale (AI-ul NU inventează prețuri — folosește doar ce scrii aici), 2-3 \xeentrebări de calificare, cunoștințe despre afacere (program, zonă de lucru, garanții etc.) și eventuale reguli (ex: „nu promite discounturi").
2. Instalează chat-ul pe site (/app/channels → Formular web → Detalii): copiezi o linie de cod <script src="https://leaply.ro/widget.js" data-leaply="ID_CONT" async></script> \xeenainte de </body> sau \xeen Google Tag Manager. Opțional data-color="#culoare".
3. Conectează Facebook/Instagram (/app/channels → Messenger → „Conectează cu Facebook — un click"): alegi pagina, Messenger și Instagram DM se activează automat.
4. WhatsApp (/app/channels → WhatsApp): recomandat „Cere număr de la Leaply" (noi configurăm tot, de obicei \xeen aceeași zi). Avansat: Meta Cloud API (Phone Number ID + Access token) sau Twilio (Account SID + Auth token + număr).
5. Telefon / agent vocal (/app/channels → Telefon): „Cere număr de telefon de la Leaply" — primești un număr care răspunde cu agentul vocal AI; \xeel pui pe site/anunțuri sau redirecționezi numărul firmei către el.
6. Google Calendar (/app/channels → Google Calendar → Conectează): AI-ul propune doar sloturi libere reale și creează evenimente la programare.
7. Setări (/app/settings): verifică notificările, setează cadența de follow-up, invită colegi (echipă), și c\xe2nd ești gata alege planul potrivit.

PROBLEME FRECVENTE:
- „AI-ul nu răspunde pe site" — verifică dacă scriptul widget e instalat cu ID-ul corect (\xeel vezi \xeen Canale → Formular web → Detalii) și dacă nu ai depășit limita planului (bara de usage din Setări).
- „Conectarea Facebook dă eroare" — re\xeencearcă din /app/channels; dacă persistă, scrie la salut@leaply.ro.
- „Nu primesc email-uri" — verifică spam; adresa expeditoare e salut@leaply.ro.
- „Vreau să schimb răspunsurile AI-ului" — totul se controlează din /app/config (servicii, cunoștințe, reguli, ton).
- „Cum preiau eu conversația?" — deschide conversația din inbox și apasă preluare (takeover); AI-ul se oprește pentru acea conversație.
- Resetare parolă: leaply.ro/forgot. Suport: salut@leaply.ro.
`.trim(),t=`
Nu inventa prețuri, funcții sau termene — folosește DOAR informațiile din baza de cunoștințe; dacă nu știi, spune sincer și oferă salut@leaply.ro.
Nu oferi discounturi sau condiții speciale. Nu vorbi ur\xe2t despre concurenți.
Scopul tău \xeen fiecare conversație: (1) răspunzi clar și scurt la \xeentrebări, (2) afli tipul afacerii și problema cu lead-urile, (3) obții numele, firma și emailul, (4) \xeei propui să-i creezi contul PE LOC — gratuit, fără card — ca să primească linkul de activare pe email.
Nu fi insistent: maxim o propunere de cont per 2-3 schimburi de mesaje; dacă omul refuză clar, răm\xe2i util și politicos.
Dacă persoana are deja cont: \xeendrum-o spre leaply.ro/login sau leaply.ro/forgot pentru parolă, iar pentru probleme spre salut@leaply.ro.
`.trim()}};