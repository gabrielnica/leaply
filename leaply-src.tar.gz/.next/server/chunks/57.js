"use strict";exports.id=57,exports.ids=[57],exports.modules={40057:(e,t,a)=>{a.d(t,{sendMail:()=>i,z:()=>o});var l=a(42739);function r(e){return`<!doctype html><html lang="ro"><body style="margin:0;padding:0;background:#F7F5F1">
<div style="background:#F7F5F1;padding:32px 16px;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif">
  <div style="max-width:560px;margin:0 auto">
    <div style="padding:0 4px 16px">
      <a href="https://leaply.ro" style="text-decoration:none;display:inline-block">
        <img src="https://leaply.ro/logo-email.png" height="28" alt="Leaply" style="height:28px;width:auto;border:0;display:block" />
      </a>
    </div>
    <div style="background:#ffffff;border:1px solid #E8E4DC;border-radius:16px;padding:28px 26px;color:#101214;font-size:15px;line-height:1.6">
      ${e}
    </div>
    <div style="padding:18px 6px 0;color:#8A867E;font-size:12.5px;line-height:1.7">
      Leaply — asistentul AI care răspunde lead-urilor tale \xeen sub 60 de secunde, 24/7.<br/>
      <a href="https://leaply.ro" style="color:#8A867E">leaply.ro</a> \xb7 <a href="mailto:salut@leaply.ro" style="color:#8A867E">salut@leaply.ro</a> \xb7 <a href="tel:+40373818737" style="color:#8A867E">0373 818 737</a><br/>
      ARHAI S.R.L. \xb7 CUI RO35913161 \xb7 Oradea, Rom\xe2nia
    </div>
  </div>
</div>
</body></html>`}async function i(e,t,a){let i=(0,l.cfg)("RESEND_API_KEY"),o=(0,l.cfg)("MAIL_FROM")||"Leaply <salut@leaply.ro>";if(!i)return console.log(`[leaply mail — netrimis, lipsește RESEND_API_KEY] către: ${e} | subiect: ${t}
${a.replace(/<[^>]+>/g," ")}`),!1;try{return(await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${i}`,"Content-Type":"application/json"},body:JSON.stringify({from:o,to:e,subject:t,html:r(a)})})).ok}catch(e){return console.error("[leaply mail] eroare trimitere:",e),!1}}async function o(e,t,a,i,o){let n=(0,l.cfg)("RESEND_API_KEY"),s=(0,l.cfg)("MAIL_FROM")||"Leaply <salut@leaply.ro>";if(!n||o.length>8e6)return!1;try{return(await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify({from:s,to:e,subject:t,html:r(a),attachments:[{filename:i,content:o.toString("base64")}]}),signal:AbortSignal.timeout(2e4)})).ok}catch(e){return console.error("[mail attach]",String(e).slice(0,150)),!1}}}};