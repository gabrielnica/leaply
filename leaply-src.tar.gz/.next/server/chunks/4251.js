"use strict";exports.id=4251,exports.ids=[4251],exports.modules={94251:(e,t,r)=>{r.d(t,{fewShotExamples:()=>s});var n=r(1035);function s(e,t=3){try{let r=(0,n.db)().prepare(`
      SELECT m.body FROM messages m
      JOIN conversations c ON c.id = m.conversation_id
      WHERE c.account_id = ? AND m.sender = 'ai' AND m.rating = 1
      ORDER BY m.created_at DESC LIMIT ?`).all(e,t);if(!r.length)return null;return r.map((e,t)=>`${t+1}) „${String(e.body).slice(0,220)}"`).join(" ")}catch{return null}}}};