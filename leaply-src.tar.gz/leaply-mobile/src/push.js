/**
 * Leaply — native integration module (Capacitor 6)
 * ============================================================================
 * WHERE DOES THIS CODE RUN?
 * ============================================================================
 * We use the REMOTE-URL model (see capacitor.config.ts): the native WebView
 * loads https://app.leaply.ro/app directly. Because that origin is listed in
 * `server.allowNavigation`, the Capacitor native runtime injects its bridge
 * (`window.Capacitor`) into the remote page, so Capacitor plugins are callable
 * from the web app's own JavaScript.
 *
 * THEREFORE: this module is meant to be shipped as part of the WEB APP bundle
 * (the Next.js app on app.leaply.ro) and called after login, e.g.:
 *
 *     import { initNative } from '@/native/push';
 *     useEffect(() => { initNative(); }, []);
 *
 * It is a no-op on the plain web (desktop browser) because Capacitor.isNativePlatform()
 * returns false there — safe to call unconditionally.
 *
 * If instead you switch to the BUNDLED model (webDir assets), copy this file
 * into your app entrypoint and call initNative() on load. Same code.
 * ============================================================================
 */

import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';
import { App } from '@capacitor/app';

const API_BASE = 'https://app.leaply.ro';

let lastRegisteredToken = null;
let listenersBound = false;

/** Platform string the backend expects: "ios" | "android". */
function currentPlatform() {
  return Capacitor.getPlatform(); // 'ios' | 'android' | 'web'
}

/**
 * POST the device token to the Leaply backend.
 * Uses the session cookie (credentials: 'include') — must be called AFTER the
 * WebView is logged in, otherwise the endpoint 401s and we retry later.
 */
async function registerTokenWithBackend(token) {
  const platform = currentPlatform();
  const res = await fetch(`${API_BASE}/api/push/register`, {
    method: 'POST',
    credentials: 'include', // send the app.leaply.ro session cookie
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ platform, token }),
  });
  if (!res.ok) {
    throw new Error(`push/register failed: ${res.status}`);
  }
  lastRegisteredToken = token;
  return true;
}

/** Tell the backend to stop sending to this token (e.g. on logout). */
export async function unregisterToken(token = lastRegisteredToken) {
  if (!token) return;
  try {
    await fetch(`${API_BASE}/api/push/unregister`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    });
  } catch (e) {
    console.warn('[Leaply push] unregister failed', e);
  } finally {
    lastRegisteredToken = null;
  }
}

/**
 * Navigate the WebView to a conversation (or any deep link) carried in the
 * notification payload. The backend should send data like:
 *   { "conversationId": "abc123", "url": "/app/conversations/abc123" }
 * We prefer an explicit `url`, else build one from conversationId.
 */
function navigateFromNotificationData(data) {
  if (!data) return;
  let path = null;
  if (typeof data.url === 'string' && data.url.startsWith('/')) {
    path = data.url;
  } else if (data.conversationId) {
    path = `/app/conversations/${data.conversationId}`;
  }
  if (!path) return;
  const target = `${API_BASE}${path}`;
  // Same-origin navigation stays inside the WebView (allowNavigation covers it).
  window.location.assign(target);
}

/**
 * Request permission + register with APNs (iOS) / FCM (Android) and wire the
 * four v6 listeners. Idempotent — safe to call multiple times.
 */
export async function initPush() {
  if (!Capacitor.isNativePlatform()) return; // no-op on desktop web

  if (!listenersBound) {
    listenersBound = true;

    // 1) Registration SUCCESS → we get the device token.
    //    On iOS this is the FCM token when Firebase is configured to swizzle
    //    APNs (recommended). On Android it is the FCM token directly.
    await PushNotifications.addListener('registration', async (token) => {
      console.log('[Leaply push] token:', token.value);
      try {
        await registerTokenWithBackend(token.value);
      } catch (e) {
        console.warn('[Leaply push] backend register failed, will retry on next login', e);
      }
    });

    // 2) Registration ERROR.
    await PushNotifications.addListener('registrationError', (err) => {
      console.error('[Leaply push] registrationError:', JSON.stringify(err));
    });

    // 3) Notification RECEIVED while app is in FOREGROUND.
    //    presentationOptions in capacitor.config.ts control whether iOS also
    //    shows the system banner. Use this to bump an in-app badge / toast.
    await PushNotifications.addListener('pushNotificationReceived', (notification) => {
      console.log('[Leaply push] received (foreground):', notification);
      // Optional: dispatch an app event so the dashboard can refresh the lead list.
      window.dispatchEvent(new CustomEvent('leaply:push', { detail: notification }));
    });

    // 4) Notification TAP (background/quit) → deep-link into the conversation.
    await PushNotifications.addListener('pushNotificationActionPerformed', (action) => {
      console.log('[Leaply push] tapped:', action);
      const data = action.notification && action.notification.data;
      navigateFromNotificationData(data);
    });
  }

  // Ask for permission. On iOS this shows the system prompt the first time;
  // 'prompt' means not-yet-decided. If already 'granted' we skip straight to
  // register(); if 'denied' the user must enable it in Settings.
  let perm = await PushNotifications.checkPermissions();
  if (perm.receive === 'prompt' || perm.receive === 'prompt-with-rationale') {
    perm = await PushNotifications.requestPermissions();
  }
  if (perm.receive !== 'granted') {
    console.warn('[Leaply push] permission not granted:', perm.receive);
    return;
  }

  // Kicks off APNs/FCM registration → fires the 'registration' listener above.
  await PushNotifications.register();

  // Clear the app icon badge / delivered notifications when we come to front.
  try {
    await PushNotifications.removeAllDeliveredNotifications();
  } catch (_) { /* Android may not support; ignore */ }
}

/**
 * Convenience bootstrap: init push and also re-check the token whenever the
 * app returns to the foreground (handles token refresh + badge clearing).
 */
export async function initNative() {
  if (!Capacitor.isNativePlatform()) return;

  await initPush();

  App.addListener('appStateChange', async ({ isActive }) => {
    if (isActive) {
      try {
        await PushNotifications.removeAllDeliveredNotifications();
      } catch (_) {}
      // Re-register in case the token rotated or the earlier attempt 401'd
      // because the user hadn't logged in yet.
      if (!lastRegisteredToken) {
        try { await PushNotifications.register(); } catch (_) {}
      }
    }
  });
}

export default { initNative, initPush, unregisterToken };
