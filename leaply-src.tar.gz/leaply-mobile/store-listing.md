# Leaply — texte gata de copiat pentru App Store & Google Play

Tot ce se completează în App Store Connect și Play Console, deja scris. Copy-paste.

---

## Comun

| Câmp | Valoare |
|---|---|
| Nume aplicație | **Leaply** |
| Bundle ID / Package | `ro.leaply.app` |
| Categorie | Business |
| Preț | Gratuit (abonamentul se vinde pe site, nu în aplicație) |
| Privacy policy URL | `https://leaply.ro/confidentialitate` |
| Termeni | `https://leaply.ro/termeni` |
| Suport | `https://leaply.ro` · `salut@gabrielnica.ro` |
| Limbă principală | Română (ro-RO) |

> **Plăți:** aplicația NU vinde nimic in-app (fără IAP). Abonamentele se cumpără pe
> site — ca Slack/Notion. Nu pune link direct de cumpărare în aplicație pe iOS
> (Apple 3.1.1); ecranul de plan doar afișează planul curent.

---

## App Store (iOS)

**Subtitle (30 car.):** `Lead-uri preluate în 60 sec`

**Promotional text (170 car.):**
`Vezi fiecare lead nou instant, preia conversația de la AI și răspunde ca pe WhatsApp — de oriunde. Asistentul Leaply lucrează non-stop pentru firma ta.`

**Description:**
```
Leaply răspunde lead-urilor firmei tale în mai puțin de 60 de secunde — pe WhatsApp,
Facebook Messenger, Instagram, formularul de pe site și chiar la telefon. Aplicația
mobilă îți pune afacerea în buzunar:

• PRIMEȘTI NOTIFICARE INSTANT când apare un lead nou — oriunde ai fi.
• VEZI TOATE CONVERSAȚIILE într-un singur inbox, în timp real, de pe toate canalele.
• PREIEI CONVERSAȚIA DE LA AI cu un singur buton, când vrei să vorbești tu.
• RĂSPUNZI CA PE WHATSAPP — scrii în aplicație, mesajul pleacă pe canalul lead-ului
  (WhatsApp, Messenger, Instagram, SMS sau widgetul de pe site).
• MARCHEZI LEAD-URILE CÂȘTIGATE și vezi exact câți bani ți-a adus Leaply.
• RAPOARTE CLARE: lead-uri pe zile, orele de vârf, funnel pe canale.

Asistentul AI al Leaply salută clienții, le răspunde la întrebări din documentele și
prețurile firmei tale, îi califică și le propune programări — inclusiv noaptea și în
weekend. Tu doar intri în aplicație și închizi vânzarea.

Aplicația necesită un cont Leaply (creat gratuit pe leaply.ro, cu 14 zile de probă).
```

**Keywords (100 car.):**
`lead,leaduri,crm,whatsapp business,mesaje,clienti,vanzari,ai,asistent,programari,inbox,firma`

**App Privacy (nutrition labels)** — colectate și legate de identitate:
- Contact Info: Name, Email Address, Phone Number (contul + lead-urile utilizatorului)
- User Content: Customer Support / Other User Content (mesajele conversațiilor)
- Identifiers: User ID; Usage Data: Product Interaction (analytics de bază)
- NU colectăm: locație, date financiare, browsing history, date de sănătate. Fără tracking / ATT.

**Review notes (pentru Apple):**
```
Demo account: [completați un cont demo cu date; ex. demo@leaply.ro / parola]
The app is a companion to our SaaS (leaply.ro). Native features: push notifications
for new leads, Face ID unlock, native splash and offline screen. Subscriptions are
sold on our website only (like Slack/Notion) — the app sells nothing.
Account deletion is available in Settings (per guideline 5.1.1(v)).
```

---

## Google Play (Android)

**Short description (80 car.):**
`Lead-urile firmei tale, preluate de AI în 60 sec. Tu răspunzi ca pe WhatsApp.`

**Full description:** aceeași ca descrierea iOS de mai sus.

**Data safety form:**
- Collected: Name, Email, Phone (account & leads), Messages (in-app conversations), App interactions.
- Shared: none. Encrypted in transit: yes. Deletion: user can delete account in-app + `https://leaply.ro` → cont → ștergere.

**Content rating (IARC):** aplicație utilitară business, fără conținut sensibil → Everyone / PEGI 3.

**App access (pentru review):** oferă aceleași credențiale demo ca la Apple, în
„App access" → „All or some functionality is restricted" → add instructions.

---

## Screenshots necesare (minim)

| Store | Dimensiuni | Ecrane recomandate |
|---|---|---|
| App Store | 6.9" (1320×2868) + 6.5" (1284×2778) | 1. Overview cu KPI-uri, 2. Inbox cu lead-uri, 3. Conversație cu preluare + reply box, 4. Raport, 5. Notificare push (mockup) |
| Google Play | telefon 1080×1920+ (min 2), feature graphic 1024×500 | aceleași |

Sursă rapidă: deschide `https://leaply.ro/app` pe telefon (sau simulator) logat în
contul demo DentArt și fă capturi direct; feature graphic se face din kitul de brand
(`leaply-brand/`, logo dark pe fundal #101214).

---

## Checklist final înainte de submit

- [ ] Apple Developer Program activ (enrolment ARHAI — 2F8A4FV985) + certificat push APNs
- [ ] Google Play Console org (8864059474845846627) verificat + service account FCM
- [ ] `npx cap add ios && npx cap add android` + `npm run assets` (iconițe/splash din assets/)
- [ ] Firebase project cu APNs key + google-services.json / GoogleService-Info.plist
- [ ] Cont demo populat pentru review (App Review nu poate primi SMS-uri reale)
- [ ] Testat pe TestFlight + Internal testing track: login, push, preluare, reply, logout
