import type { CapacitorConfig } from '@capacitor/cli';

/**
 * Leaply — Capacitor 6 configuration
 * ARHAI S.R.L. — bundle id ro.leaply.app
 *
 * ────────────────────────────────────────────────────────────────────────────
 * REMOTE-URL APPROACH (what we use here)
 * ────────────────────────────────────────────────────────────────────────────
 * `server.url` points the native WKWebView (iOS) / WebView (Android) directly
 * at the production web app: https://app.leaply.ro/app
 *
 * Pros:
 *   - Zero JS build pipeline in this repo. The web app ships from its own
 *     Next.js deploy; the native shell is a thin wrapper that only adds native
 *     capabilities (push, biometrics, splash, offline fallback).
 *   - No app-store resubmission needed for web UI changes — you edit the web
 *     app and users see it instantly. Only NATIVE changes (new plugins,
 *     permissions, icons) require a new binary.
 *   - Session-cookie auth "just works": the web app sets an HttpOnly cookie on
 *     app.leaply.ro and the WebView persists it (see WKWebsiteDataStore notes
 *     in README troubleshooting).
 *
 * Cons / caveats:
 *   - App is unusable with no connectivity → we ship a local offline fallback
 *     page in `www/index.html` (see below) and detect unreachable server.
 *   - Apple Guideline 4.2 ("minimum functionality"): a pure web wrapper can be
 *     rejected. We add NATIVE push notifications, biometric (Face ID) unlock,
 *     a native splash screen and a native offline screen — this is what makes
 *     the app "app-like" enough to pass review.
 *
 * ────────────────────────────────────────────────────────────────────────────
 * ALTERNATIVE: BUNDLED WEB ASSETS (not used)
 * ────────────────────────────────────────────────────────────────────────────
 * Instead of `server.url`, you would build the web app to static assets and
 * copy them into `webDir` (e.g. `www` or Next.js `out/`). Capacitor then loads
 * from capacitor://localhost (iOS) / https://localhost (Android). You'd talk to
 * the backend purely via API calls with a bearer token (cookies across origins
 * get awkward). This is more robust offline and gives faster cold starts, but
 * means every UI change requires an app-store release and a full SSR→static or
 * SPA refactor of the Next.js app. We deliberately chose the remote-URL model.
 * ────────────────────────────────────────────────────────────────────────────
 */
const config: CapacitorConfig = {
  appId: 'ro.leaply.app',
  appName: 'Leaply',

  // Local web assets used ONLY for the offline fallback screen. When the remote
  // server is reachable, `server.url` takes over and this is never shown.
  webDir: 'www',

  server: {
    // Load the live dashboard inside the native WebView.
    url: 'https://app.leaply.ro/app',
    // Never allow plaintext HTTP — production is HTTPS only.
    cleartext: false,
    // Keep in-app navigation (login redirect, conversation deep-links, Stripe
    // return URLs on our own domain) inside the WebView instead of kicking out
    // to the system browser. Anything NOT in this list opens externally.
    allowNavigation: [
      'app.leaply.ro',
      'leaply.ro',
      '*.leaply.ro',
    ],
    // Custom UA suffix lets the server detect the native shell (e.g. to hide
    // the "Download the app" banner, or to know a push token can be registered).
    // The web app reads this via navigator.userAgent.
    iosScheme: 'https',
    androidScheme: 'https',
  },

  ios: {
    // With a fixed header/toolbar in the web app, 'never' avoids the WebView
    // adding extra top inset. Use 'always' if you rely on safe-area insets from
    // the native side instead of CSS env(safe-area-inset-*).
    contentInset: 'never',
    // Allow the WebView to be scrolled to the very edges (matches web layout).
    scrollEnabled: true,
    limitsNavigationsToAppBoundDomains: false,
    backgroundColor: '#F7F5F1',
  },

  android: {
    backgroundColor: '#F7F5F1',
    // Mixed content stays off — everything is HTTPS.
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },

  plugins: {
    PushNotifications: {
      // How iOS displays a push while the app is in the FOREGROUND.
      // ['badge','sound','alert'] = show the banner + play sound + bump badge
      // even when the user is actively looking at the app.
      presentationOptions: ['badge', 'sound', 'alert'],
    },
    SplashScreen: {
      launchShowDuration: 1200,
      launchAutoHide: true,
      launchFadeOutDuration: 300,
      backgroundColor: '#F7F5F1',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
      splashFullScreen: true,
      splashImmersive: false,
      // iOS uses the LaunchScreen.storyboard generated from the asset set.
      iosSpinnerStyle: 'small',
    },
    StatusBar: {
      style: 'DARK',            // dark icons on the light paper background
      backgroundColor: '#F7F5F1',
      overlaysWebView: false,
    },
  },
};

export default config;
