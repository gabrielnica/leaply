# Leaply — app icon & splash source assets

Capacitor generates every platform-specific icon/splash size from a small set of
**source** images using [`@capacitor/assets`](https://github.com/ionic-team/capacitor-assets).
You only need to provide the source files below, then run one command.

## Source files to place in THIS folder (`assets/`)

| File | Size | Format | Notes |
|------|------|--------|-------|
| `icon.png` | **1024 × 1024** | PNG, no alpha/transparency | The App Store / Play Store icon. Full-bleed Leaply mark on paper `#F7F5F1` background. Do NOT round the corners — the OS masks them. |
| `icon-foreground.png` | **1024 × 1024** | PNG **with transparency** | Android adaptive-icon foreground (logo only, centered, keep art inside the safe ~66% center circle). Optional but recommended. |
| `icon-background.png` | **1024 × 1024** | PNG, solid | Android adaptive-icon background. A flat `#F7F5F1` fill is fine. Optional. |
| `splash.png` | **2732 × 2732** | PNG | Light-mode splash. Center the Leaply logo in the middle ~1200px; edges get cropped on various aspect ratios. Background `#F7F5F1`. |
| `splash-dark.png` | **2732 × 2732** | PNG | Dark-mode splash. Background `#101214`, light logo. Optional (falls back to `splash.png`). |

### Brand colors
- Paper (light bg): `#F7F5F1`
- Ink (dark bg / text): `#101214`
- Accent: `#FF4D1F`

## Generate all sizes

From the project root (after `npm install` and `npx cap add ios/android`):

```bash
npx @capacitor/assets generate \
  --assetPath assets \
  --iconBackgroundColor '#F7F5F1' \
  --iconBackgroundColorDark '#101214' \
  --splashBackgroundColor '#F7F5F1' \
  --splashBackgroundColorDark '#101214'
```

Or, since it is wired into `package.json`:

```bash
npm run assets
```

This writes:
- iOS: `ios/App/App/Assets.xcassets/AppIcon.appiconset/*` and `Splash.imageset/*`
- Android: `android/app/src/main/res/mipmap-*/` (incl. adaptive `ic_launcher_foreground`/`_background`) and `drawable-*/splash.png`

Re-run it whenever you change a source image. Commit the source images in `assets/`;
the generated per-density outputs live in the (git-ignored) native folders.

## Checklist
- [ ] `icon.png` 1024×1024, **no transparency**, no pre-rounded corners
- [ ] `splash.png` 2732×2732, logo centered within safe area
- [ ] (optional) `icon-foreground.png` + `icon-background.png` for Android adaptive icon
- [ ] (optional) `splash-dark.png` for dark mode
- [ ] Ran `npm run assets` and verified icons in Xcode & Android Studio previews
