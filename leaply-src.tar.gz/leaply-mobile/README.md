# Leaply — Native mobile app (Capacitor 6)

Native iOS + Android shell for **Leaply** (Romanian lead-response SaaS, by **ARHAI S.R.L.**).
It wraps the live web dashboard at `https://app.leaply.ro/app` in a native WebView and
adds four native capabilities so it behaves like a real app (and passes Apple review):

- **Native push notifications** for new leads (APNs → FCM → device).
- **Biometric unlock** (Face ID / Touch ID / Android BiometricPrompt).
- **Native splash screen.**
- **Native offline fallback screen** when the server is unreachable.

- **Bundle id / appId:** `ro.leaply.app`
- **Display name:** `Leaply`
- **Architecture:** remote-URL model — the WebView loads the production web app directly;
  this repo is a thin native wrapper. See the long comment in `capacitor.config.ts` for
  why, and the "bundled assets" alternative.

> This repo intentionally does **not** commit the generated `ios/` and `android/` folders.
> You create them locally with `npx cap add …`. Everything below is the runbook for doing
> that on a Mac and shipping to TestFlight + Google Play.

---

## Files in this scaffold

```
leaply-mobile/
├── package.json            # Capacitor 6 deps + scripts
├── capacitor.config.ts     # appId, server.url, push/splash/statusbar config
├── www/index.html          # local offline fallback page (webDir content)
├── src/push.js             # push permission + token registration + deep-link (runs in web app)
├── assets/README.md        # icon/splash source spec + @capacitor/assets command
├── .gitignore
└── README.md               # this runbook
```

The `src/push.js` logic is meant to be imported by the **web app** (app.leaply.ro),
because with the remote-URL model the Capacitor bridge is injected into the remote page.
See the header comment in that file. If you move to bundled assets, call `initNative()`
from your bundled entrypoint instead.

---

## 0) Prerequisites (install once, on the Mac)

| Tool | Version (2026) | Install |
|------|----------------|---------|
| Node.js | 20 LTS or 22 LTS | `brew install node@22` or nvm |
| Xcode | 16+ (from Mac App Store) | includes iOS 18 SDK |
| Xcode Command Line Tools | matching | `xcode-select --install` |
| CocoaPods | 1.15+ | `sudo gem install cocoapods` (or `brew install cocoapods`) |
| Android Studio | Ladybug (2024.2)+ | https://developer.android.com/studio |
| JDK | 17 (bundled with Android Studio, or `brew install --cask temurin@17`) | set `JAVA_HOME` |
| Capacitor CLI | 6.x | comes via `npm install` (devDependency) |

Accounts (must be **fully approved** before store submission):
- **Apple Developer Program — Organization** account for ARHAI S.R.L. (D-U-N-S verified).
  Note: org enrollment can take days/weeks; this must be *approved* before you can create
  the App Store Connect record or upload a build.
- **Google Play Console — Organization** account (org verification also required in 2026).

Also confirm on the Mac:
```bash
node -v && npm -v
xcodebuild -version
pod --version
java -version           # should be 17
```

---

## 1) Install & create native projects

From `leaply-mobile/`:

```bash
npm install

# Create the native projects (writes ios/ and android/, both git-ignored):
npx cap add ios
npx cap add android

# Copy web assets + config into the native projects and install pods:
npx cap sync
```

`npx cap sync` runs `copy` + `update` (installs iOS CocoaPods and syncs Android Gradle
plugins for every Capacitor plugin in package.json).

Generate icons & splash (see `assets/README.md` — put the source PNGs in `assets/` first):
```bash
npm run assets
```

---

## 2) Firebase (Cloud Messaging) setup

Push on **both** platforms goes through Firebase Cloud Messaging (FCM). iOS pushes are
relayed by FCM to APNs.

1. Go to https://console.firebase.google.com → **Add project** → name it `Leaply`
   (disable Google Analytics unless you want it). Note the **Project ID**.

2. **Add iOS app**
   - Apple bundle ID: `ro.leaply.app`
   - Download **`GoogleService-Info.plist`**.
   - Put it at: `ios/App/App/GoogleService-Info.plist`
     and add it to the Xcode target (drag into the *App* group, "Copy items if needed",
     target *App* checked). It's git-ignored — keep a copy in your secrets store.

3. **Add Android app**
   - Package name: `ro.leaply.app`
   - Download **`google-services.json`**.
   - Put it at: `android/app/google-services.json`
     (The Capacitor Android template already applies the `com.google.gms.google-services`
     plugin; if a fresh template doesn't, add `apply plugin: 'com.google.gms.google-services'`
     to `android/app/build.gradle` and the classpath to `android/build.gradle`.)

4. **APNs Auth Key (.p8) → Firebase** (so FCM can send to iOS)
   - In the Apple Developer portal → **Certificates, Identifiers & Profiles → Keys** →
     create a Key with **Apple Push Notifications service (APNs)** enabled → download the
     `AuthKey_XXXXXXXXXX.p8` (**you can only download it once**). Note the **Key ID** and
     your **Team ID**.
   - Firebase Console → Project settings → **Cloud Messaging** → *Apple app configuration* →
     **APNs Authentication Key** → upload the `.p8`, enter Key ID + Team ID.

5. **Server side (Leaply backend)** — the backend sends pushes via FCM using a **service
   account**:
   - Firebase Console → Project settings → **Service accounts** → *Generate new private key*
     → download the service-account **JSON**.
   - Paste the service-account JSON **and** the Firebase **Project ID** into
     **Leaply Admin → Setări platformă** (server side). The backend uses these with the
     FCM HTTP v1 API to deliver "lead nou" notifications to the tokens registered via
     `/api/push/register`.

> The device never holds the service account. The device only sends its **FCM token** to
> `POST /api/push/register` (see `src/push.js`); the server stores it and sends pushes.

---

## 3) iOS — Xcode configuration

```bash
npx cap open ios
```

In Xcode, select the **App** target → *Signing & Capabilities*:

1. **Signing**
   - Team: ARHAI S.R.L. (your Apple Developer org team).
   - Bundle Identifier: `ro.leaply.app` (must match Firebase + App Store Connect).
   - Automatically manage signing: ON (simplest) — Xcode creates the provisioning profile.

2. **Capabilities** (click "+ Capability")
   - **Push Notifications** — required for APNs.
   - **Background Modes** → check **Remote notifications** (lets silent/data pushes wake the app).

3. **Info.plist strings** (`ios/App/App/Info.plist`)
   - **`NSFaceIDUsageDescription`** (required for biometric unlock, or the app crashes on
     Face ID use and Apple rejects it):
     ```xml
     <key>NSFaceIDUsageDescription</key>
     <string>Leaply folosește Face ID pentru a debloca aplicația în siguranță.</string>
     ```
   - The display name is already `Leaply` via `CFBundleDisplayName` (set from appName).

4. **Version / build**
   - `CFBundleShortVersionString` (Marketing Version) e.g. `1.0.0`
   - `CFBundleVersion` (Build) e.g. `1` — must increase for every TestFlight upload.

5. **Archive & upload**
   - Select destination **Any iOS Device (arm64)** (not a simulator).
   - **Product → Archive**.
   - In the Organizer → **Distribute App → App Store Connect → Upload**.
   - Wait for processing in App Store Connect (a few minutes to ~1h).

> Re-run `npx cap sync ios` after any dependency/config change, then re-archive.

---

## 4) App Store Connect + review

1. https://appstoreconnect.apple.com → **My Apps → +** → **New App**
   - Platform iOS, Name **Leaply**, Primary language Romanian, Bundle ID `ro.leaply.app`
     (pick the one auto-created from Xcode), SKU e.g. `leaply-ios`.

2. **App Privacy (nutrition labels)** — declare data collection accurately. Typically for
   Leaply: *Contact info* (name/email), *Identifiers* (account/user id, **device push token**),
   *Usage/Diagnostics* if you add analytics. Mark whether data is linked to identity and
   used for tracking (Leaply: not for cross-app tracking → no ATT prompt needed unless you
   add ad SDKs).

3. **Account deletion requirement (Apple mandatory).** Any app with account creation must
   let users **delete their account from within the app** (not just deactivate, not "email
   us"). Ensure the web dashboard exposes an in-app *Șterge contul* flow reachable inside the
   WebView (e.g. Setări → Cont → Șterge contul). Reviewers actively check this. Provide the
   path in the review notes.

4. **Screenshots** — upload for at least:
   - **iPhone 6.9"** (e.g. iPhone 16 Pro Max, 1320 × 2868) — required.
   - **iPhone 6.5"** (1242 × 2688) — recommended for older devices.
   - **iPad 13"** only if you enable iPad support (2064 × 2752). If iPhone-only, set the
     app to iPhone in the target's *Supported Destinations* and skip iPad shots.

5. **TestFlight (internal testing first)**
   - TestFlight tab → your build appears after processing.
   - Add **Internal Testers** (up to 100, must be users in your App Store Connect team) →
     they install via the TestFlight app immediately (no review needed for internal).
   - Optionally add External testers (requires a light Beta App Review).

6. **Submit for review**
   - Fill *App Review Information* (a demo Leaply account login the reviewer can use — give
     working credentials), support URL, marketing URL.
   - **Guideline 4.2 (Minimum Functionality):** pure web wrappers get rejected. In the review
     notes, state explicitly that the app provides **native push notifications for new leads,
     Face ID/biometric app lock, a native splash screen, and a native offline screen** — i.e.
     functionality beyond a website. This is exactly why we added those. Also mention the app
     is for existing paying business customers (B2B), which helps.
   - Submit. First review typically 24–48h.

---

## 5) Android — build & Google Play

1. **`google-services.json`** already placed at `android/app/google-services.json` (step 2.3).

2. **Signing keystore** (create once, keep it forever + back it up):
   ```bash
   keytool -genkey -v -keystore leaply-release.keystore \
     -alias leaply -keyalg RSA -keysize 2048 -validity 10000
   ```
   Store `leaply-release.keystore` and its passwords in your secrets vault (NOT in git —
   `*.keystore` is git-ignored). Losing it means you can't update the app (unless enrolled in
   Play App Signing, which is now the default — see below).

   Create `android/keystore.properties` (git-ignored):
   ```properties
   storeFile=/absolute/path/leaply-release.keystore
   storePassword=********
   keyAlias=leaply
   keyPassword=********
   ```
   and reference it in `android/app/build.gradle` `signingConfigs { release { … } }`.

3. **Build the App Bundle (.aab)**
   - CLI:
     ```bash
     npx cap sync android
     cd android
     ./gradlew bundleRelease
     # → android/app/build/outputs/bundle/release/app-release.aab
     ```
   - Or Android Studio (`npx cap open android`) → **Build → Generate Signed Bundle / APK →
     Android App Bundle** → select the keystore → *release* → **Finish**.

4. **Google Play Console**
   - https://play.google.com/console → **Create app** → name **Leaply**, language Romanian,
     App (not game), Free/Paid as appropriate.
   - Complete the required declarations: **Privacy policy URL**, **Data safety** form
     (mirror the Apple privacy answers: contact info, identifiers/push token, no cross-app
     tracking), **Content rating** questionnaire, **Target audience** (adults / business),
     **App access** (provide test login credentials since it's behind auth), **Ads** (none,
     unless you add them), and **Government/financial** as applicable (none).
   - **App integrity → App signing:** accept **Play App Signing** (Google holds the app
     signing key; your keystore above becomes the *upload* key). Recommended.

5. **Release tracks**
   - **Testing → Internal testing** → create release → upload the `.aab` → add testers by
     email or a list → share the opt-in link. Internal testing is instant (no review) and,
     for an **organization** account, is **exempt from the 20-tester / 14-day closed-testing
     requirement** that applies to *personal* developer accounts registered after Nov 2023.
   - Then promote to **Closed → Open** as desired, and finally **Production** (full store
     review; typically hours to a few days).

---

## 6) Verifying it end-to-end

1. Install via TestFlight / Internal testing.
2. Launch → splash → WebView loads `app.leaply.ro/app`.
3. Log in in the WebView.
4. First launch prompts for **notification permission** (iOS) — accept. `src/push.js`
   registers the token and POSTs it to `/api/push/register`.
5. From Leaply backend (or Firebase Console → *Cloud Messaging → Send test message* using the
   device token), send a "lead nou" push. Tap it → the app deep-links to the conversation URL.
6. Enable airplane mode and cold-launch → the native offline screen (`www/index.html`)
   appears with a working **Reîncearcă** button.

---

## 7) Troubleshooting

**Session cookie not persisting in WKWebView (user gets logged out)**
- Capacitor 6 uses a persistent `WKWebsiteDataStore` by default, so cookies survive relaunch.
  If sessions drop, confirm the backend sets the cookie with `Secure; SameSite=Lax` (or
  `None; Secure`) and a real `Domain=app.leaply.ro` / long `Max-Age` — HttpOnly is fine.
- Ensure `server.url` origin matches the cookie domain exactly (`https://app.leaply.ro`),
  and that login redirects stay on `*.leaply.ro` (covered by `allowNavigation`).
- Do NOT set `limitsNavigationsToAppBoundDomains: true` unless you also declare
  `WKAppBoundDomains` in Info.plist — it can break cookie/JS behavior.

**Push token never arrives (`registration` listener doesn't fire)**
- iOS: confirm **Push Notifications** + **Background Modes → Remote notifications**
  capabilities are enabled, the app is on a **real device** (push doesn't work on the
  simulator for APNs), and the **APNs .p8** is uploaded to Firebase with correct Key ID/Team ID.
- Android: confirm `google-services.json` is at `android/app/` and the google-services Gradle
  plugin is applied; check Logcat for FCM init errors.
- The `/api/push/register` call needs the **session cookie**, so it must run *after* login.
  `src/push.js` retries on `appStateChange`/next launch if the first attempt 401s.
- Verify `PushNotifications.checkPermissions()` returns `granted`; if `denied`, the user must
  re-enable in OS Settings.

**Offline screen shows even when online**
- The offline page (`www/index.html`) is only shown when the WebView can't reach `server.url`.
  If it appears with connectivity, the server probe (`HEAD app.leaply.ro/app`) may be blocked
  by CORS/redirects — the page treats any `<500` status as reachable; check that a HEAD to
  `/app` returns a non-5xx quickly. Adjust the `reachable()` probe URL if `/app` requires auth
  and returns a redirect loop.

**"App is just a website" (Guideline 4.2) rejection**
- Re-emphasize native push + Face ID lock + offline screen in review notes, attach a short
  screen recording, and confirm the in-app **account deletion** path works.

---

## Handy commands

```bash
npm run sync            # cap sync (copy + update, both platforms)
npm run sync:ios        # iOS only
npm run open:ios        # open Xcode
npm run open:android    # open Android Studio
npm run assets          # regenerate icons/splash from assets/
npx cap doctor          # environment / version diagnostics
```

---

_ARHAI S.R.L. — Leaply. Bundle `ro.leaply.app`. Capacitor 6._
