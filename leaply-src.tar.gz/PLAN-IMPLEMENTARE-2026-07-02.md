# Plan implementare — runda „platformă captivantă & completă" · 2 iulie 2026

## Obiective (din cerințele tale)

1. **Funnel fără fricțiune**: formular „Cere demo" extins (nume, telefon, email, website, tip servicii) → datele curg automat în wizard, zero re-tastare.
2. **Knowledge AI de pe site-ul clientului**: în wizard, pasul „Afacerea ta" citește automat site-ul clientului și extrage servicii, descriere, ton — asistentul știe business-ul din prima.
3. **WhatsApp fără bătăi de cap pentru client**: opțiunea „Cere număr WhatsApp de la Leaply" — clientul apasă un buton, tu îi provisionezi numărul din contul tău Twilio master (el nu face niciun cont, nu intră în Meta). Plus opțiunile existente (Facebook un-click, manual).
4. **Dashboard care ține clientul**: bani câștigați estimat, utilizare plan cu bară, activitate pe ultimele 14 zile (grafic), ore lucrate de Leaply, rată de conversie.
5. **Follow-up-uri automate**: lead-urile care nu răspund primesc follow-up pe canalul original / SMS / email; SMS-uri de confirmare + reamintire programare prin **SMSLink.ro**.
6. **Facturare completă**: Stripe (recurent, există) + **SmartBill** — factura pleacă automat pe firmă la fiecare plată. Date de facturare (firmă, CIF, adresă) colectate în Setări.
7. **Admin cu date**: utilizare per cont, cereri de numere WhatsApp, chei SMSLink/SmartBill/Twilio master în Setări platformă.

## Arhitectură (ce se construiește)

- `lib/sms.ts` — SMSLink.ro (connection_id + password din Setări platformă); confirmare la booking, reamintire cu 3h înainte, follow-up.
- `lib/smartbill.ts` — emitere factură SmartBill Cloud la `checkout.session.completed` (+ salvare serie/CIF platformă în Setări; datele clientului din Setări & Plan → Facturare).
- `lib/scrape.ts` + `POST /api/onboarding/scrape` — fetch site → extragere cu LLM (sau euristică fără cheie) → servicii/descriere/cunoștințe → `config.knowledge` folosit în system prompt.
- `POST /api/channels/request-number` — cererea de număr WhatsApp gestionat de Leaply (vizibilă în admin, notificare email către tine).
- `GET /api/cron/run?key=CRON_SECRET` — motorul de follow-up-uri + reamintiri (apelat la 15 min din Coolify Scheduled Tasks sau uptime-cron extern).
- Follow-up config per cont: activat/dezactivat, după câte ore, mesaj — în Setări.
- Landing: formular extins; wizard: prefill complet + pas de import site.
- Overview: statistici extinse + grafic activitate 14 zile (SVG server-rendered).
- Admin: coloană utilizare per cont, cereri numere, grupuri noi în Setări platformă (SMSLink, SmartBill, Twilio master, CRON_SECRET).

## Chei noi în Admin → Setări platformă

SMSLINK_CONNECTION_ID, SMSLINK_PASSWORD · SMARTBILL_EMAIL, SMARTBILL_TOKEN, SMARTBILL_CIF, SMARTBILL_SERIES · TWILIO_MASTER_SID, TWILIO_MASTER_TOKEN (pentru provisionare numere) · CRON_SECRET

## Ce rămâne la tine după implementare

1. Cont SMSLink.ro → chei în Setări. 2. Cont SmartBill + token API → chei. 3. Cont Twilio master (unul singur, al tău) pentru numerele „de la Leaply". 4. Coolify → Scheduled Task: `curl https://leaply.ro/api/cron/run?key=<CRON_SECRET>` la 15 min. 5. Restul cheilor din raportul anterior (Meta, OpenAI, Resend, Google, Stripe).

## Ordine de execuție

Backend (sms, smartbill, scrape, cron, request-number, settings) → Agent UI 1 (landing form + wizard cu import site) → Agent UI 2 (overview captivant + setări facturare/follow-up + canale „cere număr") → admin update → build, teste E2E, deploy, raport.
