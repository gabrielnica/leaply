# Leaply.ro — Raport verificare + deploy · 1 iulie 2026

## Rezultat: SITE-UL E ONLINE ȘI FUNCȚIONAL ✅

leaply.ro, www.leaply.ro și app.leaply.ro servesc acum landing-ul de marketing complet stilizat, dashboard-ul cu CSS pe toate paginile, API-urile funcționale și datele existente păstrate. Deploy-ul durează ~27 secunde (înainte: minute, cu rezultat stricat).

## Ce era stricat înainte

Auditul (2 agenți paraleli: code review + QA live) a confirmat:

1. **CRITIC** — Niciun CSS pe nicio pagină (build-ul de pe server producea output incomplet din lipsă de memorie / OOM).
2. **CRITIC** — leaply.ro servea dashboard-ul aplicației în loc de landing-ul de marketing.
3. **CRITIC (securitate)** — Webhook-urile acceptau payload-uri fără semnătură când secretele Meta nu erau setate (oricine putea injecta lead-uri false).
4. **CRITIC (securitate)** — `/api/demo/message` accepta config injectat de client + istoric nelimitat (injecție de system-prompt + consum nelimitat de tokeni LLM).
5. Pagina Configurare AI promitea că modificările se aplică pe demo — dar demo-ul folosea mereu config-ul hardcodat.
6. "Preiau conversația" seta statusul greșit (`active` = AI activ) și "Redă asistentului" nu apela deloc serverul.
7. Logica de booking dădea fals-pozitive: "**Nu** îmi convine" sau orice mesaj cu o cifră programa întâlnirea.
8. Diverse: config acceptat fără validare (crash la `null`), scriptul `seed` inexistent, cifra ROI de pe landing nesincronizată (afișa +50.400 în loc de +9.000), lead-uri fantomă din ping-uri Meta goale, insert-uri fără tranzacție.

## Ce am reparat

**Blockerul de deploy (cauza principală):** `next build` nu mai rulează pe server. Build-ul se face în afara serverului, iar `.next` pre-construit e inclus în `leaply-src.tar.gz` (~550 KB). Dockerfile-ul doar dezarhivează + `npm install --omit=dev` + pornește. OOM-ul e ocolit definitiv; am adăugat și `VOLUME /data`.

**Securitate:**
- Webhooks: fail-closed în producție — fără `META_APP_SECRET`/`WHATSAPP_APP_SECRET` setate, payload-urile nesemnate primesc 401 (verificat live).
- `/api/demo/message`: config-ul clientului e ignorat (se folosește config-ul contului), istoricul e limitat la 30 de mesaje × 1000 caractere.
- `/api/account/config`: validare — body invalid → 400.
- **Basic Auth opțional** pe `/app`, `/admin`, `/api/account`, `/api/conversation`: se activează setând env `ADMIN_PASSWORD` în Coolify. Nu l-am setat (dashboard-ul rămâne deschis pentru demo-uri) — recomand să-l setezi înainte de clienți reali.

**Funcțional:**
- Configurare AI → demo funcționează acum real (welcome-ul editat apare în demo — testat).
- Takeover: status nou `human` (badge galben), "Redă asistentului" apelează serverul, 404 pe conversații inexistente.
- Booking: potrivire pe cuvânt întreg + detecție negație ("Nu îmi convine niciuna" → propune alte intervale; "Da, joi la 16:00" → booked hot). Testat ambele.
- Notele de sistem apar centrat, nu ca bule AI; cifra ROI corectată; script `seed` mort eliminat; insert-urile lead+conversație+mesaj sunt tranzacționale; ping-urile Meta fără formular nu mai creează lead-uri goale.

## Verificare finală pe producție

| Test | Rezultat |
|---|---|
| leaply.ro = landing marketing, stilizat | ✅ (titlu + CSS + "Prețuri/Calculator/Cere demo") |
| CSS pe toate cele 9 rute (landing, demo, app, inbox, canale, config, admin) | ✅ 200 + stylesheet |
| /api/health | ✅ ok, db_ok, 7 lead-uri păstrate peste deploy |
| Webhook fals fără semnătură | ✅ respins 401 |
| TLS pe toate 3 domeniile | ✅ Let's Encrypt, valid până 29.09.2026 |
| Vizual în browser (landing + dashboard) | ✅ ambele stilizate corect |

## Rămase pe lista ta (nu blochează, decizia ta)

- Setează `ADMIN_PASSWORD` în Coolify → Environment Variables ca să închizi dashboard-ul cu parolă (o singură variabilă, restart automat).
- LLM rulează pe reguli (`llm: rule-based`) — setează `OPENAI_API_KEY` sau `ANTHROPIC_API_KEY` când vrei răspunsuri generate de AI real.
- Minor, cosmetic: ghilimelele românești de închidere („text" → „text”), timpul de răspuns real afișat pentru lead-uri live va fi ~0s (măsoară procesarea serverului, nu răspunsul efectiv pe canal), `/api/health` expune KPI-uri public.

## Important pentru deploy-uri viitoare

Nu reintroduce `npm run build` în Dockerfile. Fluxul e: modifici codul → `npm run build` local → împachetezi tarball-ul CU `.next` → upload pe GitHub → Coolify face restul în ~30s. Sursa completă e acum în folderul proiectului (`Leaply.ro/`).
