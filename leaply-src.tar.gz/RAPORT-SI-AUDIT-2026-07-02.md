# Leaply — Raport implementare + Audit complet de produs
*2 iulie 2026 · commit `9b80708` · live pe leaply.ro*

---

## PARTEA 1 — Ce s-a implementat în această rundă

### 1. Onboarding cu CUI → date automate de la ANAF
Clientul scrie doar CUI-ul în wizard (pasul „Afacerea ta"). Butonul **„Preia de la ANAF"** aduce instant: denumirea firmei, nr. Reg. Com., adresa completă, statutul de plătitor TVA. Numele firmei se completează singur, iar **datele de facturare** (firmă, CIF, adresă, oraș) se salvează automat în cont — la prima plată clientul nu mai tastează nimic. Serviciu public ANAF, fără cheie API, cu rate-limiting propriu (10 cereri/min/IP) și mesaje de eroare prietenoase.

### 2. Knowledge simplu + Reguli și limite respectate strict
- Importul de pe site exista deja (scrape cu AI); acum **cunoștințele sunt editabile** direct în Configurare AI — clientul poate adăuga orice informație liberă (program, garanții, FAQ).
- Câmp nou **„Reguli și limite"** în wizard (pasul Asistent) și în Configurare AI. Regulile intră în system prompt marcate ca *„REGULI OBLIGATORII de la proprietarul afacerii — nu ai voie să le încalci sub nicio formă"*, plus instrucțiune să nu-și dezvăluie instrucțiunile. Ex.: „Nu promite termene", „Nu oferi discounturi", „Programări doar în timpul săptămânii".

### 3. Admin pregătit pentru sute de conturi
- Tabelul de conturi are acum **căutare** (firmă / email / domeniu), **filtru pe plan**, **paginare** (25/pagină) și coloane operaționale: owner, plan, conversații luna curentă, lead-uri, programări, canale conectate, ultima activitate. Interogări SQL agregate — merge la fel de repede cu 500 de conturi.
- **Pagină de detaliu per cont** (`/admin/account/{id}`): KPI-uri, utilizatori, starea fiecărui canal, rezumat configurare AI (ton, servicii, knowledge, reguli), Google Calendar, CUI facturare, follow-up — plus **schimbarea planului direct din admin** (pentru activări manuale / bonusuri).

### 4. Canal VOCE — lead-uri din apeluri telefonice
Endpoint nou `POST /api/webhooks/voice` (Twilio Voice):
- apelul e întâmpinat **în română** („v-am trimis un SMS și vă răspundem în sub un minut"), apelantul poate lăsa **mesaj vocal** (apare în conversație cu link de redare);
- apelantul devine **lead instant** în inbox (canal „voice"), primește **SMS automat în sub 60s** și de acolo tot motorul existent preia: calificare, programare, follow-up-uri;
- ownerul primește email „Lead nou din apel telefonic";
- în **Canale** există cardul „Telefon / apeluri" cu **„Cere număr de telefon de la Leaply"** — zero pași tehnici pentru client; cererea vine în admin + pe email (provisionezi numărul din Twilio master și setezi Voice webhook-ul).

### 5. API public v1 — integrare cu orice CRM / platformă
- **Autentificare**: cheie per cont `lp_…` (Bearer token). Se generează din **Setări & Plan → API**, se afișează o singură dată, se stochează doar hash SHA-256, se poate regenera/revoca oricând.
- **Endpoints**: `POST/GET /api/v1/leads` (creezi lead-uri din surse proprii — AI-ul preia conversația; listezi cu filtre), `GET /api/v1/conversations` (+ `/{id}` cu toate mesajele), `POST /api/v1/messages` (mesaj manual trimis pe canalul original al lead-ului), `GET /api/v1/stats` (KPI + utilizare plan).
- **Webhook-uri Leaply → exterior** existau deja (lead.created / lead.updated / billing.upgraded, semnate HMAC) — acum sunt documentate.
- **Documentație publică la [leaply.ro/developers](https://leaply.ro/developers)**: autentificare, toate endpoint-urile cu exemple curl + răspunsuri, verificarea semnăturii, limite.

### Verificat local înainte de deploy
ANAF cu CUI-ul real ARHAI (RO35913161 → nume + adresă corecte) ✓ · webhook voce întoarce TwiML valid în română + creează lead ✓ · API v1 respinge cereri fără cheie (401) ✓ · /developers randează ✓ · build production trece ✓.

---

## PARTEA 2 — Audit complet: ce ar mai merita un produs ca Leaply

Ordonat pe impact. ✅ = există deja · 🔶 = parțial · ⬜ = de făcut.

### A. Achiziție & onboarding
| | Element | Stare / recomandare |
|---|---|---|
| ✅ | Funnel demo → wizard cu prefill, import site cu AI, CUI → ANAF | complet |
| ⬜ | **Verificare email la signup** (link de confirmare) | important pentru igiena listei și anti-abuz |
| ⬜ | **Checklist de activare în dashboard** („3 pași până la primul lead": conectează un canal → testează → pune widgetul pe site") | crește dramatic activarea; acum userul trebuie să ghicească următorul pas |
| ⬜ | Widget de chat instalabil pe site-ul clientului (script 1 linie) — azi există doar formularul | canalul cu cea mai mică fricțiune pentru clienții fără social |
| ⬜ | Onboarding email drip (ziua 0/2/5: sfaturi, caz de succes, reminder trial) | Resend e deja configurat, lipsesc doar secvențele |

### B. Produs / AI
| | Element | Stare / recomandare |
|---|---|---|
| ✅ | Calificare + programare + follow-up multi-canal, reguli stricte, knowledge editabil | complet |
| 🔶 | **Voce**: azi apel → SMS + voicemail. Următorul nivel: transcriere voicemail (Whisper) și, ulterior, agent vocal conversațional (ex. Twilio + realtime API) | transcrierea e ieftină și rapidă de adăugat |
| ⬜ | **Detecție limbă** (maghiară în Ardeal, engleză) și răspuns în limba lead-ului | relevant pentru Bihor/Cluj/Harghita |
| ⬜ | Rezumat AI al conversației în inbox + motivul scorului („hot pentru că…") | ajută ownerul să prioritizeze la zeci de lead-uri |
| ⬜ | Reprogramare/anulare self-service pentru lead (link în SMS-ul de confirmare) | reduce no-show-urile |
| ⬜ | Notificare owner pe WhatsApp (nu doar email) când apare lead hot | ownerii SMB trăiesc pe WhatsApp |

### C. Platformă & scalare
| | Element | Stare / recomandare |
|---|---|---|
| ✅ | Multi-tenant, limite plan, admin la scară, API public | complet |
| ⬜ | **Backup automat SQLite** (cron zilnic → copie off-server, ex. S3/R2). Azi baza e doar pe volumul Coolify | risc real de pierdere totală; prioritatea #1 din listă |
| ⬜ | Migrare Postgres când conturile trec de ~200–500 active (SQLite ține, dar write-urile concurente devin risc) | plan, nu urgență |
| ⬜ | Monitoring & alerting (uptime ping + eroare 5xx → email/WhatsApp către tine; Sentry pentru stack traces) | azi afli de la clienți |
| ⬜ | Rate-limiting global pe API-urile publice + logging structurat | protecție abuz |
| ⬜ | Audit log în admin (cine a schimbat ce — mai ales schimbările de plan) | util la dispute |

### D. Monetizare & retenție
| | Element | Stare / recomandare |
|---|---|---|
| ✅ | Stripe self-service + facturi SmartBill automate + limite soft | complet |
| ⬜ | **Customer Portal Stripe** (schimbare card, downgrade, anulare self-service) — un singur API call | reduce suportul |
| ⬜ | Email „ai folosit 80% din plan" cu buton de upgrade (enforcementul există, emailul de vânzare nu) | upgrade-uri naturale |
| ⬜ | Raport săptămânal pe email către client („săptămâna asta: 14 lead-uri, 5 programări, ~7.000 lei salvați") | cel mai puternic instrument anti-churn — clientul VEDE valoarea |
| ⬜ | Plan anual cu discount (2 luni gratis) | cash-flow + retenție |

### E. Legal & conformitate (RO/UE)
| | Element | Stare / recomandare |
|---|---|---|
| ⬜ | **Pagini legale**: Termeni și condiții, Politică de confidențialitate, Cookies + banner consimțământ | obligatorii GDPR înainte de clienți plătitori la scară |
| ⬜ | DPA (acord de prelucrare) pentru clienți — Leaply e procesator al datelor lead-urilor lor | cerut de clienții mai mari |
| ⬜ | Ștergere/export date la cerere (GDPR art. 17/20) — măcar procedură manuală documentată | |
| ⬜ | Badge-uri ANPC (SAL/SOL) în footer | obligatorii legal în RO pentru comercianți online |

### F. Go-to-market (după validare)
- Pagini de vertical cu SEO („asistent AI termopane", „…stomatologie", „…service auto") — landing-ul e generic azi.
- Studii de caz cu primii 2–3 clienți (cifre reale: timp de răspuns, programări).
- Program de recomandare (o lună gratis pentru fiecare client adus).
- App Review Meta (video-urile lui Cătălin) — fără el, conectarea Facebook rămâne doar pentru testeri.

### Ordinea recomandată (următoarele 2 săptămâni)
1. **Backup automat DB** (o oră de lucru, elimină riscul existențial)
2. **Pagini legale + cookie banner** (deblochează vânzarea liniștită)
3. **Checklist activare + widget site** (activare)
4. **Raport săptămânal pe email** (retenție)
5. **App Review Meta** cu Cătălin (deblochează publicul larg pe Messenger/IG)
6. Transcriere voicemail + portal Stripe

---

## Ce mai e de făcut din sesiunile anterioare (reminder)
- Twilio master (SID + token) în Setări platformă — pentru „Cere număr de la Leaply" (WhatsApp și voce).
- CRON_SECRET + Scheduled Task în Coolify (`curl "https://leaply.ro/api/cron/run?key=…"` la 15 min) — pornește follow-up-urile automate.
- Click pe „Conectează Google Calendar" în Setări & Plan (consimțământul tău Google).
